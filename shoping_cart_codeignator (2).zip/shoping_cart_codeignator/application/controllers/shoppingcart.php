<?php

if (!defined('BASEPATH')) exit('No direct script access allowed');

class ShoppingCart extends CI_Controller {

    public function buy($id) {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');


            $this->load->model('mproduct');
            $product = $this->mproduct->find($id);
            $data = array(
                'id' => $product->id,
                'qty' => 1,
                'price' => $product->price,
                'name' => $product->name,
                'category' => $product->category
            );
            $this->cart->insert($data);
            $data['username'] = $session_data['username'];
            redirect('/product');
        }
    }

    public function delete($rowid) {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
        }
        $this->cart->update(array('rowid' => $rowid, 'qty' => 0));
        redirect('/product');
    }

    public function updatecart() {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
        }
        $i = 1;
        foreach ($this->cart->contents() as $items) {
            $this->cart->update(array('rowid' => $items['rowid'], 'qty' => $_POST['qty' . $i]));
            $i++;
        }
        redirect('/product');
    }

}
