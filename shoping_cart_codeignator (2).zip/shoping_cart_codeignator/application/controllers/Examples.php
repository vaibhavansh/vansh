<?php

if (!defined('BASEPATH')) exit('No direct script access allowed');

class Examples extends CI_Controller {

    public function __construct() {
        parent::__construct();

        $this->load->database();
        $this->load->helper('url');

        $this->load->library('grocery_CRUD');
    }

    public function _example_output($output = null) {
        $this->load->view('example.php', (array) $output);
    }

    public function index() {
        $this->_example_output((object) array('output' => '', 'js_files' => array(), 'css_files' => array()));
    }

    public function vendorlist() {
        $crud = new grocery_CRUD();
        $crud->set_table('vendorlist');
        $crud->set_subject('Vendor');
        $crud->unset_delete();
        $output = $crud->render();
        $this->_example_output($output);
    }

    public function productlist() {
        $crud = new grocery_CRUD();
        $crud->set_table('product');
        $crud->set_subject('Product');
        $crud->set_relation('category', 'product_category', 'category_name');
        $crud->unset_delete();
        $output = $crud->render();
        $this->_example_output($output);
    }

    public function categorylist() {
        $crud = new grocery_CRUD();
        $crud->set_table('product_category');
        $crud->set_subject('Category');
        $crud->unset_delete();
        $output = $crud->render();
        $this->_example_output($output);
    }
    
    public function orderlist() {
        $crud = new grocery_CRUD();
        $crud->set_table('orders');
        $crud->set_subject('Order');
        $crud->set_relation('vendor','vendorlist','vendor_name');
        $crud->field_type('status','dropdown',array('1' => 'Active', '2' => 'Rejected'));
        $crud->unset_delete();
        $output = $crud->render();
        $this->_example_output($output);
    }

}
