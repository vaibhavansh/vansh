<?php

if (!defined('BASEPATH')) exit('No direct script access allowed');

include 'dompdf/vendor/autoload.php';

use Dompdf\Dompdf;

class Product extends CI_Controller {

    public function _construct() {
        parent::_construct();
    }

    public function index($index = 0) {

        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
        } else {
            redirect('/login');
        }
        $this->load->model('mproduct');
        $data['orderdata'] = $this->mproduct->findallorder();

        // print_r($data['orderdata']);
        if ($data['orderdata']) {
            foreach ($data['orderdata'] as $key => $value) {
                $orderId[] = $value->orderNumber;
            }
            $data['orderDetils'] = $this->mproduct->findallorderdetails($orderId);
            foreach ($data['orderDetils'] as $key => $value) {
                $data['orderDetailsItems'][$value->orderid][] = $value;
            }
        }

        $data['listProduct'] = $this->mproduct->findall();
        $data['listvendor'] = $this->mproduct->findallvendor();
        $this->load->view('index', $data);
    }

    public function orderplace() {
        if ($this->session->userdata('logged_in') && !empty($_POST)) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
        } else {
            return false;
        }

        
        
        $count = sizeof($_POST['pname']);
        $pname = $_POST['pname'];
        $price = $_POST['price'];
        $subtotal = $_POST['subtotal'];
        $qty = $_POST['qty'];
        $date = date('Y-m-d h:i:s', time());
        $username = $data['username'];
        $category = $_POST['category'];
        $total_amount = $_POST['total_amount'];


        $order = array(
            'orderDate' => $date,
            'vendor' => $_POST['vendorname'],
            'status' => 1,
            'username' => $data['username'],
            'total_amount' => $total_amount,
            'name' => $_POST['customer'],
            'contact' => $_POST['contact']
        );

        $this->db->insert('orders', $order);
        $orderId = $this->db->insert_id();
        for ($i = 0; $i < $count; $i++) {
            $data = array(
                'orderid' => $orderId,
                'pname' => $pname[$i],
                'category' => $category[$i],
                'qty' => $qty[$i],
                'price' => $price[$i],
                'subtotal' => $subtotal[$i],
                'date' => $date,
                'username' => $username
            );
            $this->db->insert('order_details', $data);
        }


        foreach ($this->cart->contents() as $items) {
            $this->cart->update(array('rowid' => $items['rowid'], 'qty' => 0));
        }
        redirect('product');
    }

    function pdf($orderID) {
        if (!$orderID) {
            return false;
        }
        $this->db->select('*');
        $this->db->from('orders');
        $this->db->join('order_details', 'orders.orderNumber = order_details.orderid');
        $this->db->where('orderNumber', $orderID);
        $query = $this->db->get()->result();

        $html = '';
        $html .= '<div>Order No. <span>' . $query[0]->orderNumber . '</span></div>';
        $html .= '<div>Customer Name. <span>' . $query[0]->name . '</span></div>';
        $html .= '<div>Customer Name. <span>' . $query[0]->orderDate . '</span></div>';
        $html .= '<div>Customer Name. <span>' . $query[0]->contact . '</span></div>';
        $html .= '<br>';
        $html .= '<table border="1">';
        $html .= '<tr><th>QTY</th><th>Item Description</th><th>Item Price</th><th>Sub-Total</th></tr>';
        $i = 1;
        foreach ($query as $items) {
            $html .= '<tr>';
            $html .= '<td >' . $items->qty . '</td>';
            $html .= '<td>' . $items->pname . '</td>';
            $html .= '<td>' . $items->price . '</td>';
            $html .= '<td>' . $items->subtotal . '</td>';
            $html .= '</tr>';
            $subtotal[] = $items->subtotal;
            $i++;
        }


        $sub_total = array_sum($subtotal);

        $html .= '<tr>';
        $html .= '<td colspan="2"></td>';
        $html .= '<td>Total</td>';
        $html .= '<td>';
        $html .= $sub_total;
        $html .= '</td>';
        $html .= '</tr>';
        $html .= '</table>';

        $dompdf = new Dompdf();
        $dompdf->loadHtml($html);
        $customPaper = array(-20, 0, 360, 400);
        $dompdf->set_paper($customPaper);
        $dompdf->render();


        $dompdf->stream('my.pdf', array('Attachment' => 0));
    }

}
?>

