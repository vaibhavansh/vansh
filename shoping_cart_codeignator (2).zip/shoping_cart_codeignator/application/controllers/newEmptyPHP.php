
<html>
    <head>
        <title>Cart</title>
        <link href="<?php echo base_url(); ?>themes/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    </head>
    <body>
        <div class="container_fluied">
            <div class="col-lg-6">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Product List
                    </div>
                    <div class="panel-body">
                        <?php
                        $this->load->library('table');
                        $this->table->set_heading('Id', 'Name', 'Price', 'Discription', 'Buy');
                        foreach ($listProduct as $p)
                            $this->table->add_row($p->id, $p->name, $p->price, $p->discription, anchor('shoppingcart/buy/' . $p->id, 'Order Now'));
                        $this->table->set_template(array('table_open' => '<table border="1" class="table table-striped table-bordered table-hover" cellpadding="3" cellspacing="3">'));
                        echo$this->table->generate();
                        ?>
                    </div>
                </div>
            </div>
            <?php echo form_open('shoppingcart/updatecart'); ?>
            <div class="col-lg-6">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Orde Details
                    </div>
                    <!-- /.panel-heading -->
                    <div class="panel-body">
                        <div class="">
                            <table class="table table-striped table-bordered table-hover">
                                <thead>
                                    <tr>
                                    <tr>
                                        <th>Option</th>
                                        <th>QTY</th>
                                        <th>Item Description</th>	
                                        <th style="text-align:right">Item Price</th>
                                        <th style="text-align:right">Sub-Total</th>
                                    </tr>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i = 1; ?>
                                    <?php foreach ($this->cart->contents() as $items): ?>
                                        <?php echo form_hidden($i . '[rowid]', $items['rowid']); ?>
                                    <tbody>
                                        <tr>
                                            <td align="center"><?php echo anchor('shoppingcart/delete/' . $items['rowid'], 'X'); ?></td>
                                            <td><?php echo form_input(array('name' => 'qty' . $i, 'value' => $items['qty'], 'maxlength' => '3', 'size' => '5')); ?></td>
                                            <td><?php echo $items['name']; ?>
                                                <?php if ($this->cart->has_options($items['rowid']) == TRUE): ?>
                                                    <p>
                                                        <?php foreach ($this->cart->product_options($items['rowid']) as $option_name => $option_value): ?>
                                                            <strong><?php echo $option_name; ?>:</strong> <?php echo $option_value; ?><br />
                                                        <?php endforeach; ?>
                                                    </p>
                                                <?php endif; ?>
                                            </td>
                                            <td style="text-align:right"><?php echo $this->cart->format_number($items['price']); ?></td>
                                            <td style="text-align:right">$<?php echo $this->cart->format_number($items['subtotal']); ?></td>
                                        </tr>
                                        <?php $i++; ?>
                                    <?php endforeach; ?>
                                    <tr>
                                        <td colspan="3"></td>
                                        <td class="right" style="text-align:right"><strong>Total</strong></td>
                                        <td class="right" style="text-align:right">$<?php echo $this->cart->format_number($this->cart->total()); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <!-- /.table-responsive -->
                    </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
                <input type="submit" class="btn btn-success update_cart" value="Order Place" style="display: none;">
                <?php echo form_close(); ?>

                <?php echo form_open('product/orderplace'); ?>
                <?php
                $i = 1;
                foreach ($this->cart->contents() as $items):
                    ?>
                    <input type="hidden" name="qty[]" value="<?php echo $items['qty']; ?>">
                    <?php echo form_input(array('name' => 'pname[]', 'type' => 'hidden', 'value' => $items['name'])); ?>
                    <?php echo form_input(array('name' => 'price[]', 'type' => 'hidden', 'value' => $this->cart->format_number($items['price']))); ?>
                    <?php echo form_input(array('name' => 'category[]', 'type' => 'hidden', 'value' => $items['category'])); ?>
                    <?php echo form_input(array('name' => 'subtotal[]', 'type' => 'hidden', 'value' => $this->cart->format_number($items['subtotal']))); ?>
                    <?php $i++; ?>
                    <?php endforeach; ?>
                <select name="vendorname" class="form-control">
                    <?php
                    if (!empty($listvendor)) {
                        foreach ($listvendor as $key => $vendor) {
                            echo '<option value="' . $vendor->Id . '">' . $vendor->vendor_name . '</option>';
                        }
                    }
                    ?>
                </select>
                <br>

                <input type="hidden" name="total_amount" value="<?php echo $this->cart->format_number($this->cart->total()); ?>"><input id="updateOrder" type="button" class="btn btn-info" value="Update Order">
                <input id="placeOrder" type="submit" class="btn btn-success" value="Order Place">
<?php echo form_close(); ?>	



            </div>
            <div class="col-lg-6">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Orde Details
                    </div>
                    <!-- /.panel-heading -->
                    <div class="panel-body">           
                        <table class="table table-striped table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>Option</th>
                                    <th>QTY</th>
                                    <th>Item Description</th>	
                                    <th style="text-align:right">Item Price</th>
                                    <th style="text-align:right">Sub-Total</th>
                                </tr>                     
                            </thead>
                            <tbody>
                                <tr>
                                    <th>Option</th>
                                    <th>QTY</th>
                                    <th>Item Description</th>	
                                    <th style="text-align:right">Item Price</th>
                                    <th style="text-align:right">Sub-Total</th>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <script type="text/javascript" src="<?php echo base_url(); ?>themes/js/jquery.min.js"></script>
        <script type="text/javascript">
            $(document).ready(function () {
                $("#updateOrder").click(function () {
                    $(".update_cart").click();
                });
            });
        </script>
    </body>
</html>	