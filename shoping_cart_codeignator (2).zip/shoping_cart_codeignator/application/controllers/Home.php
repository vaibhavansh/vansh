<?php

if (!defined('BASEPATH')) exit('No direct script access allowed');

class Home extends CI_Controller {

    function __construct() {
        parent::__construct();
    }

    function index() {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $this->load->view('home_view', $data);
        } else {
            //If no session, redirect to login page
            redirect('login', 'refresh');
        }
    }

    public function dbbackup1() {
        $this->load->dbutil();
        $backup = $this->dbutil->backup();
        $this->load->helper('file');
        $todate = "DB_" . date("Y-m-d");
        write_file("/path/to/{$todate}.gz", $backup);
        $this->load->helper('download');
        force_download("{$todate}.gz", $backup);
    }

    public function dbbackup() {


        $this->load->dbutil();
        $backup = $this->dbutil->backup();
        print_r($backup);
        $this->load->helper('file');
        $todate = "DB_" . date("Y-m-d");
        write_file("/path/to/{$todate}.gz", $backup);
        $this->load->helper('download');
        force_download("{$todate}.gz", $backup);
    }

    function logout() {
        $this->session->unset_userdata('logged_in');
        redirect('login', 'refresh');
    }

}

?>