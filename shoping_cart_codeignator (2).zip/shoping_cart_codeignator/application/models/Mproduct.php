<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Mproduct extends CI_Model {

	public function _construct(){		
		parent::_construct();		
	}

	function findall(){		
		$this->db->join('product_category', 'product.category = product_category.Id');
		return  $this->db->get('product')->result();
	}
		
	function find($id){	
		$this->db->where('id',$id);
		return  $this->db->get('product')->row();
	}

	function findallvendor(){		
		return  $this->db->get('vendorlist')->result();
	}

	function findbyvendor($id){	
		$this->db->where('category',$id);
		return  $this->db->get('vendorlist')->result();
	}

	function findallorder(){	
		$this->db->select('*');
		$this->db->from('orders');
		$this->db->join('vendorlist', 'orders.vendor = vendorlist.Id');
		$this->db->like('orderDate', date('Y-m-d'), 'both'); 
		$this->db->order_by('orderNumber', 'DESC');
		return $query = $this->db->get()->result();
	}

	function findallorderdetails($orderId){	
		if(!$orderId){
			return false;
		}

		$this->db->select('*');
		$this->db->from('order_details');
		$this->db->join('product_category', 'order_details.category = product_category.Id');
		
		$this->db->where_in('orderid', $orderId);
		
		return $query = $this->db->get()->result();
	}


	
	
	function P_Insert($img_path){	
	    $data = array(
			'name' => $this->input->post('p_name'),
			'price' => $this->input->post('p_price'),
			'quantity' => $this->input->post('p_quantity'),
			'discription' => $this->input->post('p_desc'),
			'image' => 'uploads/'.$img_path['file_name']
		);
		$this->db->insert('product', $data);
	}	
	
}

