<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 <link href="http://localhost/shoping_cart_codeignator/dist/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
	<div class="page-header">
		<h1>Product Register</h1>
	</div>
	
	<div class="row">
		<div class="col-sm-4">       
			<div class="panel panel-default">
				<div class="panel-heading">Panel with panel-default class</div>
					<div class="panel-body">
						<p class="bg-danger"><?php echo $error;?> </p>	
						<?php echo form_open_multipart('P_registration/do_upload');?>
							<div class="form-group">				
								<input type="text" name="p_name" class="form-control" id="usr" placeholder="Product Name">
							</div>
							<div class="form-group">				
								<input type="text" name="p_price" class="form-control" id="usr" placeholder="Product Price">
							</div>
							<div class="form-group">				
								<input type="text" name="p_quantity" class="form-control" id="usr" placeholder="Quantity">
							</div>
							<div class="form-group">				
								<input type="text" name="p_desc" class="form-control" id="usr" placeholder="Discription">
							</div>
							<input type="file" name="userfile" size="20" required /></br>
							<input type="submit" value="upload" />
						</form>	
					</div>
				</div>
			</div>
			<div class="col-sm-8 ">
			<div class="panel panel-default">
                        <div class="panel-heading">
                            Kitchen Sink
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>Image</th>
                                            <th>Product Name</th>
                                            <th>Price</th>
                                            <th>Quantity</th>											
                                            <th>Discription</th>											
                                            <th>#</th>
                                        </tr>
                                    </thead>
                                    <tbody>
									<?php foreach($listProduct as $p){?>
                                        <tr>
                                            <td><img src="../<?php echo $p->image;?>" width="50" height="50"/></td>
                                            <td><?php echo $p->name;?></td>
                                            <td><?php echo $p->price;?></td>
                                            <td><?php echo $p->quantity;?></td>                                           
                                            <td><?php echo $p->discription;?></td>                                           
                                            <td><?php echo anchor('shoppingcart/buy/'.$p->id,'Order Now');?></td>
										</tr>
									<?php  } ?>	
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
				
			<?php
	

	$this->table->add_row($p->id,$p->name,$p->price,$p->quantity,$p->discription, anchor('shoppingcart/buy/'.$p->id,'Order Now'));
		

?>
		</div>
		</div>
		
		
</div>

</body>
</html>
