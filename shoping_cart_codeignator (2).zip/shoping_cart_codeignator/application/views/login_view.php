
<body>
	
        <form class="center" role="form" action="<?php echo base_url();?>index.php/verifylogin" method="POST">
            <fieldset class="registration-form" >
			 <?php echo validation_errors(); ?>
                <div class="form-group">
                    <input type="text" id="username" name="username" placeholder="Username" class="form-control" name="username">
					
                </div>
               
                <div class="form-group">
                    <input type="password" id="password" name="password" placeholder="Password" class="form-control" name="password">
                </div>
             
                <div class="form-group">
                    <button type="submit" class="btn btn-success btn-md btn-block">Register</button>
                </div>
            </fieldset>
        </form>

</body>
</html>
