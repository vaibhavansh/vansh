
<html>
    <head>
    <title>Cart</title>
    <link href="<?php echo base_url(); ?>themes/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    </head>
    <body>
         <h2>Welcome <?php echo $username; ?>!</h2>

   
   <a href="home/logout">Logout</a>
        <div class="container_fluied">
           
            
            <div class="col-lg-6">
            
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Product List
                    </div>
                    <div class="panel-body">
                        <?php
                        $this->load->library('table');
                        $this->table->set_heading('Id', 'Name', 'Price','Cartategory', 'Discription', 'Buy');
                        foreach ($listProduct as $p)
                            $this->table->add_row($p->id, $p->name, $p->price, $p->category_name, $p->discription, anchor('shoppingcart/buy/' . $p->id, 'Order Now'));
                        $this->table->set_template(array('table_open' => '<table border="1" class="table table-striped table-bordered table-hover" cellpadding="3" cellspacing="3">'));
                        echo$this->table->generate();
                        ?>
                    </div>
                </div>
            </div>
            <?php echo form_open('shoppingcart/updatecart'); ?>
            <div class="col-lg-6">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Orde Details
                    </div>
                    <!-- /.panel-heading -->
                    <div class="panel-body">
                        <div class="">
                            <table class="table table-striped table-bordered table-hover">
                                <thead>
                                    <tr>
                                    <tr>
                                        <th>Option</th>
                                        <th>QTY</th>
                                        <th>Item Description</th>	
                                        <th style="text-align:right">Item Price</th>
                                        <th style="text-align:right">Sub-Total</th>
                                    </tr>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i = 1; ?>
                                    <?php foreach ($this->cart->contents() as $items): ?>
                                        <?php echo form_hidden($i . '[rowid]', $items['rowid']); ?>
                                    <tbody>
                                        <tr>
                                            <td align="center"><?php echo anchor('shoppingcart/delete/' . $items['rowid'], 'X'); ?></td>
                                            <td><?php echo form_input(array('name' => 'qty' . $i, 'value' => $items['qty'], 'maxlength' => '3', 'size' => '5')); ?></td>
                                            <td><?php echo $items['name']; ?>
                                                <?php if ($this->cart->has_options($items['rowid']) == TRUE): ?>
                                                    <p>
                                                        <?php foreach ($this->cart->product_options($items['rowid']) as $option_name => $option_value): ?>
                                                            <strong><?php echo $option_name; ?>:</strong> <?php echo $option_value; ?><br />
                                                        <?php endforeach; ?>
                                                    </p>
                                                <?php endif; ?>
                                            </td>
                                            <td style="text-align:right"><?php echo $this->cart->format_number($items['price']); ?></td>
                                            <td style="text-align:right">$<?php echo $this->cart->format_number($items['subtotal']); ?></td>
                                        </tr>
                                        <?php $i++; ?>
                                    <?php endforeach; ?>
                                    <tr>
                                        <td colspan="3"></td>
                                        <td class="right" style="text-align:right"><strong>Total</strong></td>
                                        <td class="right" style="text-align:right">$<?php echo $this->cart->format_number($this->cart->total()); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <!-- /.table-responsive -->
                    </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
                <input type="submit" class="btn btn-success update_cart" value="Order Place" style="display: none;">
                <?php echo form_close(); ?>

                <?php echo form_open('product/orderplace'); ?>
                <?php
                $i = 1;
                foreach ($this->cart->contents() as $items):
                    ?>
                    <input type="hidden" name="qty[]" value="<?php echo $items['qty']; ?>">
                    <?php echo form_input(array('name' => 'pname[]', 'type' => 'hidden', 'value' => $items['name'])); ?>
                    <?php echo form_input(array('name' => 'price[]', 'type' => 'hidden', 'value' => $this->cart->format_number($items['price']))); ?>
                    <?php echo form_input(array('name' => 'category[]', 'type' => 'hidden', 'value' => $items['category'])); ?>
                    <?php echo form_input(array('name' => 'subtotal[]', 'type' => 'hidden', 'value' => $this->cart->format_number($items['subtotal']))); ?>
                    <?php $i++; ?>
                    <?php endforeach; ?>
                    <label>Vendor</label>
                    <select name="vendorname" class="form-control">
                    <?php
                    if (!empty($listvendor)) {
                        foreach ($listvendor as $key => $vendor) {
                            echo '<option value="' . $vendor->Id . '">' . $vendor->vendor_name . '</option>';
                        }
                    }
                    ?>
                    </select>
                    <label>Customer Name</label>
                    <input type="text" name="customer" class="form-control" placeholder="Customer Name" required="">
                    <label>Contact Number</label>
                    <input type="text" name="contact" class="form-control" placeholder="Contact Number">
                     <?php echo validation_errors(); ?>
                <br>
                <input type="hidden" name="total_amount" value="<?php echo $this->cart->format_number($this->cart->total()); ?>"><input id="updateOrder" type="button" class="btn btn-info" value="Update Order">
                <?php  if(empty($this->cart->contents())){ $disabled = 'disabled'; }else{ $disabled = ''; } ?>
                <input id="placeOrder" type="submit" class="btn btn-success" value="Order Place" <?php echo $disabled; ?>>
<?php echo form_close(); ?>	
            </div>
            <?php if($orderdata){ ?>
            <div class="col-lg-6">
                <div class="panel panel-default">
                   <!--  <div class="panel-heading">
                        Orde Details
                    </div> -->
                    <!-- /.panel-heading -->
                    <!-- <div class="panel-body">            -->
                        <table class="table table-striped table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>OrderNo.</th>
                                    <th>OrerDate</th>
                                    <th>Store</th>	
                                    <!--<th>status</th>-->	
                                    <th>total_amount</th>
                                    <th>#</th>	
                                   
                                </tr>                     
                            </thead>
                            <tbody>
                            <?php 
                            foreach ($orderdata as $order_key => $order): ?>
								<tr>
                                    <td><?php echo $order->orderNumber;?></td>
                                    <td><?php echo $order->orderDate;?></td>
                                    <td><?php echo $order->vendor_name;?></td>
                                    <!--<td><?php echo $order->status;?></td>-->
                                    <td><?php echo $order->total_amount;?></td>
                                    <td><a id="myBtn<?php echo $order->orderNumber;?>">view</a> | <a href="<?php echo base_url(); ?>index.php/product/pdf/<?php echo $order->orderNumber;?>" target="_blank">Print</a></td>               
                                    
                                </tr>
                            <?php endforeach; ?>
                                
                            </tbody>
                        </table>
                 <!--    </div> -->
                </div>
            </div>
        <?php  } ?>
        </div>
        <script type="text/javascript" src="<?php echo base_url(); ?>themes/js/jquery.min.js"></script>

        <script type="text/javascript" src="<?php echo base_url(); ?>themes/js/bootstrap.min.js"></script>

        <script type="text/javascript">
            $(document).ready(function () {
                $("#updateOrder").click(function () {
                    $(".update_cart").click();
                });
            });
        </script>

    </body>
</html>	


<!-- Modal -->

<?php if(!empty($orderDetailsItems)) { ?>
<?php foreach ($orderDetailsItems as $key => $orderDetailsItemsvalues) : ?>

<div class="modal fade" id="myModal<?php echo $key; ?>" role="dialog">
    <div class="modal-dialog">    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Modal Header</h4>
        </div>
        <div class="modal-body">
          <p>
           <table class="table table-striped table-bordered table-hover">
          	<tr>
          		<td>Items</td>
          		<td>Qty</td>
          		<td>Category</td>
          		<td>Price</td>
          		<td>Amount</td>
          		
          	</tr>
          	<?php foreach ($orderDetailsItemsvalues as $orderDetailsItemsvalue) : ?>
          	<tr>
          		<td><?php echo $orderDetailsItemsvalue->pname; ?></td>
          		<td><?php echo $orderDetailsItemsvalue->qty; ?></td>
          		<td><?php echo $orderDetailsItemsvalue->category_name; ?></td>
          		<td><?php echo $orderDetailsItemsvalue->price; ?></td>
          		<td><?php echo $orderDetailsItemsvalue->subtotal; ?></td>
          	</tr>
          	<?php endforeach; ?>
          </table>
          </p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>      
    </div>
</div>
 <script>
$(document).ready(function(){
    $("#myBtn<?php echo $key; ?>").click(function(){
        $("#myModal<?php echo $key; ?>").modal();
    });
});
</script>

<?php endforeach; ?>
<?php  } ?>