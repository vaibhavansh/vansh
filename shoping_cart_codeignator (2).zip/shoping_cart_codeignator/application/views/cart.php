<html>
<head>
<title>Cart</title>
<link href="http://localhost/shoping_cart_codeignator/dist/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div class="container">

<div class="col-lg-12">
                    <h1 class="page-header">Shoping Cart Information</h1>
                </div>

<?php echo form_open('shoppingcart/updatecart');
echo $username;
?>


<div class="col-lg-6">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                           Selected Product
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <tr>
												<th>Option</th>
												<th>QTY</th>
												<th>Item Description</th>	
												<th style="text-align:right">Item Price</th>
												<th style="text-align:right">Sub-Total</th>
											</tr>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $i = 1; ?>

<?php foreach ($this->cart->contents() as $items): ?>

	<?php echo form_hidden($i.'[rowid]', $items['rowid']); ?>
<tbody>
	<tr>
	<td align="center"><?php echo anchor('shoppingcart/delete/'.$items['rowid'],'X');?></td>
	  <td><?php echo form_input(array('name' => 'qty'.$i, 'value' => $items['qty'], 'maxlength' => '3', 'size' => '5')); ?></td>
	  <td>
		<?php echo $items['name']; ?>

			<?php if ($this->cart->has_options($items['rowid']) == TRUE): ?>

				<p>
					<?php foreach ($this->cart->product_options($items['rowid']) as $option_name => $option_value): ?>

						<strong><?php echo $option_name; ?>:</strong> <?php echo $option_value; ?><br />

					<?php endforeach; ?>
				</p>

			<?php endif; ?>

	  </td>
	  <td style="text-align:right"><?php echo $this->cart->format_number($items['price']); ?></td>
	  <td style="text-align:right">$<?php echo $this->cart->format_number($items['subtotal']); ?></td>
	</tr>

<?php $i++; ?>

<?php endforeach; ?>

<tr>
  <td colspan="3"></td>
  <td class="right"><strong>Total</strong></td>
  <td class="right">$<?php echo $this->cart->format_number($this->cart->total()); ?></td>
</tr>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
					
					<?php echo anchor('product','<< continue Shopoing','class="btn btn-info"');?>
					
					<?php echo form_submit('', 'Update your Cart','class="btn btn-info"'); ?> 
					
					<?php echo anchor('product','Buy Now','class="btn btn-info"');?>
					<?php echo form_close();?>
                </div>

<?php echo form_open('welcome');?>
<?php
$i = 1; 
foreach ($this->cart->contents() as $items):

?>
<input type="hidden" name="qty[]" value="<?php echo $items['qty'];?>">

<?php echo form_input(array('name' => 'pname[]', 'value' => $items['name'])); ?>
<?php echo form_input(array('name' => 'price[]', 'value' =>  $this->cart->format_number($items['price']))); ?>
<?php echo form_input(array('name' => 'subtotal[]', 'value' => $this->cart->format_number($items['subtotal']))); ?>

<?php $i++; ?>

<?php echo "</br>"; endforeach; ?>
<?php echo form_submit('', 'parches','class="btn btn-info"'); ?> 

<?php echo form_close();?>			



</div>
<!--- container--->
</body>
</html>	