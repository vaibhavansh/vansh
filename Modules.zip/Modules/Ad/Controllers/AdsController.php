<?php

class Ad_Controllers_AdsController extends Core_Controllers_SitesController
{
function displayAd($id){
    
    $ads = Ad_Models_Ad::find_all(array('where' => "id='{$id}'"));
     $variables['ads'] = $ads;
    return $variables;  
   //return array();
}

}

