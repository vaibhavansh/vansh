<?php

class Ad_Models_Ad extends Core_Models_DbTable
{

    static $table = 'ads';

    static $fields = null;


}

