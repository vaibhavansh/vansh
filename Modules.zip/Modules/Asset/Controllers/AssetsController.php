<?php

class Asset_Controllers_AssetsController extends Core_Controllers_SitesController {

    var $layoutId = 42;

    /**
     * View The Asset
     * IT shows the title/subtitle/body for asset.
     * @param type $id
     * @return Asset_Models_Asset
     * 
     *  
     */
    public function listAssetType() {
        global $page;
        $tags = func_get_args();
        $userId = $page->currentUser->id;
        $recordsPerPage = '';
        /* Get Asset Type */
        if ($tags[0] == 'upcomingholidays') {
            $tagname = $tags[0];
            $tags[0] = 'holidays';
        }
        $assetType = Asset_Models_AssetType::getAssetTypeBySlug(array_shift($tags));
        /* Show Assets According To List and Edit */
        $arrayPop = array_pop($tags);
        if ($arrayPop === 'list') {
            if (!empty($assetType->list_view))
                $variables['view'] = $assetType->list_view;
            if (!empty($assetType->edit_view))
                $variables['addform'] = Layout_Models_Layout::getWidget('Asset_Controllers_AssetsController', 'edit', $assetType->edit_view);
        } else if (strpos($arrayPop, 'limit_') !== false) {
            $variables['recordsPerPage'] = $arrayPop;
            $recordsPerPage = str_replace('limit_', '', $variables['recordsPerPage']);
        }
        $variables['pageNumber'] = array_pop($tags);
        if (!(substr($variables['pageNumber'], 0, 5) == 'page_')) {
            $tags[] = $variables['pageNumber'];
            $variables['pageNumber'] = 'page_1';
        }
        $where = '';
        if (in_array($assetType->id, Asset_Models_Asset::$userSpecificAssets)) { #show notes and bookmarks only to users . Fix this later.
            $where .= " and uploaded_by={$userId} ";
        }
        if ($assetType->slug == 'holidays') {
            if (isset($tagname) && $tagname == 'upcomingholidays') {
                $where .= "and release_date >= '" . date('Y-m-d') . "'";
            }
            $orderBy = 'release_date ASC';
        } else {
            $orderBy = 'assets.id DESC';
        }
        if (isset($_POST['searchTitle'])) {
            $variables['searchTitle'] = (trim(str_replace(array('/', '.'), '', ($_POST['searchTitle']))));
            $where .= " AND title like ('%" . $variables['searchTitle'] . "%') ";
        }
        $join = '';
        if (in_array($assetType->id, array(9, 11)) && $page->currentUser->webUserRole == 1) {
            $where .= ' AND asset_users.user_id="' . $userId . '" ';
            $join .= ' join asset_users on assets.id=asset_users.asset_id ';
        }
        if (in_array($assetType->id, array(6))) {
            $draftids = Asset_Models_Asset::find_all(array(
                        'where' => "asset_type_id = {$assetType->id}  AND  assets.published='2' And assets.uploaded_by != {$userId}",
                        'cols' => "id, uploaded_by"
            ));
            if (!empty($draftids)) {
                foreach ($draftids as $draftid) {
                    $did[] = $draftid->id;
                }
                $implodedid = implode(",", $did);
                $where .= ' AND assets.id Not IN (' . $implodedid . ') ';
            }
        }
        if ($assetType->slug == 'news_feed') {
            $join .= 'Left join asset_images on asset_images.asset_id = assets.id';
            $coloum = ", asset_images.image_id as image, asset_images.id as assetimageId";
        }

        $cols = !empty($coloum) ? $coloum : '';
        $paginatedContent = Asset_Models_Asset::getPaginatedData(array('where' => "asset_type_id = {$assetType->id} AND assets.status!='2' " . $where,
                    'join' => " users on users.id=assets.uploaded_by " . $join,
                    'pageNumber' => $variables['pageNumber'], 'recordsPerPage' => $recordsPerPage, 'orderBy' => $orderBy,
                    'cols' => " assets.*,concat(users.name,' ',users.lastname) as uploaderName ,users.image as uploaderImage $cols "
        ));
        $variables['list'] = $paginatedContent;
        $variables['assetType'] = $assetType;
        $variables['header'] = $variables['assetType']->title;
        return $variables;
    }

    function duecards() {
        global $page;
        $variables['duecards'] = Asset_Models_AssetUser::find_all(array(
                    'where' => "asset_users.user_id = {$page->currentUser->id} AND assets.asset_type_id=11 AND Status = 1  And assets.release_date > '" . date('Y-m-d') . "'",
                    'orderBy' => 'assets.release_date DESC',
                    'join' => 'assets on assets.id=asset_users.asset_id',
                    'limit' => '5'));
        $variables['title'] = "Due Cards";
        return $variables;
    }

    public function listChildAssetType() {
        global $page;
        $tags = func_get_args();
        $userId = $page->currentUser->id;
        $recordsPerPage = '';
        $list_cards = array();
        /* Get Asset Type */
        $assetType = Asset_Models_AssetType::getAssetTypeBySlug(array_shift($tags));
        /* Show Assets According To List and Edit */
        $parent_id = $where = '';
        if ($assetType->child_of != 0) {
            $parent_id = array_shift($tags);
            $variables['parent_data'] = new Asset_Models_Asset($parent_id);
            if (isset($_POST['searchTitlechild'])) {
                $variables['searchTitlechild'] = (trim(str_replace(array('/', '.', '"', ';', "'"), '', htmlspecialchars($_POST['searchTitlechild']))));
                $where .= " AND title like ('%" . $variables['searchTitlechild'] . "%') ";
            }
            $AssociatedIDs = $AssociatedId = '';
            $Associated_data = Asset_Models_AssetAsset::find_all(array('where' => "asset_id='{$parent_id}'"));
            if (!empty($Associated_data)) {
                foreach ($Associated_data as $Associated) {
                    $AssociatedId[] = $Associated->associated_asset_id;
                    $subwhere = $subjoin = '';
                    if ($page->currentUser->webUserRole == 1) {
                        $subwhere .= ' AND asset_users.user_id="' . $userId . '" ';
                        $subjoin .= ' asset_users on asset_assets.associated_asset_id=asset_users.asset_id ';
                    }
                    $child_level2 = Asset_Models_AssetAsset::find_all(array('where' => "asset_assets.asset_id='{$Associated->associated_asset_id}' " . $subwhere, 'join' => $subjoin));
                    if (!empty($child_level2)) {
                        $cards = array();
                        foreach ($child_level2 as $child) {
                            $cards[] = $child->associated_asset_id;
                        }
                        $cardsIDs = implode(',', $cards);
                        $list_cards[$Associated->associated_asset_id] = Asset_Models_Asset::find_all(array('where' => "assets.id in ({$cardsIDs}) $where",
                                'leftjoin'=>'asset_estimate_times on asset_estimate_times.asset_id = assets.id AND asset_estimate_times.estimated_by='.$userId,
                                  'cols'=>'assets.*,asset_estimate_times.estimated_by as estimated_by',
                                'orderBy' => 'priority ASC'));
                    }
                }
                $AssociatedIDs = implode(',', $AssociatedId);
            }
             $variables['ListCards'] = $list_cards;
            if (!empty($AssociatedIDs))
                $where = " AND assets.id in({$AssociatedIDs}) ";
            else
                $where = " AND assets.id=0 ";
            $variables['parent_id'] = $parent_id;
            $variables['addChildform'] = Layout_Models_Layout::getWidget('Asset_Controllers_AssetsController', 'editChild', $assetType->edit_view, $parent_id);
            if ($page->currentUser->webUserRole == 1) {
                if (in_array($variables['parent_data']->asset_type_id, array(9, 11))) {
                    $IsAssignUser = Asset_Models_AssetUser::find_all(array('where' => ' asset_id="' . $parent_id . '" AND user_id="' . $userId . '"'));
                    if (empty($IsAssignUser)) {
                        $variables['restrict'] = true;
                    }
                }
            }
        }
        $variables['AssignedUsers'] = Layout_Models_Layout::getWidget('Asset_Controllers_AssetsController', 'assetuserlist', 'asset_users_list', $parent_id);
        $arrayPop = array_pop($tags);
        if ($arrayPop === 'list') {
            if (!empty($assetType->list_view))
                $variables['view'] = $assetType->list_view;
            if (!empty($assetType->edit_view))
                $variables['addform'] = Layout_Models_Layout::getWidget('Asset_Controllers_AssetsController', 'edit', $assetType->edit_view);
        } else if (strpos($arrayPop, 'limit_') !== false) {
            $variables['recordsPerPage'] = $arrayPop;
            $recordsPerPage = str_replace('limit_', '', $variables['recordsPerPage']);
        }
        $variables['pageNumber'] = array_pop($tags);
        if (!(substr($variables['pageNumber'], 0, 5) == 'page_')) {
            $tags[] = $variables['pageNumber'];
            $variables['pageNumber'] = 'page_1';
        }
        if (in_array($assetType->id, Asset_Models_Asset::$userSpecificAssets)) { #show notes and bookmarks only to users . Fix this later.
            $where .= " and uploaded_by={$userId} ";
        }
        if ($assetType->slug == 'holidays') {
            $orderBy = 'release_date ASC';
        } else {
            $orderBy = 'assets.id DESC';
        }
        if (isset($_POST['searchTitle'])) {
            $variables['searchTitle'] = (trim(str_replace(array('/', '.'), '', ($_POST['searchTitle']))));
            $where .= " AND title like ('%" . $variables['searchTitle'] . "%') ";
        }
        if (!empty($orderBy))
            $orderBy = 'priority ASC,' . $orderBy;
        else
            $orderBy = 'priority ASC';
        $paginatedContent = Asset_Models_Asset::getPaginatedData(array('where' => " asset_type_id = {$assetType->id} AND assets.status!='2'" . $where,
                    'join' => " users on users.id=assets.uploaded_by",
                    'pageNumber' => $variables['pageNumber'], 'recordsPerPage' => $recordsPerPage, 'orderBy' => $orderBy,
                    'cols' => " assets.*,concat(users.name,' ',users.lastname) as uploaderName ,users.image as uploaderImage"
        ));
        $variables['list'] = $paginatedContent;
        $variables['assetType'] = $assetType;
        $variables['header'] = $variables['assetType']->title;
        return $variables;
    }

    public function archiveitem($id = '') {
        if (!empty($id)) {
            $assetObj = new Asset_Models_Asset($id);
            $assetObj->save(array('status' => '2'));
            unset($assetObj);
        }
        return array();
    }

    public function sortorder() {
        if (isset($_POST['ordertype']) && $_POST['ordertype'] == 'projectlist' && !empty($_POST['order'])) {
            foreach ($_POST['order'] as $key => $order) {
                $assetObj = new Asset_Models_Asset($order);
                $assetObj->save(array('priority' => $key));
                unset($assetObj);
            }
        } else if (isset($_POST['ordertype']) && $_POST['ordertype'] == 'listcard' && !empty($_POST['order'])) {
            foreach ($_POST['order'] as $lkey => $order) {
                foreach ($order as $ckey => $card) {
                    if (isset($_POST['list']) && !empty($_POST['list'][$lkey])) {
                        $list_id = $_POST['list'][$lkey];
                        $assetsasset = array_shift(Asset_Models_AssetAsset::find_all(array('where' => " associated_asset_id ='{$card}' ", 'limit' => '1')));
                        if ($assetsasset->asset_id != $list_id) {
                            global $page;
                            $assetObj = new Asset_Models_Asset($assetsasset->associated_asset_id);
                            $html = serialize(array('Tickets' => $assetObj->id));
                            $AssignUsers = Asset_Models_AssetUser::find_all(array('where' => ' asset_id="' . $assetObj->id . '"'));
                            $assignUsersArray = array();
                            foreach ($AssignUsers as $AssignUser) {
                                $assignUsersArray[] = array('id' => $AssignUser->user_id);
                            }
                            Notification_Models_Notification::AddNotifications($page->currentUser->id, $assetObj->title, 'Move Card', $assignUsersArray, $html);
                            $assetsAssetObj = new Asset_Models_AssetAsset($assetsasset->id);
                            $assetsAssetObj->save(array('asset_id' => $list_id));
                            unset($assetsAssetObj);
                        }
                    }
                    $assetObj = new Asset_Models_Asset($card);
                    $assetObj->save(array('priority' => $ckey));
                    unset($assetObj);
                }
            }
        }
        return array();
    }

    public function save() {
        $arrayPrm = func_get_args();
        $edit_id = $asset_id = (!empty($arrayPrm)) ? $arrayPrm[0] : '';
        $assetObj = new Asset_Models_Asset($asset_id);
        $oldassetObj = clone $assetObj;
        if (!empty($_POST)) {
            
            if($assetObj->asset_type_id==9)
            {
                if(isset($_POST['priority']) && $_POST['priority']=='on')
                {
                    $_POST['priority']='2';
                }else
                {
                    $_POST['priority']='0';
                }
            }
            global $page;
            if ($page->currentUser->userLoggedIn) {
                $userId = $page->currentUser->id;
                $_POST['uploaded_by'] = $userId;
            }
            if (isset($_POST['title'])) {
                $_POST['title'] = strip_tags(preg_replace("/<([a-z][a-z0-9]*)[^>]*?(\/?)>/i", '<$1$2>', $_POST['title']));
            }
            if (isset($_POST['asset_type_id'])) {
                $checkunivarsal = Asset_Models_Asset::find_all(array('where' => "asset_type_id = {$_POST['asset_type_id']} and uploaded_by = {$userId}"));
                switch ($_POST['asset_type_id']) {

                    case '2': //Bookmarks  
                        $urls = array();
                        if (!empty($checkunivarsal)) {
                            foreach ($checkunivarsal as $checkbookmarkurl) {
                                $urls[] = $checkbookmarkurl->url;
                            }
                        }
                        if (!empty($_POST['url'])) {
                            if (in_array($_POST['url'], $urls)) {
                                echo json_encode(array('status' => 'unsuccess', 'msg' => "Bookmark already exist."));
                                return array();
                            }
                        }
                        break;

                    case '3': //RSS                 
                        if (isset($_POST['url'])) {
                            $rss = @simplexml_load_file($_POST['url']);
                            if (!$rss) {
                                echo json_encode(array('status' => 'unsuccess', 'msg' => " RSS not valid. "));
                                return array();
                            }
                            $rssassetId = array_shift($checkunivarsal);
                            $assetid = !empty($rssassetId->id) ? $rssassetId->id : '';
                            $assetObj = new Asset_Models_Asset($assetid);
                            $asset_id = $assetObj->save($_POST);
                            $feedlist = new Rss($_POST['url']);
                            echo $feedlist->display(5, "");
                            return array();
                        }
                        break;

                    case '8': //ipaddress 
                        $ip = $_POST['description'];
                        if (filter_var($ip, FILTER_VALIDATE_IP) === false) {
                            echo json_encode(array('status' => 'unsuccess', 'msg' => "$ip is not a valid IP address"));
                            return array();
                        }
                        break;
                }
            }
            if (isset($_POST['listcard'])) {
                $id = array_shift(Asset_Models_AssetAsset::find_all(array('where' => "asset_assets.associated_asset_id = {$_POST['cardId']}")));
                $listfind = !empty($id) ? new Asset_Models_AssetAsset($id->id) : '';
                $listfind->save(array('asset_id' => $_POST['listcard']));
                echo "<script>setTimeout(function () {
                    reloadDiv('" . $_POST['reloadUrl'] . "', 'mainContent', 'ajax');
                }, 100);</script>";
                return array();
            }
            ob_start();
            $asset_id = $assetObj->save($_POST);
            ob_end_clean();
            if ($assetObj->asset_type_id == '11' && $oldassetObj->release_date != $assetObj->release_date) {
                $html = serialize(array('Tickets' => $assetObj->id));
                $AssignUsers = Asset_Models_AssetUser::find_all(array('where' => ' asset_id="' . $assetObj->id . '"'));
                $assignUsersArray = array();
                foreach ($AssignUsers as $AssignUser) {
                    $assignUsersArray[] = array('id' => $AssignUser->user_id);
                }
                Notification_Models_Notification::AddNotifications($page->currentUser->id, $assetObj->title, 'Change Due Date', $assignUsersArray, $html);
            } else if ($assetObj->asset_type_id == '7') {
                $newGroup = array_shift(Form_Models_FormGroup::find_all(array('where' => "forms.link_form = 'company-docs'",
                            'join' => "forms on forms.id = form_groups.form_id",
                            'cols' => "form_groups.*")));
                if (!empty($newGroup)) {
                    $newfield = new Form_Models_FormGroupField();
                    $newfield->save(array('field_title' => $_POST['title'], 'fieldType' => 'file', 'field_key' => strtolower(str_replace(' ', '_', $_POST['title'])), 'option_data' => $asset_id, 'group_id' => $newGroup->id, 'priority' => $asset_id,));
                }
            }
            if (!empty($_POST['asset_parent_id'])) {
                $assetAssetsid = '';
                $assetAssetsData = array_shift(Asset_Models_AssetAsset::find_all(array('where' => ' associated_asset_id="' . $asset_id . '" AND asset_id="' . $_POST['asset_parent_id'] . '" ')));
                if (!empty($assetAssetsData))
                    $assetAssetsid = $assetAssetsData->id;

                $assetAssetsObj = new Asset_Models_AssetAsset($assetAssetsid);
                $assetAssetsid = $assetAssetsObj->save(array('asset_id' => $_POST['asset_parent_id'], 'associated_asset_id' => $asset_id));
            }
            
            /* if (isset($_POST['asset_users'])) {
              foreach ($_POST['asset_users'] as $assignUser) {
              $assetAssetsObj = new Asset_Models_AssetUser();
              $assetAssetsid = $assetAssetsObj->save(array('asset_id' => $_POST['asset_id'], 'user_id' => $assignUser));
              }
              } */
            if (!empty($_FILES['attachments']['tmp_name'])) {
                $assetObj->saveAssetImages($_FILES['attachments']['tmp_name']);
                if (isset($_POST['formType']) && $_POST['formType'] == 'showresult') {
                    if ('11' == $_POST['asset_type_id']) {
                        /* Show Asset Images Section */
                        echo Layout_Models_Layout::getWidget('Asset_Controllers_AssetsController', 'assetImage', 'assetImage', $asset_id);
                    }
                    return array();
                }
            }
            if ($edit_id == '' && isset($_POST['formType']) && $_POST['formType'] == 'append') {
                if ('11' == $assetObj->asset_type_id || $assetObj->asset_type_id == '15') {
                    if ($page->currentUser->webUserRole == 1) {
                        $assetAssetsObj = new Asset_Models_AssetUser();
                        $assetAssetsid = $assetAssetsObj->save(array('asset_id' => $asset_id, 'user_id' => $userId));
                    }
                    ?>
                    <li class="task-item success" card-id="<?php echo $assetObj->id; ?>" card-order="<?php echo $assetObj->priority; ?>">
                        <div class="task-handle"></div>
                        <div class="task-desc new-desc"><a href="/viewticket/<?php echo $assetObj->id; ?>/" card-id="<?php echo $assetObj->id; ?>" class="card card<?php echo $assetObj->id; ?>" rel="popUpBoxHR" ><?php echo $assetObj->title; ?></a></div>
                       <?php /*if($assetObj->asset_type_id == '11'){ ?>
                        <div class="task-play">
                            <a class="start-timer-btn link" title="Start Timer"><span class="fa fa-play"></span></a>
                            <a class="remove-timer-btn hidden link" title="Stop & Save Timer"><span class="fa fa-stop"></span></a>
                        </div>
                       <?php  }*/ ?>
                        <div class="task-menu ui-sortable-handle"></div>
                    </li>
                    <script type="text/javascript">
                        $('.task-list-holder').horizontalscroll();
                    </script>
                    <?php
                }
                return array();
            } else if (in_array($assetObj->asset_type_id, array(9, 6))) {
                $findassetUserId = array_shift(Asset_Models_AssetUser::find_all(array('where' => "asset_id={$asset_id} and user_id = {$userId}")));
                $assetUserId = !empty($findassetUserId->id) ? $findassetUserId->id : '';
                $assetAssetsObj = new Asset_Models_AssetUser($assetUserId);
                $assetAssetsid = $assetAssetsObj->save(array('asset_id' => $asset_id, 'user_id' => $userId));
            }
            echo json_encode(array('status' => 'success', 'msg' => "Record Update successfully.", 'success' => true));
            die;
            return array();
        }
    }

    public function editChild() {
        $variables = array();
        $tags = func_get_args();
        $variables['parent_id'] = array_shift($tags);
        $id = array_pop($tags);
        if (is_numeric($id)) {
            $variables['asset'] = array_shift(Asset_Models_Asset::find_all(array('where' => " assets.id = '" . $id . "'",
                        'join' => "asset_images on asset_images.asset_id = assets.id join images on images.id = asset_images.image_id join users on users.id = assets.uploaded_by",
                        'cols' => "assets.*, concat(name,' ' ,lastName) as fullName, users.email as userEmail, GROUP_CONCAT(images.id) as imageId, users.image",
                        'orderBy' => "assets.modified desc")));
            if ($variables['asset']->asset_type_id == '6') {
                $variables['assetUserComments'] = array_shift(Asset_Models_AssetComment::getUserComments($id));
            }
            $variables['assetType'] = new Tag_Models_Tag($variables['asset']->asset_type_id);
            if (!empty($variables['assetType'])) {
                $variables['header'] = 'Edit ' . $variables['asset']->title;
                if (!empty($variables['assetType']->edit_view)) {
                    $variables['view'] = $variables['assetType']->edit_view;
                }
            }
        } else {
            if (is_numeric($variables['parent_id'])) {
                $parent_assetType = new Asset_Models_Asset($variables['parent_id']);
                if ($parent_assetType->asset_type_id == 9) {
                    $variables['assetType'] = new Tag_Models_Tag(10);
                }
            } else {
                $variables['assetType'] = Asset_Models_AssetType::getAssetTypeBySlug(array_shift($tags));
            }
            if (!empty($variables['assetType'])) {
                $variables['header'] = 'Edit ' . $variables['assetType']->title;
                if (!empty($variables['assetType']->edit_view)) {
                    $variables['view'] = $variables['assetType']->edit_view;
                }
            }
        }
        return $variables;
    }

    public function edit() {
        $variables = array();
        $tags = func_get_args();
        $id = array_pop($tags);
        global $page;
        $userId = $page->currentUser->id;
        if (is_numeric($id)) {
            if ($page->currentUser->webUserRole == 1 && $id != '') {
                $assets = new Asset_Models_Asset($id);
                if (in_array($assets->asset_type_id, array(9, 11))) {
                    $IsAssignUser = Asset_Models_AssetUser::find_all(array('where' => ' asset_id="' . $id . '" AND user_id="' . $userId . '"'));
                    if (empty($IsAssignUser)) {
                        $variables['restrict'] = true;
                    }
                }
            }
            $variables['asset'] = array_shift(Asset_Models_Asset::find_all(array('where' => " assets.id = '" . $id . "'",
                        'join' => "asset_images on asset_images.asset_id = assets.id join images on images.id = asset_images.image_id join users on users.id = assets.uploaded_by",
                        'cols' => "assets.*, concat(name,' ' ,lastName) as fullName, users.email as userEmail, GROUP_CONCAT(images.id) as imageId, users.image",
                        'orderBy' => "assets.modified desc")));
            $variables['assetImages'] = Layout_Models_Layout::getWidget('Asset_Controllers_AssetsController', 'assetImage', 'assetImage', $id);
            if ($variables['asset']->asset_type_id == '6') {
                $variables['assetUserComments'] = array_shift(Asset_Models_AssetComment::getUserComments($id));
            }
            $variables['assetType'] = new Tag_Models_Tag($variables['asset']->asset_type_id);
            if (!empty($variables['assetType'])) {
                $variables['header'] = 'Edit ' . $variables['asset']->title;
                if (!empty($variables['assetType']->edit_view)) {
                    $variables['view'] = $variables['assetType']->edit_view;
                }
            }
        } else {
            $variables['assetType'] = Asset_Models_AssetType::getAssetTypeBySlug(array_shift($tags));
            if (!empty($variables['assetType'])) {
                $variables['header'] = 'Edit ' . $variables['assetType']->title;
                if (!empty($variables['assetType']->edit_view)) {
                    $variables['view'] = $variables['assetType']->edit_view;
                }
            }
        }
        return $variables;
    }

    public function view($assetType, $id, $readonly = '') {       
        $variables = array();
        global $page;
        $userId = $page->currentUser->id;
        if ($page->currentUser->webUserRole == 1) {
            $assets = new Asset_Models_Asset($id);
            if (in_array($assets->asset_type_id, array(9, 11))) {
                $IsAssignUser = Asset_Models_AssetUser::find_all(array('where' => ' asset_id="' . $id . '" AND user_id="' . $userId . '"'));
                if (empty($IsAssignUser)) {
                    $variables['restrict'] = true;
                }
            }
        }
        $variables['asset'] = array_shift(Asset_Models_Asset::find_all(array('where' => " assets.id = '" . $id . "'",
                    'join' => " users on users.id = assets.uploaded_by",
                    'cols' => "assets.*, concat(name,' ' ,lastName) as fullName, users.email as userEmail ",
                    'orderBy' => "assets.modified desc")));
        if ($variables['asset']->asset_type_id == '11') {
            $projectId = $this->ProjectByTicketId($variables['asset']->id);
            $variables['listNames'] = Asset_Models_AssetAsset::find_all(array('where' => "asset_assets.asset_id = {$projectId}",
                        'join' => " assets on assets.id = asset_assets.associated_asset_id"));
            $variables['project_id'] = $projectId;
            global $project_Id;
            $project_Id=$projectId;
        }

        /* Show Asset Images Section */
        $variables['readonly'] = !empty($readonly) ? $readonly : '';
        $variables['assetImages'] = Layout_Models_Layout::getWidget('Asset_Controllers_AssetsController', 'assetImage', 'assetImage', $id . "," . "{$variables['readonly']}");
        /* Show Asset Comments Section */
        $variables['assetUserComments'] = Layout_Models_Layout::getWidget('Asset_Controllers_AssetsController', 'assetComment', 'assetComment', $id);
        global $related;
        $assetType = new Tag_Models_Tag($variables['asset']->asset_type_id);
        $related['assetType'] = $assetType;
        if ($assetType->id == 11) {
            $variables['AssignedUsers'] = Layout_Models_Layout::getWidget('Asset_Controllers_AssetsController', 'assetuserlist', 'asset_users_list', $id);
            $userId = $page->currentUser->id;
            $variables['ticketTimes'] = Asset_Models_AssetTime::find_all(array('where' => 'user_id="' . $userId . '" AND asset_id="' . $id . '"'));
            $variables['ticketEstimatedTime'] = Layout_Models_Layout::getWidget('Asset_Controllers_AssetsController', 'ticketEstimatedTime', 'ticketEstimatedTime', $id);
            global $allowaddtime;
            $variables['vallowaddtime']=$allowaddtime;
        }
        $variables['assetType'] = $assetType;
        if (!empty($assetType->display_view))
            $variables['view'] = $assetType->display_view;
        return $variables;
    }

    public function saveAssignMember($assetId) {
        $variables = array();
        global $page;
        $assetTypeTitle = 'Asset';
        if ($assetId != '') {
            if (isset($_POST['asset_users'])) {
                $assetObj = new Asset_Models_Asset($_POST['asset_id']);
                if (!empty($assetObj->asset_type_id)) {
                    $tagObj = new Tag_Models_Tag($assetObj->asset_type_id);
                    $assetTypeTitle = $tagObj->title;
                }
                $html = serialize(array($assetTypeTitle => $assetObj->id));
                $Title = $assetObj->title;
                if ($assetObj->asset_type_id == '11') {
                    $projectId = $this->ProjectByTicketId($assetObj->id);
                    $projectDetail = new Asset_Models_Asset($projectId);
                    $Title = $assetObj->title . ' - ' . $projectDetail->title;
                }
                foreach ($_POST['asset_users'] as $assignUser) {
                    $listDetail = array_shift(Asset_Models_AssetUser::find_all(array('where' => 'asset_id="' . $projectId . '" and  user_id ="' . $assignUser . '"', 'limit' => '1')));
                    $assetAssetsObj = new Asset_Models_AssetUser();
                    $assetAssetsid = $assetAssetsObj->save(array('asset_id' => $_POST['asset_id'], 'user_id' => $assignUser));
                    if (empty($listDetail)) {
                        $projectTagObj = new Asset_Models_AssetUser();
                        $projectTag = $projectTagObj->save(array('asset_id' => $projectId, 'user_id' => $assignUser));
                    }
                    Notification_Models_Notification::AddNotifications($page->currentUser->id, $Title, 'assigned you', $assignUser, $html);
                }
            } else if (isset($_POST['parameter']) && $_POST['parameter'] == 'removeuser') {
                $delassetAssetsObj = new Asset_Models_AssetUser($_POST['parameterid']);
                $assetObj = new Asset_Models_Asset($delassetAssetsObj->asset_id);
                if (!empty($assetObj->asset_type_id)) {
                    $tagObj = new Tag_Models_Tag($assetObj->asset_type_id);
                    $assetTypeTitle = $tagObj->title;
                }
                $html = serialize(array($assetTypeTitle => $assetObj->id));
                if (!empty($delassetAssetsObj)) {
                    $Title = $assetObj->title;
                    if ($assetObj->asset_type_id == '11') {
                        $projectId = $this->ProjectByTicketId($assetObj->id);
                        $projectDetail = new Asset_Models_Asset($projectId);
                        $Title = $assetObj->title . ' - ' . $projectDetail->title;
                    }
                    Notification_Models_Notification::AddNotifications($page->currentUser->id, $Title, 'Remove you from', $delassetAssetsObj->user_id, $html);
                    $delassetAssetsObj->delete();
                }
            }
            $variables = $this->assetuserlist($assetId);
            $variables['asset_id'] = $assetId;
            $variables['view'] = 'asset_users_list';
        }
        return $variables;
    }

    public function ProjectByTicketId($ticket_id) {

        $listDetail = array_shift(Asset_Models_AssetAsset::find_all(array('where' => 'associated_asset_id="' . $ticket_id . '"', 'limit' => '1')));
        if (!empty($listDetail)) {
            $ProjectDetail = array_shift(Asset_Models_AssetAsset::find_all(array('where' => 'associated_asset_id="' . $listDetail->asset_id . '"', 'limit' => '1')));
            if (!empty($ProjectDetail)) {
                return $ProjectDetail->asset_id;
            }
        }
    }

    public function assetuserlist($assetId) {
        $where = '';
        if ($assetId) {
            $variables['AssignUsers'] = Asset_Models_AssetUser::find_all(array('join' => ' users on users.id=asset_users.user_id ', 'cols' => ' users.*,asset_users.id as assetuserid ', 'where' => ' asset_id="' . $assetId . '"'));

            $where .= ' AND id NOT IN (SELECT user_id FROM asset_users WHERE asset_id="' . $assetId . '")';
        }
        $userSelector = new OptionBox(array('name' => 'asset_users[]',
            'id' => 'fullname' . rand(),
            'multiSelect' => true,
            'dBTableOptions' => array('className' => 'User_Models_User', 'where' => ' status="1" ' . $where, 'cols' => 'name', 'orderBy' => 'name'),
            'noneOption' => 0));
        /* 'dBTableOptions' => array('className'=>'User_Models_User','where'=>' status="1" '.$where,'cols'=>'CONCAT(name, " ", lastname) as fullname','orderBy'=>'name'), */
        $variables['userSelector'] = $userSelector->generate();
        $variables['view'] = 'asset_users_list';
        return $variables;
    }

    public function savetickettime($assetId) {
        $where = '';
        $variables = array();	
        date_default_timezone_set('Asia/Kolkata');        
        global $page;
        if ($assetId) {
            $userId = $page->currentUser->id;
            $_POST['asset_id']=$assetId;
            $_POST['user_id']=$userId;
            if (!($_POST['minutes'] < 1 && $_POST['hours'] < 1)) {
                $_POST['end_time'] =  date('Y-m-d H:i:s');
                $tickettimeid = !empty($_POST['tickettimeid']) ? $_POST['tickettimeid'] : '';
                if(empty($tickettimeid)){
                     $_POST['start_time'] =  date('Y-m-d H:i:s');
                }
                $assettimeObj = new Asset_Models_AssetTime($tickettimeid);
                $assettimeObj->save($_POST);
            }elseif ($_POST['posttype'] === "starttimer") {
                $_POST['start_time'] =  date('Y-m-d H:i:s');
                $assettimeObj = new Asset_Models_AssetTime();
                $id = $assettimeObj->save($_POST);
                echo $id;
                die();                 
            }
            $ticketTimes = Asset_Models_AssetTime::find_all(array('where' => 'user_id="' . $userId . '" AND asset_id="' . $assetId . '"'));
            if (!empty($ticketTimes))
                $olddate = '';
            foreach ($ticketTimes as $ticketTime) {
                $date = date('M j, Y', strtotime($ticketTime->added_date));
                if ($olddate != $date) {
                    if ($olddate != '')
                        echo '<div class="clearfix"></div><hr class="mt10 mb10" />';
                    echo '<div class="col-sm-12 mb10">' . $date . '</div><div class="clearfix"></div>';
                    $olddate = $date;
                }
                echo '<div class="time-tag">' . sprintf('%02d', $ticketTime->hours) . ':' . sprintf('%02d', $ticketTime->minutes) . ' </div>';
            }
        }
        return $variables;
    }
    
    public function approveTicket() {
        $where = '';
        $variables = array();
        $id = !empty($_POST['id']) ? $_POST['id'] : '';
        $status = !empty($_POST['status']) ? $_POST['status'] : '';
        foreach ($status as $key => $approveStatus) {
            $approve = new Asset_Models_AssetTime($key);
            if ($approveStatus == "on") {
                $approve->save(array('status' => 1));
            } else {
                $approve->save(array('status' => 0));
            }
        }
        return $variables;
    }
    
    public function saveticketestimated($assetId) {
        $where = '';
        $variables = array();
        global $page;
        if ($assetId) {
            if($page->currentUser->webUserRole==2)
            {
                $adminId=$page->currentUser->id;
                $userId=$_POST['user_id'];
            }else
            {
                $adminId=$userId=$page->currentUser->id;
                
            }
            if (!($_POST['minutes'] < 1 && $_POST['hours'] < 1)) {
                $assettimeObj = new Asset_Models_AssetEstimateTime();
                $assettimeObj->save(array('asset_id' => $assetId, 'estimated_for' => $userId,'estimated_by'=>$adminId, 'hours' => $_POST['hours'], 'minutes' => $_POST['minutes']));
                if($adminId==$userId)
                {
                    echo '<script> $(".ticketEstimatedClass").show();</script>';
                    if(isset($_POST['reloadUrl']))
                    {
                        echo "<script>setTimeout(function () {
                            reloadDiv('" . $_POST['reloadUrl'] . "', 'mainContent', 'ajax');
                        }, 100);</script>";
                    }
                }
            }
        }
        if(isset($_POST['project_Id']) && $_POST['project_Id'])
        {
            global $project_Id;
            $project_Id=$_POST['project_Id'];
        }
        echo $variables['ticketEstimatedTime'] = Layout_Models_Layout::getWidget('Asset_Controllers_AssetsController', 'ticketEstimatedTime', 'ticketEstimatedTime', $assetId);
        
        return $variables;
    }
    public function ticketEstimatedTime($assetId) {
        global $page;
        global $allowaddtime;
        $allowaddtime='no';
        $where = '';
        $variables['assetId']=$assetId;
        $AllUsers = User_Models_User::find_all();
        $userColaction=array();
        foreach ($AllUsers as $Alluser)
        {
            $userColaction[$Alluser->id]=$Alluser;
        }
        $variables['AllUsers']= $userColaction;
        $userId= $page->currentUser->id;
        if($page->currentUser->webUserRole==2)
        {
            if ($assetId) {
                $where .= ' AND id IN (SELECT user_id FROM asset_users WHERE asset_id="' . $assetId . '")';
            }
            $userSelector = new OptionBox(array('name' => 'user_id',
                'id' => 'fullname' . rand(),
                'multiSelect' => false,
                'dBTableOptions' => array('className' => 'User_Models_User', 'where' => ' status="1" ' . $where, 'cols' => 'name', 'orderBy' => 'name'),
                'noneOption' => 0));
            $variables['userSelector'] = $userSelector->generate();
            $variables['AssignUsers']=  Asset_Models_AssetEstimateTime::find_all(array('where' => ' asset_id="' . $assetId . '" AND estimated_by="'.$userId.'"'));
            $variables['EstimatedByUsers']=  Asset_Models_AssetEstimateTime::find_all(array('where' => ' asset_id="' . $assetId . '" AND estimated_by=estimated_for '));
        }else
        {
            $variables['AssignUsers']=  Asset_Models_AssetEstimateTime::find_all(array('where' => ' asset_id="' . $assetId . '" AND estimated_for="'.$userId.'" AND estimated_by!=estimated_for'));
            $variables['EstimatedByUsers']=  Asset_Models_AssetEstimateTime::find_all(array('where' => ' asset_id="' . $assetId . '" AND estimated_by="'.$userId.'" '));
            if(count($variables['EstimatedByUsers'])>0)
            {
                $allowaddtime='yes';
            }
            /*$variables['AssignUsers']=  Asset_Models_AssetEstimateTime::find_all(array('where' => ' asset_id="' . $assetId . ' AND estimated_by!="'.$userId.'"'));
            $variables['EstimatedByUsers']=  Asset_Models_AssetEstimateTime::find_all(array('where' => ' asset_id="' . $assetId . ' AND estimated_by=estimated_for '));*/
        }
        return $variables;
    }

    function timereport($project_id = '0', $list_id = '0', $card_id = '0', $userid = '0', $form_date = '0', $to_date = '0',$ProjectType='0', $pageNumber = '1') {
        $variables = array();
        $where = array();
        $whereProjecType='';
        /*
        select associated_asset_id from asset_assets where asset_id IN(select associated_asset_id from asset_assets where asset_id IN( SELECT GROUP_CONCAT(assets.id SEPARATOR "," ) FROM assets WHERE assets.asset_type_id=9 AND ( assets.priority!=2  OR assets.priority is null) ));
select associated_asset_id from asset_assets where asset_id IN( SELECT GROUP_CONCAT(assets.id SEPARATOR "," ) FROM assets WHERE assets.asset_type_id=9 AND ( assets.priority!=2  OR assets.priority is null));
SELECT GROUP_CONCAT(assets.id SEPARATOR "," ) FROM assets WHERE assets.asset_type_id=9 AND ( assets.priority!=2  OR assets.priority is null);
         */
        if($ProjectType=='1')
        {
            $whereProjecType = ' asset_times.asset_id IN (select associated_asset_id  from asset_assets where asset_id IN(select associated_asset_id from asset_assets where asset_id IN(SELECT assets.id  FROM assets WHERE assets.asset_type_id=9 AND ( assets.priority!=2  OR assets.priority is null)))) ';
        }else if ($ProjectType=='2')
        {
            $whereProjecType = ' asset_times.asset_id IN (select associated_asset_id from asset_assets where asset_id IN(select associated_asset_id from asset_assets where asset_id IN(SELECT assets.id FROM assets WHERE assets.asset_type_id=9 AND assets.priority=2))) ';
        }
            
        $wherelist = $variables['filterdata']['lists'] = $variables['filterdata']['cards'] = $wherestr = '';
        if ($project_id != '0') {
            if ($list_id == '0') {
                $wherelist = ' select associated_asset_id from asset_assets where asset_id in(select associated_asset_id from asset_assets where asset_id="' . $project_id . '")';
            } else {
                $wherelist = ' select associated_asset_id from asset_assets where asset_id in(' . $list_id . ')';
            }
            $variables['filterdata']['lists'] = Asset_Models_Asset::find_all(array('where' => ' asset_type_id ="10" AND status="1" AND id in(select associated_asset_id from asset_assets where asset_id="' . $project_id . '") '));
            $variables['filterdata']['cards'] = Asset_Models_Asset::find_all(array('where' => ' asset_type_id ="11" AND status="1" AND id in(' . $wherelist . ')'));
            $wherelist = 'asset_times.asset_id in(' . $wherelist . ')';
        }
        $filterdata = array_shift(Asset_Models_AssetTime::find_all(array(
                    'cols' => "GROUP_CONCAT(DISTINCT asset_times.user_id SEPARATOR ',' ) user_ids, GROUP_CONCAT(DISTINCT users.username SEPARATOR ',' ) users",
                    'join' => ' users on users.id=asset_times.user_id',
                    'where' => $wherelist)));
        if (!empty($filterdata)) {
            $variables['filterdata']['users'] = array_combine(explode(',', $filterdata->user_ids), explode(',', $filterdata->users));
        }
        $variables['filterdata']['projects'] = Asset_Models_Asset::find_all(array('where' => ' asset_type_id ="9" AND status="1"'));


        if ($userid != 0) {
            $where[] = 'asset_times.user_id="' . $userid . '"';
        }
        if ($card_id != 0) {
            $where[] = 'assets.id="' . $card_id . '"';
        }
        if (!empty($form_date) || !empty($todate)) {
            if ($form_date == "today") {
                $toDate = $to_date='0';
                $fromDate = date("Y-m-d");
                $where[] = 'added_date >"' . date('Y-m-d 00:00:00', strtotime($fromDate)) . '"';
            } elseif ($form_date == "month") {
                $toDate = $to_date='0';
                $where[] = "MONTH(added_date) = MONTH(CURDATE())";
            } elseif ($form_date == "weekly") {
                $toDate = $to_date='0';
                $where[] = "yearweek(added_date)= yearweek(curdate()) ";
            }if ($form_date == "lastmonth") {
                $toDate = $to_date='0';
                $where[] = "YEAR(added_date) = YEAR(CURRENT_DATE - INTERVAL 1 MONTH) AND MONTH(added_date) = MONTH(CURRENT_DATE - INTERVAL 1 MONTH)";
                //  echo $where[] = "added_date >= curdate() - INTERVAL DAYOFWEEK(curdate())+6 DAY AND added_date < curdate() - INTERVAL DAYOFWEEK(curdate())-1 DAY";   this query is last week days
            } else {
                if ($form_date) {
                    $fromDate = $form_date;
                    $where[] = 'added_date >"' . date('Y-m-d 00:00:00', strtotime($fromDate)) . '"';
                }
                if ($to_date) {
                    $toDate = $to_date;
                    $where[] = 'added_date<"' . date('Y-m-d 23:59:59', strtotime($toDate)) . '"';
                }
            }
            $fromDate = $form_date;
        }

        if ($wherelist != '') {
            $where[] = $wherelist;
        }
        if (!empty($where)) {
            $wherestr = implode(' AND ', $where);
            if(!empty($whereProjecType))
                $whereProjecType=' AND '.$whereProjecType;
        }
        $alltime = array_shift(Asset_Models_AssetTime::find_all(array(
                    'cols' => 'sum(hours) as hours, sum(minutes) as minutes',
                    'join' => ' users on users.id=asset_times.user_id join assets on assets.id=asset_times.asset_id',
                    'where' => $wherestr.$whereProjecType
        )));
        
        $variables['alltotaltime'] = Core_Models_Utility::countTime($alltime->hours, $alltime->minutes);
        $variables['ticketTimes'] = Asset_Models_AssetTime::getPaginatedData(array(
                    'cols' => ' users.username as user, assets.title as card,asset_times.*',
                    'join' => ' users on users.id=asset_times.user_id join assets on assets.id=asset_times.asset_id',
                    'where' => $wherestr.$whereProjecType,
                    'recordsPerPage' => '50',
                    'orderBy' => 'asset_times.id desc',
                    'pageNumber' => $pageNumber));
        $variables['FromDate'] = !empty($fromDate) ? $fromDate : '0';
        $variables['ToDate'] = !empty($toDate) ? $toDate : '0';
        $variables['project_id'] = $project_id;
        $variables['list_id'] = $list_id;
        $variables['userid'] = $userid;
        $variables['card_id'] = $card_id;
        $variables['ProjectType']=$ProjectType;

        /* , 'groupBy'=>' asset_id,user_id' */
        return $variables;
    }

    function deleteimage($imageid, $asset_id) {
        $variables = array();
        $image = new Image_Models_Image($imageid);
        if (!empty($image->id)) {
            if ($image->delete()) {
                $assetImage = array_shift(Asset_Models_AssetImage::find_all(array('where' => " image_id='{$imageid}' AND asset_id='{$asset_id}'", 'limit' => '1')));
                $assetImage;
                $content = new Asset_Models_AssetImage($assetImage->id);
                if (!empty($content->id)) {
                    if ($content->delete()) {
                        $variables['result'] = 'Delete Success';
                    } else {
                        $variables['result'] = 'Delete Fail';
                    }
                } else {
                    $variables['result'] = 'Delete Fail';
                }
            }
        }
        if (isset($_POST['parameter']) && $_POST['parameter'] == 'removeimage') {
            /* Show Asset Images Section */
            echo Layout_Models_Layout::getWidget('Asset_Controllers_AssetsController', 'assetImage', 'assetImage', $asset_id);
            return array();
        }
        echo $variables['result'];
        return $variables;
    }

    public function saveAssetComment() {
        $variables = array();
        global $page;
        if ($page->currentUser->userLoggedIn) {
            $userId = $page->currentUser->id;
        } else {
            echo "<script>window.location = '/';</script>";
            die;
        }
        $asset_comment_id = (!empty($id)) ? $id : '';
        $assetCommentImage = array();
        if (!empty($_FILES['commentImages']['tmp_name'])) {
            foreach ($_FILES['commentImages']['tmp_name'] as $value) {
                $imageData['image'] = Image_Models_Image::scaleImage($value);
                $imageData['image_thumb'] = Image_Models_Image::generateThumb($value);
                $imageData['type'] = 'jpeg';
                $image = new Image_Models_Image();
                $ImageId = $image->save($imageData);
                $assetCommentImage[] = !empty($ImageId) ? $ImageId : '';
            }
        }
        $asset_comment_images_id = '';
        if (!empty($assetCommentImage)) {
            $asset_comment_images_id = implode(",", $assetCommentImage);
        }
        $userAssetComment = new Asset_Models_AssetComment();
        $data = $userAssetComment->save(array(
            'user_id' => $userId,
            'asset_id' => $_POST['asset_id'],
            'comments' => $_POST['comments'],
            'comment_at' => date("Y-m-d H:i:s"),
            'comment_images' => $asset_comment_images_id
        ));

        $assetImage = new Asset_Models_AssetImage();
        $assetImage->save(array('comment_id' => $_POST['asset_id'], 'image_id' => !empty($ImageId) ? $ImageId : ''));

        $assetObj = new Asset_Models_Asset($_POST['asset_id']);
        $AssignUsersToAsset = array_shift(Asset_Models_AssetUser::find_all(array('where' => ' asset_id="' . $assetObj->id . '" AND user_id="' . $userId . '"', 'limit' => '1')));
        if (empty($AssignUsersToAsset)) {
            $AssetsuserObj = new Asset_Models_AssetUser();
            $AssetsuserObj->save(array('asset_id' => $assetObj->id, 'user_id' => $userId));
        }
        if (!empty($assetObj->asset_type_id)) {
            $tagObj = new Tag_Models_Tag($assetObj->asset_type_id);
            $assetTypeTitle = $tagObj->title;
            $html = serialize(array($assetTypeTitle => $assetObj->id));
            $AssignUsers = Asset_Models_AssetUser::find_all(array('where' => ' asset_id="' . $assetObj->id . '"'));
            $assignUsersArray = array();
            foreach ($AssignUsers as $AssignUser) {
                $assignUsersArray[] = array('id' => $AssignUser->user_id);
            }
            Notification_Models_Notification::AddNotifications($page->currentUser->id, $assetObj->title, 'Comment on', $assignUsersArray, $html);
        }
        if (isset($_POST['formType']) && $_POST['formType'] == 'showresult') {
            echo Layout_Models_Layout::getWidget('Asset_Controllers_AssetsController', 'assetComment', 'assetComment', $_POST['asset_id']);
            return array();
        }
        echo json_encode(array('status' => 'success', 'msg' => Core_Models_Utility::flashMessage("Comment Saved Successfully.", 'valid')));
        return $variables;
    }

    function assetComment($asset_id, $pageNumber = '1') {
        $variables = array();
        if (!empty($asset_id))
            $variables['assetUserComments'] = array_shift(Asset_Models_AssetComment::getUserComments($asset_id, $pageNumber));
        $variables['asset_id'] = $asset_id;
        $variables['pageNumber'] = $pageNumber;
        $variables['view'] = 'assetComment';
        return $variables;
    }

    function assetImage($asset_id, $readonly = '', $pageNumber = '1') {

        $variables = array();
        if (!empty($asset_id)) {
            $assetImages = Asset_Models_Asset::getPaginatedData(array('where' => " assets.id = '" . $asset_id . "'",
                        'join' => "asset_images on asset_images.asset_id = assets.id join images on images.id = asset_images.image_id ",
                        'pageNumber' => $pageNumber, 'cols' => "images.* ", 'orderBy' => 'images.id desc'));
            $variables['assetImages'] = $assetImages->data;
        }
        $variables['asset_id'] = $asset_id;
        $variables['pageNumber'] = $pageNumber;
        $variables['readonly'] = $readonly;
        $variables['view'] = 'assetImage';
        return $variables;
    }

    function printcertificates($certificateid, $userid) {
        $variables['viewcertificate'] = array_shift(Asset_Models_Asset::find_all(array('where' => "assets.id = $certificateid")));
        if ($userid) {
            $variables['employeedetails'] = array_shift(User_Models_User::find_all(array('where' => "users.id = $userid")));
        }
        $variables['certificateid'] = $certificateid;
        $variables['userid'] = $userid;
        return $variables;
    }

    function likes() {
        global $page;
        $likescount = '';
        if (isSet($_POST['msg_id']) && isSet($_POST['rel']) && isSet($_POST['type'])) {
            $msg_id = $_POST['msg_id'];
            $rel = $_POST['rel'];
            $uid = $page->currentUser->id;
            $type = $_POST['type'];
            if ($type == "comment") {
                echo $where .= "and asset_likes.comment_id = {$msg_id}";
                $model .= "Asset_Models_AssetComment";
                $join .= "'join' => 'asset_users on asset_comments.asset_id = asset_users.asset_id'";
                $where_where = "asset_comments.id = {$msg_id}";
            } elseif ($type == "assetComment") {
                echo $where .= "and asset_likes.asset_id = {$msg_id}";
                $model .= "Asset_Models_Asset";
                $where_where .= "assets.id = {$msg_id}";
            }
            $data = Asset_Models_AssetLike::find_all(array('where' => "asset_likes.user_id = {$uid}  $where ", 'cols' => 'id'));
            $likeid = array_shift($data);
            $likeObj = !empty($likeid->id) ? new Asset_Models_AssetLike($likeid->id) : new Asset_Models_AssetLike();
            $likecountObj = new $model($msg_id);
            $like_count = $model::find_all(array('where' => $where_where, $join));
            if ($type == "comment") {
                if ($rel == 'Like') {
                    $likeObj->save(array("comment_id" => "{$msg_id}", "user_id" => "{$uid}"));
                    $likescount = $likecountObj->like_count + 1;
                    $likecountObj->save(array("like_count" => "{$likescount}"));
                    foreach ($like_count as $sendnotification) {
                        $usersassingId[] = $sendnotification->user_id;
                    }
                    Notification_Models_Notification::AddNotifications($uid, $sendnotification->comments, 'Unlike This Comment', $usersassingId);
                } else {
                    $likeObj->delete();
                    $likescount = $likecountObj->like_count - 1;
                    $likecountObj->save(array("like_count" => "{$likescount}"));
                    foreach ($like_count as $sendnotification) {
                        $usersassingId[] = $sendnotification->user_id;
                    }
                    Notification_Models_Notification::AddNotifications($uid, $sendnotification->comments, 'Unlike This Comment', $usersassingId);
                }
            } elseif ($type == "assetComment") {
                if ($rel == 'Like') {
                    $likeObj->save(array("asset_id" => "{$msg_id}", "user_id" => "{$uid}"));
                    $likescount = $likecountObj->like_count + 1;
                    $likecountObj->save(array("like_count" => "{$likescount}"));
                    foreach ($like_count as $sendnotification) {
                        $usersassingId[] = $sendnotification->user_id;
                    }
                    Notification_Models_Notification::AddNotifications($uid, $sendnotification->title, 'Like This Status', 'all');
                } else {
                    $likeObj->delete();
                    $likescount = $likecountObj->like_count - 1;
                    $likecountObj->save(array("like_count" => "{$likescount}"));
                    foreach ($like_count as $sendnotification) {
                        $usersassingId[] = $sendnotification->user_id;
                    }
                    Notification_Models_Notification::AddNotifications($uid, $sendnotification->title, 'Unlike This Status', 'all');
                }
            }
            return array();
        }
    }

    function showUserLike($id = '', $type = "", $pageNumber = '1') {
        $variables = array();
        $assetId = !empty($id) ? $id : '';
        $variables['likeUsersLayout'] = Layout_Models_Layout::getWidget('Asset_Controllers_AssetsController', 'loadmorelike', 'asset_users_list', "{$id},{$type},{$pageNumber}");
        $variables['likeUsers'] = Asset_Models_AssetLike::likesViewStatus($assetId, $type);
        $variables['asset_id'] = $id;
        return $variables;
    }

    function loadmorelike($asset_id, $type = '', $pageNumber = '1') {
        $variables = array();
        if (!empty($asset_id))
            $variables['likeUsers'] = Asset_Models_AssetLike::loadmore($asset_id, $type, $pageNumber);
        $variables['asset_id'] = $asset_id;
        $variables['pageNumber'] = $pageNumber;
        $variables['view'] = 'loadmorelike';
        $variables['type'] = $type;
        return $variables;
    }

    

    public function hrsiteContent() {
        global $page;
        $this->layoutId = 50;
        $menuids = Asset_Models_Asset::find_all(array('where' => ' asset_type_id = 13 and status = 1'));
        foreach ($menuids as $menuid) {
            $menu_lists = Asset_Models_AssetAsset::find_all(array('where' => "asset_assets.asset_id = $menuid->id"));

            foreach ($menu_lists as $key => $menu_list) {
                $menu_list_detail=new Asset_Models_Asset($menu_list->associated_asset_id);      
                $cards = Asset_Models_AssetAsset::find_all(array('where' => "asset_assets.asset_id = $menu_list->associated_asset_id",'orderBy' => 'asset_assets.asset_id desc'));
                 foreach ($cards as $card) {
                  $cardvlaue[$menuid->title][$menu_list_detail->title][] = array_shift(Asset_Models_Asset::find_all(array('leftjoin'=>'asset_images on asset_images.asset_id=assets.id ','where' => " assets.id = {$card->associated_asset_id} and status = 1",
                          'cols'=>'assets.*,asset_images.id as assetimageid, asset_images.asset_id , asset_images.image_id',
                          'orderBy' => 'assets.id desc')));
                }
            }
        }

        $page->logToGoogle = true;
        $page->metaKeywords = "employee management, leave management";
        $page->pageTitle = "HR Bezoar: A Powerful Employee Management Tool";
        $variables['contactForm'] = Layout_Models_Layout::getWidget('Asset_Controllers_AssetsController', 'hrcontactform', 'hrcontactform');    
        $variables["hrSiteContents"] = $cardvlaue;
        return $variables;
    }
    
    
    function viewlinks($slug='') {
        $variables =array();
        $this->layoutId = 51;
        if ($slug)  {
               $implink = array_shift(Asset_Models_Asset::find_all(array('where' => "slug = '{$slug}' and asset_type_id = 16 and status = 1")));              
               
            if (!empty($implink)) {
                $variables['implinks'] = $implink;              
               } else {
                echo "<script>window.location.href = '" . BASE_PATH_ROOT . "';</script>";
            }
        } else {
            echo "<script>window.location.href = '" . BASE_PATH_ROOT . "';</script>";
        }         
        return $variables;
    }

    function hrcontactform(){ 
        $this->layoutId = 50;
        $variables['importantLinks'] = Asset_Models_Asset::find_all(array(
                    'where' => ' asset_type_id = 16 and status = 1',
                    'orderBy' => 'assets.id DESC',
                    'limit' => '5'
        ));
        return $variables;         
    }
    
    
    public function contactus() {
        if ($_POST['email']) {
            $fname = !empty($_POST['name']) ? $_POST['name'] : '';
            $email = !empty($_POST['email']) ? $_POST['email'] : '';
            $to = HR_EMAIL;
            $subject = "Hr Bezoar Contact Us";
            $message = !empty($_POST['message']) ? $_POST['message'] : '';
            $from = $email;
            $headers = "From:" . $from;
            if (mail($to, $subject, $message, $headers)) {
               echo json_encode(array('status' => 'success', 'msg' => Core_Models_Utility::flashMessage("Send Successfully.", 'valid')));
                 return $variables;             
            }else{
                echo  Core_Models_Utility::flashMessage("Wrong Email Address.", 'error');               
            }           
        }
        return array();
    }

}
