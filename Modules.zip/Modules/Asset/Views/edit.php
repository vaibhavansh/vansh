<div id="editObject<?php echo $object->id ?>ResultDiv"></div>
<form name ="editObject<?php echo $object->id ?>" id="editObject<?php echo $object->id ?>" method="post" keepResult="1" action="/<?php echo $object->coreURL ?>/save" rel="ajaxifiedForm" enctype="multipart/form-data">
    <div class="col-xs-12">
        <h2 class="col-xs-12">
            <?php echo $header;  ?>
            <input type="submit" name="submit" class="btn btn-primary" value ="Save Asset" />
        </h2>
        <?php // if (!empty($assetImage->id)) { ?>
<!--            <div id="image_preview_<?php echo $object->id; ?>">
                <?php
//                $assetImage->printImageThumb();
                ?>
            </div>-->
            <!--<br />-->
            <!--||<a href="/image_images/edit/<?php echo $assetImage->image_id ?>" rel="popUpBox" onCloseFunction="refreshImage('<?php echo $assetImage->image_id ?>')">Edit Image</a><br />-->
        <?php // } else { ?>
            <!--<div id="image_preview_<?php echo $object->id; ?>"></div><br />-->
        <?php // }
        ?>
        <!--||<a href="/image_images/imageGallary/<?php echo $object->id; ?>" rel="popUpBox">Select from Library</a>-->
        <!--<input type ="hidden" value="0" name="image_id" id="image_<?php echo $object->id; ?>" />-->
        <!--<input type="file" name="image" id ="image_ddd" />-->
    <!--</div>-->
    <div class="grid_10 omega alpha">
        <div class="grid_3"><label for='title'>Media Title</label></div>
        <input type="textbox" name="title" class="grid_6" id="title_<?php echo $object->id ?>" value="<?php echo $object->title ?>" />
        <div class="spacer"></div>


        <div class="grid_3">
            <label for='subtitle'>Description</label></div>
        <div class="grid_6">
            <textarea name ="subtitle" id="subtitle"><?php echo $object->subtitle; ?></textarea>
        </div>
        <div class="spacer"></div>

        <?php foreach ($selectors as $key => $value) { ?>
            <div class="grid_3">
                <?php echo preg_replace('/(?<=\\w)(?=[A-Z])/', ' $1', $key); ?>
            </div>
            <div class="grid_6">
                <?php
                echo $value->generate();
                ?>
            </div>
            <div class="spacer"></div>
        <?php } ?>
    </div>
    <div class="grid_10 omega alpha">
        <div class="grid_3">
            Media Type
        </div>
        <div class="grid_6">
            <?php
            echo $mediaTypeSelector->generate();
            ?>
        </div>
        <div class="spacer"></div>
        <div class="grid_3 ">
            Movie/TvShow
        </div>
        <div class="grid_6">
            <?php echo $parentAssetSelector->generate();
            ?>
        </div>
        <div class="grid_3 ">
            Tv-Show Season
        </div>
        <div class="grid_6">

            <?php
            echo $seasonSelector->generate();
            ?>
        </div>
        <div class="grid_3">
            Release Date
        </div>
        <div class="grid_6">
            <input type="text" name="release_date" id="release_date_<?php echo $object->id; ?>" value="<?php echo $object->release_date; ?>" rel="datePicker"/>
            
        </div>
        <br/>
        
        <div class="spacer"></div>
        <div class="grid_3">
            Editor</div>
        <div class="grid_6"> 
            <?php echo $uploaded_by->generate(); ?></div>
        <!--     <div class="grid_6">
                    <input type="text" name="uploaded_by" class="grid_6" id="uploaded_by__<?php echo $object->id ?>" value="<?php echo $object->uploaded_by ?>" /></div>
                    <div class="grid_3 ">
        
                    </div> 
                    <div class="grid_6">
        <?php //  echo $uploaded_by->generate();
        ?>
                    </div>-->
        <div class="spacer"></div>
        <div class="grid_3">
            Create New Tags(Seperate by (,))
        </div>
        <div class="grid_6">
            <input type="textbox" name="keywords" id="keyword_<?php echo $object->id; ?>" value="" />
        </div>
        <div class="spacer"></div>
        <?php echo $publishToggleSelector->generate(); ?>

        <?php
        if (empty($assetImage->id)) {
            ?>
            <div class="grid_3">
                Generate Automatic News
            </div>
            <div class="grid_6">
                <input type="checkbox" name="autogeneratenews" id="autogeneratenews" value="yes" />
            </div>
            <?php
        }
        ?>

    </div>
    <div class="spacer10"></div>
    <a href="javascript:void()" onclick ="queryOMDB('<?php echo $object->id ?>');" >Query OMDB</a>
    <div id="omdbdata_<?php echo $object->id; ?>"></div>
    <?php
    if (!empty($assetImage->id)) {
        ?>
        <div class="wrap">
            <?php $assetImage->printImageThumb(); ?>
        </div>
        <?php
    }
    ?>
    <div class="wrap">
        <a href="/image_images/imageGallary/<?php echo $object->id; ?>" rel="popUpBox">Select from Library</a>
        <input type ="hidden" value="0" name="image_id" id="image_<?php echo $object->id; ?>" />
        <!-- image preview area-->
        <img id="uploadPreview" style="display:none;"/>
        <!-- image uploading form -->
        <!--<input type="file" name="image" id ="image_ddd" />-->
        <!--<input id="uploadImage" type="file" accept="image/jpeg" name="image" />-->
        <input id="image_ddd" type="file" name="image" />
        <!--<input type="submit" value="Upload">-->

        <!-- hidden inputs -->
        <input type="hidden" id="x" name="x" />
        <input type="hidden" id="y" name="y" />
        <input type="hidden" id="w" name="w" />
        <input type="hidden" id="h" name="h" />
    </div><!--wrap-->

    <div class="spacer10"></div>

    <div  class="grid_24 omega  lightGreyBackground">
        <div class="grid_20 omega alpha">
            Asset Videos
        </div>
        <div class="grid_4  alpha">
            <input type='button' onclick="addVideo()" class="rightAlign" value='Add Video' />
        </div>
        <div class="spacer">
        </div>
        <ul id="assetVideos" class="sortable">
            <?php foreach ($object->assetVideos() as $assetVideo) { ?>
                <div name="assetVideo" class="  well wrap" id="assetVideo_<?php echo $assetVideo->id; ?>">
                    <input    type="hidden" name="assetVideoIds[]" value="<?php echo $assetVideo->id; ?>"/>
                    <div class="grid_6 assetVideoTitle">
                    </div>
                    <div class="spacer"></div>
                    <input  class="grid_10"  type="textbox" name="assetVideoEmbedCodes[]" value="<?php echo $assetVideo->embed_code; ?>" />
                    <div class="grid_2 omega alpha">
                        <input class=" btn" type="button"  onclick="removeVideo($(this))" value="Remove" />
                    </div>
                    <div class="spacer"></div>
                </div>
            <?php }
            ?></ul>


    </div>
    <div class="spacer10"></div>
    <div class="grid_24 omega lightGreyBackground" id="searchYoutubeForm_<?php echo $object->id ?>">
        <script>
            reloadDiv('/asset_assets/searchYouTubeForm/', 'searchYoutubeForm_<?php echo $object->id ?>');</script>
    </div>
    <div class="spacer10"></div>


    <div id="assetCustomFields" >

        <?php
        if (!empty($object->custom_fields))
            foreach ($object->customFields() as $key => $value) {
                ?>
                <div id="tkv_<?php echo $key ?>" class="form-inline">
                    <input class="grid_2" type='text' name="custom_fields_array[title][]" value="<?php echo $value->title ?>">
                    <input class="grid_3" type='text' id="key_<?php echo $key ?>" name='custom_fields_array[key][]'
                           value="<?php echo $key ?>" class="uniqueKey">
                    <input class="grid_3" type='text' name='custom_fields_array[value][]' value="<?php echo $value->value ?>">
                    <input type="button" class="btn grid_3" onclick="$('#tkv_<?php echo $key ?>').remove()" value="Remove" >
                    <div class="spacer10"></div>
                </div>
            <?php } ?>

        <div class="spacer10"></div>

        <input type='button' onclick="$('#tkv').clone(true).insertBefore($(this)).show().removeAttr('id');" value='Add Custom Fields' />
        <div class="spacer10"></div>

    </div>
    <input type="hidden" name="id" value="<?php echo $object->id ?>"/>
    <input type="hidden" id="assetVideoOrder" name="assetVideoOrder" value=""/>

</div>
</form>
<div class="spacer"></div>
<div id="tkv" name ="tkv" style="display:none" class="form-inline">
    <input class="grid_2" type='text' placeholder="Title"  name="custom_fields_array[title][]" class="required">
    <input class="grid_3" type='text' placeholder="Key"  name='custom_fields_array[key][]' class="uniqueKey">
    <input class="grid_3" type='text' placeholder="Value" name='custom_fields_array[value][]'>
    <input class=" grid_3 btn" type="button"  onclick="$(this).parent('div [name=tkv]').remove()" value="Remove" />
    <div class="spacer10"></div>
</div>

<div name="assetVideo" class="  well wrap" id="emptyAssetVideo" style="display:none">
    <input    type="hidden" name="assetVideoIds[]" />

    <div class="grid_6 assetVideoTitle" >
    </div>
    <div class="spacer"></div>
    <input  class="grid_10"  type="textbox" name="assetVideoEmbedCodes[]" />
    <div class="grid_2 omega alpha">
        <input class=" btn" type="button"  onclick="removeVideo($(this))" value="Remove" />
    </div>
    <div class="spacer"></div>
</div>
<script>
    function removeVideo(element) {
        element.parent().parent("div[name='assetVideo']").hide().find("input[name='assetVideoEmbedCodes[]']").val('');
    }
    function sortIt() {
        sortable = $("ul#assetVideos").sortable({
            update: function () {
                $('#assetVideoOrder').val($(this).sortable('toArray'));
            }
        });
        $('#assetVideoOrder').val(sortable.sortable('toArray'));

    }
    function addVideo() {
        $("ul#assetVideos >div").length
        $('#emptyAssetVideo').clone(true).appendTo($('#assetVideos')).show().attr('id', 'newAssetVideo_' + $("ul#assetVideos >div").length);
        sortIt();
    }
    sortIt();
    $("#release_date_<?php echo $object->id; ?>").datepicker({changeMonth: true,
        changeYear: true, yearRange: 'c-65:c+1', dateFormat: 'yy-mm-dd'});

</script>
<script>
    function queryOMDB(videoId) {
        $.post('/DesiFilmZone_DesiFilmZones/importFromOMDB/', {
            pageRequestType: 'ajax',
            title: encodeURI($('#title_' + videoId).val()),
            year: encodeURI($('#release_date_' + videoId).val()),
            videoId: videoId
        }, function (data) {
            $("#omdbdata_" + videoId).html(data);
        });

    }
</script>

<script type="text/javascript">
    $(document).ready(function () {
        $("#subtitle").cleditor({
            width: "250", // width not including margins, borders or padding
            height: 550, // height not including margins, borders or padding
            controls: // controls to add to the toolbar
                    "bold italic underline strikethrough subscript superscript | font size " +
                    "style | color highlight removeformat | bullets numbering | outdent " +
                    "indent | alignleft center alignright justify | undo redo | " +
                    "rule  | cut copy paste pastetext | print source"
        });
    });
</script>

<script>

// set info for cropping image using hidden fields

    function setInfo(i, e) {
        $('#x').val(e.x1);
        $('#y').val(e.y1);
        $('#w').val(e.width);
        $('#h').val(e.height);
    }

    $(document).ready(function () {
        var p = $("#uploadPreview");

        // prepare instant preview
        $("#image_ddd").change(function () {

            // fadeOut or hide preview
            p.fadeOut();

            // prepare HTML5 FileReader
            var oFReader = new FileReader();
            oFReader.readAsDataURL(document.getElementById("image_ddd").files[0]);

            oFReader.onload = function (oFREvent) {
                p.attr('src', oFREvent.target.result).fadeIn();
            };
        });

        // implement imgAreaSelect plug in (http://odyniec.net/projects/imgareaselect/)
        $('img#uploadPreview').imgAreaSelect({
            // set crop ratio (optional)
            aspectRatio: '1:1',
            onSelectEnd: setInfo
        });
    });
</script>
<style>
    .wrap{
        width: 100%;
        margin: 10px auto;
        padding: 10px 15px;
        background: white;
        border: 2px solid #DBDBDB;
        -webkit-border-radius: 5px;
        -moz-border-radius: 5px;
        border-radius: 5px;
        text-align: center;
        overflow: hidden;
    }
    img#uploadPreview{
        border: 0;
        border-radius: 3px;
        -webkit-box-shadow: 0px 2px 7px 0px rgba(0, 0, 0, .27);
        box-shadow: 0px 2px 7px 0px rgba(0, 0, 0, .27);
        margin-bottom: 30px;
        overflow: hidden;
    }

</style>