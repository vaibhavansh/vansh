<?php
global $page;
if ($page->currentUser->userLoggedIn) {
    $webUserRole = $page->currentUser->webUserRole;
    if ($webUserRole == 2) {
        $cols = 'col-md-9  main-div';
        $summernote = "summernote";
    } else {
        $cols = 'col-md-12';
    }
}
?> 
<section class="">
    <!-- begin: .tray-center-->
    <div id="animation-switcher" class="tray-center pn  <?php echo $cols; ?>" >
        <?php
        if (empty($list)) {
            $changeclass = 'col-lg-12';
        } else {
            $changeclass = 'col-sm-12 col-xs-12';
        }
        ?>
        <div class=" <?php echo $changeclass; ?> changeclass" id="">
            <div class="DelResultDiv"></div>
            <div class="panel mb25 mt5">
                <div class="panel-heading"><span class="panel-title"> <i class="fa fa-th-list"></i> Policies</span>
                    <?php if ($page->currentUser->webUserRole == 2) { ?>
                        <span class="pull-right fix-right">
                            <div class="btn-group">
                                <button type="button" class="btn btn-default light div-slider visible-lg"><i class="fa"></i></button>
                            </div>
                            <div class="btn-group">
                                <a href="policies/edit"  rel="popUpBox" oncloseFunction = "reloadDiv('/policies','mainContent', 'ajax');" class="btn btn-default light hidden-lg"><i class="fa fa-plus"></i></a>
                            </div>
                        </span>
                    <?php } ?><div class="clearfix"></div>
                </div>
                <div class="panel-menu admin-form theme-primary pbn p5">                 
                    <div class="row">                    
                        <form resultDiv='mainContent' name="searchAssets" id="searchAssets" method="post" class="form-inline col-xs-12 pln pb5" keepVisible="1" keepResult="1" action="/policies/" rel="ajaxifiedForm">      
                            <div class="col-lg-12 prn">
                                <label for="name" class="field prepend-icon">
                                    <input class="event-name gui-input br-light light mbn search-input" type="text" name="searchTitle" placeholder="Search" value="<?php echo $searchTitle = ( isset($_POST['searchTitle']) && $_POST['searchTitle'] != '' ) ? $_POST['searchTitle'] : ''; ?>" />
                                    <label for="name" class="field-icon"><i class="fa fa-search"></i></label>
                                    <div class="btn-fix-right">
                                        <button type="submit" class="submit-btn button btn-success pull-left mr5"><i class="fa fa-search hidden-lg"></i><span class="visible-lg">Search</span></button>
                                        <button type="reset" class="reset-btn button btn-danger"><i class="fa fa-refresh hidden-lg"></i><span class="visible-lg">Reset</span></button>    
                                    </div>
                                </label>
                            </div>
                        </form>               
                    </div>                    
                </div>
                <div class="panel-body pn task-widget">
                    <div class="">
                        <div class="list-com" id="list-com">
                            <div class="col-sm-12 pn com-detail pt10 bg-light">
                                <div class="col-sm-4 col-xs-12"><p><strong>Policy Title</strong></p></div>
                                <div class="clearfix"></div>
                            </div>
                            <?php if (empty($list->data)) { ?>
                                <div class="col-sm-12 com-detail p15">
                                    <div class="col-sm-12">Policies Not Found</div>
                                </div>
                                <?php
                            } else {
                                $i = 1;
                                foreach ($list->data as $companypolicy) {
                                    ?>
                                    <div class="com-detail col-sm-12 pt5 pb5" id="section_<?php echo $companypolicy->id ?>">
                                        <div class="text-left">
                                            <a id="" class="showdiv" href="#<?php echo $i; ?>a" data-toggle="tab"><?php echo trim($companypolicy->title); ?></a> 
                                            <?php if ($webUserRole == 2) { ?>
                                                <span class="pull-right">
                                                    <a href="" id="" class="btn btn-danger br2 btn-xs closediv" onclick="deleteRow('<?php echo $companypolicy->id ?>', '<?php echo $companypolicy->title; ?>', 'deletecompanypolicy', '/policies', 'Company Policy');
                                                                            ('<?php echo $companypolicy->id ?>');"><span class="fa fa-close"></span></a>  
                                                                    </span>
                                                   <?php } ?>
                                        </div>
                                    </div>
                                    <?php
                                    $i = $i + 1;
                                }
                            }
                            ?>
                            <div class="col-sm-12">
                                <div class="pull-left">
                                    <h5><?php echo $list->getCurrentPageInfo(); ?></h5>
                                </div>
                                <div class="pull-right" >
                                    <?php echo $list->printPageNumbers(array('url' => "/policies", 'div_id' => 'mainContent', 'ajaxRequest' => true)); ?>
                                </div>
                            </div>
                        </div>            
                    </div>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-xs-12 tab-content policiesupdate" >
            <div id="" class="resultDiv1"></div>
            <?php
            $i = 1;
            foreach ($list->data as $companypolicy) {
                ?>                  
                <div class="tab-pane <?php
                if ($i < 2) {
                    echo 'active';
                }
                ?>" id="<?php echo $i; ?>a" >                
                    <div class="col-xs-12 pull-right ">
                        <?php
                        if ($webUserRole == 2) {
                            if ($companypolicy) {
                                ?>
                                <div class="panel mb25 mt5">            
                                    <div id="policy<?php echo $i;?>ResultDiv" class="policyResultDiv"></div>
                                    <div class="panel-heading"><span class="panel-title"> <i class="fa fa-file-text"></i> Update Policy</span>
                                        <div class="clearfix"></div>
                                    </div>
                                    <form keepVisible="1" role="form" resultDiv="policy<?php echo $i;?>ResultDiv" action="/savecompanypolicy/<?php echo $companypolicy->id; ?>" method="POST" id="policy<?php echo $i;?>" rel='ajaxifiedForm' autocomplete="off" backToPage="/policies" successMsg="Policy Update Successfully!">    
                                        <div class="panel-body p5 pbn">
                                            <div class="tab-content pn br-n admin-form">
                                                <div id="tab1_1" class="tab-pane active">
                                                    <div class="section row mbn">
                                                        <div class="col-md-12 pn">
                                                            <input  type="hidden" name="asset_type_id" value="4">
                                                            <div class="section ">
                                                                <div class="col-xs-12 mb5">
                                                                    <label for="policytitle" class="field prepend-icon">
                                                                        <input id="policytitle" type="text" name="title" placeholder="Policy Title" value="<?php echo htmlspecialchars($companypolicy->title); ?>" class="certificatetitle event-name gui-input br-light light required">
                                                                        <label for="policytitle" class="field-icon"><i class="fa fa-file-text"></i></label>
                                                                    </label>
                                                                </div>
                                                            </div>
                                                            <div class="section row mbn">
                                                                <div class="col-xs-12">
                                                                    <label for="description" class="field prepend-icon">
                                                                        <textarea id="description" type="text" name="description" placeholder="Add Desription Here..." class="summernote event-name gui-textarea br-light light required"><?php echo $companypolicy->description; ?></textarea>
                                                                        <label for="description" class="field-icon"></label>
                                                                    </label>
                                                                </div>
                                                            </div>                                                       
                                                            <div class="clearfix"></div>                                                   
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="clearfix"></div>
                                            </div>
                                        </div>
                                        <div class="panel-footer text-right bg-wild-sand savenoteenter">
                                            <input type="submit" class="btn btn-success btn-sm ph15 savenote" value="Update Policy">
                                        </div>
                                    </form>
                                </div>

                                <?php
                            }
                        } else {
                            ?>

                            <div class="panel mb25 mt5">            
                                <div class="panel-heading"  id="title" >
                                    <i class="fa fa-text"></i>
                                    <span id="id_of_title" class="panel-title id_of_title" ><?php echo $companypolicy->title; ?>
                                    </span>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="">
                                    <div class="panel-body"><?php echo $companypolicy->description; ?></div>
                                </div>                                
                            </div>
                        <?php } ?>                
                    </div>
                </div>      
                <?php
                $i = $i + 1;
            }
            ?>      
        </div>       
        <div class="clearfix"></div>
        <?php
        if ($webUserRole == 2) { ?>
        <span class="sliding-div">
            <div class="btn-group">
              <button type="button" class="light div-slider-box visible-lg"><i class="fa fa-sign-out"></i></button>
            </div>
        </span>
         <?php } ?>
    </div>

    <div id="add_new_policy_popup" class="side-div">
        <?php
        if ($webUserRole == 2) {
            if (!empty($addform))
                echo $addform;
        }
        ?>
    </div>

</section>

<script type="text/javascript">

    jQuery(document).ready(function () {
        "use strict";
        $('.summernote').summernote({
            height: 290, //set editable area's height
            focus: false, //set focus editable area after Initialize summernote
            oninit: function () {
            },
            onChange: function (contents, $editable) {
            },
        });


        $('.policiesupdate').hide(); // hide edit panel //vai
        $(".closediv").click(function () { //hideclose div click //vaib
            $('.policiesupdate').hide();
            $('#animation-switcher .changeclass').removeClass('col-sm-6 col-xs-12').addClass('col-sm-12');
        });
        $(".showdiv").click(function () { // show div on click // vai
            $('#animation-switcher .changeclass').removeClass('col-sm-12').addClass('col-sm-6 col-xs-12');
            $('.policiesupdate').show();
        });
    });
</script>
<script>
$(".reset-btn").click(function(){
  $(this).parents("form").find(".search-input").val("");
  $(this).parents("form").find(".submit-btn").click();
});
</script>
