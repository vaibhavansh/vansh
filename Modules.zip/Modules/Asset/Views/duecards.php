<section class="">
    <div class="bs-components">
        <div id="add<?php echo $title; ?>ResultDiv" class="resultDiv"></div>
        <div class="panel panel-widget draft-widget">
            <div class="panel-heading"><span class="panel-icon"><i class="fa fa-ticket  "></i></span><span class="panel-title"> <?php echo $title; ?></span> 
                <span class="pull-right fix-right">
                    <div class="btn-group text-right">
                        <?php if($duecards){?>
                            <a rel="ajaxRequest" href="/viewticket/59" class="btn btn-info btn-sm ph15">View All </a>
                        <?php }?>
                    </div>
                </span>
            </div>
            <div class="panel-body pn">
                <?php if (!empty($duecards)) { ?> 
                    <div class="table-responsive of-a">
                        <table class="table table-striped admin-form theme-warning tc-checkbox-1 fs13">
                            <tbody id="bookmarktbody">
                                <?php foreach ($duecards as $duecard) {
                                    if($duecard->release_date != '0000-00-00'){ ?>                                 
                                        <tr>
                                            <td class="text-left">
                                                <a card-id="<?php echo $duecard->id; ?>" class="card card<?php echo $duecard->id; ?>"  href="/viewticket/<?php echo $duecard->id; ?>" rel="popUpBoxHR"><?php echo $duecard->title; ?></a>
                                                <span class="pull-right">   <?php Core_Models_Utility::printFormatedDates(array('startDate' => $duecard->release_date)); ?> </span>
                                            </td>
                                        </tr>
                                <?php }}?> 
                            </tbody>
                        </table>
                    </div><?php
                    } else {?>
                       <div class="table-responsive of-a p15">
                        No cards
                    </div>
                    <?php } ?>
            </div>
        </div>
    </div>
</section>