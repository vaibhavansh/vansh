<?php if (!empty($assetImages)) { ?>
            <?php foreach ($assetImages as $assetImage) { ?>
                <div id="mix_<?php echo $assetImage->id; ?>" class="mix col-lg-2 col-md-3 col-sm-4 col-xs-6 mt5">
                    <?php $assetImageId = Asset_Models_AssetImage::getIdByImageId($assetImage->id); ?>
                    <div id="section" class="panel p6 pbn">
                        <div class="of-h">
                            <?php $assetImageobj = new Asset_Models_AssetImage($assetImageId);
                            $assetImageobj->printImageFancy();?>
                             <?php if(empty($readonly)){ ?>
                                <div class="section admin-form row p10">
                                    <div class="col-xs-6">
                                        <a class="button btn-info col-lg-12 pull-left" target="_blank" href="/images/<?php echo  $assetImage->id; ?>_main.jpg"><i class="fa fa-download"></i></a>
                                    </div>
                                    <div class="col-xs-6">
                                        <a class="button btn-danger col-xs-12 pull-right" rel="ajaxRequestShowResultHR" data-href="/deleteassetimage/<?php echo  $assetImage->id; ?>/<?php echo $asset_id; ?>" resultdiv="assetImage<?php echo $asset_id?>ResultDiv" parameterid="<?php echo  $assetImage->id; ?>" parameter="removeimage" confirmMsg="Are you sure to remove image." ><i class="fa fa-close"></i></a>
                                    </div>
                                </div>
                             <?php } ?>
                        </div>
                    </div>
                </div>
            <?php } 
        if (count($assetImages) > 9) {
        $randval = rand();?>
        <div id="imageloading<?php echo $randval; ?>" class="text-center">
            <div class="clearfix"></div>
            <a class="btn btn-info fs12 btn-lg mt20 mb20" resultDiv="imageloading<?php echo $randval; ?>" data-href="/assetimage/<?php echo $asset_id . '/' . ++$pageNumber; ?>"  removeDiv="imageloading<?php echo $randval; ?>" appendDiv="assetImage<?php echo $asset_id ?>ResultDiv" rel="ajaxRequestAppendResultHR" > Load More... </a>
        </div>
    <?php
    } ?>
<?php }else{
    echo '<div class="p15" >
        <span class="panel-icon"><i class="glyphicon glyphicon-paperclip"></i></span>
        <span class="panel-title" contenteditable="true">No Attachment Yet !</span>
    </div>';
}?>