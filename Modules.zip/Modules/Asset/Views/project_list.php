<?php
global $page;
$rand = rand(10, 1000);
?>
<section class="">
    <div class="panel-menu theme-primary p5 pbn">
        <div class="panel mb5 mtn">
            <div class="panel-heading text-center">
                <span class="panel-icon col-sm-12 hidden-xs"><i class="fa fa-line-chart hidden-xs fs20"></i> Projects</span>
                <span class="panel-icon col-xs-12 visible-xs text-left">Projects</span>
                <span class="pull-right fix-right">
                    <div class="btn-group text-right">
                        <a href="/projects/edit" rel="popUpBox" class="btn btn-success fs12 btn-xs" ><span class="fa fa-plus"></span> <span class="hidden-xs">Add New</span></a>
                    </div>
                </span>
            </div>
        </div>
    </div>
    <div class="panel-menu pn">          
        <div class=" admin-form pt5">
            <form resultDiv='mainContent' name="searchAssets" id="searchAssets" method="post" class="form-inline col-xs-12 pln pb5" keepVisible="1" keepResult="1" action="/projects/" rel="ajaxifiedForm">        
                <div class="col-lg-12 prn">
                    <label for="name" class="field prepend-icon">
                        <input class="event-name gui-input br-light light mbn search-input" type="text" name="searchTitle" placeholder="Search" value="<?php echo $searchTitle = ( isset($_POST['searchTitle']) && $_POST['searchTitle'] != '' ) ? $_POST['searchTitle'] : ''; ?>" />
                        <label for="name" class="field-icon"><i class="fa fa-search"></i></label>
                        <div class="btn-fix-right">
                            <button type="submit" class="submit-btn button btn-success pull-left mr5"><i class="fa fa-search hidden-lg"></i><span class="visible-lg">Search</span></button>
                            <button type="reset" class="reset-btn button btn-danger"><i class="fa fa-refresh hidden-lg"></i><span class="visible-lg">Reset</span></button>    
                        </div>
                    </label>
                </div>
            </form>            
        </div>
        <div class="clearfix"></div>
    </div>
    <div class="clearfix"></div>
    <div id="animation-switcher" class="tray-center  main-div pn">
        <div id="projects_listing" class="paginationnew">
            <?php
            if (!empty($list->data)) {
                foreach ($list->data as $project) {
                    ?>
                    <div id="project<?php echo $project->id; ?>">
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="panel mb25 mt5">
                                <div id="projects<?php echo $project->id; ?>ResultDiv" class="resultDiv"></div>
                                <div id="projects<?php echo $project->id; ?>priorityResultDiv" class="resultDiv"></div>
                                <form id="projects<?php echo $project->id; ?>" name="projects<?php echo $project->id; ?>" method="POST" keepvisible="1" role="form" action="/saveproject/<?php echo $project->id; ?>" rel="ajaxifiedFormHR" autocomplete="off" successMsg="Project Save Successfully!">
                                    <div class="panel-heading">
                                        <span class="editablebox pull-left col-md-11">
                                            <span class="editableedit btn-info btn"><i class="fa fa-pencil"></i></span>
                                            <span class="panel-icon col-sm-1 hidden-xs"><i class="fa fa-th-list hidden-xs"></i></span>
                                            <a class="btn btn-danger fs12 btn-xs" rel="ajaxRequestShowResultHR" removeDiv="project<?php echo $project->id; ?>" data-href="/archiveitem/<?php echo $project->id; ?>" parameterid="<?php echo $project->id; ?>" parameter="list" confirmmsg="Are you sure to archive project <?php echo $project->title; ?>.">
                                                <span class="fa fa-close"></span>
                                            </a>
                                            <input class="contenteditable" id="project<?php echo $project->id; ?>title" value="<?php echo $project->title; ?>" onkeypress="set('project<?php echo $project->id; ?>title')" name="title" readonly="true" type="text"/>
                                            <button type="submit" class="editablesave btn-success btn" onclick="clearCookie('project<?php echo $project->id; ?>title')">save</button>
                                        </span>
                                        <span class="col-xs-2 prn text-right">
                                            <div class="btn-group text-right">
                                                <a class="btn btn-danger fs12 btn-xs" rel="ajaxRequestShowResultHR" removeDiv="project<?php echo $project->id; ?>" data-href="/archiveitem/<?php echo $project->id; ?>" parameterid="<?php echo $project->id; ?>" parameter="list" confirmmsg="Are you sure to archive project <?php echo $project->title; ?>.">
                                                    <span class="fa fa-close"></span>
                                                </a>
                                            </div>
                                        </span>
                                    </div>
                                </form>
                                <form id="projects<?php echo $project->id; ?>des" name="projects<?php echo $project->id; ?>" method="POST" keepvisible="1" role="form" action="/saveproject/<?php echo $project->id; ?>" rel="ajaxifiedFormHR" autocomplete="off" successMsg="Project Save Successfully!" resultDiv="projects<?php echo $project->id; ?>ResultDiv">
                                    <div class="panel-body p10 mimh-100">
                                        <div class="editablebox">
                                            <span class="editableedit btn-info btn"><i class="fa fa-pencil"></i></span>
                                            <textarea id="project<?php echo $project->id; ?>description" class="contenteditable" readonly="true" name="description" onkeypress="set('project<?php echo $project->id; ?>description')"><?php echo $project->description; ?></textarea>
                                            <button type="submit" class="editablesave btn-success btn" onclick="clearCookie('project<?php echo $project->id; ?>description')">save</button>
                                        </div>
                                    </div>
                                </form>
                                <div class="panel-footer bg-wild-sand text-right">
                                    <?php if ($page->currentUser->webUserRole == 2) {?>
                                        <div class="pull-left">
                                            <form id="projects<?php echo $project->id; ?>priority" method="POST" keepvisible="1" role="form" action="/productive/<?php echo $project->id; ?>" rel="ajaxifiedFormHR" autocomplete="off" successMsg="Project Productive Save Successfully!">
                                                <input type="checkbox" name="priority" id="priority<?php echo $project->id;?>" <?php if($project->priority==2){echo ' checked="checked"';}?> class="toggletrigger" data-trigger="btnpriority<?php echo $project->id;?>"> <label for="priority<?php echo $project->id;?>">Non productive</label>
                                                <input type="submit" value="save" class="btnpriority<?php echo $project->id;?>" style="display:none;"/>
                                            </form>
                                        </div>
                                    <?php }?>
                                    <a href="/projecttimereport/<?php echo $project->id; ?>/" rel="ajaxRequestHR" class="btn btn-info btn-sm ph15">Project Time Report</a>
                                    <a href="/lists/<?php echo $project->id; ?>/" rel="ajaxRequestHR" class="btn btn-success btn-sm ph15">Open Project</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                }
            } else {
                echo '<div class="col-xs-12"><div class="panel mb25 mt5"><div class="panel-heading"><h3>No Projects Found</h3></div></div></div>';
            }
            ?>
            <div class="clearfix visible-sm visible-lg visible-md visible-xs"></div>                 
        </div>   
        <div class="clearfix"></div>
        <div id="pagingControls" class="pull-left">
            <h5><?php echo $list->getCurrentPageInfo(); ?></h5>
        </div>
        <div class="pull-right" >              
            <ul class="pagination bootpag">  
                <?php echo $list->printPageNumbers(array('url' => "/projects", 'div_id' => 'mainContent', 'ajaxRequest' => true)); ?>
            </ul>
        </div>  
        <div class="clearfix" ></div>
        <span class="sliding-div">
            <div class="btn-group">
                <button type="button" class="light div-slider-box visible-lg"><i class="fa fa-sign-out"></i></button>
            </div>
        </span>
    </div>
    <div id="add_new_project_popup" class="side-div">
        <?php if (!empty($addform)) echo $addform; ?>
    </div>
</section>
<script>
    $(".reset-btn").click(function()
    {
        $(this).parents("form").find(".search-input").val("");
        $(this).parents("form").find(".submit-btn").click();
    });
</script>