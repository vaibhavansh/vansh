<?php if (empty($asset->id)) { ?>
    <div id="modal-form" class="mfp-with-anim">
        <div class="panel">
            <!-- create new order panel-->
            <div id="saveBlogResultDiv" class="resultDiv"></div>
            <div class="panel mbn mt-0">
                <div class="panel-heading">
                    <span class="panel-title"> 
                        <i class="fa fa-pencil hidden-xs"></i>New Blog
                    </span><div class="clearfix"></div>
                </div>
                <div class="panel-body p20 pb10">
                    <div class="tab-content pn br-n admin-form">
                        <div id="tab1_1" class="tab-pane active">
                            <div class="section row mbn">
                                <div class="col-md-12 pl15 pbn">
                                    <form keepVisible="1" role="form" resultDiv="saveBlogResultDiv" close_popup="1" action="/saveblog" method="POST" id='saveBlog' rel='ajaxifiedForm' autocomplete="off" backToPage="/blogs" successMsg="Blog Added Successfully!">
                                        <input type="hidden" id="assettype" name="asset_type_id" value="6">
                                        <input type="hidden" id="published" class="published" name="published" value="1">
                                        <div class="section row mb15">
                                            <div class="col-xs-12">
                                                <label for="title" class="field prepend-icon">
                                                    <input id="title" type="text" name="title" placeholder="Blog Title" class="event-name gui-input br-light light required" autocomplete="off" required="">
                                                    <label for="title" class="field-icon"><i class="fa fa-file"></i></label>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="section row mb15">
                                            <div class="col-xs-12">
                                                <label for="description" class="field prepend-icon">
                                                    <textarea id="description_0" type="textarea" name="description" placeholder="Blog Description" class="event-name gui-textarea br-light light required" autocomplete="off" required=""></textarea>
                                                    <script>
                                                        $('#description_0').summernote({height: 250});
                                                    </script>

                                                </label>
                                            </div>
                                        </div>
                                        <div class="section row mb15">
                                            <div class="col-xs-12">
                                                <label for="file1" class="field file"><span class="button btn btn-primary"> Choose File</span>
                                                    <input id="attachments" multiple="multiple" type="file" name="attachments[]" onchange="document.getElementById('uploader1').value = this.value;" class="gui-file">
                                                    <input id="uploader1" type="text" placeholder="no file selected" readonly="" class="gui-input">
                                                </label>
                                            </div>
                                        </div>
                                        <div class="section row mb15">
                                            <div class="col-xs-12">
                                                <label for="tags" class="field prepend-icon">
                                                    <input id="tags" type="text" name="custom_fields" placeholder="Tags" class="event-name gui-input br-light light required" autocomplete="off" required="">
                                                    <label for="tags" class="field-icon"><i class="glyphicon glyphicon-tags"></i></label>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="section row mb15">
                                            <div class="mr10 pull-right">
                                                <a class="button btn btn-danger col-xs-12 pull-right closepopup" > Cancel </a>
                                            </div>                                            
                                            <div class="mr10 pull-right">
                                                <button class="button btn-success pull-right submit-btn" type="submit" id="submit">Save & Publish</button>
                                            </div>
                                            <div class="mr10 pull-right">
                                                <button class="button btn-success pull-right savedraft-btn" type="button" id="">Save Draft</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php } else { ?>
    <div id="blog<?php echo $asset->id; ?>ResultDiv" class="resultDiv"></div>
    <div id="modal-form" class="admin-form mfp-with-anim">
        <div class="panel">
            <div class="panel-heading"><span class="panel-title"><i class="fa fa-pencil"></i>Edit Blog</span><div class="clearfix"></div></div>
            <form id="blog<?php echo $asset->id; ?>" name='blog<?php echo $asset->id; ?>' method="POST" successMsg="Blog Updated Successfully!" keepVisible="1" role="form" action="/saveblog/<?php echo $asset->id; ?>" backToPage='/blogs' rel='ajaxifiedForm' autocomplete="off" close_popup="1">

                <input type="hidden" id="assetTag" name="asset_id" value="<?php echo $asset->id; ?>"> 
                <input type="hidden" id="asset_type_id" name="asset_type_id" value="<?php echo $asset->asset_type_id; ?>" />
                <input type="hidden" id="published" class="published" name="published" value="1">
                <div class="">
                    <div class="panel-body p15 pbn">
                        <div class="row">
                            <div class="col-md-12 mb15">
                                <label for="blogtitle" class="field prepend-icon">
                                    <input id="title" type="text" name="title" placeholder="Blog Title" class="gui-input" value="<?php echo $asset->title; ?>">
                                    <label for="blogtitle" class="field-icon"><i class="fa fa-key"></i></label>
                                </label>
                            </div>
                            <div class="col-md-12 mbn">
                                <label for="blogdescription" class="field prepend-icon">                                    
                                    <textarea id="description_<?php echo $asset->id; ?>" type="textarea" name="description" placeholder="Blog Description" class="event-name gui-textarea br-light light required" autocomplete="off" required=""><?php echo $asset->description; ?></textarea>
                                    <script>
                                        $('#description_<?php echo $asset->id; ?>').summernote({height: 250});
                                    </script>
                                </label>
                            </div>
                        </div>
                    </div>
                    <hr class="mb5 mt5"/>  
                        <div class="panel-body pn">
                            <div id="assetImage<?php echo $asset->id ?>ResultDiv">
                                <?php echo $assetImages; ?>
                            </div>
                        </div>
                    <div class="section col-xs-12 mb5">
                        <div class="col-xs-12">
                            <label for="file1" class="field file"><span class="button btn-primary"> Choose File</span>
                                <input id="attachments" multiple="multiple" type="file" name="attachments[]" onchange="document.getElementById('uploader1').value = this.value;" class="gui-file">
                                <input id="uploader1" type="text" placeholder="no file selected" readonly="" class="gui-input">
                            </label>
                        </div><div class="clearfix"></div>
                    </div><div class="clearfix"></div>                    
                    <div class="section col-xs-12 mb5">
                        <div class="col-xs-12">
                            <label for="tags1" class="field prepend-icon">
                                <input id="tags1" type="text" name="custom_fields" placeholder="Tags" class="event-name gui-input br-light light required" value="<?php echo $asset->custom_fields; ?>" autocomplete="off" required="">
                                <label for="tags1" class="field-icon"><i class="glyphicon glyphicon-tags"></i></label>
                            </label>
                        </div>
                    </div><div class="clearfix"></div>             
                </div>
                <div class="panel-footer">
                    <div class="mr10 pull-right">
                        <a class="button btn-danger col-xs-12 pull-right closepopup" > Cancel </a>
                    </div>
                    <div class="mr10 pull-right">
                        <button type="submit" id="<?php echo $asset->id; ?>" class="button btn-success pull-right submit-btn">Save & Publish</button>
                    </div>
                    <div class="mr10 pull-right">
                        <button class="button btn-success pull-right savedraft-btn" type="button" id="">Save Draft</button>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </form>
            <script type="text/javascript">
                function deleteImage(imageid, contentid)
                {
                    var msg = 'Are you sure to delete.\nThis will delete this content';
                    if (confirm(msg)) {
                        $.post('/deleteblogimage/' + imageid + '/' + contentid, {
                            pageRequestType: 'ajax'
                        }, function (data) {
                            if (data.indexOf('Delete Success') !== -1) {
                                $('#mix_' + imageid).hide();
                            }
                        });
                    }
                }
            </script>
            <!-- /input-group-->
        </div>    
    <?php } ?>
    <script>
        $(document).ready(function () {
            $(".savedraft-btn").click(function () {
                $(this).parents("form").find(".published").val("2");
                $(this).parents("form").find(".submit-btn").click();
            });
        });
    </script>
</div>
