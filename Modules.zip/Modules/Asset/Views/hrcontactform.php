
<div class="contactFormWrapp">

    <div class="container">
        <div class="col-sm-12 columns">
            <h1>Contact us</h1>
            <p>Our team is read to make your dreams come true</p>
        </div>

        <div class="col-sm-12 columns formWrapp">
            <div class="clearfix"></div>
            <div id="contactUsResultDiv" class="resultDiv"></div>            
            <div class="clearfix"></div>
            <form keepVisible="1" role="form" resultDiv="contactUsResultDiv" action="/contactus" method="POST" id='contactUs' rel='ajaxifiedForm' autocomplete="off" backToPage="" successMsg="Send Successfully">
                <input type="text" name="name" placeholder="NAME:" class="required col-xs-12 mb-30">
                <input type="email" name="email" placeholder="EMAIL:" class="required col-xs-12 mb-30">
                <textarea name="message" class="col-xs-12 mb-30 required" cols="30" rows="10" placeholder="MESSAGE:"></textarea>
                <input type="submit" value="Send Message">
            </form>
        </div>
    </div>
</div>
<div id="successRoad">
    <div class="">
        <div class="col-md-4 col-sm-6 columns grayHolder">
            <h3 class="text-center">Important Links</h3>
            <div class="blogInfo">        
                <ul>
                    <?php foreach ($importantLinks as $importantLink) { ?>
                        <li><a href="<?php BASE_PATH_ROOT; ?>/pages/<?php echo $importantLink->slug; ?>" class="opennewtab"><?php echo $importantLink->title; ?></a></li>
                    <?php } ?>
                </ul>
            </div>
        </div>
        <div class="col-md-8 col-sm-6">
            <div class="col-md-6 columns">
            </div>
            <div class="col-md-6 columns contact-info">
                <h3 class="text-center">Contant Details</h3>
                <ul>
                    <li><a href="mailto:hr@bezoarsoftware.com">hr@bezoarsoftware.com</a></li>
                    <li>102, FBC Indore, MP, India</li>
                </ul>
            </div>
        </div>
        <div class="clearfix"></div>
    </div>
</div>