<div class="panel mb25 mt5">
    <div id="policyResultDiv" class="policyResultDiv"></div>  
    <?php if (empty($asset->id)) { ?>
        <div class="panel-heading"><span class="panel-title"> <i class="fa fa-file-text"></i> Add New Policy</span>
        </div>
        <div class="panel-body p20 pb10">
            <div class="tab-content pn br-n admin-form">
                <div id="tab1_1" class="tab-pane active">
                    <div class="section row mbn">
                        <div class="col-md-12 pn">                            
                            <form id="policy" name="policy" method="POST" close_popup="1" keepvisible="1" role="form" action="/savecompanypolicy" rel="ajaxifiedForm" autocomplete="off" backToPage="/policies" successMsg="Policy Added Successfully!" >
                                <input type="hidden" name="asset_type_id" value="4" />
                                <div class="section row mb15">
                                    <div class="col-xs-12">
                                        <label for="policytitle" class="field prepend-icon">
                                            <input type="text" name="title" placeholder="Policy's Title" class="event-name gui-input br-light light required" aria-required="true">
                                            <label for="policytitle" class="field-icon"><i class="fa fa-file-text"></i></label>
                                            <p class="policytitleerror"></p>
                                        </label>
                                    </div>
                                </div>
                                <div class="section row mb15">
                                    <div class="col-xs-12">
                                        <label for="description" class="field prepend-icon">
                                            <textarea type="text" name="description" placeholder="Add Desription Here..." class="event-name gui-textarea br-light light required"  aria-required="true"></textarea>
                                            <label for="description" class="field-icon"><i class="fa fa-file-o"></i></label>
                                            <p class="policydescriptionerror"></p>
                                        </label>
                                    </div>
                                </div>                                  
                                <div class="section row mb15">
                                    <div class="col-xs-12">
                                        <input type="submit" value="Add Policy" class="button btn-success col-xs-12 pull-right save_policies" >  
                                    </div>
                                </div>
                            </form>     
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    <?php } ?>
</div>   <!-- menu quick links-->
