<?php
foreach ($employeeDetails as $mydata) {
    $a = json_decode($mydata->custom_fields);
    ?>
    <div class="container" id="table">       
        <div class="col-lg-12 ">
            <div class="row" id="mydiv">   
                <h2 align="center">Employee Details</h2>
            </div>

            <div class="row" id="mydiv">   
             <img src="http://local.hrbezoar.com/images/bollyduniya-logo.png"  alt="" class="img-responsive __web-inspector-hide-shortcut__">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <td colspan="5"><h4>Personal Details</h4></td>       
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Name</td>
                            <td>
                                <?php
                                if ($a->firstName) {
                                    echo ucfirst($a->firstName) . ' ' . ucfirst($a->lastName);
                                } else {
                                    echo "null";
                                }
                                ?>
                            </td>

                            <td>Date of Birth</td>
                            <td><?php
                                if ($a->dob) {
                                    echo $a->dob;
                                } else {
                                    echo "null";
                                }
                                ?></td>
                        </tr>
                        <tr>
                            <td>Birth Place</td>
                            <td><?php
                                if ($a->birthPlace) {
                                    echo $a->birthPlace;
                                } else {
                                    echo "null";
                                }
                                ?></td>

                            <td>Height/Weight</td>
                            <td colspan="2"><?php
                                if ($a->heightWidth) {
                                    echo $a->heightWidth;
                                } else {
                                    echo "null";
                                }
                                ?></td>
                        </tr>
                        <tr>
                            <td>Blood Group </td>
                            <td><?php
                                if ($a->bloodGroup) {
                                    echo $a->bloodGroup;
                                } else {
                                    echo "null";
                                }
                                ?></td>

                            <td>Age</td>
                            <td colspan="2"><?php
                                if ($a->age) {
                                    echo $a->age;
                                } else {
                                    echo "null";
                                }
                                ?></td>
                        </tr>
                        <tr>
                            <td>Disability</td>
                            <td colspan="4"><?php
                                if ($a->disability) {
                                    echo $a->disability;
                                } else {
                                    echo "null";
                                }
                                ?></td>
                        </tr>
                        <tr>
                            <td>Email Id </td>
                            <td><?php
                                if ($a->emailAddress) {
                                    echo $a->emailAddress;
                                } else {
                                    echo "null";
                                }
                                ?></td>

                            <td>Marital Status</td>
                            <td colspan="2"><?php
                                if ($a->maritalStatus) {
                                    echo $a->maritalStatus;
                                } else {
                                    echo "null";
                                }
                                ?></td>
                        </tr>
                        <tr>
                            <td>Mobile Number</td>
                            <td><?php
                                if ($a->mobileNumber) {
                                    echo $a->mobileNumber;
                                } else {
                                    echo "null";
                                }
                                ?></td>

                            <td>Local Contact No.</td>
                            <td><?php
                                if ($a->localContact) {
                                    echo $a->localContact;
                                } else {
                                    echo "null";
                                }
                                ?></td>

                        </tr>
                        <tr>                          
                            <td>Permanent Contact No.</td>
                            <td><?php
                                if ($a->permanentContact) {
                                    echo $a->permanentContact;
                                } else {
                                    echo "null";
                                }
                                ?></td>

                            <td>Hobbies</td>
                            <td><?php
                                if ($a->hobbies) {
                                    echo $a->hobbies;
                                } else {
                                    echo "null";
                                }
                                ?></td>

                        </tr>
                        <tr>
                            <td>Nationality</td>
                            <td><?php
                                if ($a->nationality) {
                                    echo $a->nationality;
                                } else {
                                    echo "null";
                                }
                                ?></td>

                            <td>Religion</td>
                            <td colspan="2"><?php
                                if ($a->religion) {
                                    echo $a->religion;
                                } else {
                                    echo "null";
                                }
                                ?></td>
                        </tr>
                    </tbody>
                </table>

                <table class="table table-bordered">
                    <thead>                        
                        <tr>
                            <td colspan="5"><h4>Educational Background</h4></th>    

                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td style="font-weight: bold;">UG, Graduation, PG & diplomas if any.</td>
                            <td style="font-weight: bold;">Specialization</td>
                            <td style="font-weight: bold;">Grade attained</td>
                            <td style="font-weight: bold;">University & City</td>
                            <td style="font-weight: bold;">Year of completion</td>
                        </tr>
                        <?php
                        $Educational = $a->graduaction;
                        foreach ($Educational as $key => $cc) {
                            if ($cc) {
                                ?>
                                <tr>
                                    <td align=""><?php echo $a->graduaction[$key]; ?></td>
                                    <td align=""><?php echo $a->specialization[$key]; ?></td>
                                    <td align=""><?php echo $a->GradeAttained[$key]; ?></td>
                                    <td align=""><?php echo $a->universityCity[$key]; ?></td>
                                    <td align=""><?php echo $a->yearCompletion[$key]; ?></td>
                                </tr>

                                <?php
                            } else {
                                echo "";
                            }
                        }
                        ?>
                    </tbody>
                </table>

                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <td colspan="5"><h4>Prior Experience</h4></th>    
                        </tr>
                    </thead>
                    <tbody
                        <tr>
                            <td style="font-weight: bold;">Post held </td>
                            <td style="font-weight: bold;">Department/Function</td>
                            <td style="font-weight: bold;">Company Name</td>
                            <td style="font-weight: bold;">City</td>
                            <td style="font-weight: bold;">Tenure </td>
                        </tr>
                        <?php
                        $PriorExperience = $a->pstHeld; //                              
                        foreach ($PriorExperience as $key => $cc) {
                            if ($cc) {
                                ?>

                                <tr>
                                    <td align=""><?php echo $a->pstHeld[$key]; ?></td>
                                    <td align=""><?php echo $a->departmentFunction[$key]; ?></td>
                                    <td align=""><?php echo $a->company[$key]; ?></td>
                                    <td align=""><?php echo $a->city[$key]; ?></td>
                                    <td align=""><?php echo $a->tenurein[$key]; ?></td>
                                </tr>

                                <?php
                            } else {
                                echo "";
                            }
                        }
                        ?>
                    </tbody>
                </table>

                <table class="table table-bordered">
                  
                        <tr>
                            <td colspan="5"><h4>Family Details</h4></th>    
                        </tr> 

                   
                  
                        <tr>
                            <td>Father's Full Name</td>
                            <td><?php echo $a->fatherName; ?></td>
                            <td>Age</td>
                            <td colspan="2"><?php echo $a->fatherAge; ?></td>                              
                        </tr>
                        <tr>
                            <td>Occupation</td>
                            <td><?php echo $a->fatherOccupation; ?></td>
                            <td>Current Work Status</td>
                            <td colspan="2"><?php echo $a->fatherCurrentWork; ?></td>                              
                        </tr>
                        <tr>
                            <td>Mothers Maiden Name</td>
                            <td><?php echo $a->motherName; ?></td>
                            <td>Current Work Status</td>
                            <td><?php echo $a->motherOccupation; ?></td>                              
                        </tr>
                        <tr>
                            <td style="font-weight: bold;">Brothers/Sisters </td>
                            <td style="font-weight: bold;">Current Work Status</td>
                            <td style="font-weight: bold;">Educational Status </td>
                            <td style="font-weight: bold;">Marital Status </td>
                            <td style="font-weight: bold;">Residing In </td>
                        </tr>
                        <?php
                        $FamilyDetails = $a->brotherSister; //                         
                        foreach ($FamilyDetails as $key => $cc) {
                            if ($cc) {
                                ?>

                                <tr>
                                    <td align=""><?php echo $a->brotherSister[$key]; ?></td>
                                    <td align=""><?php echo $a->brotherSisterCurrentWork[$key]; ?></td>
                                    <td align=""><?php echo $a->brotherSisterEducational[$key]; ?></td>
                                    <td align=""><?php echo $a->brotherSisterMaritalStatus[$key]; ?></td>
                                    <td align=""><?php echo $a->residingIn[$key]; ?></td>
                                </tr>

                                <?php
                            } else {
                                echo "";
                            }
                        }
                        ?>   </tbody>
                </table>
            </div>
        </div>
    </div>

<?php } ?>

<button onclick="printDiv();">Print it</button>
<script>
    function printDiv() {
        var divToPrint = document.getElementById('table');
        var htmlToPrint = '' +
                '<style type="text/css">' +
                'table  {' +
                'width: 100%;table-layout: auto;border:1px solid #000;' +              
                '}' +
              
                 'tr:nth-child(even)  {' +
                ' background-color: #f2f2f2' +              
                '}' +
                '</style>';
        htmlToPrint += divToPrint.outerHTML;
        newWin = window.open("");
        newWin.document.write(htmlToPrint);
        newWin.print();
        newWin.close();
    }</script>