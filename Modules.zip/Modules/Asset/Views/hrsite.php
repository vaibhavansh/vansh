<?php echo Core_Models_Utility::includeCSS('https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css', 'url'); ?>
<?php echo Core_Models_Utility::includeCSS('https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css', 'url'); ?>
<?php echo Core_Models_Utility::includeCSS('/hrdemo/css/layout-multi.css', 'url'); ?>
<?php echo Core_Models_Utility::includeCSS('/hrdemo/css/styles.css', 'url'); ?>
<?php echo Core_Models_Utility::includeCSS('http://fonts.googleapis.com/css?family=Lato:300,400,700,900,300italic', 'url'); ?>
<?php echo Core_Models_Utility::includeCSS('http://fonts.googleapis.com/css?family=Arvo:400,700,400italic,700italic', 'url'); ?>
<?php echo Core_Models_Utility::includeJS('/hrdemo/js/modernizr.custom.js', 'url'); ?>

<svg class="hidden">
<g id="icon-grid">
<rect x="32.5" y="5.5" width="22" height="22"/>
<rect x="4.5" y="5.5" width="22" height="22"/>
<rect x="32.5" y="33.5" width="22" height="22"/>
<rect x="4.5" y="33.5" width="22" height="22"/>
</g>
<g id="icon-cross">
<line x1="4.5" y1="55.5" x2="54.953" y2="5.046"/>
<line x1="54.953" y1="55.5" x2="4.5" y2="5.047"/>
</g>
</svg>
<div class="outer-menu">
    <input class="checkbox-toggle" type="checkbox" />
    <div class="hamburger">
        <div></div>
    </div>
    <nav class="component thumb-nav menu">
        <div>
            <div>
                <ul>
                    <?php
                    if (!empty($hrSiteContents)) {
                        foreach ($hrSiteContents as $key => $hrSiteContent) {
                            $sectionMenuCount = 1;
                            foreach ($hrSiteContent as $sectionKey => $section) {
                                ?>
                                <li><a id="thumb-<?php echo $sectionMenuCount; ?>" data-container="container-<?php echo $sectionMenuCount; ?>" class="thumb-nav__item" href="#"><?php echo $sectionKey; ?></a></li>
                                <?php
                                $sectionMenuCount = $sectionMenuCount + 1;
                            }
                        }
                    }
                    ?>
                    <li><a class="thumb-nav__item redirectlogin opennewtab" href="<?php BASE_PATH_ROOT;?>/login">Employee Login</a></li>
                </ul>
            </div>
        </div>
    </nav>
</div>


<?php
if (!empty($hrSiteContents)) {
    foreach ($hrSiteContents as $key => $hrSiteContent) {
        $sectionCount = 1;
        $descriptions = "";
        foreach ($hrSiteContent as $sectionKey => $section) {
            ?>           

            <div id="container-<?php echo $sectionCount; ?>" class="div-container theme-1" >

                <?php
                $tabs = 1;
                foreach ($section as $data) {
                    if ($tabs < 2) {
                        ?>

                        <header class="intro">
                            <?php
                            $assetImageobj = new Asset_Models_AssetImage($data->assetimageid);
                            $assetImageobj->hrsiteImage($class = "intro__image", $height = "", $width = "", $imagetype = "main");
                            ?>
                            <div class="intro__title">
                                <div class="intro__title__content fade-in">
                                    <h2><?php echo $data->title; ?></h2><br/>
                                    <p class="fade-in-2"><?php echo $data->description; ?></p>
                                </div>
                            </div>
                            <div class="intro__content">

                                <div class='mouse-container'>
                                    <div class='mouse'>
                                        <span class='scroll-down'></span>
                                    </div>
                                    <div>Scroll Down</div>
                                </div>
                                <button class="trigger">
                                    <svg width="100%" height="100%" viewBox="0 0 60 60" preserveAspectRatio="none">
                                    <use class="icon icon--grid" xlink:href="#icon-grid" />
                                    <use class="icon icon--cross" xlink:href="#icon-cross" />
                                    </svg>
                                    <span>Toggle content</span>
                                </button>
                            </div>
                        </header>
                        <?php
                    } else {
                        $descriptions[] = $data->description;
                    }
                    $tabs = $tabs + 1;
                } $sectionCount = $sectionCount + 1;
                ?>
                <div class="items-wrap">
                    <div  class="block-view">
                        <div id="about" class="sectionWrapper clearfix">
                            <div class="overlay contentWrapper">
                                <div class="scrollContent">
                                    <?php
                                    if ($descriptions) {
                                        foreach ($descriptions as $descriptionData) {
                                            echo $descriptionData;
                                        }
                                    }

                                    if (isset($contactForm)) {
                                        echo $contactForm;
                                    }
                                    ?>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php
            $descriptions = "";
        }
    }
}
?>

<div id="footer">
    <div class="footerLogo">
        <ul id="socials">
            <li><a target="_blank" class="facebook-ico" href="#">Facebook</a></li>
            <li><a target="_blank" class="twitter-ico" href="#">Twitter</a></li>
        </ul>
        <a class="copyright" target="_blank" href="www.bezoarsoftware.com">Created by Bezoarsoftware</a>
    </div>
</div>
<?php echo Core_Models_Utility::includeJS('http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js', 'url'); ?>
<?php echo Core_Models_Utility::includeJS('/hrdemo/js/classie.js', 'url'); ?>
<?php echo Core_Models_Utility::includeJS('/hrdemo/js/hrdemo.js', 'url'); ?>

<script>    
    $(document).on('click', '.opennewtab', function () {
        var url = $(this).attr("href");
        window.open(url);
    });
</script>