<div class="panel mb25 mt5"> 
    <div id="AddholidayResultDiv" class="resultdiv"></div>
    <?php if (empty($asset->id)) { ?>
        <div class="panel-heading"><span class="panel-title"> <i class="fa fa-file-text hidden-xs"></i> Add New Holiday</span>
        </div>
        <div class="panel-body p20 pb10">
            <div class="tab-content pn br-n admin-form">
                <div id="tab1_1" class="tab-pane active">
                    <div class="section row mbn">
                        <div class="col-md-12 pn">
                            <form keepVisible="1" role="form" resultDiv="AddholidayResultDiv" close_popup="1" method="POST" rel='ajaxifiedForm' autocomplete="off" backToPage="/holidays" successMsg="Holiday Added Successfully!" id="holiday"  action="/saveholiday/">
                                <div class="section row mb15">
                                    <div class="col-xs-12">
                                        <label for="holidaytitle" class="field prepend-icon">
                                            <input id="holidaytitle" type="text" name="title" placeholder="Enter Holiday's Title" class="holidaytitle event-name gui-input br-light light required " required="required" >
                                            <label for="holidaytitle" class="field-icon"><i class="fa fa-file-text"></i></label>
                                        </label>
                                    </div>
                                </div>
                                <div class="section row mb15">
                                    <div class="col-xs-12">
                                        <label for="release_date" class="field prepend-icon">
                                            <input id="holidaydate<?php echo rand(); ?>"  type="text" name="release_date" placeholder="Enter Holiday's Date" class="release_date event-name gui-input br-light light required datepicker" required="required" >
                                            <label for="release_date" class="field-icon"><i class="glyphicon glyphicon-calendar"></i></label>
                                        </label>
                                    </div>
                                    <input type="hidden" name="asset_type_id" value="5" />
                                </div>
                                <div class="section row mb15">
                                    <div class="col-xs-12">
                                        <button type="submit" class="button btn-success col-xs-12 pull-right" > Add Holiday </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    <?php } else { ?>
        <div id="<?php echo $asset->id ?>holidayResultDiv" class="resultDiv"></div>
        <div class="panel-heading"><span class="panel-title"> <i class="fa fa-file-text hidden-xs"></i> Edit Holiday</span>
        </div>
        <div class="panel-body p20 pb10">
            <div class="tab-content pn br-n admin-form">
                <div id="tab1_1" class="tab-pane active">
                    <div class="section row mbn">
                        <div class="col-md-12 pl15">
                            <form id="<?php echo $asset->id ?>holiday" name="holiday" method="POST" close_popup="1" keepvisible="1" role="form" action="/saveholiday/<?php echo $asset->id ?>" rel="ajaxifiedForm" autocomplete="off" backToPage="/holidays" successMsg="Holiday Saved Successfully!" >
                                <div class="section row mb15">
                                    <input type="hidden" name="asset_type_id" value="<?php echo $asset->asset_type_id; ?>">
                                    <div class="col-xs-12">
                                        <label for="holidaytitle" class="field prepend-icon">
                                            <input id="holidaytitle" type="text" name="title"  value="<?php echo $asset->title; ?>" placeholder="Enter Holiday's Title" class="event-name gui-input br-light light required" required="">
                                            <label for="holidaytitle" class="field-icon"><i class="fa fa-file-text"></i></label>
                                        </label>
                                    </div>
                                </div>
                                <div class="section row mb15">
                                    <div class="col-xs-12">
                                        <label for="dateholiday" class="field prepend-icon">
                                            <input id="dateholiday"  type="text" name="release_date"  value="<?php echo $asset->release_date; ?>" placeholder="Enter Holiday's Date" class=" dateholiday event-name gui-input br-light light required datepicker" required="">
                                            <label for="dateholiday" class="field-icon"><i class="glyphicon glyphicon-calendar"></i></label>
                                        </label>
                                    </div>
                                </div>
                                <div class="section row mb15">
                                    <div class="col-xs-12">
                                        <input type="submit" class="button btn-success col-xs-12 pull-right" value="Update Holiday">
                                    </div>
                                </div>                           
                            </form>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    <?php } ?>
</div>

