<?php
global $page;
$userId = $page->currentUser->id;
if (isset($restrict) && $restrict == true) {
    ?>
    <section class="">
        <div class="col-sm-12 p20">
            <div class="panel mb25 mt5">
                <div class="panel-heading">
                    <span class="pull-left fix-left">
                        <div class="btn-group">
                            <a href="/projects/" rel="ajaxRequestHR" class="btn btn-default light btn-xs fs12"><i class="fa fa-long-arrow-left"></i> <span class="hidden-xs">Back</span></a>
                        </div>
                    </span>
                    <span class="panel-title col-sm-12 text-center"> <i class="fa fa-warning hidden-xs"></i><span> Access Denied </span></span><div class="clearfix"></div>
                </div>
            </div>
        </div>
    </section>
<?php } else { ?>
    <section class="">
        <div class="panel-menu theme-primary p5 pbn">
            <div class="panel mb5 mtn">
                <div id="projects<?php echo $parent_data->id; ?>ResultDiv" class="resultDiv"></div>
                <form id="projects<?php echo $parent_data->id; ?>" name="projects<?php echo $parent_data->id; ?>" method="POST" keepvisible="1" role="form" action="/saveproject/<?php echo $parent_data->id; ?>" rel="ajaxifiedFormHR" autocomplete="off" successMsg="Project Save Successfully!">
                    <div class="panel-heading">
                        <span class="pull-left fix-left">
                            <div class="btn-group">
                                <a href="/projects/" rel="ajaxRequestHR" class="btn btn-default light btn-xs fs12"><i class="fa fa-long-arrow-left"></i> <span class="hidden-xs">Back</span></a>
                            </div>
                        </span>
                        <span class="editablebox col-sm-12 col-xs-12 pn">
                            <span class="editableedit btn-info btn"><i class="fa fa-pencil"></i></span>
                            <input name="title" type="text" class="contenteditable text-center" value="<?php echo $parent_data->title; ?>" readonly="true"/>
                            <button type="submit" class="editablesave btn-success btn">save</button>
                        </span>
                        <span class="pull-right fix-right hidden-lg">
                            <div class="btn-group">
                                <a href="/assetuserlist/<?php echo $parent_data->id; ?>" rel="popUpBox" class="btn btn-default light btn-xs fs12 "><span class="fa fa-user-plus"></span></a>
                            </div>
                            <div class="btn-group">
                                <a href="/editchild/<?php echo $parent_data->id; ?>" rel="popUpBox" class="btn btn-default light btn-xs fs12 "><i class="fa fa-list-alt"></i></a>
                            </div>
                        </span>
                    </div>
                </form>
            </div>        
        </div>
        <div class="panel-menu pn">          
            <div class=" admin-form pt5">
                <form resultDiv='mainContent' name="searchAssets" id="searchAssets" method="post" class="form-inline col-xs-12 pln pb5" keepVisible="1" keepResult="1" action="<?php echo $_SERVER['REQUEST_URI']; ?>" rel="ajaxifiedForm">        
                    <div class="col-lg-12 prn">
                        <label for="name" class="field prepend-icon">
                            <input class="event-name gui-input br-light light mbn search-input" type="text" name="searchTitlechild" placeholder="Search" value="<?php echo $searchTitle = ( isset($_POST['searchTitlechild']) && $_POST['searchTitlechild'] != '' ) ? $_POST['searchTitlechild'] : ''; ?>" />
                            <label for="name" class="field-icon"><i class="fa fa-search"></i></label>
                            <div class="btn-fix-right">
                                <button type="submit" class="submit-btn button btn-success pull-left mr5"><i class="fa fa-search hidden-lg"></i><span class="visible-lg">Search</span></button>
                                <button type="reset" class="reset-btn button btn-danger"><i class="fa fa-refresh hidden-lg"></i><span class="visible-lg">Reset</span></button>    
                            </div>
                        </label>
                    </div>
                </form>            
            </div>
            <div class="clearfix"></div>
        </div>
        <div class="ResultDiv"></div>
        <div id="animation-switcher" class="tray-center main-div pn high80 ovfw-h" style="min-height: 70vh; max-height: 80vh;">
            <?php
            $order = 0;
            if (!empty($list->data)) {
                ?>
                <div class="scroll-page high80">
                    <div id="paginationnew" class="paginationnew task-list-holder">
                        <input type="hidden" id="list_parent" value="<?php echo $parent_id; ?>" />
                        <?php
                        foreach ($list->data as $singlelist) {
                            $order++;
                            ?>
                            <div id="list<?php echo $singlelist->id; ?>" class="task-panel task-widget ui-sortable col-sm-6 col-xs-12" list-id="<?php echo $singlelist->id; ?>" list-order="<?php echo $order; ?>">
                                <!-- Task Widget-->
                                <div class="panel panel-widget">
                                    <form id="lists<?php echo $singlelist->id; ?>" name="lists<?php echo $singlelist->id; ?>" method="POST"  keepvisible="1" role="form" action="/savelist/<?php echo $singlelist->id; ?>" rel="ajaxifiedFormHR" autocomplete="off" successMsg="List Save Successfully!">
                                        <div id="lists<?php echo $singlelist->id; ?>ResultDiv" class="resultDiv"></div>
                                        <div class="panel-heading  move-btn" > 
                                            <span class="panel-icon col-sm-1 hidden-xs"><i class="fa fa-th-list"></i></span>
                                            <span class="editablebox pull-left col-md-11">
                                                <span class="editableedit btn-info btn"><i class="fa fa-pencil"></i></span>
                                                <input class="contenteditable" id="lists<?php echo $singlelist->id; ?>title" value="<?php echo $singlelist->title; ?>" onkeypress="set('lists<?php echo $singlelist->id; ?>title')" name="title" readonly="true" type="text"/>
                                                <button type="submit" class="editablesave btn-success btn" onclick="clearCookie('lists<?php echo $singlelist->id; ?>title')">save</button>
                                            </span>

                                            <span class="col-sm-2 col-xs-2 prn text-right">
                                                <div class="btn-group text-right">
                                                    <a class="btn btn-danger fs12 btn-xs" rel="ajaxRequestShowResultHR" removeDiv="list<?php echo $singlelist->id; ?>" data-href="/archiveitem/<?php echo $singlelist->id; ?>" parameterid="<?php echo $singlelist->id; ?>" parameter="list" confirmmsg="Are you sure to archive list <?php echo $singlelist->title; ?>.">
                                                        <span class="fa fa-close"></span>
                                                    </a>
                                                </div>
                                            </span>
                                            <div class="clearfix"></div>
                                        </div>
                                    </form>
                                    <div class="panel-body pn">
                                        <ul class="task-list task-current" id="ticketCollection<?php echo $singlelist->id; ?>">
                                            <?php
                                            if (!empty($ListCards[$singlelist->id])) {
                                                foreach ($ListCards[$singlelist->id] as $card) {
                                                    ?>            
                                                    <li class="task-item success" card-id="<?php echo $card->id; ?>" card-order="<?php echo $card->priority; ?>">
                                                        <div class="task-handle"></div>
                                                        <div class="task-desc new-desc"><a href="/viewticket/<?php echo $card->id; ?>/" card-id="<?php echo $card->id; ?>" class="card card<?php echo $card->id; ?>" rel="popUpBoxHR" ><?php echo $card->title; ?></a></div>
                                                        <?php
                                                        if ($card->estimated_by == $userId) {?>
                                                            <div class="task-play">
                                                                <a class="start-timer-btn link" title="Start Timer"><span class="fa fa-play"></span></a>
                                                                <a class="remove-timer-btn hidden link" title="Stop & Save Timer"><span class="fa fa-stop"></span></a>
                                                            </div>
                                                        <?php }?>
                                                        <div class="task-menu ui-sortable-handle"></div>
                                                    </li>
                                                    <?php
                                                }
                                            } else {
                                                echo '<li class="emptymsg"> Not card in this list </li>';
                                            }
                                            ?>                                          
                                        </ul>
                                        <div class="ticket<?php echo $singlelist->id; ?>">
                                            <div id="ticket<?php echo $singlelist->id; ?>ResultDiv" class="resultDiv"></div>
                                            <form id="ticket<?php echo $singlelist->id; ?>" name="lists" method="POST" close_popup="1" keepvisible="1" role="form" action="/saveticket/" rel="ajaxRequestShowResultHR" autocomplete="off" backToPage="" successMsg="Card Added Successfully!" appentdiv="ticketCollection<?php echo $singlelist->id; ?>">
                                                <input type="hidden" name="asset_type_id" value="11" />
                                                <input type="hidden" name="asset_parent_id" value="<?php echo $singlelist->id; ?>" />
                                                <input type="hidden" name="priority" value="9999"/>
                                                <div class="section row mb15">
                                                    <div class="col-xs-12">
                                                        <input type='text' name="title" class="form-control reset required" placeholder='Create New Card' required=""/>
                                                    </div>
                                                </div>
                                                <div class="section row mb15">
                                                    <div class="col-xs-12">
                                                        <input type="submit" class="button btn-success col-xs-12 pull-right savelistsave lists_save" style="display: none;" id="saveticket"  value="Save Card">
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        <div class="clearfix visible-sm visible-lg visible-md visible-xs"></div>
                    </div>
                    <div class="clearfix"></div>
                    <div id="pagingControls" class="pull-left">
                        <h5><?php echo $list->getCurrentPageInfo(); ?></h5>
                    </div>
                    <div class="pull-right" >
                        <ul class="pagination bootpag">
                            <?php echo $list->printPageNumbers(array('url' => "/lists", 'div_id' => 'mainContent', 'ajaxRequest' => true)); ?>
                        </ul>
                    </div>
                    <span class="sliding-div">
                        <div class="btn-group">
                            <button type="button" class="light div-slider-box visible-lg"><i class="fa fa-sign-out"></i></button>
                        </div>
                    </span>
                </div>
                <?php
            } else {
                echo '<div class="col-xs-12"><div class="panel mb25 mt5"><div class="panel-heading"><h3>No Lists Found</h3></div></div></div>';
            }
            ?>
            <div class="clearfix" ></div>
        </div>
        <div id="add_new_list_popup" class="side-div">
            <?php echo $AssignedUsers; ?>
            <?php if (!empty($addChildform)) echo $addChildform; ?>
        </div>
    </section>
    <script type="text/javascript">
        $(document).ready(function()
        {
            if($('#cardtimer .ticket .card').length>0)
            {
                $('.card'+$('#cardtimer .ticket .card').attr('card-id')).parents('.task-item').find('.task-play').find('.start-timer-btn').addClass('hidden');
                $('.card'+$('#cardtimer .ticket .card').attr('card-id')).parents('.task-item').find('.task-play').find('.remove-timer-btn').removeClass('hidden');
            }
        });

        $(".reset-btn").click(function()
        {
            $(this).parents("form").find(".search-input").val("");
            $(this).parents("form").find(".submit-btn").click();
        });
    </script>
<?php }
?>
