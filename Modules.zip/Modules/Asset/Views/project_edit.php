<!-- create new order panel-->
<?php $rand = rand(10, 1000);?>
<div class="panel mb25 mt5">
    <div id="projects<?php echo $rand;?>ResultDiv" class="resultDiv"></div>
    <?php if (empty($asset->id)) { ?>
        <div class="panel-heading"><span class="panel-title"> <i class="fa fa-file-text hidden-xs"></i> Add Project</span>
        </div>
        <div class="panel-body p20 pb10">
            <div class="tab-content pn br-n admin-form">
                <div id="tab1_1" class="tab-pane active">
                    <div class="section row mbn">
                        <div class="col-md-12 pn">
                            <form id="projects<?php echo $rand;?>" name="projects" method="POST" close_popup="1" keepvisible="1" role="form" action="/saveproject/" rel="ajaxifiedFormHR" autocomplete="off" backToPage="/projects/" successMsg="Project Added Successfully!">
                                <input  type="hidden" name="asset_type_id" value="9">
                                <div class="section row mb15">
                                    <div class="col-xs-12">
                                        <label for="projecttitle" class="field prepend-icon">
                                            <input id="projecttitle" type="text" name="title" placeholder="Project's Title" class="event-name gui-input br-light light required">
                                            <label for="projecttitle" class="field-icon"><i class="fa fa-file-text"></i></label>
                                            <p class="projecttitleclass"></p>
                                        </label>
                                    </div>
                                </div>
                                <div class="section row mb15">
                                    <div class="col-xs-12">
                                        <label for="description" class="field prepend-icon">
                                            <textarea id="description" type="text" name="description" placeholder="Add Desription Here..." class="event-name gui-textarea br-light light required"></textarea>
                                            <label for="description" class="field-icon"><i class="fa fa-file-o"></i></label>
                                            <p class="projectdescriptionclass"></p>
                                        </label>
                                    </div>
                                </div>
                                <div class="section row mb15">
                                    <div class="col-xs-12">
                                        <input type="submit" class="button btn-success col-xs-12 pull-right saveprojectsave projects_save" id="save"  value="Add Project">
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    <?php }else{ ?>
        <div class="panel-heading"><span class="panel-title"> <i class="fa fa-file-text"></i> <?php echo $header;?></span>
        </div>
        <div class="panel-body p20 pb10">
            <div class="tab-content pn br-n admin-form">
                <div id="tab1_1" class="tab-pane active">
                    <div class="section row mbn">
                        <div class="col-md-12 pn">
                            <form id="projects<?php echo $rand;?>" name="projects" method="POST" close_popup="1" keepvisible="1" role="form" action="/saveproject/<?php echo $asset->id;?>" rel="ajaxifiedFormHR" autocomplete="off" backToPage="/projects/" successMsg="Project Added Successfully!">
                                <input  type="hidden" name="asset_type_id" value="9">
                                <div class="section row mb15">
                                    <div class="col-xs-12">
                                        <label for="projecttitle" class="field prepend-icon">
                                            <input id="projecttitle" type="text" name="title" placeholder="Project's Title" class="event-name gui-input br-light light required" value="<?php echo $asset->title;?>">
                                            <label for="projecttitle" class="field-icon"><i class="fa fa-file-text"></i></label>
                                            <p class="projecttitleclass"></p>
                                        </label>
                                    </div>
                                </div>
                                <div class="section row mb15">
                                    <div class="col-xs-12">
                                        <label for="description" class="field prepend-icon">
                                            <textarea id="description" type="text" name="description" placeholder="Add Desription Here..." class="event-name gui-textarea br-light light required"><?php echo $asset->description;?></textarea>
                                            <label for="description" class="field-icon"><i class="fa fa-file-o"></i></label>
                                            <p class="projectdescriptionclass"></p>
                                        </label>
                                    </div>
                                </div>
                                <div class="section row mb15">
                                    <div class="col-xs-12">
                                        <input type="submit" class="button btn-success col-xs-12 pull-right saveprojectsave projects_save" id="save"  value="Save Project">
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    <?php }?>
</div>   <!-- menu quick links-->
