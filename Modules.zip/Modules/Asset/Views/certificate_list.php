<section  class="">
    <!-- begin: .tray-center-->
    <div id="animation-switcher" class="tray-center col-md-12 col-sm-12">
        <div class="col-sm-6 changeclass" id="">
            <div class="panel mb25 mt5">
                <div class="panel-heading"><span class="panel-title"> <i class="fa fa-th-list "></i> Certificates List</span>
                    <span class="pull-right fix-right">
                        <div class="btn-group">
                            <a   href="certificates/edit"  rel="popUpBox" oncloseFunction = "reloadDiv('certificates','mainContent', 'ajax');" class="btn btn-default light"><i class="fa fa-plus"></i></a>
                        </div>
                    </span>
                    <div class="clearfix"></div>
                </div>
                <div class="panel-menu admin-form theme-primary pbn p5">
                    <div class="row">                    
                        <form resultDiv='mainContent' name="searchAssets" id="searchAssets" method="post" class="form-inline col-xs-12 pln pb5" keepVisible="1" keepResult="1" action="/certificates/" rel="ajaxifiedForm">      
                            <div class="col-lg-12 prn">
                                <label for="name" class="field prepend-icon">
                                    <input class="event-name gui-input br-light light mbn search-input" type="text" name="searchTitle" placeholder="Search" value="<?php echo $searchTitle = ( isset($_POST['searchTitle']) && $_POST['searchTitle'] != '' ) ? $_POST['searchTitle'] : ''; ?>" />
                                    <label for="name" class="field-icon"><i class="fa fa-search"></i></label>
                                    <div class="btn-fix-right">
                                        <button type="submit" class="submit-btn button btn-success pull-left mr5"><i class="fa fa-search hidden-lg"></i><span class="visible-lg">Search</span></button>
                                        <button type="reset" class="reset-btn button btn-danger"><i class="fa fa-refresh hidden-lg"></i><span class="visible-lg">Reset</span></button>    
                                    </div>
                                </label>
                            </div>
                        </form>                
                    </div>
                </div>
                <?php if (!empty($list->data)) { ?>
                    <div class="DelResultDiv"></div>
                    <div class="panel-body pn task-widget">
                        <div class="">
                            <div class="list-com" id="list-com">
                                <div class="col-sm-12 pn com-detail pt10 bg-light">
                                    <div class="col-sm-4 col-xs-12"><p><strong>Certificate Title</strong></p></div>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                            <div class="list-com showtrdata">
                                <?php if (empty($list->data)) { ?>
                                    <div class="col-sm-12 com-detail p15">
                                        <div class="col-sm-12">Certificates Not Found</div>
                                    </div>
                                    <?php
                                } else {
                                    $i = 1;
                                    ?>
                                    <?php foreach ($list->data as $certificate) {
                                        ?>
                                        <div class="com-detail col-sm-12 pt5 pb5" id="section_<?php echo $certificate->id ?>">
                                            <div class="text-left">
                                                <span class="pull-right">
                                                    <a href="#" id="" class="btn btn-danger br2 btn-xs " onclick="deleteRow('<?php echo $certificate->id ?>', '<?php echo $certificate->title; ?>', 'deletenote', '/certificates', 'Certificate');"><span class="fa fa-close"></span></a>
                                                </span> 
                                                <a id="" class="showdiv" href="#<?php echo $i; ?>a" data-toggle="tab"><?php echo trim($certificate->title); ?></a>
                                            </div>
                                            <div class="clearfix"></div>
                                        </div>
                                        <?php
                                        $i = $i + 1;
                                    }
                                }
                                ?>
                                <div class="col-sm-12">
                                    <div class="pull-left">
                                        <h5><?php echo $list->getCurrentPageInfo(); ?></h5>
                                    </div>
                                    <div class="pull-right" >
                                        <?php echo $list->printPageNumbers(array('url' => "/certificates", 'div_id' => 'mainContent', 'ajaxRequest' => true)); ?>
                                    </div>
                                </div>
                            </div>
                        </div>            
                    </div>
                    <?php
                } else {
                    echo '<div class="col-xs-12"><div class="panel mb25 mt5"><div class="panel-heading"><h3>No Certificates Found</h3></div></div></div>';
                }
                ?>
            </div> 
        </div>
        <?php
        if (!empty($list->data)) {
            $hideform = 'display:none';
        } else {
            $hideform = '';
        }
        ?>
        <div class="addcertificateform" id="addcertificateform" style="<?php echo $hideform; ?>">
            <div id="animation-switcher" class="col-sm-12">                         
                <div id="" class="tab-content">

                    <div class="panel mb25 mt5">
                        <div id="savecertificateResultDiv" class="savecertificateResultDiv"></div>
                        <div class="panel-heading">
                            <span class="panel-title"> <i class="fa fa-star"></i> Add Certificate</span>
                            <div class="clearfix"></div>
                        </div>
                        <div class="panel-body pn">
                            <div class="tab-content pn br-n admin-form">
                                <div id="" class="">
                                    <div class="section mbn">
                                        <div class="col-md-12 pn">
                                            <form keepVisible="1" role="form" resultDiv="savecertificateResultDiv" action="/savecertificates/" method="POST" id='savecertificate' rel='ajaxifiedForm' autocomplete="off" backToPage="/certificates" successMsg="Certificate Save Successfully!">    
                                                <input  type="hidden" name="asset_type_id" value="7">
                                                <div class="section row mb15">
                                                    <div class="col-xs-12">
                                                        <label for="certificatetitle" class="field prepend-icon">
                                                            <input type="text" name="title" placeholder="Certificate Title" value="" class="enterkeyblock certificatetitle event-name gui-input br-light light required">
                                                            <label for="certificatetitle" class="field-icon"><i class="fa fa-file-text"></i></label>
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="section row mbn">
                                                    <div class="col-xs-12">
                                                        <label for="description" class="field prepend-icon">
                                                            <textarea type="text" name="description" placeholder="Add Desription Here..." class="summernote event-name gui-textarea br-light light required"></textarea>
                                                            <label for="description" class="field-icon"></label>
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="panel-footer text-right bg-wild-sand">

                                                    <button type="submit" class="btn btn-success btn-sm ph15 save_certificate" >Save Certificate</button>
                                                </div>
                                                <div class="clearfix"></div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div> 
                </div>                                   
            </div>
        </div>
        <!-- recent orders table-->
        <div class="tab-content col-sm-6 prn update_certificate_form" id="">
            <div class="resultDiv1"></div>
            <?php
            $i = 1;
            foreach ($list->data as $certificate) {
                ?>                  
                <div class="tab-pane <?php
                if ($i < 2) {
                    echo 'active';
                }
                ?>" id="<?php echo $i; ?>a" >
                    <a id="savenoteeentes" class="savenoteeentes" onclick="savecertificate('<?php echo $certificate->id ?>');" ></a> 

                    <div class="col-xs-12 pull-right ">
    <!--                        <span class="pull-right fix-right">
                            <div class="btn-group text-right">
                                <button type="button" id="" class="btn btn-success br2 btn-xs add_certificate" style="z-index: 10000;margin-left: -157px;margin-top: 24px;">Add Certificate</button>
                            </div>
                        </span>-->
                        <?php if ($certificate) { ?>
                            <div class="panel mb25 mt5">            
                                <div class="panel-heading"  id="title" >
                                    <a class="editfocus"><i class="fa fa-pencil"></i></a>
                                    <span id="id_of_title" class="panel-title enterkeyblock" contenteditable="true" ><?php
                                        if ($certificate->title) {
                                            echo $certificate->title;
                                        } else {
                                            echo "Add Title";
                                        }
                                        ?></span><div class="clearfix"></div>
                                </div>
                                <div class="message-reply">
                                    <div class="summernote"><?php
                                        if ($certificate->description) {
                                            echo $certificate->description;
                                        } else {
                                            echo "Add Description";
                                        }
                                        ?></div>
                                </div>
                                <div class="panel-footer text-right bg-wild-sand savenoteenter">
                                    <button type="button" class="btn btn-info btn-sm ph15"  onclick="printcertificates();">Print</button>
                                    <input type="button" class="btn btn-success btn-sm ph15 savecertificate" id="savecertificate" onclick="savecertificate('<?php echo $certificate->id ?>');" value="Update">
                                </div>
                            </div>
                        <?php } ?>                
                    </div>
                </div>      
                <?php
                $i = $i + 1;
            }
            ?>            
        </div>
        <div class="clearfix"></div>
    </div>

</section>
<!-- Start: Right Sidebar-->
<script type="text/javascript">

    $('.add_certificate').click(function () {
        $('.addcertificateform').show();
        $('.update_certificate_form').hide();
    });
    $("tbody tr td a").click(function () {
        $('.addcertificateform').hide();
        $('.update_certificate_form').show();
    });


    function printcertificates() {
        title = $('.tab-pane.active .panel-title').val();
        description = $('.tab-pane.active .note-editable').html();
        $.ajax({
            type: "POST",
            url: '<?php echo BASE_PATH_ROOT; ?>/dropboxapi/letterhead.php',
            data: ({title: title, description: description}),
            success: function (data) {
                var w = window.open('data:application/pdf;base64, ' + btoa(data));
                $(w.document.body).html(data);

                $('.resultDiv1').html(data);
                setTimeout(function () {
                    $('.resultDiv1').html('');
                }, 1500);

            }
        });
    }

    jQuery(document).ready(function () {
        "use strict";
        $('.summernote').summernote({
            height: 290, //set editable area's height
            focus: false, //set focus editable area after Initialize summernote
            oninit: function () {
            },
            onChange: function (contents, $editable) {
            },
        });

        $(".tab-pane.active .savenoteeentes .note-codable").attr("disabled", "disabled").attr("value", "Updating...");

        $('.editfocus').click(function () { //vai
            $(".id_of_title").focus()
        });


    });

    function enteractionevent() {
        $('.tab-pane.active .savenoteeentes').click();
    }

    function savecertificate(assetid)
    {
        $("#savenote").attr("disabled", "disabled").attr("value", "Updating...");
        title = $('.tab-pane.active .panel-title').html();
        description = $('.tab-pane.active .note-editable').html();

        $.ajax({
            type: "POST",
            url: '/savecertificates/' + assetid,
            data: ({id: assetid, title: title, description: description, asset_type_id: 7, pageRequestType: 'ajax'}),
            success: function (jsondata)
            {
                try {
                    var obj = JSON.parse(jsondata);
                    if (obj.status == 'success')
                    {
                        notify(obj.status, 'Note Update successfully!', obj.status);
                    }
                } catch (error) {
                    data = jsondata;
                    $('.resultDiv1').html("<div class='validBox'>Cerificate Update successfully!</div>");
                }

                $('#section_' + assetid + ' .showdiv').html(title);
                setTimeout(function ()
                {
                    $('.resultDiv1').html('');
                    $("#savecertificate").removeAttr("disabled").attr("value", "Update Certificate");
                }, 1500);

            }
        });
    }
</script>
<script>
    $(".reset-btn").click(function () {
        $(this).parents("form").find(".search-input").val("");
        $(this).parents("form").find(".submit-btn").click();
    });
</script>