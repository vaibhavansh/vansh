<!-- create new order panel-->
<div class="panel mb25 mt5">
    <div id="tabsResultDiv" class="resultDiv"></div>
    <?php if (empty($asset->id)) { ?>
        <div class="panel-heading"><span class="panel-title"> <i class="fa fa-file-text hidden-xs"></i> Add New Section</span>
        </div>
        <div class="panel-body p20 pb10">
            <div class="tab-content pn br-n admin-form">
                <div id="tab1_1" class="tab-pane active">
                    <div class="section row mbn">
                        <div class="col-md-12 pl15">
                            <form id="tabs" name="tabs" method="POST" close_popup="1" keepvisible="1" role="form" action="/savelist/" rel="ajaxifiedForm" autocomplete="off" backToPage="/hrtabs/<?php echo $parent_id;?>/" successMsg="Tab Added Successfully!">
                                <input  type="hidden" name="asset_type_id" value="14">
                                <input  type="hidden" name="asset_parent_id" value="<?php echo !empty($parent_id) ? $parent_id: '';?>">
                                <div class="section row mb15">
                                    <div class="col-xs-12">
                                        <label for="listtitle" class="field prepend-icon">
                                            <input id="listtitle" type="text" name="title" placeholder="Section Title" class="event-name gui-input br-light light required">
                                            <label for="listtitle" class="field-icon"><i class="fa fa-file-text"></i></label>
                                            <p class="listtitleclass"></p>
                                        </label>
                                    </div>
                                </div>
                                <div class="section row mb15">
                                    <div class="col-xs-12">
                                        <input type="submit" class="button btn-success col-xs-12 pull-right savelistsave lists_save" id="save"  value="Add Section">
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    <?php }else{ ?>
        <div class="panel-heading"><span class="panel-title"> <i class="fa fa-file-text"></i><?php echo $header;?></span>
        </div>
        <div class="panel-body p20 pb10">
            <div class="tab-content pn br-n admin-form">
                <div id="tab1_1" class="tab-pane active">
                    <div class="section row mbn">
                        <div class="col-md-12 pl15">
                            <form id="tabs" name="tabs" method="POST" close_popup="1" keepvisible="1" role="form" action="/savelist/<?php echo $asset->id;?>" rel="ajaxifiedForm" autocomplete="off" backToPage="" successMsg="Tab Save Successfully!">
                                <input  type="hidden" name="asset_type_id" value="14">
                                <input  type="hidden" name="asset_parent_id" value="<?php echo !empty($parent_id) ? $parent_id: '';?>">
                                <div class="section row mb15">
                                    <div class="col-xs-12">
                                        <label for="listtitle" class="field prepend-icon">
                                            <input id="listtitle" type="text" name="title" placeholder="List's Title" class="event-name gui-input br-light light required" value="<?php echo $asset->title;?>">
                                            <label for="listtitle" class="field-icon"><i class="fa fa-file-text"></i></label>
                                            <p class="listtitleclass"></p>
                                        </label>
                                    </div>
                                </div>
                                <div class="section row mb15">
                                    <div class="col-xs-12">
                                        <input type="submit" class="button btn-success col-xs-12 pull-right savelistsave lists_save"  value="Save Tabs">
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    <?php }?>
</div>   <!-- menu quick links-->
