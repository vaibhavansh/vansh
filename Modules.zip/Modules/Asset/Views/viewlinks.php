
<section class="">
    <div class="panel-menu theme-primary p5 pbn">
        <div class="panel mb5 mtn">
            <div class="panel-heading text-center">
                <span class="panel-icon col-sm-12 hidden-xs"><?php echo $implinks->title;?></span>
                <span class="pull-right fix-right">
                    
                </span>
            </div>
        </div>
    </div>
    <div class="panel-body">          
        <div class=" admin-form pt5">
           <?php echo $implinks->description;?>
            <div class="clearfix"></div>
        </div>
    </div>
</section>

