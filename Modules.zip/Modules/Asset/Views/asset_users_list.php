<?php global $page;
$rand=rand();
if(!isset($asset_id))
$asset_id=isset($page->queryString[1])?$page->queryString[1]:'';
?>
<!-- create new order panel-->
<div id="assingMember<?php echo $rand;?>ResultDiv">
    <div class="panel mb10 mtn">
        <div class="panel-heading">
            <a data-toggle="collapse" data-parent="#accordion2" href="#accord2_5" class="accordion-toggle accordion-icon link-unstyled collapsed">
                <span class="panel-title"> <i class="fa fa-users hidden-xs"></i>Assign Members</span>
            </a>
        </div>
        <div id="accord2_5" class="panel-collapse collapse in">
        <div class="panel-body pn">
            <div class="">
                <?php if(!empty($AssignUsers)){
                    foreach ($AssignUsers as $AssignUser)
                    {?>
                        <div class="btn-group text-right mb10 mt10 ml10">
                            <span class="button btn btn-light btn-rounded  btn-custom p5 pr10 pl15"><?php echo $AssignUser->name[0].$AssignUser->lastname[0];?></span>
                            <a class="btn btn-danger btn-rounded  fs12 btn-xs" rel="ajaxRequestShowResultHR" data-href="/assignmember/<?php echo $asset_id; ?>" parameterid="<?php echo $AssignUser->assetuserid;?>" parameter="removeuser" resultDiv="assingMember<?php echo $rand;?>ResultDiv" confirmMsg="Are you sure to remove <?php echo $AssignUser->name.' '.$AssignUser->lastname;?> form assign members.">
                                <span class="fa fa-close"></span>
                            </a>
                        </div>
                <?php }
                }?>
            </div>
            <?php if(!empty($userSelector)){?>
                <form id="assingMember<?php echo $rand;?>" resultDiv="assingMember<?php echo $rand;?>ResultDiv" method="POST" keepvisible="1" role="form" action="/assignmember/<?php echo $asset_id; ?>" rel="ajaxifiedFormShowResultHR" autocomplete="off" backToPage="" successMsg="Assign Member Successfully!">
                    <input type="hidden" name="asset_id" value="<?php echo $asset_id;?>">
                    <div class="panel-body p20 pb10">
                        <div class="tab-content pn br-n admin-form">
                            <div id="tab1_1" class="tab-pane active">
                                <div class="section row mbn">
                                    <div class="col-md-12 pn">
                                        <div class="section row mb15">
                                            <div class="col-xs-12">
                                                <?php echo $userSelector;?>
                                            </div>
                                        </div>
                                        <div class="section row mb15">
                                            <div class="col-xs-12">
                                                <button type="submit" class="button btn-success col-xs-12 pull-right">Assign Member</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            <?php }?>
        </div>
    </div>
    </div>
</div>