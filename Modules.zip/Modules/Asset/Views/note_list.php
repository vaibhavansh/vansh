<?php
if (empty($list)) {
    $coloums = "col-sm-12";
} else {
    $coloums = "col-sm-12 col-xs-12";
}
?>
<section  class="">
    <!-- begin: .tray-center-->
    <div id="animation-switcher" class="tray-center  main-div pn">
        <div class="<?php echo $coloums; ?> changeclass" id="">
            <div class="panel mb25 mt5">
                <div class="DelResultDiv"></div>
                <div class="panel-heading"><span class="panel-title"> <i class="fa  fa-files-o "></i> Notes List</span>
                    <span class="pull-right fix-right">
                        <div class="btn-group">
                          <button type="button" class="btn btn-default light div-slider visible-lg"><i class="fa "></i></button>
                        </div>
                        <div class="btn-group">
                            <a href="notes/edit"  rel="popUpBox" oncloseFunction = "reloadDiv('mainContent', 'ajax');" class="btn btn-default light hidden-lg"><i class="fa fa-plus"></i></a>
                        </div>
                    </span>
                </div>
                <div class="panel-menu admin-form theme-primary pbn p5">  
                    <div class="row">
                        <form resultDiv='mainContent' name="searchAssets" id="searchAssets" method="post" class="form-inline col-xs-12 pln pb5" keepVisible="1" keepResult="1" action="/notes/" rel="ajaxifiedForm">      
                            <div class="col-lg-12 prn">
                                <label for="name" class="field prepend-icon">
                                    <input class="event-name gui-input br-light light mbn search-input" type="text" name="searchTitle" placeholder="Search" value="<?php echo $searchTitle = ( isset($_POST['searchTitle']) && $_POST['searchTitle'] != '' ) ? $_POST['searchTitle'] : ''; ?>" />
                                    <label for="name" class="field-icon"><i class="fa fa-search"></i></label>
                                    <div class="btn-fix-right">
                                        <button type="submit" class="submit-btn button btn-success pull-left mr5"><i class="fa fa-search hidden-lg"></i><span class="visible-lg">Search</span></button>
                                        <button type="reset" class="reset-btn button btn-danger"><i class="fa fa-refresh hidden-lg"></i><span class="visible-lg">Reset</span></button>    
                                    </div>
                                </label>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="panel-body pn task-widget">
                    <div class="">
                        <div class="list-com" id="list-com">
                            <div class="col-sm-12 pn com-detail pt10 bg-light">
                                <div class="col-sm-4 col-xs-12"><p><strong>Note Title</strong></p></div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                        <div class="list-com showtrdata">
                            <div class="clearfix"></div>
                            <?php if (empty($list->data)) { ?>
                                <div class="col-sm-12 com-detail p15">
                                    <div class="col-sm-12">Notes Not Found</div>
                                </div>
                                    <?php
                                } else {
                                    $i = 1;
                                    ?>
                                    <?php foreach ($list->data as $notesLists) {
                                        ?>
                                        <div class="com-detail col-sm-12 pt5 pb5" id="section_<?php echo $notesLists->id ?>">
                                            <div class="text-left">
                                                <span class="pull-right">
                                                    <a href="#" id="" class="btn btn-danger br2 btn-xs " onclick="deleteRow('<?php echo $notesLists->id ?>', '<?php echo $notesLists->title; ?>', 'deletenote', '/notes', 'Note');"><span class="fa fa-close"></span></a>
                                                </span> 
                                                <a id="" class="showdiv" href="#<?php echo $i; ?>a" data-toggle="tab"><?php echo trim($notesLists->title); ?></a>
                                            </div>
                                            <div class="clearfix"></div>
                                        </div>
                                        <?php
                                        $i = $i + 1;
                                    }
                                }
                                ?>
                            <div class="col-sm-12">
                                <div class="pull-left">
                                    <h5><?php echo $list->getCurrentPageInfo(); ?></h5>
                                </div>
                                <div class="pull-right" >
                                     <?php echo $list->printPageNumbers(array('url' => "/notes", 'div_id' => 'mainContent', 'ajaxRequest' => true)); ?>
                                </div>
                            </div>
                        </div>
                    </div>            
                </div>
            </div>
        </div> 
        <!-- recent orders table-->
        <div class="tab-content col-sm-6 noteupdate" id="">
            <div class="resultDiv1"></div>
            <?php
            $i = 1;
            foreach ($list->data as $notesLists) {
                ?>                  
                <div class="tab-pane <?php
                if ($i < 2) {
                    echo 'active';
                }
                ?>" id="<?php echo $i; ?>a" >
                    <a id="savenoteeentes" class="savenoteeentes" onclick="savenote('<?php echo $notesLists->id ?>');" ></a> 
                    <div class="col-xs-12 pull-right ">
                        <?php if ($notesLists) { ?>
                            <div class="panel mb25 mt5">            
                                <div class="panel-heading"  id="title" >
                                    <a class="editfocus"><i class="fa fa-pencil"></i></a>
                                    <span id="id_of_title" class="panel-title enterkeyblock" contenteditable="true" ><?php
                                        if ($notesLists->title) {
                                            echo $notesLists->title;
                                        } else {
                                            echo "Add Title";
                                        }
                                        ?></span><span class="pull-right fix-right">
                                    </span>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="message-reply">
                                    <div class="summernote"><?php
                                        if ($notesLists->description) {
                                            echo $notesLists->description;
                                        } else {
                                            echo "Add Description";
                                        }
                                        ?></div>
                                </div>
                                <div class="panel-footer text-right bg-wild-sand savenoteenter">
                                    <input type="button" class="btn btn-success btn-sm ph15 savenote" id="savenote" onclick="savenote('<?php echo $notesLists->id ?>');" value="Update Note">
                                </div>
                            </div>
                        <?php } ?>                
                    </div>
                </div>      
                <?php
                $i = $i + 1;
            }
            ?>            
        </div>
        <div class="clearfix"></div>
        <span class="sliding-div">
            <div class="btn-group">
              <button type="button" class="light div-slider-box visible-lg"><i class="fa fa-sign-out"></i></button>
            </div>
        </span>
    </div>
    <div id="add_new_note_popup" class="side-div">
        <?php if (!empty($addform)) echo $addform; ?>
    </div>
</section>
<!-- Start: Right Sidebar-->
<script type="text/javascript">
    jQuery(document).ready(function () {
        "use strict";
        $('.summernote').summernote({
            height: 290, //set editable area's height
            focus: false, //set focus editable area after Initialize summernote
            oninit: function () {
            },
            onChange: function (contents, $editable) {
            },
        });

        $(".tab-pane.active .savenoteeentes .note-codable").attr("disabled", "disabled").attr("value", "Updating...");

        $('.editfocus').click(function () { //vai
            $(".id_of_title").focus()
        });

        $('.noteupdate').hide();
        $(".closediv").click(function () {
            $('.noteupdate').hide();
            $('#animation-switcher .changeclass').removeClass('col-sm-6 col-xs-12').addClass('col-sm-12');
        });
        $(".showdiv").click(function () {
            $('#animation-switcher .changeclass').removeClass('col-sm-12').addClass('col-sm-6 col-xs-12');
            $('.noteupdate').show();
        });
    });

    function enteractionevent() {
        $('.tab-pane.active .savenoteeentes').click();
    }

    function savenote(assetid)
    {
        $("#savenote").attr("disabled", "disabled").attr("value", "Updating...");
        title = $('.tab-pane.active .panel-title').html();
        description = $('.tab-pane.active .note-editable').html();

        $.ajax({
            type: "POST",
            url: '/savenote/' + assetid,
            data: ({id: assetid, title: title, description: description, asset_type_id: 1, pageRequestType: 'ajax'}),
            success: function (jsondata)
            {
                try {
                    var obj = JSON.parse(jsondata);
                    if (obj.status == 'success')
                    {
                        notify(obj.status, 'Note Update successfully!', obj.status);
                    }
                }
                catch (error) {
                    data = jsondata;
                    $('.resultDiv1').html("<div class='validBox'>Note Update successfully!</div>");
                }

                $('#section_' + assetid + ' .showdiv').html(title);
                setTimeout(function ()
                {
                    $('.resultDiv1').html('');
                    $("#savenote").removeAttr("disabled").attr("value", "Update Note");
                }, 1500);

            }
        });
    }
</script>
<script>
$(".reset-btn").click(function(){
  $(this).parents("form").find(".search-input").val("");
  $(this).parents("form").find(".submit-btn").click();
});
</script>