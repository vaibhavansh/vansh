<div class="grid_11 omega">
    <h3><?php echo $header ?></h3>
</div>

<div class="grid_5 alpha">
    <h3><a href="/<?php echo $objects->coreURL ?>/edit/0" oncloseFunction="reloadDiv('/<?php echo $objects->coreURL; ?>/index','mainContent');" rel="ajaxRequest">Create New </a></h3>
</div>
<div class="spacer"></div>
<div class="grid_16">
    <form resultDiv='mainContent' name ="searchAssets" id="searchAssets" method="post" class="form-inline"
          keepVisible="1" keepResult="1" action="/asset_assets/index/" rel="ajaxifiedForm">
        <input class="required" type="text" name="searchTitle" placeholder="Search"/>
        <button type="submit" class="btn">Search</button>

    </form>
</div>

<div class="grid_16">
    <?php echo $objects->pageLinks(array('url' => "/{$objects->coreURL}/index", 'ajaxRequest' => true)); ?>
</div>
<div class='grid_24 omega alpha'>
    <h4 class="">
    <div class="grid_6 omega alpha greyBackground">Title</div>
    <div class="grid_3  omega greyBackground">Modified</div>

    <div class="grid_15 omega  greyBackground">Actions</div>
    </h4>

</div>

<div class='grid_24 omega alpha'><?php
    if (!empty($objects->data))
        foreach ($objects->data as $object) {
            ?>
            <div id="row_<?php echo $object->id ?>">
                <div class="grid_6 omega">
                    <a href="/<?php echo $objects->coreURL . '/edit/' . $object->id ?>"  rel="ajaxRequest" >
<?php /*div_name="edit_asset_<?php echo $object->id; ?>" onclick="$('#edit_asset_<?php echo $object->id;?>').toggle();"*/?>
                    <?php echo $object->title; ?></a>
                    <br />
                    <?php if($object->belongsTo()){?>
                    <strong>(<?php echo $object->belongsTo->title;?>)</strong>
                    <?php }?>
                </div>
                <div class="grid_3 omega ">
                    <?php echo DateTime::createFromFormat('Y-m-d H:i:s', $object->modified)->format('M-d H:i');?>
                </div>
                <a href="/<?php echo $objects->coreURL . '/edit/' . $object->id ?>"  rel="ajaxRequest" div_name="edit_asset_<?php echo $object->id; ?>" class="grid_1 editIcon" onclick="$('#edit_asset_<?php echo $object->id;?>').toggle();"></a>
                <a class="grid_1  viewIcon" href="/<?php echo $objects->coreURL . '/view/' . $object->id ?>" rel="popUpBox" ></a>
                <a class="grid_1  viewIcon" href="/<?php echo $objects->coreURL . '/togglepublish/' . $object->id ?>" rel="popUpBox" ></a>

                <a href="/<?php echo $objects->coreURL . '/delete/' . $object->id ?>" rel="confirmClickURL" confirmTrueFunction="$('#row_<?php echo $object->id ?>').hide()" message="Are you sure you want to remove '<?php echo $object->title; ?>'." class="deleteIcon grid_1  alpha omega" >&nbsp;</a>
            </div>
                <div class="spacer"></div>
                <div id="edit_asset_<?php echo $object->id; ?>" class="well" style="display:none"></div>

            <?php
        }
    ?>
</div>

<script>
    function togglePublish(assetId){
        reloadDiv('/asset_assets/togglePublish/'+assetId,'nowhere');

    }
    </script>
