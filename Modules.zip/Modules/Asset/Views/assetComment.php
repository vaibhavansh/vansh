<?php
global $page;
$userId = $page->currentUser->id;
if (!empty($assetUserComments)) {
    ?>
    <div class="panel-body p10 mt-20">
        <?php
        $count = 1;
        foreach ($assetUserComments as $assetUserComment) {
            $class = ($count % 2 == 0) ? 'pull-right' : '';
            ?>
            <div class="media">
                <?php if ($count % 2 == 1) { ?>
                    <div class="media-left"><a href="#"><img alt="" src="<?php echo (!empty($assetUserComment->image)) ? 'images/' . $assetUserComment->image . '_thumb.jpg' : '/img/avatars1.jpg'; ?>" class="media-object"></a></div>
                <?php } if ($count % 2 == 0) { ?>
                    <div class="media-right pull-right"><a href="#"><img alt="64x64" src="<?php echo (!empty($assetUserComment->image)) ? 'images/' . $assetUserComment->image . '_thumb.jpg' : '/img/avatars1.jpg'; ?>" class="media-object"></a></div>
                <?php } ?>
                <div class="media-body <?php echo $class; ?>">
                    <h4 class="media-heading">
                        <?php echo $assetUserComment->fullName; ?>
                        <small class="text-muted"> - <?php $datetime = explode(" ",$assetUserComment->comment_at);  echo $datetime[1];?> <?php  echo Core_Models_Utility::printFormatedDates(array('startDate' => $datetime[0])); ?></small>
                    </h4> 
                    <?php echo $assetUserComment->comments; ?>
                    <div class="clearfix"></div>

                    <?php
                            if (!empty($assetUserComment->comment_images)) {
                                $assetImageobj = new Asset_Models_AssetComment($assetUserComment->id);
                                $assetImageobj->printImageFancyComment();
                            }
                        ?>
                    <div id="likesyetem" class="panel-body p10 mimh-100" title-tooltip="comment">  
                            <div title="">
                    <?php

                            if (!empty($assetUserComment->id)) {
                                $likecomments = new Asset_Models_AssetComment();
                                $likecomments->likeSystem($userId, $assetUserComment->id, $type = "comment");
                            }
                    ?>
                    </div>
                    </div>
                    
                </div>
            </div>
            <div class="clearfix"></div>
            <?php
            $count++;
        }
        if (count($assetUserComments) > 9) {
            $randval = rand();
            ?>
            <div id="loading<?php echo $randval; ?>" class="text-center">
                <a class="btn btn-info fs12 btn-lg mt20 mb20" resultDiv="loading<?php echo $randval; ?>" data-href="/assetcomment/<?php echo $asset_id . '/' . ++$pageNumber; ?>"  removeDiv="loading<?php echo $randval; ?>" appendDiv="CommentCollection<?php echo $asset_id ?>" rel="ajaxRequestAppendResultHR" > Load More... </a>
            </div>
        <?php } ?>
    </div>
    <?php
} else {
    echo '<div class="panel-body p15"><h5 class="mt10 pl5">No Comments Found</h5></div>';
}
?>