<section class="">
    <!-- begin: .tray-center-->
    <div id="animation-switcher" class="tray-center main-div p5">
        <div class="col-sm-12 col-xs-12 pn changeclass" id="">
            <div class="DelResultDiv"></div>
            <div class="panel mb25 mt5">
                <div class="panel-heading"><span class="panel-title"> <i class="fa fa-th-list"></i> Bookmark List</span>
                    <span class="pull-right fix-right">
                        <div class="btn-group">
                          <button type="button" class="btn btn-default light div-slider visible-lg"><i class="fa"></i></button>
                        </div>
                        <div class="btn-group">
                            <a href="bookmarks/edit"  rel="popUpBox" oncloseFunction = "reloadDiv('mainContent', 'ajax');" class="btn btn-default light hidden-lg"><i class="fa fa-plus"></i></a>
                        </div>
                    </span><div class="clearfix"></div>
                </div>
                <div class="panel-menu admin-form theme-primary p5 pbn">                   
                    <div class="row">                    
                        <form resultDiv='mainContent' name="searchAssets" id="searchAssets" method="post" class="form-inline col-xs-12 pln pb5" keepVisible="1" keepResult="1" action="/bookmarks/" rel="ajaxifiedForm">      
                            <div class="col-lg-12 prn">
                                <label for="name" class="field prepend-icon">
                                    <input class="event-name gui-input br-light light mbn search-input" type="text" name="searchTitle" placeholder="Search" value="<?php echo $searchTitle = ( isset($_POST['searchTitle']) && $_POST['searchTitle'] != '' ) ? $_POST['searchTitle'] : ''; ?>" />
                                    <label for="name" class="field-icon"><i class="fa fa-search"></i></label>
                                    <div class="btn-fix-right">
                                        <button type="submit" class="submit-btn button btn-success pull-left mr5"><i class="fa fa-search hidden-lg"></i><span class="visible-lg">Search</span></button>
                                        <button type="reset" class="reset-btn button btn-danger"><i class="fa fa-refresh hidden-lg"></i><span class="visible-lg">Reset</span></button>    
                                    </div>
                                </label>
                            </div>
                        </form>   
                    </div>
                </div>
                <div class="panel-body pn task-widget">
                    <div class="">
                        <div class="list-com" id="list-com">
                            <div class="col-sm-12 com-detail pt10">
                                <div class="col-sm-4 col-xs-12"><p><strong>Title</strong></p></div>
                                <div class="col-md-7 col-sm-6 col-xs-12"><p><strong>Url</strong></p></div>
                                <div class="col-md-1 col-sm-2 col-xs-12 text-right pn"><p><strong>Action</strong></p></div>
                                <div class="clearfix"></div>
                            </div>
                            <?php if (empty($list->data)) { ?>
                             <div class="col-sm-12 com-detail p15">
                                <div class="col-sm-12">Bookmarks Not Found</div>
                            </div>
                            <?php
                            } else {
                                $i = 1;
                                foreach ($list->data as $bookmarkList) {
                                    ?>
                            <div class="com-detail col-sm-12 pt5" id="section_<?php echo $bookmarkList->id ?>">
                                <div class="text-left booktitle col-sm-4"><p><?php echo $bookmarkList->title ?></p></div>
                                <div class="col-md-7 col-sm-6"><p style="overflow: hidden"><?php  echo $status_text = preg_replace('#(\A|[^=\]\'"a-zA-Z0-9])(http[s]?://(.+?)/[^()<>\s]+)#i', '\\1<a target="_blank" href="\\2">\\3</a>', $bookmarkList->url); ?></p></div>                       
                                <div class="col-md-1 col-sm-2 text-right pn">
                                    <div class="btn-group text-right pb5">
                                        <a href="#" id="" class="btn btn-danger br2 btn-xs " onclick="deleteRow('<?php echo $bookmarkList->id ?>', '<?php echo $bookmarkList->title; ?>', 'deletebookmark', '/bookmarks', 'Bookmark');"><span class="fa fa-close"></span></a>
                                    </div>        
                                </div>
                            </div>
                            <?php
                            $i = $i + 1;
                                }
                            }
                            ?>
                            <div class="col-sm-12">
                                <div class="pull-left">
                                    <h5><?php echo $list->getCurrentPageInfo(); ?></h5>
                                </div>
                                <div class="pull-right" >
                                     <?php echo $list->printPageNumbers(array('url' => "/bookmarks", 'div_id' => 'mainContent', 'ajaxRequest' => true)); ?>
                                </div>
                            </div>
                        </div>
                    </div>            
                </div>
            </div>
        </div> 
        <!-- recent orders table-->
        <div class="clearfix"></div>
        <span class="sliding-div">
            <div class="btn-group">
              <button type="button" class="light div-slider-box visible-lg"><i class="fa fa-sign-out"></i></button>
            </div>
        </span>
    </div>
    <div class=" side-div tray-right p5" id="">
        <?php if (!empty($addform)) echo $addform; ?>
    </div>
</section>
<script>
$(".reset-btn").click(function(){
  $(this).parents("form").find(".search-input").val("");
  $(this).parents("form").find(".submit-btn").click();
});
</script>
