 <?php
 $title = !empty($asset->id) ? "Edit IPAddress" : "Add IPAddress" ;
 ?>
<div class="panel mb25 mt10" id="ipaddress">
            <div id="saveipaddressResultDiv" class="resultDiv"></div>
        <div class="panel-heading"><span class="panel-title"> <i class="fa fa-star hidden-xs"></i> <?php echo $title; ?></span>
        </div>
        <div class="panel-body p20 pb10">
            <div class="tab-content pn br-n admin-form">
                <div id="tab1_1" class="tab-pane active">
                    <div class="section row mbn">
                        <div class="col-md-12 pn">
                            <form keepVisible="1" role="form" resultDiv="saveipaddressResultDiv" action="/saveipaddress/<?php echo !empty($asset->id) ? $asset->id:''; ?>" method="POST" id='saveipaddress' rel='ajaxifiedForm' autocomplete="off" close_popup="1"  backToPage="/ipaddress" successMsg="Ipaddress Save Successfully!">
                                <input  type="hidden" name="asset_type_id" value="8">
                                <input  type="hidden" name="status" value="1">
                                <div class="section row mb15">
                                    <div class="col-xs-12">
                                        <label for="" class="field prepend-icon">
                                            <input id="" type="text" name="title" value="<?php echo !empty($asset->title) ? $asset->title:''; ?>" placeholder="Ipaddress Title" class="event-name gui-input br-light light" required="" aria-required="true">
                                            <label for="" class="field-icon"><i class="fa fa-file-text"></i></label>
                                        </label>
                                    </div>
                                </div>
                                <div class="section row mb15">
                                    <div class="col-xs-12">
                                        <label for="urllink" class="field prepend-icon">
                                            <input id="ipaddress" type="text" name="description"  value="<?php echo !empty($asset->description) ? $asset->description:''; ?>" placeholder="Enter Ipaddress" class="event-name gui-input br-light light" autocomplete="off" required="" aria-required="true">
                                            <label for="Ipaddress" class="field-icon"><i class="fa fa-file-text"></i></label>
                                        </label>
                                    </div>
                                </div>               

                                <div class="section row mb15">
                                    <div class="col-xs-12">
                                        <button class="button btn-success col-xs-12 pull-right"> Save </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>   <!-- menu quick links-->
