<?php if (!empty($likeUsers)) {    
    foreach ($likeUsers as $key => $likeUser) {
        ?>
        <div class="col-sm-12 com-detail pt5 pb5" >
            <div class="col-lg-1 visible-lg">
                <img class="img-responsive mw30 ib mr10" src="/images/<?php echo $likeUser->image; ?>_thumb.jpg" title="user">
            </div>                                                 
            <div class="col-sm-2 col-xs-5"><a class="closepopup" rel="ajaxrequest"><?php echo $likeUser->name . ' ' . $likeUser->lastname; ?></a></div>                                   
            <div class="col-sm-2 col-xs-5"><a  class="closepopup"></a></div>                                  

            <div class="clearfix"></div>
        </div>
            <div class="clearfix"></div>
        <?php
    }
}
    
if (count($likeUsers) > 5) {
    $randval = rand();
    ?>  
    <div id="loading<?php echo $randval; ?>" class="text-center">
        <a class="btn btn-info fs12 btn-lg mt20 mb20" resultDiv="loading<?php echo $randval; ?>" data-href="/asset_assets/loadmorelike/<?php echo $asset_id . '/' . $type . '/' . ++$pageNumber; ?>"  removeDiv="loading<?php echo $randval; ?>" appendDiv="CommentCollection<?php echo $asset_id ?>" rel="ajaxRequestAppendResultHR" > Load More... </a>
    </div>
<?php } ?>