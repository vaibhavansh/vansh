<?php
global $page;
$userId = $page->currentUser->id;
?>
<section class="">
    <div class="panel-menu theme-primary p5 pbn">
        <div class="panel mb5 mtn">
            <div class="panel-heading text-center">
                <span class="panel-icon col-sm-12 hidden-xs"><i class="fa fa-pencil hidden-xs"></i> Blogs</span>
                <span class="pull-right fix-right">
                    <div class="btn-group text-right">
                        <a href="/blogs/edit" rel="popUpBox" class="btn btn-success fs12 btn-xs" ><span class="fa fa-plus"></span> <span class="hidden-xs">Add New</span></a>
                    </div>
                </span>
            </div>
        </div>
    </div>
    <div class="panel-menu pn">          
        <div class=" admin-form pt5">
            <form resultDiv='mainContent' name="searchAssets" id="searchAssets" method="post" class="form-inline col-xs-12 pln pb5" keepVisible="1" keepResult="1" action="/blogs/" rel="ajaxifiedForm">        
                <div class="col-lg-12 prn">
                    <label for="name" class="field prepend-icon">
                        <input class="event-name gui-input br-light light mbn search-input" type="text" name="searchTitle" placeholder="Search" value="<?php echo $searchTitle = ( isset($_POST['searchTitle']) && $_POST['searchTitle'] != '' ) ? $_POST['searchTitle'] : ''; ?>" />
                        <label for="name" class="field-icon"><i class="fa fa-search"></i></label>
                        <div class="btn-fix-right">
                            <button type="submit" class="submit-btn button btn-success pull-left mr5"><i class="fa fa-search hidden-lg"></i><span class="visible-lg">Search</span></button>
                            <button type="reset" class="reset-btn button btn-danger"><i class="fa fa-refresh hidden-lg"></i><span class="visible-lg">Reset</span></button>    
                        </div>
                    </label>
                </div>
            </form>            
            <div class="clearfix"></div>
        </div>
    </div>
    <!--    <div class="col-lg-3 col-xs-12 pull-right">
    <?php //if (!empty($addform)) echo $addform; ?>
        </div>-->
    <div id="animation-switcher " class="tray-center col-lg-12 col-xs-12 pn pull-left">
        <div id="paginationnew" class="paginationnew">
            <?php
            $count = 0;
            if (!empty($list->data)) {
                foreach ($list->data as $blog) {
                    ?>
                    <div class="z">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="panel mb25 mt5">
                                <div class="panel-heading"><span class="panel-title"> <i class="fa fa-th-list"></i><a href="/viewblog/<?php echo $blog->id; ?>/readonly" rel="popUpBox"><?php echo $blog->title; ?></a></span>
                                    <?php if ($page->currentUser->id == $blog->uploaded_by) { ?>
                                        <span class="pull-right fix-right">
                                            <div class="btn-group text-right">
                                                <a href="/blogs/edit/<?php echo $blog->id; ?>/" rel="popUpBox" class="btn btn-info br2 btn-xs popup"><span class="fa fa-pencil"></span></a>
                                            </div>
                                        </span>                                           
                                    <?php } ?><div class="clearfix"></div>
                                </div>
                                <div class="panel-body p10 mimh-100">
                                    <p><?php echo $blog->description ?></p>
                                    <a href="/viewblog/<?php echo $blog->id; ?>/readonly" rel="popUpBox" class="pull-right">Read More</a>
                                </div>
                                <!-------------like system start----------->
<!--                               <div id="likesyetem" class="panel-body p10 mimh-100" title="assetComment">
                                   <?php
//                                    $likecomments = new Asset_Models_AssetComment();
//                                    $likecomments->likeSystem($userId, $blog->id, $type = "assetComment");
                                    ?>

                                </div>     -->
                                <!-----------end lik system----------------->
                                <div class="panel-body p10 mimh-100">
                                    <?php
                                    if ($blog->custom_fields) {
                                        $tags = explode(",", $blog->custom_fields);
                                        foreach ($tags as $tag) {
                                            if (!empty($tag)) {
                                                ?>                                       
                                                <span class="label label-info tags"> <?php echo $tag; ?> </span>                                    
                                                <?php
                                            }
                                        }
                                    }
                                    ?>
                                </div>
                            </div>

                        </div>
                    </div>
                    <?php
                    if ($count % 2) {
                        echo '<div class="clearfix"></div>';
                    }
                    $count++;
                }
            } else {
                echo '<div class="col-xs-12"><div class="panel mb25 mt5"><div class="panel-heading"><h3>No Blogs Found</h3></div></div></div>';
            }
            ?>
            <div class="clearfix visible-sm visible-lg visible-md visible-xs"></div>                 
        </div>   
        <div class="clearfix"></div>
        <?php if ($list->nextPageExists()) { ?>
            <a class="btn btn-default col-sm-12" href="<?php echo $list->getNextPageLink(array('url' => '/blogs')); ?>" rel="ajaxrequest">Load More</a>
        <?php } ?>

        <div class="clearfix" ></div>
    </div>
</section>
<script>
    $(".reset-btn").click(function () {
        $(this).parents("form").find(".search-input").val("");
        $(this).parents("form").find(".submit-btn").click();
    });
</script>

