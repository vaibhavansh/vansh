<!-- create new order panel-->
<?php $rand = rand(10, 1000);?>
<div class="panel mb25 mt5">
    <div id="menus<?php echo $rand;?>ResultDiv" class="resultDiv"></div>
    <?php if (empty($asset->id)) { ?>
        <div class="panel-heading"><span class="panel-title"> <i class="fa fa-file-text hidden-xs"></i> Add Pages</span>
        </div>
        <div class="panel-body p20 pb10">
            <div class="tab-content pn br-n admin-form">
                <div id="tab1_1" class="tab-pane active">
                    <div class="section row mbn">
                        <div class="col-md-12 pn">
                            <form id="menus<?php echo $rand;?>" name="menus" method="POST" close_popup="1" keepvisible="1" role="form" action="/saveproject/" rel="ajaxifiedFormHR" autocomplete="off" backToPage="/hrmenus/" successMsg="Menus Added Successfully!">
                                <input  type="hidden" name="asset_type_id" value="13">
                                <div class="section row mb15">
                                    <div class="col-xs-12">
                                        <label for="menuttitle" class="field prepend-icon">
                                            <input id="menuttitle" type="text" name="title" placeholder="Page Title" class="event-name gui-input br-light light required">
                                            <label for="menuttitle" class="field-icon"><i class="fa fa-file-text"></i></label>
                                            <p class="menuttitle"></p>
                                        </label>
                                    </div>
                                </div>
                                <div class="section row mb15">
                                    <div class="col-xs-12">
                                        <label for="description" class="field prepend-icon">
                                            <textarea id="description" type="text" name="description" placeholder="Add Desription Here..." class="event-name gui-textarea br-light light required"></textarea>
                                            <label for="description" class="field-icon"><i class="fa fa-file-o"></i></label>
                                            <p class="projectdescriptionclass"></p>
                                        </label>
                                    </div>
                                </div>
                                <div class="section row mb15">
                                    <div class="col-xs-12">
                                        <input type="submit" class="button btn-success col-xs-12 pull-right saveprojectsave projects_save" id="save"  value="Add Page">
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    <?php }else{ ?>
        <div class="panel-heading"><span class="panel-title"> <i class="fa fa-file-text"></i> <?php echo $header;?></span>
        </div>
        <div class="panel-body p20 pb10">
            <div class="tab-content pn br-n admin-form">
                <div id="tab1_1" class="tab-pane active">
                    <div class="section row mbn">
                        <div class="col-md-12 pn">
                            <form id="menus<?php echo $rand;?>" name="menus" method="POST" close_popup="1" keepvisible="1" role="form" action="/saveproject/<?php echo $asset->id;?>" rel="ajaxifiedFormHR" autocomplete="off" backToPage="/hrmenus/" successMsg="Menus Added Successfully!">
                                <input  type="hidden" name="asset_type_id" value="13">
                                <div class="section row mb15">
                                    <div class="col-xs-12">
                                        <label for="menuttitle" class="field prepend-icon">
                                            <input id="menuttitle" type="text" name="title" placeholder="Page Title" class="event-name gui-input br-light light required" value="<?php echo $asset->title;?>">
                                            <label for="menuttitle" class="field-icon"><i class="fa fa-file-text"></i></label>
                                            <p class="menuttitle"></p>
                                        </label>
                                    </div>
                                </div>
                                <div class="section row mb15">
                                    <div class="col-xs-12">
                                        <label for="description" class="field prepend-icon">
                                            <textarea id="description" type="text" name="description" placeholder="Add Desription Here..." class="event-name gui-textarea br-light light required"><?php echo $asset->description;?></textarea>
                                            <label for="description" class="field-icon"><i class="fa fa-file-o"></i></label>
                                            <p class="projectdescriptionclass"></p>
                                        </label>
                                    </div>
                                </div>
                                <div class="section row mb15">
                                    <div class="col-xs-12">
                                        <input type="submit" class="button btn-success col-xs-12 pull-right saveprojectsave projects_save" id="save"  value="Save Menu">
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    <?php }?>
</div>   <!-- menu quick links-->
