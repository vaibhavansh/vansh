<?php

class Asset_Models_AssetImage extends Core_Models_DbTable {

    static $table = 'asset_images';
    static $fields = null;

    function printImageThumb() {
        ?>
        <div id="displayImageThumb<?php echo $this->image_id ?>">
            <a  href="#displayImage<?php echo $this->image_id ?>" rel="popUpBox">
                <img src='/image_images/displayimagethumb/<?php echo $this->image_id ?>/' />
            </a>
        </div>
        <div id="displayImage<?php echo $this->image_id ?>" style="display:none;">
            <img src='/image_images/displayimage/<?php echo $this->image_id ?>/' width="640"/>
        </div>
        <?php
    }
    
    function printImageFancy() {       
        ?>
        <div id="displayImageThumb<?php echo $this->image_id ?>">
            <a class="fancybox" data-thumbnail="/images/<?php echo $this->image_id ?>_thumb.jpg" href="#displayImage<?php echo $this->image_id ?>" rel="group_asset">
                <img src='/images/<?php echo $this->image_id ?>_thumb.jpg' class='mw140' />
            </a>
        </div>
        <div id="displayImage<?php echo $this->image_id ?>" style="display:none;">
            <img src='/images/<?php echo $this->image_id ?>_main.jpg' />
        </div>
        <?php
    }
    
    function hrsiteImage($class, $height, $width, $imagetype) {
        if ($imagetype == "main") { 
            ?>
                <img class="<?php echo $class; ?>" src="/images/<?php echo $this->image_id ?>_main.jpg" alt="Hr Bezoar"/>
                <?php } else {?>
                 <img class="<?php echo $class; ?>" src="/images/<?php echo $this->image_id ?>_thumb.jpg" alt="Hr Bezoar"/>
            <?php
            }
        }

    function imageURL() {
        return "/images/" . $this->image_id . "_main.jpg";
    }

    function imageThumbURL() {
        return "/images/" . $this->image_id . "_thumb.jpg";
    }

    public function getIdByImageId($imageId = '') {
        $assetImageId = Asset_Models_AssetImage::find_all(array('where' => "image_id = {$imageId}",
                    'cols' => "asset_images.id"));
        $assetImage = array_shift($assetImageId);
        return $assetImage->id;
    }

}
?>
