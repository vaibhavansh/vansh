<?php

class Asset_Models_AssetEstimateTime extends Core_Models_DbTable {

    static $table = 'asset_estimate_times';
    static $fields = null;
}

?>
