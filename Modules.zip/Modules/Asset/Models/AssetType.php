<?php

class Asset_Models_AssetType extends Core_Models_DbTable {

    static $table = 'tags';
    static $fields = null;

    static function getAssetTypeBySlug($slug) {
        $tag = array_shift(Tag_Models_Tag::find_all(array('where' => "slug='{$slug}'")));
        if (!empty($tag)) {
            return $tag;
        } else {
            return false;
        }
    }

}
