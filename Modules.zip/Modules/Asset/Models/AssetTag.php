<?php

class Asset_Models_AssetTag extends Core_Models_DbTable {

    static $table = 'asset_tags';
    static $fields = null;
}

?>
