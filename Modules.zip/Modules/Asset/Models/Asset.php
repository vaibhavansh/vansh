<?php

class Asset_Models_Asset extends Core_Models_DbTable {

    static $table = 'assets';
    protected $className;
    static $fields = null;
    static $userSpecificAssets = array(1,2,3); #notes/bookmarks/rss
    /**
     * This is just a fix for mr/hi code already indexed in google
     * this should not be needed eventually.
     * @var type
     */
    function save($data = array()) {
        $data['created'] = !empty($this->created) ? $this->created : date('Y-m-d H:i:s');
        $data['modified'] = date('Y-m-d H:i:s');
        parent::save($data);
        return $this->id;
    }

    /**
     * Save the asset tags for the asset passes the new tags array with id of tags to save.
     * Deletes any asset_tag not found.
     * $tags is an array of tags id like array(14,25,43);
     * @param array $data
     */
    function saveAssetTags($tags = array()) {
        foreach ($this->assetTags() as $assetTag) {
            $key = array_search($assetTag->tag_id, $tags);
            if ($key === NULL) {
                unset($tags[$key]);
            } else {
                $assetTag->delete();
            }
        }
        foreach ($tags as $tag) {
            $newAssetTag = new Asset_Models_AssetTag();
            if (!empty($tag)) {
                $newAssetTag->save(array('tag_id' => $tag, 'asset_id' => $this->id));
            }
        }
    }

    /**
     * Save the videos for asset.
     * needs array with two arrays.
     * 1) the assetvideoids in priority order.
     * 2) embedcode in same order.
     * saves/deletes.
     * @param type $videos
     */
    function primaryImage() {
        $this->images();
        $this->primaryImage = !empty($this->images) ? array_shift($this->images) : null;
        return $this->primaryImage;
    }

    function images() {
        if (empty($this->images))
            $this->images = Asset_Models_AssetImage::find_all(array('where' => "asset_id='{$this->id}'", 'join' => 'images on images.id=asset_images.image_id', 'cols' => 'asset_images.*,images.title'));
        return $this->images;
    }

    function assetTags() {
        $this->assetTags = Asset_Models_AssetTag::find_all(array('where' => " asset_id='{$this->id}' "));
        return $this->assetTags;
    }

    function assetType() {
        $this->assetType = new Tag_Models_Tag($this->asset_type_id);
        return $this->assetType;
    }
    
    function saveAssetImages($tempImages) {
        if (!empty($tempImages)) {
            $imageData = array();
            foreach ($tempImages as $value) {
                $imageData['image'] = Image_Models_Image::scaleImage($value);
                $imageData['image_thumb'] = Image_Models_Image::generateThumb($value);
                $imageData['type'] = 'jpeg';
                $imageData['title'] = $_POST['title'];

                $image = new Image_Models_Image();
                $imageId = $image->save($imageData);
                if (!empty($imageId)) {
                    $newAssetImage = new Asset_Models_AssetImage();
                    $newAssetImage->save(array('asset_id' => $this->id, 'image_id' => $imageId));
                }
            }
        }
    }

}
