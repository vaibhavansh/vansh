<?php

class Form_Models_FormGroup extends Core_Models_DbTable {

    var $className = 'FormGroup';
    static $table = 'form_groups';
    static $fields = NULL;

    function getChildIdData() {
        $groupAddMore = new Form_Models_FormGroup($this->child_group_id);
        if (!empty($groupAddMore)) {
            return $groupAddMore->add_more_group;
        } else {
            return FALSE;
        }
    }

    function getChildIdAddMoreData() {
        global $page;
        $childFieldDatas = Form_Models_FormGroupField::find_all(array('where' => "group_id = '{$this->child_group_id}'"));
        if (!empty($childFieldDatas)) {
            foreach ($childFieldDatas as $userField) {
                if ($userField->fieldType == 'OptionBox') {
                    if (!empty($userField->option_data)) {
                        list( $optionsBoxData, $optionBoxKeys) = explode(':', $userField->option_data);
                        $fieldOptions['optionBoxData'] = array_combine(explode(',', $optionBoxKeys), explode(',', $optionsBoxData));
                    }
                    $fieldOptions['defaultValue'] = array();
                    $fieldOptions['className'] = isset($userField->className) ? $userField->className : 'form-control'; #using isset, as it could be blank.
                    $fieldOptions['multiSelect'] = $userField->multi_select;
                    $fieldOptions['name'] = "data_array[{$userField->id}][data][]";
                    $fieldOptions['forceDropDown'] = 1;
                    $fieldOptions['noneOption'] = 1;
                    $fieldOptions['noneOptionText'] = isset($userField->default_val) ? $userField->default_val : '';
                    $valueField = new $userField->fieldType($fieldOptions);
                    ?>
                    <div class="col-sm-6 col-xs-12 mb15">
                        <label for="<?php echo $userField->field_key; ?>" class="field select">
                            <?php echo $valueField->generate(); ?>
                            <i class="arrow"></i>
                        </label>
                    </div>
                    <?php
                } else if ($userField->fieldType == 'Textarea') {
                    ?>
                    <div class="col-sm-6 col-xs-12 mb15">
                        <label for="<?php echo $userField->field_key; ?>" class="field prepend-icon">
                            <textarea class="<?php echo $userField->className; ?>" placeholder="<?php echo $userField->field_title; ?>" name="data_array[<?php echo $userField->id; ?>][data][]" type="<?php echo $userField->fieldType; ?>" id="<?php echo $userField->field_key; ?>"></textarea>
                            <label for="<?php echo $userField->field_key; ?>" class="field-icon">
                                <i class="<?php echo $userField->divclassName ?>"></i>
                            </label>
                        </label>
                    </div>
                    <?php
                } else if ($userField->fieldType == 'file') {
                    ?>
                    <input type="hidden" name="field[<?php echo $userField->id; ?>][field_key][]" value="<?php echo $userField->field_key; ?>">
                    <input type="hidden" name="data_array_old[<?php echo $userField->id; ?>][data][]" value="<?php echo $userField->data; ?>">
                    <div class="col-sm-6 col-xs-12 mb20">
                        <label class="p10"><?php echo $userField->title; ?></label>
                        <label for="<?php echo $userField->field_key; ?>" class="field file"><span class="button btn-primary"> Choose File</span>
                            <input id="<?php echo $userField->field_key; ?>" type="<?php echo $userField->fieldType; ?>" 
                                   name="data_array[<?php echo $userField->id; ?>][data][]" 
                                   onchange="document.getElementById('uploader<?php echo $userField->field_key; ?>').value = this.value;" class="<?php echo $userField->className; ?>">
                            <input id="uploader<?php echo $userField->field_key; ?>" type="text" placeholder="no file selected" readonly class="<?php echo $userField->divClassName; ?>">
                        </label>
                    </div>
                    <?php
                } else {
                    ?>
                    <div class="col-sm-6 col-xs-12 mb15">
                        <label for="<?php echo $userField->field_key; ?>" class="field prepend-icon">
                            <input id="<?php echo $userField->field_key; ?>" type="<?php echo $userField->fieldType; ?>" name="data_array[<?php echo $userField->id; ?>][data][]" placeholder="<?php echo $userField->field_title; ?>" class="<?php echo $userField->className; ?>">
                            <label for="<?php echo $userField->field_key; ?>" class="field-icon">
                                <i class="<?php echo $userField->divClassName ?>"></i>
                            </label>
                        </label>
                    </div>
                <?php }
                ?>
                <input type="hidden" name="data_array[<?php echo $userField->id; ?>][group_id][]" value="<?php echo $userField->group_id; ?>">
                <input type="hidden" name="data_array[<?php echo $userField->id; ?>][field_id][]" value="<?php echo $userField->id; ?>">
                <input type="hidden" name="data_array[<?php echo $userField->id; ?>][form_id][]" value="<?php echo $this->form_id ?>">
                <input type="hidden" name="data_array[<?php echo $userField->id; ?>][user_id][]" value="<?php echo $page->currentUser->id; ?>">
                <input type="hidden" name="data_array[<?php echo $userField->id; ?>][modified_date][]" value="<?php echo date('Y-m-d'); ?>">
                <?php
            }
            ?>
            <a id="remove_button" href="javascript:void(0)" onclick="$(this).parents('.childeditmoresection').prev('h4').remove();
                                $(this).parents('.childeditmoresection').remove();" class="btn btn-sm btn-danger pull-right">Remove</a>
            <div class="clearfix"></div>
            <?php
        }
        return;
    }

    function getGroupsByFormId($form_id,$group_id = '') {
        $getGroupsData = array_shift(Form_Models_FormGroup::find_all(array('where' => "form_id = '{$form_id}' and id = (select min(id) from form_groups where id > '{$group_id}')")));
        if (!empty($getGroupsData)) {
            return $getGroupsData;
        } else {
            return FALSE;
        }
    }

}
?>