<?php

class Form_Models_FormGroupField extends Core_Models_DbTable {

    var $className = 'FormGroupField';
    static $table = 'form_group_fields';
    static $fields = NULL;
}
?>