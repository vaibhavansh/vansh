<?php

class Form_Models_Form extends Core_Models_DbTable {

    var $className = 'Form';
    static $table = 'forms';
    static $fields = NULL;
    static $showFrom = array(
        1 => 'Show Popup When Login',
        2 => 'Add To Menu'
    );

    public function getNameById($formId) {
        $name = array_shift(Form_Models_Form::find_all(array('where' => "id = '{$formId}'",
                    'cols' => "title")));
        return $name->title;
    }

    public function getDescriptionById($formId) {
        $description = array_shift(Form_Models_Form::find_all(array('where' => "id = '{$formId}'",
                    'cols' => "description")));
        return $description->description;
    }

    public function listAllUsersSubmittedForm() {
        $variables = array();
        $variables['listAllSubmittedForms'] = User_Models_UserData::find_all(array('where' => "forms.link_form != 'registration'",
                    'leftjoin' => "forms on forms.id = user_data.form_id",
                    'cols' => "user_data.id,user_data.user_id as userFormUserId,forms.id as formId,forms.title",
                    'groupBy' => "user_data.user_id,user_data.form_id",
                    'orderBy' => "user_data.id asc"));
        return $variables;
    }

}

?>