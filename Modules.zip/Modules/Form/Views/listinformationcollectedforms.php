<?php
global $page;
?>
<section class="">
    <div id="saveEmployeeResultDiv" class="resultDiv"></div>
    <!-- begin: .tray-center-->
    <div id="animation-switcher" class="tray-center ">
        <!-- recent orders table-->
        <div class="panel mb25 mt5">
            <div class="panel-heading"><span class="panel-title"> <i class="fa fa-th-list"></i> Information Requests</span>
                <div class="clearfix"></div>
            </div>
            <div class="panel-menu admin-form theme-primary p5 pbn">
                <div class="row">
                    <form resultDiv='mainContent' name="searchUsers" id="searchUsers" method="post" class="form-inline col-xs-12 pln pb5" keepVisible="1" keepResult="1" action="/listInformationCollectedForm/" rel="ajaxifiedForm">      
                        <div class="col-xs-12 prn">
                            <label for="name" class="field prepend-icon">
                                <input class="event-name gui-input br-light light mbn search-input" type="text" name="searchTitle" placeholder="Search" value="<?php echo $searchTitle = ( isset($_POST['searchTitle']) && $_POST['searchTitle'] != '' ) ? $_POST['searchTitle'] : ''; ?>" />
                                <label for="name" class="field-icon"><i class="fa fa-search"></i></label>
                                <div class="btn-fix-right">
                                    <button type="submit" class="submit-btn button btn-success pull-left mr5"><i class="fa fa-search hidden-lg"></i><span class="visible-lg">Search</span></button>
                                    <button type="reset" class="reset-btn button btn-danger"><i class="fa fa-refresh hidden-lg"></i><span class="visible-lg">Reset</span></button>    
                                </div>
                            </label>
                        </div>
                    </form>
                </div>
            </div>
            <?php if (!empty($forms->data)) { ?>
                <div class="panel-body pn">
                    <div class="list-com" id="list-com">
                        <div class="no-tpad upperCase">
                            <div class="panel-body pn">
                                <div class="com-detail ">
                                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
                                        <p><strong>Form Name</strong></p>
                                    </div>
                                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
                                        <p><strong>Form Description</strong></p>
                                    </div>
                                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
                                        <p><strong>Action</strong></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php
                        foreach ($forms->data as $form) {
                            if (in_array($page->currentUser->webUserRole, $user_role_id)) {
                                ?>
                                <div class="list-com-data pn">
                                    <div class="com-detail ">
                                        <div class="text-left col-sm-4"><p><?php echo $form->title ?></p></div>
                                        <div class="text-left col-sm-4"><p><?php echo $form->description ?></p></div>
                                        <div class="text-left col-sm-4 mt5 mb5">
                                            <a href="/form_forms/informationcollectedform/<?php echo $form->id; ?>/" rel="popUpBox" class="btn btn-danger popup btn-xs" data-effect="mfp-flipInY" oncloseFunction="reloadDiv('listinformationcollectedforms', 'mainContent', 'ajax');">
                                                <i class="fa fa-pencil"></i>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                    <div class="clearfix"></div>
                                </div>
                                <?php
                            }
                        }
                        ?>
                        <div class="list-com-data pn">
                            <div class="panel-body pn">
                                <div class="com-detail ">
                                    <div class="col-xs-12 pt5">
                                        <div class="pull-left">                             
                                            <h5><?php echo $forms->getCurrentPageInfo(); ?></h5>
                                        </div>
                                        <div class="pull-right" >   
                                            <?php echo $forms->printPageNumbers(array('url' => "/listinformationcollectedforms", 'div_id' => 'mainContent', 'ajaxRequest' => true)); ?>
                                        </div>
                                    </div>
                                </div> 
                            </div>
                        </div>
                    <?php } else {
                        ?>
                        <div class="list-com-data pn">
                            <div class="panel-body pn">
                                <div class="com-detail ">
                                    <div class="col-lg-12 p25">
                                        You do not have any information requests at this time.
                                    </div>
                                </div> 
                            </div>
                        </div>
                    <?php }
                    ?>
                </div>
            </div>
        </div>
    </div>  
    <div class="clearfix"></div>
</section>