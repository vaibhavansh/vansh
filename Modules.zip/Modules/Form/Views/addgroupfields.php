<script type="text/javascript">
    function fieldoptions() {
        $('#fieldType_data').empty();
        switch ($('#fieldType').val()) {
            case 'TextField':
                $('#textfield_div').clone(true).prependTo($('#fieldType_data')).show();
                break;
            case 'Textarea':
                $('#textarea_div').clone(true).prependTo($('#fieldType_data')).show();
                break;
            case 'checkbox':
                $('#checkbox_div').clone(true).prependTo($('#fieldType_data')).show();
                break;
            case 'OptionBox':
                $('#optionbox_div').clone(true).prependTo($('#fieldType_data')).show();
                break;
            case 'file':
                $('#fileUpload_div').clone(true).prependTo($('#fieldType_data')).show();
                break;
            default:
                $('#fieldType_data').append("<label>Please Select Correct Option</label>");
        }
    }
    function optionboxdata() {
        $('#option_box_options').clone(true).appendTo($('#selectbox_options')).show().find('input.form-control').val('');
    }
</script>
<div id='addgroupFieldResultDiv' class="resultDiv"></div>
<div id="modal-form" class="admin-form mfp-with-anim">
    <div class="panel">
        <div id="addgroupFieldResultDiv" class="resultDiv"></div>
        <div class="panel-heading">
            <span class="panel-title">
                <i class="fa fa-pencil"></i>
                Add New field
            </span>
        </div>
        <form close_popup='1' resultDiv="addgroupFieldResultDiv" name='addgroupField' rel='ajaxifiedForm' id ='addgroupField' role='form' method='post' backToPage='/form_forms/editformsgroupsfields/<?php echo $form_id; ?>/<?php echo $groupId; ?>' action='/form_forms/addGroupFields/<?php echo $form_id; ?>/<?php echo $groupId; ?>' >
            <input type="hidden" name="submit" value="1">
            <div class="panel-body p25">
                <div class="col-sm-6 mb15">
                    <input type="text" placeholder="Field Title" name="field_title" id="field_title" class="required valid form-control">
                </div>
                <div class="col-sm-6 mb15">
                    <select onchange = "fieldoptions()" class='form-control required valid' id='fieldType' name='fieldType'>
                        <option value=''>Select Field Type</option>
                        <option value='TextField'>TextField</option>
                        <option value='Textarea'>Textarea</option>
                        <option value='checkbox'>checkbox</option>
                        <option value='OptionBox'>OptionBox</option>
                        <option value='file'>fileUpload</option>
                    </select>
                </div>
                <div id='fieldType_data'></div>
                <div class="clearfix spacer10"></div>
                <div class="red-note"><h4>Note For "event-name" class:</h4>
                    <p>1) Please add 'required' if you want to make field required.<br/>
                        2) Please add 'datepicker dob' for date of birth field.<br/>
                        3) Plaese add 'datepicker' if you want to show date.<br/>
                        4) Please add 'monthpicker' if you want to show month.<br/>
                    </p>
                </div>
                <div>
                    <button type="submit" class="btn btn-success" value="Save Group Data">Save Group Data</button>
                </div>
            </div>
        </form>
        <div id="textarea_div" style="display:none">
            <div class="col-sm-6 mb15">
                <input type='text' name='field_key' placeholder='Field Key' id="field_key" class=" form-control required" value="">
            </div>
            <div class="col-sm-6 mb15">
                <input id="priority" placeholder="Priority" type="text" value="" name="priority" class="form-control">
            </div>
            <div class="col-sm-6 mb15">
                <input id="divClassName" placeholder="Div Class Name" type="text" value="fa fa-certificate" name="divClassName" class="form-control">
            </div>
            <div class="col-sm-6 mb15">
                <input id="className" placeholder="Class Name" type="text" value="event-name gui-textarea br-light light" name="className" class="form-control">
            </div>
        </div>
        <div id="textfield_div" style="display:none">
            <div class="col-sm-6 mb15">
                <input type='text' name='field_key' placeholder='Field Key' id="field_key" class=" form-control required" value="">
            </div>
            <div class="col-sm-6 mb15">
                <input id="priority" placeholder="Priority" type="text" value="" name="priority" class="form-control">
            </div>
            <div class="col-sm-6 mb15">
                <input id="divClassName" placeholder="Div Class Name" type="text" value="fa fa-certificate" name="divClassName" class="form-control">
            </div>
            <div class="col-sm-6 mb15">
                <input id="className" placeholder="Class Name" type="text" value="event-name gui-input br-light light" name="className" class="form-control">
            </div>
        </div>
        <div id="checkbox_div" style="display:none">
            <div class="col-sm-6 mb15">
                <input type='text' name='field_key' placeholder='Field Key' id="field_key" class=" form-control required" value="">
            </div>
            <div class="col-sm-6 mb15">
                <input id="priority" placeholder="Priority" type="text" value="" name="priority" class="form-control">
            </div>
            <div class="col-sm-6 mb15">
                <input id="default_value" placeholder="Default Value" type="text" value="" name="default_val" class="form-control">
            </div>
            <div class="col-sm-6 mb15">
                <input id="option_data" placeholder="Text" type="text" value="" name="option_data" class="form-control">
            </div>
            <div class="col-sm-6 mb15">
                <input id="className" placeholder="Class Name" type="text" value="" name="className" class="form-control">
            </div>
            <div class="col-sm-6 mb15">
                <input id="divClassName" placeholder="Div Class Name" type="text" value="" name="divClassName" class="form-control">
            </div>
        </div>
        <div id="optionbox_div" style="display:none">
            <div class="col-sm-6 mb15">
                <input type='text' name='field_key' placeholder='Field Key' id="field_key" class=" form-control required" value="">
            </div>
            <div class="col-sm-6 mb15">
                <input id="priority" placeholder="Priority" type="text" value="" name="priority" class="form-control">
            </div>
            <div class="col-sm-6 mb15">
                <input id="default_value" placeholder="Default Value" type="text" value="" name="default_val" class="form-control">
            </div>
            <div class="col-sm-6 mb15">
                <input id="multi_select" placeholder="Multi Select" type="text" value="" name="multi_select" class="form-control">
            </div>
            <div class="col-sm-6 mb15">
                <input id="className" placeholder="Class Name" type="text" value="form-control" name="className" class="form-control">
            </div>
            <div id="selectbox_options">
                <div class="option_box_options">
                    <h4>Option Field And Value:</h4>
                    <div class="col-sm-6 mb15">
                        <input type='text' name='options[field][]' placeholder="Option Field Text" class='form-control required valid'>
                    </div>
                    <div class="col-sm-6 mb15">
                        <input type='text' name='options[value][]' placeholder="Option Field Value" class='form-control required valid'> 
                    </div>
                </div>
            </div>
            <div class="spacer10"></div>
            <a href="javascript:void(0)" class="btn btn-sm btn-primary mb15" onclick="optionboxdata()">Add More Options</a>
            <div class="spacer10"></div>
        </div>
        <div id="option_box_options" class="option_box_options" style="display: none;">
            <div class="col-sm-6 mb15">
                <input type='text' placeholder="Option Field Text" name='options[field][]' class='form-control required valid'>
            </div>
            <div class="col-sm-6 mb15">
                <input type='text' placeholder="Option Field Value" name='options[value][]' class='form-control required valid'>
            </div>
            <a href="javascript:void()" onclick="$(this).parents('.option_box_options').remove()" class="btn btn-sm btn-danger pull-right">Remove</a>
            <div class="clearfix spacer10 mb15"></div>
        </div>
        <div id="fileUpload_div" style="display:none">
            <div class='col-sm-6 mb15'>
                <input type='text' name='field_key' placeholder='Field Key' id="field_key" class=" form-control required" value="">
            </div>
            <div class="col-sm-6 mb15">
                <input id="priority" placeholder="Priority" type="text" value="" name="priority" class="form-control">
            </div>
            <div class="col-sm-6 mb15">
                <input id="className" placeholder="Class Name" type="text" value="gui-file" name="className" class="form-control">
            </div>
        </div>
    </div>
</div>