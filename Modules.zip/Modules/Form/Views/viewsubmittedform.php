<?php
global $page;
$userId = !empty($user_id) ? $user_id : $page->currentUser->id;
?>
<section id="content_wrapper">
    <!-- Begin: Content-->
    <section id="content" class="">
        <!-- Begin .page-heading-->
        <div id="animation-switcher">
            <div class="clearfix"></div>
            <!-- begin: .tray-center-->
            <?php
            if (!empty($user_id)) {
                User_Controllers_UsersController::userProfileMenus($user_id);
            }
            ?>
            <div class="clearfix"></div>
            <!-- recent orders table-->
            <div id="view_profile" name="view_profile">
                <div class="panel mb25">
                    <div class="panel-heading">
                        <span class="panel-title"><i class="fa fa-th-list hidden-xs"></i> <?php echo $fullName; ?> Information Requests</span>
                        <div class="clearfix"></div>
                    </div>
                    <div class="panel-menu admin-form theme-primary p5 pbn">
                        <div class="row">
                            <form resultDiv='mainContent' name="searchUsers" id="searchUsers" method="post" class="form-inline col-xs-12 pln pb5" keepVisible="1" keepResult="1" action="/user_users/viewsubmittedform/<?php echo $user_id; ?>" rel="ajaxifiedForm">      
                                <div class="col-xs-12 prn">
                                    <label for="name" class="field prepend-icon">
                                        <input class="event-name gui-input br-light light mbn search-input" type="text" name="searchTitle" placeholder="Search" value="<?php echo $searchTitle = ( isset($_POST['searchTitle']) && $_POST['searchTitle'] != '' ) ? $_POST['searchTitle'] : ''; ?>" />
                                        <label for="name" class="field-icon"><i class="fa fa-search"></i></label>
                                        <div class="btn-fix-right">
                                            <button type="submit" class="submit-btn button btn-success pull-left mr5"><i class="fa fa-search hidden-lg"></i><span class="visible-lg">Search</span></button>
                                            <button type="reset" class="reset-btn button btn-danger"><i class="fa fa-refresh hidden-lg"></i><span class="visible-lg">Reset</span></button>    
                                        </div>
                                    </label>
                                </div>
                            </form>
                        </div>
                    </div>
                    <?php if (!empty($forms->data)) { ?>
                        <div class="panel-body pn">
                            <div class="list-com" id="list-com">
                                <div class="no-tpad upperCase">
                                    <div class="panel-body pn">
                                        <div class="com-detail ">
                                            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
                                                <p><strong>Form Name</strong></p>
                                            </div>
                                            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
                                                <p><strong>Form Description</strong></p>
                                            </div>
                                            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
                                                <p><strong>Action</strong></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php
                                foreach ($forms->data as $form) {
                                    ?>
                                    <div class="list-com-data pn">
                                        <div class="com-detail ">
                                            <div class="text-left col-sm-4"><p><?php echo $form->title ?></p></div>
                                            <div class="text-left col-sm-4"><p><?php echo $form->description ?></p></div>
                                            <div class="text-left col-sm-4 mt5 mb5">
                                                <a href="/form_forms/viewinformationcollectedform/<?php echo $userId; ?>/<?php echo $form->id; ?>/" rel="popUpBox" class="btn btn-danger popup btn-xs" data-effect="mfp-flipInY">
                                                    View
                                                </a>
                                            </div>
                                        </div>
                                        <div class="clearfix"></div>
                                        <div class="clearfix"></div>
                                    </div>
                                    <?php
                                }
                                ?>
                                <div class="list-com-data pn">
                                    <div class="panel-body pn">
                                        <div class="com-detail ">
                                            <div class="col-xs-12 pt5">
                                                <div class="pull-left">                             
                                                    <h5><?php echo $forms->getCurrentPageInfo(); ?></h5>
                                                </div>
                                                <div class="pull-right" >   
                                                    <?php echo $forms->printPageNumbers(array('url' => "/viewsubmittedform/{$user_id}", 'div_id' => 'mainContent', 'ajaxRequest' => true)); ?>
                                                </div>
                                            </div>
                                        </div> 
                                    </div>
                                </div>
                            <?php } else {
                                ?>
                                <div class="list-com-data pn">
                                    <div class="panel-body pn">
                                        <div class="com-detail ">
                                            <div class="col-lg-12 p25">
                                                No Information Request Form Submitted By This User.
                                            </div>
                                        </div> 
                                    </div>
                                </div>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="clearfix"></div>
        <script>
            $(".reset-btn").click(function () {
                $(this).parents("form").find(".search-input").val("");
                $(this).parents("form").find(".submit-btn").click();
            });
        </script>
    </section>
</section>