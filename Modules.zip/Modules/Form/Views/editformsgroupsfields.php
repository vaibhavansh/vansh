<section id="content_wrapper">
    <section id="content" class="">
        <div id="animation-switcher" class="col-sm-12">
            <script type="text/javascript">
                function optionboxdataadd(input, id) {
                    $('#option_box_add').clone(true).appendTo($('#' + input + ' #selectBox')).show().find('input.form-control').val('');
                    $('#' + input + ' #selectBox #option_box_add input#fieldId').attr('name', 'data_dashboard[' + id + '][options][fields][]');
                    $('#' + input + ' #selectBox #option_box_add input#valueId').attr('name', 'data_dashboard[' + id + '][options][value][]');
                }
            </script> 
            <div class='col-sm-12 pn'>
                <div id='editObjectResultDiv' class="resultDiv"></div>
                <div class="col-sm-3 hidden-xs mb15">
                    <div>
                        <a type="button" href="/form_forms/listformsgroups/<?php echo $form_id; ?>/" rel="ajaxRequest" class="btn btn-default">Back</a>
                    </div>
                </div>
                <div class="col-sm-5 col-xs-9 text-center">
                    <h4 style="margin-top: 15px;"><?php echo Form_Models_Form::getNameById($form_id); ?></h4>
                </div>
                <?php if (!empty($editGroup->id)) { ?>
                    <div div class="col-sm-4 col-xs-3 rightAlign text-right mb15">
                        <a class="btn btn-success" href="/form_forms/addgroupfields/<?php echo $form_id; ?>/<?php echo $editGroup->id; ?>" rel="popUpBox"><i class="fa fa-plus visible-xs"></i><span class="hidden-xs">Add Fields to this Group</span></a>
                    </div>
                    <?php
                    $backlink = "/form_forms/editformsgroupsfields/{$form_id}/{$editGroup->id}";
                } else {
                    $backlink = "/form_forms/listformsgroups/{$form_id}/";
                }
                ?>
                <div class="clearfix"></div>
            </div>
            <div class="clearfix"></div>
            <div class="panel mb25 mt5">
                <div class="panel-heading"><i class="fa fa-pencil hidden-xs"></i> <?php echo ' ' . $header; ?></div>
                <div class="clearfix mb15"></div>
                <div class="panel-body pn">
                    <form class="p10 pbn" name ="editObject" resultDiv="editObjectResultDiv" id="editObject" backToPage="<?php echo $backlink; ?>" method="POST" keepVisible="1" keepResult="1" action="/form_forms/saveFormsGroupsFields/<?php echo isset($editGroup->id) ? $editGroup->id : ''; ?>" rel="ajaxifiedForm">
                        <input type="hidden" name="form_id" value="<?php echo $form_id; ?>">
                        <input type="hidden" name="group_id" value="<?php echo $editGroup->id; ?>">
                        <div class='col-md-2 col-sm-4'><input type='text' name='group_title' placeholder='Group Title' id="group_title" class="form-control required" value="<?php echo isset($editGroup->group_title) ? $editGroup->group_title : ''; ?>"></div>
                        <div class='col-md-2 col-sm-4'><input type='text' name='group_key' placeholder='Key' id="group_key" class=" form-control required" value="<?php echo isset($editGroup->group_key) ? $editGroup->group_key : ''; ?>"></div>
                        <div class='col-md-2 col-sm-4'><input type='text' name='group_priority' placeholder='Group Priority' id="group_priority" class=" form-control required" value="<?php echo isset($editGroup->group_priority) ? $editGroup->group_priority : ''; ?>"></div>
                        <?php if (!empty($childGroupId)) { ?>
                            <div class='col-md-2 col-sm-4'>
                                <?php echo isset($childGroupId) ? $childGroupId : ''; ?>
                            </div>
                        <?php } ?>
                        <div class='col-md-2 col-sm-4'>
                            <input type="hidden" id="add_more" value="<?php echo $editGroup->add_more_group; ?>"> 
                            <select name='add_more_group' id="add_more_group" class='form-control required'>              
                                <option value="" <?php echo (isset($editGroup->add_more_group) && ($editGroup->add_more_group == '')) ? 'selected' : ''; ?>>Add More (0/1)</option>
                                <option value="0" <?php echo (isset($editGroup->add_more_group) && ($editGroup->add_more_group == '0')) ? 'selected' : ''; ?>>0</option>
                                <option value="1" <?php echo (isset($editGroup->add_more_group) && ($editGroup->add_more_group == '1')) ? 'selected' : ''; ?>>1</option>
                            </select>
                        </div>
                        <div class="clearfix mb15"></div>
                        <?php if (!empty($groupFields)) { ?>
                            <div id="accordion1" class="panel-group accordion accordion-lg">
                                <?php
                                foreach ($groupFields as $field) {
                                    ?>
                                    <input type='hidden' value='<?php echo isset($field->id) ? $field->id : '' ?>' name='data_dashboard[<?php echo $field->id; ?>][id]'>
                                    <input type='hidden' value='<?php echo isset($field->fieldType) ? $field->fieldType : '' ?>' name='data_dashboard[<?php echo $field->id; ?>][fieldType]'>
                                    <input type='hidden' value='<?php echo isset($field->field_key) ? $field->field_key : '' ?>' name='data_dashboard[<?php echo $field->id; ?>][field_key]'>
                                    <div class="panel mt-15">
                                        <div class="panel-heading"><a data-toggle="collapse" data-parent="#accordion1" href="#<?php echo $field->field_key; ?>" class="accordion-toggle accordion-icon link-unstyled collapsed"><?php echo $field->field_title; ?></a></div>
                                        <div id="<?php echo $field->field_key; ?>" style="height: 0px;" class="panel-collapse collapse">
                                            <div class="panel-body">
                                                <div class="col-sm-6 mb15">
                                                    <label>Field Title</label>
                                                    <input type='text' value="<?php echo $field->field_title; ?>" name='data_dashboard[<?php echo $field->id; ?>][field_title]' class='form-control required valid'>
                                                </div>
                                                <?php if ($field->fieldType != 'TextField' && $field->fieldType != 'Textarea') { ?>
                                                    <div class="col-sm-6 mb15">
                                                        <label>Default</label>
                                                        <input type='text' value="<?php echo isset($field->default_val) ? $field->default_val : '' ?>" name='data_dashboard[<?php echo $field->id; ?>][default_val]' class='form-control'>
                                                    </div>
                                                <?php } ?>
                                                <div class="col-sm-6 mb15">
                                                    <label>Priority</label>
                                                    <input type='text' value="<?php echo isset($field->priority) ? $field->priority : '' ?>" name='data_dashboard[<?php echo $field->id; ?>][priority]' class='form-control'>
                                                </div>
                                                <div class="col-sm-6 mb15">
                                                    <label>ClassName(For Input Field)</label>
                                                    <input type='text' value="<?php echo isset($field->className) ? $field->className : '' ?>" name='data_dashboard[<?php echo $field->id; ?>][className]' class='form-control'>
                                                </div>
                                                <?php if ($field->fieldType != 'OptionBox') { ?>
                                                    <div class="col-sm-6 mb15">
                                                        <label>ClassName(For Input Label Field)</label>
                                                        <input type='text' value="<?php echo isset($field->divClassName) ? $field->divClassName : '' ?>" name='data_dashboard[<?php echo $field->id; ?>][divClassName]' class='form-control'>
                                                    </div>
                                                    <?php
                                                }
                                                if ($field->fieldType == 'OptionBox') {
                                                    ?>
                                                    <div class="col-sm-6 mb15">
                                                        <label>Multi Select</label>
                                                        <input type='text' value="<?php echo isset($field->multi_select) ? $field->multi_select : '' ?>" name='data_dashboard[<?php echo $field->id; ?>][multi_select]' class='form-control required valid'>
                                                    </div>
                                                    <div class="clearfix"></div>
                                                    <div id="selectBox">
                                                        <?php
                                                        if (isset($field->option_data) && !empty($field->option_data)) {
                                                            $optiondata = explode(':', $field->option_data);
                                                            $optionField = explode(',', $optiondata[0]);
                                                            $optionValue = explode(',', $optiondata[1]);
                                                            ?>
                                                            <?php foreach ($optionField as $optionK => $options) {
                                                                ?>
                                                                <div id="option_box_added" class="option_box_added">
                                                                    <div class="col-sm-6 mb15"> 
                                                                        <label>Option Field</label>
                                                                        <input type='text' value="<?php echo $options ?>" name='data_dashboard[<?php echo $field->id; ?>][options][fields][]' class='form-control required valid'>
                                                                    </div>
                                                                    <div class="col-sm-6 mb15">
                                                                        <label>Option Value</label>
                                                                        <input type='text' value="<?php echo $optionValue[$optionK] ?>" name='data_dashboard[<?php echo $field->id; ?>][options][value][]' class='form-control required valid'>
                                                                    </div>
                                                                    <a href="javascript:void()" onclick="$(this).parents('.option_box_added').remove()" class="btn btn-sm btn-danger pull-right">Remove</a>
                                                                    <div class="clearfix spacer10 mb15"></div>
                                                                </div>
                                                            <?php }
                                                            ?>
                                                        <?php }
                                                        ?>
                                                    </div>
                                                    <div id="option_box_add" class="option_box_add" style="display: none;">
                                                        <div class="col-sm-6 mb15">
                                                            <label>Option Field</label>
                                                            <input type='text' placeholder="Option Field Text" name='' id='fieldId' class='form-control required valid'>
                                                        </div>
                                                        <div class="col-sm-6 mb15">
                                                            <label>Option Value</label>
                                                            <input type='text' placeholder="Option Field Value" name='' id="valueId" class='form-control required valid'>
                                                        </div>
                                                        <a href="javascript:void()" onclick="$(this).parents('.option_box_add').remove()" class="btn btn-sm btn-danger pull-right">Remove</a>
                                                        <div class="clearfix spacer10 mb15"></div>
                                                    </div>
                                                    <a href="javascript:void(0)" class="btn btn-sm btn-primary mb15" onclick="optionboxdataadd('<?php echo $field->field_key; ?>', '<?php echo $field->id; ?>')">Add More Options</a>                                          
                                                <?php } elseif ($field->fieldType == 'checkbox') {
                                                    ?>
                                                    <div class="col-sm-6 mb15">
                                                        <label>Text</label>
                                                        <input type='text' value="<?php echo isset($field->text) ? $field->text : '' ?>" name='data_dashboard[<?php echo $field->id; ?>][option_data]' class='form-control'>
                                                    </div>
                                                <?php } ?>
                                                <div class="clearfix"></div>
                                                <div class="red-note"><h4>Note For "event-name" class:</h4>
                                                    <p>1) Please add 'required' if you want to make field required.<br/>
                                                        2) Please add 'datepicker dob' for date of birth field.<br/>
                                                        3) Plaese add 'datepicker' if you want to show date.<br/>
                                                        4) Please add 'monthpicker' if you want to show month.<br/>
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php } ?>
                            </div>
                        <?php } ?>
                        <div class="panel-footer row bg-wild-sand text-center p5">
                            <?php if (!empty($editGroup->id)) { ?>
                                <a href="/form_forms/addgroupfields/<?php echo $form_id; ?>/<?php echo $editGroup->id; ?>" rel="popUpBox" id="field_ini" class="btn btn-warning mb10 mt10">Add Fields to this Group</a>
                            <?php } ?>
                            <button type="submit" class="btn btn-success mb10 mt10" value="Save Group Data">Save Group Data</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
</section>