<section id="content_wrapper">
    <section id="content" class="">
        <div id="animation-switcher" class="tray-center main-div">
            <div class="panel mb25 mt5">
                <div class="panel-heading"><span class="panel-title"> <i class="fa fa-th-list hidden-xs"></i> User Dashboard Sections</span>
                    <span class="pull-right fix-right">
                        <div class="btn-group">
                            <button type="button" class="btn btn-default light div-slider"><i class="fa"></i></button>
                        </div>
                        <div class="btn-group">
                            <a href="#add_new_dash_section_popup"  rel="popUpBox" oncloseFunction = "reloadDiv('mainContent', 'ajax');" class="btn btn-success btn-xs hidden-lg"><i class="fa fa-plus"></i></a>
                        </div>
                    </span>
                </div>
                <?php if (!empty($forms->data)) { ?>
                    <div class="panel-body pn">
                        <div class="">
                            <div class="list-com" id="list-com">
                            <div class="col-sm-12 com-detail pt10">
                                <div class="col-sm-4 col-xs-6"><p><strong>Title</strong></p></div>
                                <div class="col-sm-4 hidden-xs"><p><strong>Description</strong></p></div>
                                <div class="col-sm-4 col-xs-6 text-right"><p><strong>Action</strong></p></div>
                                <div class="clearfix"></div>
                            </div>
                            <?php foreach ($forms->data as $data) { ?>
                                <div class="col-sm-12 com-detail p15" id='section_<?php echo $data->id ?>'>
                                    <div class="col-sm-4 col-xs-12"><p><?php echo $data->title; ?></p></div>
                                    <div class="col-sm-4 hidden-xs"><p><?php echo $data->description; ?></p></div>
                                    <div class="clearfix visible-xs"></div>
                                    <div class="col-sm-4 col-xs-12 text-right prn">
                                        <a class="btn btn-xs btn-info" href="/form_forms/editforms/<?php echo $data->id ?>"  rel='popUpBox'  data-toggle="tooltip" data-placement="bottom" title="Edit"><span class="glyphicon glyphicon-pencil"></span></a>
                                        <a class="btn btn-xs btn-warning" href="/form_forms/listformsgroups/<?php echo $data->id ?>/" rel='ajaxRequest' data-toggle="tooltip" data-placement="bottom" title="Manage Details"><span class="glyphicon glyphicon-wrench"></span></a>                           
                                        <a class="btn btn-xs btn-danger" href="javascript:void(0);" onclick="deleteForm('<?php echo $data->id ?>');"  data-toggle="tooltip" data-placement="bottom" title="Delete"><span class="glyphicon glyphicon-remove"></span></a>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                            <?php } ?>
                            </div>
                        </div>
                    </div>
                    <?php
                } else {
                    echo '<div class="panel-heading">';
                    echo '<span class="panel-title">Dashboard Section Not Found</span>';
                    echo '</div>';
                }
                ?>
            </div>
        </div>
        <aside id="add_new_dash_section_popup" data-tray-height="match" class="tray tray-center side-div">
            <?php echo!empty($addform) ? $addform : ''; ?>
        </aside>
    </section>
    <script type="text/javascript">
        function deleteForm(formid)
        {
            var msg = 'Are you sure to delete.\nThis will delete this content';
            if (confirm(msg)) {
                $.post('/deleteForms/' + formid + '/', {
                    pageRequestType: 'ajax'
                }, function (data) {
                    if (data.indexOf('Delete Success') !== -1) {
                        $('#section_' + formid).hide();
                    }
                });
            }
        }
    </script>
</section>