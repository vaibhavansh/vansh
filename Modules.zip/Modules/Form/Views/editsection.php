<?php global $page; ?>
<div id="modal-form" class="mfp-with-anim">
    <?php if ($editSections) { ?>
        <div class="panel panel-success">
            <div id="edit_section<?php echo $group_id; ?>ResultDiv" class="resultDiv"></div>
            <form close_popup="1" keep_visible="1" successMsg="Data Saved Successfully." keepVisible="1" id="edit_section<?php echo $group_id; ?>" method="post" action="/user_users/saveuserdata/<?php echo $page->currentUser->id; ?>/<?php echo $group_id; ?>" rel='ajaxifiedForm' autocomplete="off">
                <div class="panel-heading">
                    <span class="panel-title">
                        <i class="fa fa-pencil"></i>
                        Edit Section
                    </span>
                    <div class="clearfix"></div>
                </div>
                <div class="panel-body p25 admin-form ">
                    <div class="section row mb5">
                        <?php
                        $multivalgroup = '';
                        foreach ($editSections as $editSection) {
                            ?>
                            <div class="multi_<?php echo $editSection->multi_val_group; ?>">
                                <?php
                                if ($editSection->fieldType == 'OptionBox') {
                                    if (!empty($editSection->option_data)) {
                                        list( $optionsBoxData, $optionBoxKeys) = explode(':', $editSection->option_data);
                                        $fieldOptions['optionBoxData'] = array_combine(explode(',', $optionBoxKeys), explode(',', $optionsBoxData));
                                    }
                                    $fieldOptions['defaultValue'] = isset($editSection->data) ? array($editSection->data) : array();
                                    $fieldOptions['className'] = isset($editSection->className) ? $editSection->className : 'form-control'; #using isset, as it could be blank.
                                    $fieldOptions['multiSelect'] = $editSection->multi_select;
                                    $fieldOptions['name'] = "data_array[{$editSection->id}][data][]";
                                    $fieldOptions['forceDropDown'] = 1;
                                    $fieldOptions['noneOption'] = 1;
                                    $fieldOptions['noneOptionText'] = isset($editSection->default_val) ? $editSection->default_val : '';
                                    $valueField = new $editSection->fieldType($fieldOptions);
                                    ?>
                                    <div class="col-sm-6 col-xs-12 mb15">
                                        <label for="<?php echo $editSection->field_key; ?>" class="field select">
                                            <?php echo $valueField->generate(); ?>
                                            <i class="arrow"></i>
                                        </label>
                                    </div>
                                    <?php
                                } else if ($editSection->fieldType == 'Textarea') {
                                    ?>
                                    <div class="col-sm-6 col-xs-12 mb15">
                                        <label for="<?php echo $editSection->field_key; ?>" class="field prepend-icon">
                                            <textarea class="<?php echo $editSection->className; ?>" placeholder="<?php echo $editSection->field_title; ?>" name="data_array[<?php echo $editSection->id; ?>][data][]" type="<?php echo $customField->fieldType; ?>" id="<?php echo $editSection->field_key; ?>"><?php echo $editSection->data; ?></textarea>
                                            <label for="<?php echo $editSection->field_key; ?>" class="field-icon">
                                                <i class="<?php echo $editSection->divclassName ?>"></i>
                                            </label>
                                        </label>
                                    </div>
                                <?php } else if ($editSection->fieldType == 'file') {
                                    ?>
                                    <input type="hidden" name="field[<?php echo $editSection->id; ?>][field_key]" value="<?php echo $editSection->field_key; ?>">
                                    <label class="p10"><strong><?php echo $editSection->field_title; ?></strong></label>
                                    <?php if (!empty($editSection->field_key)) { ?>
                                        <div class="clearfix"></div>
                                        <input type="hidden" name="data_array_old[<?php echo $editSection->id; ?>][data][]" value="<?php echo $editSection->data; ?>">
                                        <div class="clearfix"></div>
                                        <label class="p10">You have already uploaded <?php echo $editSection->field_title; ?>. <a href='#' onclick="$('#reuploaddoc<?php echo $editSection->field_key; ?>').show();"> Upload <?php echo $editSection->field_title; ?> again</a>?</label>
                                        <div id="reuploaddoc<?php echo $editSection->field_key; ?>" style='display:none'>                                     
                                            <label for="<?php echo $editSection->field_key; ?>" class="field file"><span class="button btn-primary"> Choose File</span>
                                                <input id="<?php echo $editSection->field_key; ?>" type="<?php echo $editSection->fieldType; ?>" 
                                                       name="data_array[<?php echo $editSection->id; ?>][data][]" 
                                                       onchange="document.getElementById('uploader<?php echo $editSection->field_key; ?>').value = this.value;" class="<?php echo $editSection->className; ?>">
                                                <input id="uploader<?php echo $editSection->field_key; ?>" type="text" placeholder="no file selected" readonly class="<?php echo $editSection->divClassName; ?>">
                                            </label><br />
                                            <a href='#' onclick="$('#reuploaddoc<?php echo $editSection->field_key; ?>').hide();">Cancel</a>
                                        </div>
                                        <?php
                                    }
                                    ?>
                                    <?php
                                } else {
                                    ?>
                                    <div class="col-sm-6 col-xs-12 mb15">
                                        <label for="<?php echo $editSection->field_key; ?>" class="field prepend-icon">
                                            <input id="<?php echo $editSection->field_key; ?>" type="<?php echo $editSection->fieldType; ?>" name="data_array[<?php echo $editSection->id; ?>][data][]" placeholder="<?php echo $editSection->field_title; ?>" class="<?php echo $editSection->className; ?>" value="<?php echo $editSection->data; ?>">
                                            <label for="<?php echo $editSection->field_key; ?>" class="field-icon">
                                                <i class="<?php echo $editSection->divClassName ?>"></i>
                                            </label>
                                        </label>
                                    </div>
                                <?php }
                                ?>
                                <input type="hidden" name="data_array[<?php echo $editSection->id; ?>][id][]" value="<?php echo $editSection->id; ?>">
                                <input type="hidden" name="data_array[<?php echo $editSection->id; ?>][group_id][]" value="<?php echo $editSection->group_id; ?>">
                                <input type="hidden" name="data_array[<?php echo $editSection->id; ?>][field_id][]" value="<?php echo $editSection->field_id; ?>">
                                <input type="hidden" name="data_array[<?php echo $editSection->id; ?>][form_id][]" value="<?php echo $editSection->form_id ?>">
                                <input type="hidden" name="data_array[<?php echo $editSection->id; ?>][user_id][]" value="<?php echo $page->currentUser->id; ?>">
                                <input type="hidden" name="data_array[<?php echo $editSection->id; ?>][modified_date][]" value="<?php echo date('Y-m-d'); ?>">
                                <input type="hidden" name="data_array[<?php echo $editSection->id; ?>][multi_val_group][]" value="<?php echo $editSection->multi_val_group; ?>">
                            </div>
                        <?php }
                        ?>
                    </div>
                </div>
                <div class="panel-footer bg-wild-sand admin-form">
                    <div class="section col-sm-12 mb15">
                        <div>                            
                            <input type="submit" id="submit_section" value="Save Section" class="button btn-success">
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </form>
        </div>
    <?php }
    ?>
</div>