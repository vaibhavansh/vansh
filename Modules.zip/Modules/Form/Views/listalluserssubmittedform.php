<div class="panel mb25">
    <div class="panel-heading">
        <span class="panel-title"><i class="fa fa-th-list hidden-xs"></i>Users Submitted Form</span>
        <div class="clearfix"></div>
    </div>
    <?php if (!empty($listAllSubmittedForms)) { ?>
        <div class="panel-body pn">
            <?php
            foreach ($listAllSubmittedForms as $listAllSubmittedForm) {
                ?>
                <div class="list-com-data pn">
                    <div class="com-detail ">
                        <div class="text-left col-sm-12 mt5 mb5">
                            <a href="/form_forms/viewinformationcollectedform/<?php echo $listAllSubmittedForm->userFormUserId; ?>/<?php echo $listAllSubmittedForm->formId; ?>/" rel="popUpBox" data-effect="mfp-flipInY">
                                <?php echo $listAllSubmittedForm->title; ?>  (<?php echo User_Models_User::getFullNameById($listAllSubmittedForm->userFormUserId); ?>)
                            </a>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
                <?php
            }
        } else {
            ?>
            <div class="list-com-data pn">
                <div class="panel-body pn">
                    <div class="com-detail ">
                        <div class="col-lg-12 p25">
                            No Information Request Form Submitted By This User.
                        </div>
                    </div> 
                </div>
            </div>
        <?php } ?>
    </div>
</div>