<?php global $page; ?>
<section id="content_wrapper">
    <section id="content" class="">
        <div id="animation-switcher" class="col-sm-12">
            <div class='col-sm-12 pn'>
                <div class="col-sm-3 hidden-xs mb15">
                    <div>
                        <a type="button" href="/listforms/" rel="ajaxRequest" class="btn btn-default">Back</a>
                    </div>
                </div>
                <div class="col-sm-6 text-center">
                    <h4 style="margin-top: 15px;"><?php echo Form_Models_Form::getNameById($formId); ?></h4>
                </div>
                <?php if ($page->currentUser->webUserRole === '2') { ?>
                    <div div class="rightAlign text-right mb15">
                        <a class="btn btn-success" href="/form_forms/editformsgroupsfields/<?php echo $formId; ?>" rel='ajaxRequest'>Add More</a>
                    </div>
                <?php } ?>
                <div class="clearfix"></div>
            </div>
            <div class="clearfix"></div>
            <?php
            if (!empty($groups)) {
                foreach ($groups as $group) {
                    ?>
                    <div id="section_<?php echo $group->id; ?>" class="panel panel-success panel-border top mb25 mt5">
                        <div class="panel-heading">
                            <span class="panel-title"><i class ="fa fa-th-list hidden-xs"></i>
                                <?php echo $group->group_title; ?>
                            </span>
                            <?php if ($page->currentUser->webUserRole === '2') { ?>
                                <span class="pull-right fix-right">
                                    <div class="btn-group mr10">
                                        <a class="btn btn-info br2 btn-xs" rel="ajaxRequest" href="/form_forms/editformsgroupsfields/<?php echo $formId; ?>/<?php echo $group->id; ?>"><span class="glyphicon glyphicon-pencil small" aria-hidden="true"></span>
                                        </a>
                                    </div>
                                    <div class="btn-group">
                                        <a class="btn btn-xs btn-danger" href="javascript:void(0);" onclick="deleteGroup('<?php echo $group->id; ?>');"  data-toggle="tooltip" data-placement="bottom" title="Delete"><span class="glyphicon glyphicon-remove"></span></a>
                                    </div>
                                </span>                           
                            <?php } ?>
                        </div>
                        <?php
                        if (!empty($fields)) {
                            ?>
                            <div class="panel-body pn">
                                <div class="">
                                    <div class="list-com" id="list-com">
                                        <div class="com-detail upperCase p5">
                                            <div class="col-md-2 col-sm-3 pln">
                                                <p class="mbn"> <strong>Title</strong></p>
                                            </div>
                                            <div class="col-md-1 col-sm-2 pln hidden-xs">
                                                <p class="mbn"> <strong>Type</strong></p>
                                            </div>
                                            <div class="col-md-2 col-sm-3 pln hidden-xs">
                                                <p class="mbn"> <strong>Key</strong></p>
                                            </div>
                                            <div class=" col-md-5 hidden-sm hidden-xs pln">
                                                <p class="mbn"> <strong>Text/Option Data</strong></p>
                                            </div>
                                            <div class="col-sm-1 col-sm-2 pln hidden-xs">
                                                <p class="mbn"> <strong>Priority</strong></p>
                                            </div>
                                            <div class="col-md-1 col-sm-2 pn hidden-xs">
                                                <p class="mbn pull-right"><strong>Action</strong></p>
                                            </div>
                                            <div class="clearfix"></div>
                                        </div>
                                        <?php
                                        foreach ($fields as $data) {
                                            if ($data->group_id == $group->id) {
                                                ?>
                                                <div id='field_<?php echo $data->id; ?>' class="col-sm-12 pt10 pb5 com-detail">
                                                    <div class="col-md-2 col-sm-3 col-xs-6 pln">
                                                        <p ><?php echo $data->field_title; ?></p>
                                                    </div>
                                                    <div class="col-md-1 col-sm-2 col-xs-6 pln">
                                                        <p><?php echo $data->fieldType; ?></p>
                                                    </div>
                                                    <div class="clearfix visible-xs"></div>
                                                    <div class="col-md-2 col-sm-3 col-xs-6 pln">
                                                        <p><?php echo $data->field_key; ?></p>
                                                    </div>
                                                    <div class="col-md-5 hidden-sm hidden-xs pln">
                                                        <p><?php
                                                            if ($data->fieldType == "checkbox")
                                                                echo $data->text;
                                                            elseif ($data->fieldType == "OptionBox")
                                                                echo $data->option_data;
                                                            ?></p>
                                                    </div>
                                                    <div class="col-sm-1 col-sm-2 col-xs-6 pln">
                                                        <p><?php echo $data->priority; ?></p>
                                                    </div>
                                                    <div class="clearfix visible-xs"></div>
                                                    <div class="col-md-1 col-sm-2 pn mb5 text-right">
                                                        <div class="btn-group">
                                                            <a href="javascript:void(0);" onclick="deleteGroup('', '<?php echo $data->id; ?>')" class="btn btn-danger br2 btn-xs fs12"><i class="fa fa-close"></i></a>
                                                        </div>
                                                    </div>
                                                    <div class="clearfix"></div>
                                                </div>
                                                <?php
                                            }
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                            <?php
                        }
                        ?>
                    </div>
                    <div class="clearfix"></div>
                    <?php
                }
            } else {
                echo '<div class="panel-heading">';
                echo '<span class="panel-title">Groups Not Added For This Form</span>';
                echo '</div>';
            }
            ?>
        </div>
    </section>
    <script type="text/javascript">
        function deleteGroup(Groupid, fieldid) {
            var msg = 'Are you sure to delete.\nThis will delete this content';
            if (confirm(msg)) {
                if (fieldid === '' || fieldid === undefined) {
                    $.post('/deleteForms/0/' + Groupid + '/', {
                        pageRequestType: 'ajax'
                    }, function (data) {
                        if (data.indexOf('Delete Success') !== -1) {
                            $('#section_' + Groupid).hide();
                        }
                    });
                } else if (Groupid === '' || Groupid === undefined) {
                    $.post('/deleteForms/0/0/' + fieldid + '/', {
                        pageRequestType: 'ajax'
                    }, function (data) {
                        if (data.indexOf('Delete Success') !== -1) {
                            $('#list-com #field_' + fieldid).hide();
                        }
                    });
                }
            } else {
                return false;
            }
        }
    </script>
</section>