<?php
global $page;
if ($page->currentUser->userLoggedIn) {
    $userId = $page->currentUser->id;
}
?>
<div id="modal-form" class="mfp-with-anim">
    <?php
    if (!empty($groupId)) {
        ?>
        <div class="panel panel-success">
            <div id="saveFeedbackform<?php echo $groupId->id ?>ResultDiv" class="resultDiv"></div>
            <form close_popup="1" keep_visible="1" keepVisible="1" role="form" successMsg="Your Data Saved." name="saveFeedbackform<?php echo $groupId->id ?>" resultDiv="saveFeedbackform<?php echo $groupId->id ?>ResultDiv" id="saveFeedbackform<?php echo $groupId->id; ?>" method="post" action="/user_users/saveuserdata/<?php echo $userId; ?>/<?php echo $groupId->id; ?>"  rel='ajaxifiedFormHR' autocomplete="off">
                <input type="hidden" name="changeGroup" value="<?php echo $groupId->id; ?>">
                <input type="hidden" name="sameForm" value="<?php echo $groupId->form_id; ?>">
                <div class="panel-heading">
                    <span class="panel-title">
                        <i class="fa fa-pencil"></i>
                        <?php echo $groupId->group_title; ?>
                    </span>
                    <div class="clearfix"></div>
                </div>
                <div class="panel-title mt10"><strong><?php echo Form_Models_Form::getDescriptionById($groupId->form_id); ?></strong></div>
                <div class="clearfix"></div>
                <hr class="mt5 mb5">
                <div class="panel-body p25 admin-form ">
                    <div id="sectionId" class="section row mb5">
                        <?php
                        if (!empty($showFormFields)) {
                            $count = 1;
                            foreach ($showFormFields as $showFormField) {
                                if ($showFormField->fieldType == 'OptionBox') {
                                    if (!empty($showFormField->option_data)) {
                                        list( $optionsBoxData, $optionBoxKeys) = explode(':', $showFormField->option_data);
                                        $fieldOptions['optionBoxData'] = array_combine(explode(',', $optionBoxKeys), explode(',', $optionsBoxData));
                                    }
                                    $fieldOptions['defaultValue'] = array();
                                    $fieldOptions['className'] = isset($showFormField->className) ? $showFormField->className : 'form-control'; #using isset, as it could be blank.
                                    $fieldOptions['multiSelect'] = $showFormField->multi_select;
                                    $fieldOptions['name'] = "data_array[{$showFormField->id}][data][]";
                                    $fieldOptions['forceDropDown'] = 1;
                                    $fieldOptions['noneOption'] = 1;
                                    $fieldOptions['noneOptionText'] = isset($showFormField->default_val) ? $showFormField->default_val : '';
                                    $valueField = new $showFormField->fieldType($fieldOptions);
                                    ?>
                                    <div class="col-sm-6 col-xs-12 mb15">
                                        <label for="<?php echo $userField->field_key; ?>" class="field select">
                                            <?php echo $valueField->generate(); ?>
                                            <i class="arrow"></i>
                                        </label>
                                    </div>
                                    <?php
                                } else if ($showFormField->fieldType == 'Textarea') {
                                    ?>
                                    <div class="col-sm-6 col-xs-12 mb15">
                                        <label for="<?php echo $showFormField->field_key; ?>" class="field prepend-icon">
                                            <textarea class="<?php echo $showFormField->className; ?>" placeholder="<?php echo $showFormField->field_title; ?>" name="data_array[<?php echo $showFormField->id; ?>][data][]" type="<?php echo $showFormField->fieldType; ?>" id="<?php echo $showFormField->field_key; ?>"></textarea>
                                            <label for="<?php echo $showFormField->field_key; ?>" class="field-icon">
                                                <i class="<?php echo $showFormField->divclassName ?>"></i>
                                            </label>
                                        </label>
                                    </div>
                                    <?php
                                } else if ($showFormField->fieldType == 'file') {
                                    ?>
                                    <input type="hidden" name="field[<?php echo $showFormField->id; ?>][field_key][]" value="<?php echo $showFormField->field_key; ?>">
                                    <input type="hidden" name="data_array[<?php echo $showFormField->id; ?>][data][]" value="<?php echo $showFormField->data; ?>">
                                    <div class="col-sm-6 col-xs-12 mb20">
                                        <div id="add_file_section<?php echo $showFormField->id; ?>">
                                            <label class="p10"><?php echo $showFormField->title; ?></label>
                                            <label for="<?php echo $showFormField->field_key; ?>" class="field file"><span class="button btn-primary"> Choose File</span>
                                                <input id="<?php echo $showFormField->field_key; ?>" type="<?php echo $showFormField->fieldType; ?>" 
                                                       name="data_array[<?php echo $showFormField->id; ?>][data][]" 
                                                       onchange="document.getElementById('uploader<?php echo $showFormField->field_key; ?>').value = this.value;" class="<?php echo $showFormField->className; ?>">
                                                <input id="uploader<?php echo $showFormField->field_key; ?>" type="text" placeholder="<?php echo $showFormField->field_title; ?>" readonly class="<?php echo $showFormField->divClassName; ?>">
                                            </label>
                                        </div>
                                    </div>
                                    <?php
                                } else {
                                    ?>
                                    <div class="col-sm-6 col-xs-12 mb15">
                                        <label for="<?php echo $showFormField->field_key; ?>" class="field prepend-icon">
                                            <input id="<?php echo $showFormField->field_key; ?>" type="<?php echo $showFormField->fieldType; ?>" name="data_array[<?php echo $showFormField->id; ?>][data][]" placeholder="<?php echo $showFormField->field_title; ?>" class="<?php echo $showFormField->className; ?>">
                                            <label for="<?php echo $showFormField->field_key; ?>" class="field-icon">
                                                <i class="<?php echo $showFormField->divClassName ?>"></i>
                                            </label>
                                        </label>
                                    </div>
                                <?php }
                                ?>
                                <input type="hidden" name="data_array[<?php echo $showFormField->id; ?>][group_id][]" value="<?php echo $showFormField->group_id; ?>">
                                <input type="hidden" name="data_array[<?php echo $showFormField->id; ?>][field_id][]" value="<?php echo $showFormField->id; ?>">
                                <input type="hidden" name="data_array[<?php echo $showFormField->id; ?>][form_id][]" value="<?php echo $groupId->form_id ?>">
                                <input type="hidden" name="data_array[<?php echo $showFormField->id; ?>][user_id][]" value="<?php echo $page->currentUser->id; ?>">
                                <input type="hidden" name="data_array[<?php echo $showFormField->id; ?>][modified_date][]" value="<?php echo date('Y-m-d'); ?>">
                                <?php
                                if ($count % 2 == 0) {
                                    echo '<div class="clearfix"></div>';
                                }
                                $count++;
                            }
                        }
                        ?>
                    </div>
                </div>
                <div class="panel-footer bg-wild-sand admin-form">
                    <div class="section row mb15">
                        <div class="col-xs-6 pull-right text-right">
                            <?php if (!empty($totalCount)) { ?>
                                <input type="submit" id="savenext" value="Save And Next" class="button btn-success">
                            <?php } else if (empty($totalCount)) { ?>
                                <input type="submit" id="submit" value="Save <?php echo $groupId->group_title ?>" class="button btn-success">
                            <?php } ?>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </form>
            <script type="text/javascript">
                $("#savenext").click(function () {
                    var stepNext = $('form#saveFeedbackform<?php echo $groupId->id ?>').last();
                    $('<input type="hidden" value="1" name="nextstep" id="nextstep">').appendTo(stepNext);
                    $('form#saveFeedbackform<?php echo $groupId->id ?>').removeAttr("close_popup");
                });
            </script>
        <?php } ?>
    </div>
</div>
