<?php
if (isset($editForms) && !empty($editForms)) {
    ?>
    <div id="modal-form" class="mfp-with-anim">
        <div class="panel">
            <div id="updatedSection<?php echo $editForms->id; ?>ResultDiv" class="resultDiv"></div>
            <div class="panel-heading">
                <span class="panel-title">
                    <i class="fa fa-pencil hidden-xs"></i>
                    <?php echo $header; ?>
                </span>
            </div>
            <form class="admin-form" keepVisible="1" role="form" resultDiv="updatedSection<?php echo $editForms->id; ?>ResultDiv" close_popup="1" method="POST" rel='ajaxifiedForm' autocomplete="off" backToPage="/listforms" successMsg="Your Leave Request Sent Successfully" id="updatedSection<?php echo $editForms->id; ?>" name="updatedSection<?php echo $editForms->id; ?>" action="/form_forms/saveForms/<?php echo $editForms->id; ?>">
                <input type="hidden" id="sharedMailId" name="sharedMailId[]" value="<?php echo $editForms->share_mail_id; ?>" />
                <div class="panel-body p25 popup-pbody">
                    <div class="col-md-12 pn">
                        <div class="section row mb15">
                            <div class="col-xs-12">
                                <label for="title" class="field prepend-icon">
                                    <input id="title_<?php echo $editForms->id; ?>" type="text" name="title" placeholder="Title" class="event-name gui-input br-light light" value="<?php echo $editForms->title; ?>">
                                    <label for="title" class="field-icon"><i class="fa fa-key"></i></label>
                                </label>
                            </div>
                        </div>
                        <div class="section row mb15">
                            <div class="col-xs-12">
                                <label for="link" class="field prepend-icon">
                                    <input id="link_<?php echo $editForms->id; ?>" type="text" name="link" placeholder="Enter Link" class="event-name gui-input br-light light" value="<?php echo $editForms->link_form; ?>">
                                    <label for="link" class="field-icon"><i class="fa fa-key"></i></label>
                                </label>
                            </div>
                        </div>
                        <div class="section row mb15">
                            <div class="col-xs-12">
                                <label for="Description" class="field prepend-icon">
                                    <input id="description" type="text" name="description" placeholder="Description" class="event-name gui-input br-light light" value="<?php echo $editForms->description; ?>">
                                    <label for="description" class="field-icon"><i class="fa fa-key"></i></label>
                                </label>
                            </div>
                        </div>
                        <div class="section row mb15">
                            <div class="col-xs-12">
                                <?php echo $userRoleId; ?>
                            </div>
                        </div>
                        <div id="selectUserId" class="section row mb15">
                            <div class="col-xs-12">
                                <?php
                                $showFormTypes = Form_Models_Form::$showFrom;
                                if (!empty($showFormTypes)) {
                                    $showKeys = explode(',', $editForms->showform);
                                    if (!empty($showKeys)) {
                                        foreach ($showKeys as $showKey) {
                                            $selectedshowFormId[] = $showKey;
                                        }
                                    }
                                    foreach ($showFormTypes as $key => $showFormType) {
                                        $showFormId[] = $showFormType[$key];
                                    }
                                    $showId = new OptionBox(array('name' => 'formShow[]',
                                        'id' => 'formShow' . rand(0, 9),
                                        'multiSelect' => true,
                                        'defaultValue' => $selectedshowFormId,
                                        'optionBoxData' => $showFormTypes,
                                        'className' => 'chosen-select form-control'));
                                    echo $showId->generate();
                                }
                                ?>
                            </div>
                        </div>
                        <div id="forGuestUser" style="display: none;">
                            <div class="section row mb15">
                                <div class="col-xs-12">
                                    <?php
                                    $prospectiveUsers = User_Models_User::find_all(array('where' => "webUserRole = '5'"));
                                    if (!empty($prospectiveUsers)) {
                                        $prospectiveSharedUsers = explode(',', $editForms->share_mail_id);
                                        if (!empty($prospectiveSharedUsers)) {
                                            foreach ($prospectiveSharedUsers as $prospectiveSharedUser) {
                                                $sharedshowFormId[] = $prospectiveSharedUser;
                                            }
                                        }
                                        foreach ($prospectiveUsers as $prospectiveUser) {
                                            $mailSendUsers[$prospectiveUser->email] = $prospectiveUser->username;
                                        }
                                        $showMailId = new OptionBox(array('name' => 'mailId[]',
                                            'id' => 'mailId' . rand(0, 9),
                                            'multiSelect' => true,
                                            'defaultValue' => $sharedshowFormId,
                                            'optionBoxData' => $mailSendUsers,
                                            'className' => 'chosen-select form-control selectMailId'));
                                        echo $showMailId->generate();
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                        <div class="section row mb15">
                            <div class="col-xs-12">
                                <button class="button btn-success col-xs-12 pull-right" type="submit">Save</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
            <script type="text/javascript">
                $(".selectId").change(function (e, params) {
                    var value = $(".selectId").chosen().val();
                    if ($.inArray('5', value) !== -1) {
                        $('form #forGuestUser').show();
                    } else {
                        $('form #forGuestUser').hide();
                    }
                });
                $(document).ready(function () {
                    var value = $(".selectId").chosen().val();
                    if ($.inArray('5', value) !== -1) {
                        $('form #forGuestUser').show();
                    }
                });
                var contentTitle = $('#title_<?php echo $editForms->id; ?>');
                var contentSlug = $('#link_<?php echo $editForms->id; ?>');
                if (contentTitle.val() !== '') {
                    if (returnSlug(contentTitle.val()) !== contentSlug.val()) {
                        contentTitle.keyup(function () {
                            reviseSlug(contentTitle.val());
                        });
                    } else {
                        contentTitle.keyup(function () {
                            reviseSlug(contentTitle.val());
                        });
                    }
                }
                function reviseSlug(title) {
                    createSlug('<?php echo $editForms->id ?>', title);
                    $('form #link_<?php echo $editForms->id; ?>').text(contentSlug.val());
                }
            </script>
        </div>
    </div>
<?php } else { ?>
    <div id="saveDashboardFormResultDiv" class="resultDiv"></div>
    <div class="panel mb25 mt5">
        <div class="panel-heading">
            <span class="panel-title"> <i class="fa fa-plus hidden-xs"></i> <?php echo $header; ?></span>
        </div>
        <div class="panel-body p20 pb10">
            <div class="tab-content pn br-n admin-form">
                <div id="tab1_1" class="tab-pane active">
                    <div class="section row mbn">
                        <form name ="saveDashboardForm" id="saveDashboardForm" method="POST" resultDiv="saveDashboardFormResultDiv" close_popup="1" autocomplete="off" backToPage="/listforms" keepVisible="1" keepResult="1" action="/form_forms/saveForms/" rel="ajaxifiedForm">
                            <div class="col-md-12 pn">
                                <div class="section row mb15">
                                    <div class="col-xs-12">
                                        <label for="title" class="field prepend-icon">
                                            <input id="title_" type="text" name="title" placeholder="Title" class="required event-name gui-input br-light light" required="">
                                            <label for="title" class="field-icon"><i class="fa fa-key"></i></label>
                                        </label>
                                    </div>
                                </div>
                                <div class="section row mb15">
                                    <div class="col-xs-12">
                                        <label for="link" class="field prepend-icon">
                                            <input id="link_" type="text" name="link" placeholder="Enter Link" class="event-name gui-input br-light light">
                                            <label for="link" class="field-icon"><i class="fa fa-key"></i></label>
                                        </label>
                                    </div>
                                </div>
                                <div class="section row mb15">
                                    <div class="col-xs-12">
                                        <label for="Description" class="field prepend-icon">
                                            <input id="description" type="text" name="description" placeholder="Description" class="event-name gui-input br-light light">
                                            <label for="description" class="field-icon"><i class="fa fa-key"></i></label>
                                        </label>
                                    </div>
                                </div>
                                <div class="section row mb15">
                                    <div class="col-xs-12">
                                        <?php echo $userRoleId; ?>
                                    </div>
                                </div>
                                <div id="selectUserId" class="section row mb15">
                                    <div class="col-xs-12">
                                        <?php
                                        $showFormTypes = Form_Models_Form::$showFrom;
                                        if (!empty($showFormTypes)) {
                                            foreach ($showFormTypes as $key => $showFormType) {
                                                $showFormId[] = $showFormType[$key];
                                            }
                                            $showId = new OptionBox(array('name' => 'formShow[]',
                                                'id' => 'formShowCreate' . rand(0, 9),
                                                'multiSelect' => true,
                                                'optionBoxData' => $showFormTypes,
                                                'className' => 'chosen-select form-control'));
                                            echo $showId->generate();
                                            ?>
                                        <?php } ?>
                                    </div>
                                </div>
                                <div id="NewForGuestUser" style="display: none;">
                                    <div class="section row mb15">
                                        <div class="col-xs-12">
                                            <?php
                                            $prospectiveUsers = User_Models_User::find_all(array('where' => "webUserRole = '5'"));
                                            if (!empty($prospectiveUsers)) {
                                                foreach ($prospectiveUsers as $prospectiveUser) {
                                                    $mailSendUsers[$prospectiveUser->email] = $prospectiveUser->username;
                                                }
                                                $showMailId = new OptionBox(array('name' => 'mailId[]',
                                                    'id' => 'mailIdCreate' . rand(0, 9),
                                                    'multiSelect' => true,
                                                    'optionBoxData' => $mailSendUsers,
                                                    'className' => 'chosen-select form-control'));
                                                echo $showMailId->generate();
                                            }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="section row mb15">
                                    <div class="col-xs-12">
                                        <button class="button btn-success col-xs-12 pull-right" type="submit">Save</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <script type="text/javascript">
            $(".createSelectId").change(function (e, params) {
                var value = $(".createSelectId").chosen().val();
                if ($.inArray('5', value) !== -1) {
                    $('form #NewForGuestUser').show();
                } else {
                    $('form #NewForGuestUser').hide();
                }
            });
            var contentTitleNew = $('#title_');
            var contentSlugNew = $('#link_');
            contentTitleNew.keyup(function () {
                reviseSlugNew(contentTitleNew.val());
            });
            function reviseSlugNew(title) {
                createSlug('', title);
                $('form #link').text(contentSlugNew.val());
            }
        </script>
    </div>
<?php }
?>