<?php
global $page;
?>
<div id="modal-form" class="mfp-with-anim">
    <div class="panel">
        <div id="getlist" class="panel-body p25 pt5 admin-form ">
            <div class="col-sm-12 mb15">
                <ul id="presentationParent" class="nav nav-tabs" role="tablist">
                    <?php foreach ($allGroupsIds as $allGroup) {
                        ?>
                        <li role="presentation" class="presentation<?php echo $allGroup->id; ?>">
                            <a id="<?php echo $allGroup->id; ?>" class="groupIdclick pull-btn"><?php echo $allGroup->group_title; ?></a>
                        </li>
                    <?php }
                    ?>
                </ul>
            </div>
            <div class="clearfix"></div>
            <div id="sectionId" class="section row mb5">
                <?php
                if (!empty($getDataLists)) {
                    $count = 1;
                    foreach ($getDataLists as $getDataList) {
                        ?>
                        <input type="hidden" value="activeGroupId" id="getActiveGroupId">
                        <div class="col-sm-6 col-xs-12 mb15">
                            <p class="text-muted pb10">
                                <strong><?php echo isset($getDataList->field_title) ? $getDataList->field_title . ':' : ''; ?></strong>
                                <?php if ($getDataList->fieldType == 'file') { ?>
                                    <a href="<?php echo $getDataList->data; ?>" target="_blank"><?php echo $getDataList->field_title; ?></a>
                                    <?php
                                } else {
                                    echo $getDataList->data;
                                    ?>
                                </p>
                            <?php } ?>
                        </div>
                        <?php
                        if ($count % 2 == 0) {
                            echo '<div class="clearfix"></div>';
                        }
                        $count++;
                    }
                } else {
                    ?>
                        <h4>User Close PopUp Before Fill Up This Group</h4>
                <?php }
                ?>
            </div>
        </div>
        <div class="panel-footer bg-wild-sand admin-form">
            <div class="section row mb15">
                <div class="col-xs-6 pull-right text-right">
                    <input type="button" id="Close" value="Close" onclick="$('.popUpDiv').overlay().close();" class="button btn-success">
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
        <script type="text/javascript">
            $(document).ready(function () {
                $('#presentationParent').find('.presentation<?php echo $getGroupId; ?>').addClass('active disabled');
            });
            $("a.groupIdclick").on('click', function () {
                var group_id = $(this).attr('id');
                var form_id = '<?php echo $form_Id; ?>';
                var user_id = '<?php echo $userId; ?>';
                reloadDiv('/form_forms/viewinformationcollectedform/' + user_id + '/' + form_id + '/' + group_id, 'modal-form', 'ajax');
            });
        </script>
        <style type="text/css">
            .disabled {
                pointer-events: none;
                cursor: default;
            }
            a.groupIdclick{
                cursor: pointer;
            }
        </style>
    </div>
</div>
