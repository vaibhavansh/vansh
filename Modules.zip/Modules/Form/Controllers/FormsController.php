<?php

class Form_Controllers_FormsController extends Core_Controllers_SitesController {

    function listForms() {
        $variables = array();
        $where = '';
        global $page;
        $tags = func_get_args();
        $variables['pageNumber'] = array_pop($tags);
        if (!(substr($variables['pageNumber'], 0, 5) == 'page_')) {
            $tags[] = $variables['pageNumber'];
            $variables['pageNumber'] = 'page_1';
        }
        $variables['forms'] = Form_Models_Form::getPaginatedData(array(
                    'pageNumber' => $variables['pageNumber'],
                    'where' => $where,
                    'orderBy' => 'id desc'));
        $variables['addform'] = Layout_Models_Layout::getWidget('Form_Controllers_FormsController', 'editForms', 'editforms');
        return $variables;
    }

    function editForms($formId = '') {
        $variables = array();
        $userForms = User_Models_UserRole::find_all();
        if (!empty($userForms)) {
            foreach ($userForms as $userForm) {
                $userFormRoleId[$userForm->id] = $userForm->title;
            }
        }
        if (!empty($formId)) {
            $selectedUserRoleId = '';
            $variables['editForms'] = new Form_Models_Form($formId);
            $variables['header'] = "Edit {$variables['editForms']->title}";
            $keys = explode(',', $variables['editForms']->user_role_id);
            if (!empty($keys)) {
                foreach ($keys as $key) {
                    $selectedUserRoleId[] = $key;
                }
            }
            $userRoleId = new OptionBox(array('name' => 'webUserRole[]',
                'id' => 'webUserRole' . rand(0, 9),
                'multiSelect' => true,
                'defaultValue' => $selectedUserRoleId,
                'optionBoxData' => $userFormRoleId,
                'className' => 'chosen-select form-control selectId'));
            $variables['userRoleId'] = $userRoleId->generate();
        } else {
            $variables['header'] = "Add Dashboard Form";
            $userRoleId = new OptionBox(array('name' => 'webUserRole[]',
                'id' => 'webUserRoleCreate' . rand(0, 9),
                'multiSelect' => true,
                'optionBoxData' => $userFormRoleId,
                'className' => 'chosen-select form-control createSelectId'));
            $variables['userRoleId'] = $userRoleId->generate();
        }
        return $variables;
    }

    function saveForms($formId = '') {
        $_POST['user_role_id'] = !empty($_POST['webUserRole']) ? implode(',', $_POST['webUserRole']) : '';
        $_POST['showform'] = !empty($_POST['formShow']) ? implode(',', $_POST['formShow']) : '';
        $link = array_shift(Form_Models_Form::find_all(array('where' => "link_form = '{$_POST['link']}' and id != '{$formId}'")));
        if (empty($link)) {
            $_POST['link_form'] = $_POST['link'];
            if (in_array('5', $_POST['webUserRole'])) {
                if (isset($_POST['mailId']) && !empty($_POST['mailId'])) {
                    foreach ($_POST['mailId'] as $mail_id) {
                        $mailId[] = $mail_id;
                        $password = array_shift(User_Models_User::find_all(array('where' => "email = '{$mail_id}'")));
                        if ($password->send_form_link_flag == '0') {
                            $getPwd = User_Models_User::randomPassword();
                            $to = $mail_id;
                            $subject = $_POST['title'];

                            $message = "{$_POST['title']}
                                      Please Click on this link for fill up form.
                                      *-------------------------------------*
                                       --Active this usernane and password-- 
                                      *-------------------------------------*

                                      * Hr Bezoar Login username Password *
                                        URL: " . BASE_PATH_ROOT . '/employee/' . $_POST['link'] . "
                                        username : " . $password->username . "
                                        password : " . $getPwd . "";

                            $from = DEVELOPER_EMAIL;
                            $headers = "From:" . $from;
                            if (mail($to, $subject, $message, $headers)) {
                                $saveFlag = new User_Models_User($password->id);
                                $saveFlag->save(array('send_form_link_flag' => '1', 'temp_pass_form' => $getPwd));
                            } else {
                                echo Core_Models_Utility::flashMessage("Please Enter Proper Email Address", 'error');
                            }
                        }
                    }
                }
            }
            $_POST['share_mail_id'] = !empty($mailId) ? implode(',', $mailId) : '';
            if (!empty($formId)) {
                $saveForm = new Form_Models_Form($formId);
                $saveForm->save($_POST);
                echo json_encode(array('status' => 'success', 'msg' => "Dashboard Form Updated."));
            } else {
                $saveForm = new Form_Models_Form();
                $saveForm->save($_POST);
                echo json_encode(array('status' => 'success', 'msg' => "Dashboard Form Saved."));
            }
        } else {
            echo json_encode(array('status' => 'error', 'msg' => "Form slug should not be same."));
        }
        return array();
    }

    function listFormsGroups($formId) {
        $variables = array();
        $group_id = array();
        $where = '';
        $orderBy = '';
        if (!empty($formId)) {
            $variables['groups'] = Form_Models_FormGroup::find_all(array('where' => "form_groups.form_id = '{$formId}'",
                        'orderBy' => 'group_priority asc'));
            if (!empty($variables['groups'])) {
                foreach ($variables['groups'] as $value) {
                    $group_id[] = $value->id;
                }
            }
            if (isset($group_id) && !empty($group_id)) {
                $groupId = implode(',', $group_id);
                $where = "form_group_fields.group_id in ({$groupId})";
//                $orderBy = "priority asc";
            }
            $variables['fields'] = Form_Models_FormGroupField::find_all(array('where' => $where,
                        'orderBy' => "priority asc"));
        }
        $variables['formId'] = $formId;
        return $variables;
    }

    function editFormsGroupsFields($form_id, $groupId = '') {
        $variables = array();
        $parentGroupId = '';
        if (!empty($groupId)) {
            $variables['editGroup'] = new Form_Models_FormGroup($groupId);
            $variables['groupFields'] = Form_Models_FormGroupField::find_all(array('where' => "form_group_fields.group_id = '{$groupId}'",
                        'orderBy' => "priority asc"));
            $variables['header'] = 'Edit ' . $variables['editGroup']->group_title;
            $parentGroups = Form_Models_FormGroup::find_all(array('where' => "form_id = '{$form_id}'"));
            if (!empty($parentGroups)) {
                foreach ($parentGroups as $parentGroup) {
                    $optionBoxData[$parentGroup->id] = $parentGroup->group_title;
                }
                $childGroupId = new OptionBox(array('name' => 'child_group_id',
                    'id' => 'parent_group_id',
                    'multiSelect' => false,
                    'defaultValue' => array($variables['editGroup']->child_group_id),
                    'optionBoxData' => $optionBoxData,
                    'className' => 'chosen-select form-control',
                    'noneOption' => 1,
                    'noneOptionText' => "Select Child Group"));
                $variables['childGroupId'] = $childGroupId->generate();
            }
        } else {
            $variables['header'] = 'Add new group and field';
        }
        $variables['form_id'] = $form_id;
        return $variables;
    }

    function saveFormsGroupsFields($groupId = '') {
        if (!empty($groupId)) {
            $saveGroup = new Form_Models_FormGroup($groupId);
            $saveGroup->save($_POST);
            if (!empty($_POST['data_dashboard'])) {
                foreach ($_POST['data_dashboard'] as $data_dashboard) {
                    if (isset($data_dashboard['options']) && !empty($data_dashboard['options']['value']) && !empty($data_dashboard['options']['fields'])) {

                        $OptionValues = implode(',', $data_dashboard['options']['value']);
                        $OptionFields = implode(',', $data_dashboard['options']['fields']);
                        $data_dashboard['option_data'] = $OptionFields . ':' . $OptionValues;
                        unset($data_dashboard['options']);
                    }
                    $save_data_dashboard = new Form_Models_FormGroupField($data_dashboard['id']);
                    $save_data_dashboard->save($data_dashboard);
                }
            }
            echo json_encode(array('status' => 'success', 'msg' => "Group Updated."));
        } else {
            $saveGroup = new Form_Models_FormGroup();
            $saveGroup->save($_POST);
            echo json_encode(array('status' => 'success', 'msg' => "Group Saved."));
        }
        return array();
    }

    function addGroupFields($form_id, $groupId) {
        $variables = array();
        if (isset($_POST['submit']) && $_POST['submit'] == '1') {
            $_POST['group_id'] = $groupId;
            if (isset($_POST['options'])) {
                $OptionValues = implode(',', $_POST['options']['value']);
                $OptionFields = implode(',', $_POST['options']['field']);
                $_POST['option_data'] = $OptionFields . ':' . $OptionValues;
                unset($_POST['options']);
            }
            $newfield = new Form_Models_FormGroupField();
            $newfield->save($_POST);
            echo json_encode(array('status' => 'success', 'msg' => "Field Form Saved."));
            die();
        } else {
            $variables['groupId'] = $groupId;
            $variables['form_id'] = $form_id;
        }
        return $variables;
    }

    function deleteForms($form_id = '', $groupId = '', $fieldId = '', $userDataId = '') {
        $variables = array();
        global $page;
        $form = new Form_Models_Form($form_id);
        if (!empty($form->id)) {
            if ($form->delete()) {
                $groups = Form_Models_FormGroup::find_all(array('where' => "form_id = '{$form->id}'"));
                if (!empty($groups)) {
                    foreach ($groups as $group) {
                        if ($group->delete()) {
                            $fields = Form_Models_FormGroupField::find_all(array('where' => "group_id = '{$group->id}'"));
                            if (!empty($fields)) {
                                foreach ($fields as $field) {
                                    if ($field->delete()) {
                                        $variables['result'] = 'Delete Success';
                                    } else {
                                        $variables['result'] = 'Delete Fail';
                                    }
                                }
                            }
                        } else {
                            $variables['result'] = 'Delete Fail';
                        }
                    }
                } else {
                    $variables['result'] = 'Delete Success';
                }
            } else {
                $variables['result'] = 'Delete Fail';
            }
        } else if (!empty($groupId)) {
            $group = new Form_Models_FormGroup($groupId);
            if (!empty($group->id)) {
                if ($group->delete()) {
                    $fields = Form_Models_FormGroupField::find_all(array('where' => "group_id = '{$group->id}'"));
                    if (!empty($fields)) {
                        foreach ($fields as $field) {
                            if ($field->delete()) {
                                $variables['result'] = 'Delete Success';
                            } else {
                                $variables['result'] = 'Delete Fail';
                            }
                        }
                    } else {
                        $variables['result'] = 'Delete Success';
                    }
                } else {
                    $variables['result'] = 'Delete Fail';
                }
            }
        } else if (!empty($fieldId)) {
            $field = new Form_Models_FormGroupField($fieldId);
            if (!empty($field->id)) {
                if ($field->delete()) {
                    $variables['result'] = 'Delete Success';
                } else {
                    $variables['result'] = 'Delete Fail';
                }
            }
        } else if (isset($userDataId) && $userDataId !== '') {
            $userDatas = User_Models_UserData::find_all(array('where' => "multi_val_group = '{$userDataId}' and user_id = '{$page->currentUser->id}' and group_id = '{$_POST['group_id']}'"));
            if (!empty($userDatas)) {
                foreach ($userDatas as $userData) {
                    if ($userData->delete()) {
                        $variables['result'] = 'Delete Success';
                    } else {
                        $variables['result'] = 'Delete Fail';
                    }
                }
            } else {
                $variables['result'] = 'Delete Fail';
            }
        }
        echo $variables['result'];
        return $variables;
    }

    function editsection($multi_val_group, $group_id) {
        global $page;
        $variables = array();
        $variables['editSections'] = User_Models_UserData::find_all(array('where' => "user_data.multi_val_group = '{$multi_val_group}' and user_data.group_id = '{$group_id}' and user_data.user_id = '{$page->currentUser->id}'",
                    'join' => "form_group_fields on form_group_fields.id = user_data.field_id",
                    'cols' => "user_data.*,form_group_fields.field_title,form_group_fields.field_key,form_group_fields.className,form_group_fields.divClassName,form_group_fields.fieldType",
                    'orderBy' => 'form_group_fields.priority asc'));
        $variables['group_id'] = $group_id;
        $variables['multi_val_group'] = $multi_val_group;
        return $variables;
    }

    function viewSubmittedForm($id = '') {
        global $page;
        $variables = array();
        $tags = func_get_args();
        $where = '';
        $userId = !empty($id) ? $id : $page->currentUser->id;
        $variables['pageNumber'] = array_pop($tags);
        if (!(substr($variables['pageNumber'], 0, 5) == 'page_')) {
            $tags[] = $variables['pageNumber'];
            $variables['pageNumber'] = 'page_1';
        }
        $where .= "forms.id != 1 and user_data.user_id = '{$userId}'";
        if (isset($_POST['searchTitle'])) {
            $variables['searchTitle'] = (trim(str_replace(array('/', '.'), '', ($_POST['searchTitle']))));
            $where .= " And forms.title like ('%" . $variables['searchTitle'] . "%')";
        }
        $variables['forms'] = Form_Models_Form::getPaginatedData(array(
                    'pageNumber' => $variables['pageNumber'],
                    'where' => $where,
                    'join' => "user_data on user_data.form_id = forms.id",
                    'cols' => "forms.*",
                    'groupBy' => "user_data.form_id",
                    'orderBy' => 'forms.id desc'));
        $variables['user_id'] = $id;
        $variables['fullName'] = User_Models_User::getFullNameById($id);
        return $variables;
    }

    function listInformationCollectedForms() {
        global $page;
        $variables = array();
        $tags = func_get_args();
        $variables['pageNumber'] = array_pop($tags);
        if (!(substr($variables['pageNumber'], 0, 5) == 'page_')) {
            $tags[] = $variables['pageNumber'];
            $variables['pageNumber'] = 'page_1';
        }
        $where = "forms.showform Like '%2%' and forms.id not in (SELECT form_id FROM user_data WHERE user_data.user_id = '{$page->currentUser->id}') and forms.user_role_id LIKE '%{$page->currentUser->webUserRole}%'";
        if (isset($_POST['searchTitle'])) {
            $variables['searchTitle'] = (trim(str_replace(array('/', '.'), '', ($_POST['searchTitle']))));
            $where .= " And forms.title like ('%" . $variables['searchTitle'] . "%')";
        }
        $variables['forms'] = Form_Models_Form::getPaginatedData(array(
                    'pageNumber' => $variables['pageNumber'],
                    'where' => $where,
                    'orderBy' => 'forms.id desc'));
        if ($variables['forms']->data) {
            foreach ($variables['forms']->data as $value) {
                $user_role_id = explode(',', $value->user_role_id);
            }
        }
        $variables['user_role_id'] = isset($user_role_id) ? $user_role_id : '';
        return $variables;
    }

    function informationCollectedForm($formId, $groupId = '', $formNext = '') {
        $variables = array();
        if (!empty($formId)) {
            if (!empty($formNext)) {
                $variables['groupId'] = new Form_Models_FormGroup($groupId);
            } else {
                $variables['groupId'] = array_shift(Form_Models_FormGroup::find_all(array('where' => "form_id = '{$formId}'")));
            }
            if (!empty($variables['groupId'])) {
                $variables['showFormFields'] = Form_Models_FormGroupField::find_all(array('where' => "form_group_fields.group_id = '{$variables['groupId']->id}'",
                            'orderBy' => "form_group_fields.priority ASC"));
                $variables['totalCount'] = Form_Models_FormGroup::getGroupsByFormId($formId, $variables['groupId']->id);
            }
        }
        return $variables;
    }

    function viewInformationCollectedForm($userId, $form_Id, $group_id = '') {
        $variables = array();
        if (!empty($form_Id)) {
            $allGroupsIds = Form_Models_FormGroup::find_all(array('where' => "form_id = '{$form_Id}'"));
            $variables['allGroupsIds'] = $allGroupsIds;
            if (empty($group_id)) {
                $getGroup = array_shift($allGroupsIds);
            }
            $variables['getGroupId'] = !empty($getGroup) ? $getGroup->id : $group_id;
            $variables['getDataLists'] = User_Models_UserData::find_all(array('where' => "user_data.group_id = '{$variables['getGroupId']}' and user_data.user_id = '{$userId}' and user_data.form_id = '{$form_Id}'",
                        'join' => "form_group_fields on form_group_fields.id = user_data.field_id",
                        'cols' => "form_group_fields.*,user_data.data",
                        'orderBy' => "form_group_fields.priority asc"));
            $variables['userId'] = $userId;
            $variables['form_Id'] = $form_Id;
        }
        return $variables;
    }

}
