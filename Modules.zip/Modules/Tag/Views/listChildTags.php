<section id="content_wrapper">
    <section id="content" class="">
        <div id="animation-switcher" class="col-xs-12">
            <div class="panel mb25 mt5">
                <div class="panel-heading">
                    <span class="panel-title"> <i class="fa fa-th-list"></i> <?php echo $header ?></span>
                    <span class="pull-right fix-right">
                        <div class="btn-group text-right">
                            <a class="btn btn-info br2 btn-xs" href="/<?php echo $objects->coreURL ?>/edit/0" oncloseFunction="reloadDiv('/<?php echo $objects->coreURL; ?>/listChildTags/<?php echo $parent->id . '/' . $pageNumber; ?>','mainContent');" rel="popUpBox"><span class="fa fa-plus"></span></a>
                        </div>
                    </span><div class="clearfix"></div>
                </div>
                <div class="panel-menu admin-form theme-primary">
                    <div class="row">
                        <div class="col-md-12">
                            <form resultDiv='mainContent' name ="searchTags" id="searchTags" method="post" class="form-inline" keepVisible="1" keepResult="1" action="/tag_tags/index/" rel="ajaxifiedForm">      
                                <div class="col-sm-11">
                                    <label for="name" class="field prepend-icon">
                                        <input class="required event-name gui-input br-light light" type="text" name="searchTitle" placeholder="Search" />
                                        <label for="name" class="field-icon"><i class="fa fa-gear"></i></label>
                                    </label>
                                </div>
                                <div class="col-xs-1">
                                    <button type="submit" class="button btn-success pull-right">Search</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="panel-body pn">
                    <div class="col-sm-12">
                        <?php echo $objects->pageLinks(array('url' => "/{$objects->coreURL}/listChildTags/{$parent->id}", 'ajaxRequest' => true)); ?>
                    </div>
                    <div class="clearfix"></div>
                    <div class="table-responsive of-a">
                        <?php if (!empty($objects->data)) { ?>
                            <table data-filter="#fooFilter_0" class="table admin-form theme-warning tc-checkbox-1 fs13 footable">
                                <thead>
                                    <tr class="bg-light">
                                        <th>Tags</th>
                                        <th class="text-right">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    foreach ($objects->data as $object) {
                                        ?>
                                        <tr id="row_<?php echo $object->id ?>">
                                            <td class="text-left"><a href="/<?php echo $objects->coreURL . '/edit/' . $object->id ?>" oncloseFunction="reloadDiv('/<?php echo $objects->coreURL; ?>/listChildTags/<?php echo $parent->id . '/' . $pageNumber ?>/','mainContent');" rel="popUpBox"  > <?php echo $object->title; ?></a></td>
                                            <td class="text-right">
                                                <div class="btn-group text-right">
                                                    <button type="button" data-toggle="dropdown" aria-expanded="false" class="btn button btn-info br2 btn-xs fs12 dropdown-toggle">Action<span class="caret ml5"></span></button>
                                                    <ul role="menu" class="dropdown-menu">
                                                        <li><a href="/<?php echo $objects->coreURL . '/listChildTags/' . $object->id ?>"  rel="ajaxRequest"  ><strong><?php echo $object->title; ?> </strong></a></li>
                                                        <li><a href="/<?php echo $objects->coreURL . '/edit/' . $object->id ?>" oncloseFunction="reloadDiv('/<?php echo $objects->coreURL; ?>/listChildTags/<?php echo $parent->id . '/' . $pageNumber ?>/','mainContent');" rel="popUpBox" >Edit</a></li>
                                                        <li><a href="/<?php echo $objects->coreURL . '/delete/' . $object->id ?>" rel="confirmClickURL" confirmTrueFunction="$('#row_<?php echo $object->id ?>').hide()" message="Are you sure you want to remove '<?php echo $object->title; ?>'." >Delete</a></li>
                                                    </ul>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php
                                    }
                                    ?>
                                </tbody>
                            </table>
                        <?php } else {
                            ?>
                            <span class="panel-title">No Tags Found</span>
                        <?php }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</section>