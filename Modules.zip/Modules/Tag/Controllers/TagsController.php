<?php

class Tag_Controllers_TagsController extends Core_Controllers_SitesController {

    function edit($id = 0) {
        $variables = parent::edit($id);
        $variables['tagSelector'] = new OptionBox(array('dBTableOptions' => array('className' => 'Tag_Models_Tag', 'cols' => 'title'), 'multiSelect' => 0, 'id' => "tagselector_{$variables['object']->id}", 'noneOption' => 1, 'name' => 'child_of', 'defaultValue' => array($variables['object']->child_of), 'className' => 'form-control'));
        $variables['priority'] = new OptionBox(array('optionBoxData' => range(0,10,1), 'multiSelect' => 0, 'id' => "priority{$variables['object']->id}", 'name' => 'priority', 'defaultValue' => array($variables['object']->priority), 'className' => 'form-control'));

        return $variables;
    }
    function searchTags(){

    }
    /**
     * List all childs of given tag. Shows main taxonomy for 0.
     * @param type $parent : id of the tag that childrens are required.
     * @param type $pageNumber
     * @return array of childs.
     */
    function listChildTags($parent = 0, $pageNumber=1,$recordsPerPage = 15) {
        $variables['parent'] = new Tag_Models_Tag($parent);
        if (!$variables['parent']->id) {
            $variables['parent']->id = 0; #so it will pass 0 to page numbers;
            $variables['parent']->child_of = 0; #so it will pass 0 to page numbers;
            $variables['header'] = "List all Tags";
        } else {
            $variables['header'] = $variables['parent']->title;
//            $variables['header'] = $variables['parent']->value;
        }
        $variables['pageNumber'] = $pageNumber;
        $variables['objects'] = Tag_Models_Tag::getPaginatedData(array('recordsPerPage'=>$recordsPerPage, 'pageNumber' => $pageNumber, 'where' => "child_of='{$parent}'",'orderBy'=>'title asc'));
        $variables['objects']->coreURL = 'tag_tags';
        return $variables;
    }

    function save() {
        $variables = parent::save();
        return $variables;
    }

}

