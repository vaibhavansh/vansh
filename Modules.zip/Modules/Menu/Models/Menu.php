<?php

class Menu_Models_Menu extends Core_Models_DbTable {

    static $table = 'menus';
    static $fields = NULL;
    /**
     * This CSS is required to function a horrizontal 3 level drop down menu.
     * @var type
     */
    static $generalCSS = ".nav,.nav ul{margin:0;padding:0;list-style-type:none;list-style-position:outside;position:relative}.nav li ul li{z-index:199}.nav li ul a{height:auto;float:left}.nav li{float:left;position:relative}.nav ul{position:absolute;display:none;width:auto;top:auto}.nav ul ul{top:auto}.nav li:hover ul ul,.nav li:hover ul ul ul,.nav li:hover ul ul ul ul{display:none}.nav li:hover ul,.nav li li:hover ul,.nav li li li:hover ul,.nav li li li li:hover ul{display:block}";

    static $defaultCSS = "li{background:#FF5D17;color:#26FF2D;font-family:'Oswald', sans-seriftext-align;text-align:center;line-height:50px;width:150px; }a{color:#26FF2D}li ul li{width:200px;}li ul ul{left:201px;}li:hover{background-color:#406CFF}a:hover{background-color:#406CFF}";


    /**
     * RETURNS ALL THE ITEMS FOR A MENU. JSON DECODES THE DATA FROM TABLE.
     * @return type
     */
    function items() {
        $this->items = json_decode($this->menu_items);
        return $this->items;
    }

    /**
     * This function formats the css of menu into an array, and also keep a copy as style
     * So preview can be used with style, and arrray can be edited.
     * Called from __get method.
     * @return type
     */
    function cssArray() {
        preg_match_all('/(.+?)\s?\{\s?(.+?)\s?\}/', $this->css, $matches);
        $this->style = '';
        $this->cssArray = array();
        foreach ($matches[0] AS $i => $original) {
            $this->style .= "#{$this->unique_id} ". $matches[1][$i] . '{';
            foreach (explode(';', $matches[2][$i]) AS $attr)
                if (strlen(trim($attr)) > 0) { // for missing semicolon on last element, which is legal
                    list($name, $value) = explode(':', $attr);
                    $this->cssArray[$matches[1][$i]][trim($name)] = trim($value);
                    $this->style .= trim($name) . ':' . trim($value) . ';';
                }
            $this->style .= '}';
        }
        return $this->cssArray;
    }

    /**
     * Returns the style for a tag. both the function are inefficient and incorrect.
     * inefficient because multiple foreachloop. and incorrect because style should return
     *  a tag.
     * @return type
     */
    function style() {
        $this->cssArray();
        return $this->style;
    }

    /**
     * Function to get the menu items in ul/litag.
     * Used for editing menu. NOT FOR PRINTING. NO AHREF TAG
     * @param type $mainMenu
     * @param type $menuItems
     */
    public function getMenu($mainMenu, $menuItems) {
        if (!empty($mainMenu))
            foreach ($mainMenu as $menuItem) {
                $linkOptions = $menuItem->link_options ? " " . $menuItem->link_options . " " : '';
                $classNameMenus = !empty($menuItem->classNameMenus) ? $menuItem->classNameMenus : '';
                $visible_to = !empty($menuItem->visible_to) ? $menuItem->visible_to : '';
                echo "<li
                id='$menuItem->id' title=\"" . str_replace('\\', '', $menuItem->title) . "\" link='{$menuItem->link}'
                link_options=\"" . str_replace('\\', '', $menuItem->link_options) . "\" class='lightGreyBackground' classNameMenus='{$classNameMenus}' visible_to='{$visible_to}'>";
                echo "<div rel='menuItemTitle' class='col-sm-4 col-xs-12'>{$menuItem->title}</div>";
                $childs = $this->getChild($menuItem->id, $menuItems);
                if (!empty($childs)) {
                    echo "<ul>";
                    $this->getMenu($childs, $menuItems);
                    echo "</ul>";
                }
                echo '</li>';
            }
    }

    /**
     * FUNCTION TO PRINT MENU ON FRONT END.
     * ONLY SHOWS PUBLISHED ITEMS
     *
     * @param type $mainMenu
     * @param type $menuItems
     */
    public function printMenu($mainMenu, $menuItems) {
         global $page;
        if (!empty($mainMenu)) 
            foreach ($mainMenu as $menuItem) {
                echo "<li id='$menuItem->id' class='{$this->className} ' >";
                $pageURL =  $_SERVER["REQUEST_URI"];
                if($pageURL != '/')                {
                    $pos = strpos( $menuItem->link, $pageURL);
                    if($pos === false){
                         
                        $active = '';
                    }
                    else {
                        $active = 'active';
                    }
                }
                
//               else if($pageURL == $url)
//                {
//                    $active = 'active';
//                }
               
                   
                if ($menuItem->link == "Login") {
                    if ($page->currentUser->userLoggedIn) {
                        echo '<a href="user_users/logout" rel="ajaxRequest" class="">Logout</a>';
                    } else {
                        echo '<a href="Login" rel="ajaxRequest" class="">Login</a>';
                    }
                } else if ($menuItem->link == "User-Profile") {
                    if ($page->currentUser->userLoggedIn) {
                        echo '<a href="User-Profile" rel="ajaxRequest" class="">User Profile</a>';
                    }
                    else{
                        
                    }
                    
                } else {
                    echo!empty($menuItem->link) ? "<a href='{$menuItem->link}' {$menuItem->link_options}>{$menuItem->title}</a>" : "<p>{$menuItem->title}</p>";
                }




                $childs = $this->getChild($menuItem->id, $menuItems);
                if (!empty($childs)) {
                    echo "<ul>";
                    $this->printMenu($childs, $menuItems);
                    echo "</ul>";
                }
                echo '</li>';
            }
    }
    
     public function printmovieMenu($mainMenu, $menuItems) {
        if (!empty($mainMenu))
            foreach ($mainMenu as $menuItem) {
                echo "<li class='{$this->className} ' >";
                echo!empty($menuItem->link) ? "<a id='$menuItem->id' href='{$menuItem->link}' onclick ='showactive()' {$menuItem->link_options}>{$menuItem->title}</a>" : "<p>{$menuItem->title}</p>";
                $childs = $this->getChild($menuItem->id, $menuItems);
                if (!empty($childs)) {
                    echo "<ul>";
                    $this->printMenu($childs, $menuItems);
                    echo "</ul>";
                }
                echo '</li>';
            }
    }

    /**
     * ITERATE THROUGH MENU ITEMS AND GET THE CHILDS OF GIVEN MENU ITEM.
     *
     * @param type $itemID
     * @param type $menuItems
     * @return array
     */
    public function getChild($itemID, $menuItems) {
        $childs = array();
        if (!empty($menuItems))
            foreach ($menuItems as $item) {
                if ($item->child_of == $itemID)
                    array_push($childs, $item);
            }
        return $childs;
    }
    public function save($data){
        $menu_items = array();
        if (!empty($data['menuItems'])) {
            foreach ($data['menuItems'] as $key => $ul) {
                if (!empty($ul)) {
                    $lis = explode(',', $ul);
                    if (!empty($lis))
                        foreach ($lis as $li) {
                            if (!empty($li)) {
                                $menu_items[$li] = array('id' => $li, 'link_options' => stripslashes($data['menuItemData'][$li]['link_options']), 'visible_to' => $data['menuItemData'][$li]['visible_to'], 'link' => $data['menuItemData'][$li]['link'], 'title' => str_replace('\\', '', $data['menuItemData'][$li]['title']), 'child_of' => $key, 'menu_id' => $this->id, 'classNameMenus' => $data['menuItemData'][$li]['classNameMenus']);
                            }
                        }
                }
            }
            $data['menu_items'] = json_encode($menu_items);
        }
        if(empty($this->id)){
            $data['css'] = !empty($data['css'])?$data['css'] :Menu_Models_Menu::$defaultCSS;
            $data['unique_id'] = !empty($data['unique_id'])?$data['unique_id'] :'unique_'.rand(1,999).'_'.rand(999,9999);

            }

        return parent::save($data);

    }     
} ?>





