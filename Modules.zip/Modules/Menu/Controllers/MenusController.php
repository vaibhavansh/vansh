<?php

class Menu_Controllers_MenusController extends Core_Controllers_SitesController {

    /**
     * EDIT MENU AND MENU ITEMS
     * @param type $menuId
     * @return type
     */
    function edit($menuId = 0) {
        $variables = parent::edit($menuId);
        return $variables;
    }

    /**
     * DISPLAY MENU FUNCTION FOR FRONT END.
     * @param type $menuId
     * @return \Menu_Models_Menu
     */
    function showMenu($menuId = 1) {
        $variables['object'] = new Menu_Models_Menu($menuId);
        return $variables;
    }

    /**
     * Generates The HTML for the given menu.
     * Adds it to a text editor.
     * @param type $id
     * @return type
     */
    function generateHTML($menuId) {
        $variables['object'] = new Menu_Models_Menu($menuId);
        return $variables;
    }

    /**
     * Edit CSS for the given Menu
     */
    function editCSS($id) {
        $variables['object'] = new Menu_Models_Menu($id);
        return $variables;
    }
    /**
     * Import CSS to database form.
     * THis will take the css as input and take out the
     * useful fields for the menu.
     */
    function importCSSForm($id){
        $variables['object'] = new Menu_Models_Menu($id);
        return $variables;
    }
    /** IMPORT CSS. NOT YET WORKING
     *
     * @return type
     */
    function importCSS(){
                preg_match_all('/(.+?)\s?\{\s?(.+?)\s?\}/', $this->css, $matches);
        $this->style = '';
        $this->cssArray = array();
        foreach ($matches[0] AS $i => $original) {
            $this->style .= "#{$this->unique_id} ". $matches[1][$i] . '{';
            foreach (explode(';', $matches[2][$i]) AS $attr)
                if (strlen(trim($attr)) > 0) { // for missing semicolon on last element, which is legal
                    list($name, $value) = explode(':', $attr);
                    $this->cssArray[$matches[1][$i]][trim($name)] = trim($value);
                    $this->style .= trim($name) . ':' . trim($value) . ';';
                }
            $this->style .= '}';
        }
        return $this->cssArray;

    }

}
