<?php
global $page;
if ($page->currentUser->userLoggedIn) {
    $image = $page->currentUser->image;
    $userid = $page->currentUser->id;
}
$menus = $object->getChild('li0', $object->items);
if (!empty($menus)) {
    ?>
    <header class="navbar navbar-shadow undefined navbar-fixed-top">
        <div class="navbar-branding">
            <a href="dashboard" class="navbar-brand"><?php //echo $menus[0]->title;      ?> <img src="/img/hrbezoar-logo.png" class="img-responsive logo" /></a>
            <span id="toggle_sidemenu_l" class="fa fa-bars toggle_sidemenu_l"></span>
        </div>
        <ul id="<?php echo $object->id; ?>" class="nav navbar-nav navbar-left">
            <?php
            foreach ($menus as $menu) {
                if (!empty($menu->visible_to)) {
                    $visibleTo = explode(',', $menu->visible_to);
                } else {
                    $visibleTo = array();
                }
                if (in_array($page->currentUser->webUserRole, $visibleTo) || empty($visibleTo)) {
                    ?>
                    <li id="<?php echo $menu->id; ?>" class="header-link veil reveal-xs-block">
                        <a href="<?php echo $menu->link; ?>" <?php echo $menu->link_options; ?> class="<?php echo $menu->classNameMenus; ?>">
                            <?php echo $menu->title; ?>
                        </a>
                        <?php
                        $mainMenuChilds = $object->getChild($menu->id, $object->items);
                        if (!empty($mainMenuChilds)) {
                            ?>
                            <ul class="nav sub-nav mainSubMenu" style="display:none;">
                                <?php
                                foreach ($mainMenuChilds as $mainMenuChild) {
                                    ?>
                                    <li>
                                        <a href="<?php echo $mainMenuChild->link; ?>" <?php echo $mainMenuChild->link_options; ?>>
                                            <?php echo $mainMenuChild->title; ?>
                                        </a>
                                    </li>
                                <?php }
                                ?>
                            </ul>
                        <?php }
                        ?>
                    </li>
                    <?php
                }
            }
        }
        ?>
                    <?php if($page->currentUser->userLoggedIn){?>
        <li class="admin-dropdown pull-right">
            <ul class="nav navbar-nav navbar-right">
                <li class="dropdown menu-merge">
                    <a href="#" data-toggle="dropdown" class="dropdown-toggle">
                        <img src="<?php echo!empty($image) ? '/images/' . $image . '_thumb.jpg' : '/img/avatars1.jpg'; ?>" alt="<?php echo $page->currentUser->name . ' ' . $page->currentUser->lastname; ?>" class="veil reveal-sm-inline-block mw64 br64" style="height: 60px; width: 64px;">
                        <span class="hidden-xs pl15"><?php echo $page->currentUser->name . ' ' . $page->currentUser->lastname; ?></span> <span class="caret caret-tp"></span>
                    </a>
                    <ul role="menu" class="dropdown-menu list-group dropdown-persist w250">                       
                        <li class="dropdown-footer"><a href="/logout"><span class="fa fa-power-off pr5"></span> Logout</a></li>
                    </ul>
                </li>
            </ul>
        </li>
                    <?php } ?>
    </ul>
    <?php
    //echo "<pre>";
// print_r($rightMenu); 
    ?>
    <script type="text/javascript">
        $(document).ready(function () {
            $('#<?php echo $object->id; ?> li:nth-child(1)').removeClass('reveal-xs-block');
            $('body').removeClass('external-page');
            Core.init();
            $('.dropdown-menu .list-group-item a').on('click', function () {
                $(this).parents('.menu-merge').removeClass('open');
            });
        });
    </script>
</header>

<div class="clearfix"></div>
<div id="cardtimer" class="hidden">
    <div class="ticket pb10"></div>
    <div class="task-play">
        <a class="remove-timer-btn link hidden" title="Stop &amp; Save Timer"><span class="fa fa-stop"></span></a>
    </div>
    <div class="task-timer"><input name="timer" class="form-control timer cardtime" placeholder="0 sec" disabled="" type="text"></div>
</div>
  <div class="return_cardId"></div>