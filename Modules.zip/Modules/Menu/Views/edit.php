<style type="text/css">
    child{min-height: 35px;}
    #menuEditor li{padding-left: 5px;outline:1px solid #666;min-height: 35px}
</style>
<section id="content_wrapper">
    <section id="content" class="">
        <div id="animation-switcher" class=" col-md-12">
            <div id="editObject<?php echo $object->id ?>ResultDiv"></div>
            <form name ="editObject<?php echo $object->id ?>" id="editObject<?php echo $object->id ?>" method="post" keepVisible="1" action="/<?php echo $object->coreURL ?>/save" rel="ajaxifiedForm">
                <div class="center-block">
                    <div class="panel panel-warning panel-border top mt20">
                        <div class="panel-heading"><span class="panel-title"> <i class="fa fa-pencil"></i> <?php echo $header ?></span>
                        </div>
                        <div class="panel-body p20 pb10">
                            <div class="pn br-n admin-form">
                                <div class="col-xs-12" id="saveMenu" style="display:none">
                                    <div class="warningBox">You have Unsaved Changes.
                                        <a href="javascript:void(0)" id="saveMenuItem" >Save</a> || <a href="/menu_menus/index/" rel="ajaxRequest" >Cancel & Go Back</a>
                                    </div>
                                </div>
                                <div class="section row mbn">
                                    <div class="col-md-12 pl15">
                                        <div class="section row mb15">
                                            <div class="col-xs-12"><h5 class="text-left"><small> Title</small></h5>
                                                <label for="title" class="field prepend-icon">
                                                    <input type="textbox" name="title" id="title" value="<?php echo $object->title ?>" class="required event-name gui-input br-light light" />
                                                    <label for="title" class="field-icon"><i class="fa fa-info"></i></label>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="section row mb15">
                                            <div class="col-xs-12"><h5 class="text-left"><small> Class Name(It goes to all li items)</small></h5>
                                                <label for="className" class="field prepend-icon">
                                                    <input type="textbox" name="className" id="className" class="event-name gui-input br-light light" value="<?php echo $object->className ?>" />
                                                    <label for="className" class="field-icon"><i class="fa fa-pencil"></i></label>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="section row mb15">
                                            <div class="col-xs-12"><h5 class="text-left"><small> Unique ID</small></h5>
                                                <label for="uniqueId" class="field prepend-icon">
                                                    <input type="textbox" class="required  event-name gui-input br-light light" name="unique_id" id="uniqueId" value="<?php echo $object->unique_id ?>" />
                                                    <label for="uniqueId" class="field-icon"><i class="fa fa-info"></i></label>
                                                </label>
                                            </div>
                                        </div>
                                        <input type="hidden" name="id" value="<?php echo $object->id ?>"/>
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                        <hr class="mb5 mt5">
                        <div class="clearfix"></div>
                        <div class="panel-border mb35">
                            <div class="panel-heading">
                                <div class="col-sm-6 col-xs-12 ">
                                    <h4><?php echo $header . '\'s Menu Items' ?></h4>
                                </div>
                                <div class="col-sm-3 col-xs-6">
                                    <h4><a href="javascript:void(0)" onclick="addChild($('#menuEditor > ul'))">Add New Item</a></h4>
                                </div>
                                <div class="col-sm-3 col-xs-6">
                                    <h4><a href="/menu_menus/generateHTML/<?php echo $object->id; ?>" rel="popUpBox">Generate HTML</a></h4>
                                </div>
                            </div>
                            <div class="panel-body pn pt15 pb10">
                                <div class="col-sm-12" >
                                    <div id="menuEditor">
                                        <ul class='sortable droptrue connectedSortable' childOf="li0" >
                                            <?php
                                            $object->getMenu($object->getChild('li0', $object->items), $object->items);
                                            ?>
                                        </ul>
                                    </div>
                                </div>
                                <div id="menuItemDataDiv" class="grid_16"></div>
                            </div>
                            <div class="panel-footer text-right bg-wild-sand" id="saveMenu-1" style="display:none">
                                <div class="warningBox">You have Unsaved Changes.
                                    <a href="javascript:void(0)" id="saveMenuItem-1" >Save</a> || <a href="/menu_menus/index/" rel="ajaxRequest" >Cancel & Go Back</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
            <div id="editMenuItem"  style ="display:none" title="Edit Menu Item">
                <div id="modal-form" class="admin-form mfp-with-anim">
                    <div class="panel">
                        <div class="panel-heading">
                            <span class="panel-title">
                                <i class="fa fa-pencil"></i>Edit Menu Item</span>
                        </div>
                        <div class="panel-body p25">
                            <div class="section row">
                                <div class="col-md-12">
                                    <label class="col-md-3 control-label">Title</label>
                                    <div class="col-md-8">         
                                        <input type="textbox" name="title" id="menuItemTitle" class="gui-input form-control"/>
                                    </div>               
                                </div>                
                            </div>
                            <div class="section row">
                                <div class="col-md-12">
                                    <label class="col-md-3 control-label">Link</label>
                                    <div class="col-md-8">         
                                        <input type="textbox" name="link" id="menuItemLink" class="gui-input form-control"/>
                                    </div>               
                                </div>                
                            </div>
                            <div class="section row">
                                <div class="col-md-12">
                                    <label class="col-md-3 control-label">Select User Role(Visible To)</label>
                                    <div class="col-md-8">
                                        <?php
                                        $visibleuserForms = User_Models_UserRole::find_all();
                                        if (!empty($visibleuserForms)) {
                                            ?>
                                            <select id="selectUserRoleMenu" name="visibleto" multiple="multiple" style="width: 100%">
                                                <?php foreach ($visibleuserForms as $visibleuserForm) { ?>
                                                    <option value="<?php echo $visibleuserForm->id ?>"><?php echo $visibleuserForm->title; ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>               
                                </div>                
                            </div>
                            <div id="ajaxify_link" class="section row">
                                <div class="col-md-12">
                                    <label class="col-md-3 control-label">Ajaxify Link:</label>
                                    <div class="col-md-8">         
                                        <input type="radio" value="rel='ajaxRequest'" class="ajaxify_link" name="linkOption"/>
                                    </div>  
                                </div>
                            </div>
                            <div id="div_name" class="section row">
                                <div class="col-md-12">
                                    <label class="col-md-3 control-label">Div Name</label>
                                    <div class="col-md-8">
                                        <input type="text" name="ajaxifiedDivName" class="gui-input form-control"/>
                                    </div>
                                </div>               
                            </div> 
                            <div class="section row">
                                <div class="col-md-12">
                                    <label class="col-md-3 control-label">Open in New Window</label>
                                    <input type="radio" value="target='_blank'" name="linkOption"/>
                                </div>               
                            </div> 
                            <div class="section row">
                                <div class="col-md-12">
                                    <label class="col-md-3 control-label">Open in PopUpBox</label>
                                    <input type="radio" value="rel='popUpBox'" name="linkOption"/>
                                </div>               
                            </div>
                            <div class="section row">
                                <div class="col-md-12">
                                    <label class="col-md-3 control-label">None</label>
                                    <input type="radio" value="" name="linkOption"/>
                                </div>               
                            </div>
                            <div class="section row">
                                <div class="col-md-12">
                                    <label class="col-md-3 control-label">Class Name</label>
                                    <div class="col-md-8">         
                                        <input type="textbox" name="classNameMenus" id="classNameMenus" class="gui-input form-control"/>
                                    </div>               
                                </div>                
                            </div>
                            <div class="section row mb5">
                                <div class="mr10 pull-right">
                                    <button id='editMenuItemCancel' class="button btn-danger col-xs-12 pull-right">Cancel</button>
                                </div>
                                <div class="mr10 pull-right">
                                    <button type="button" id="editMenuItemOK" class="button btn-success col-xs-12 pull-right">Save Changes</button>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</section>
<script>
    /**
     * Add a Child to a given list
     */
    function addChild(ul) {
        var newLI = $("<li class='ui-state-default' title='item' link='/' link_options='' visible_to=''></li>");
        ul.prepend(newLI);
        newLI.prepend("<div rel='menuItemTitle' class='grid_5 omega'>Item</div>");
        addEditOptions(newLI);
        sortIt();
        showSaveMenu()
    }
    function showSaveMenu() {
        $('#saveMenu, #saveMenu-1').show();
    }
    /**
     * Add a submenu to a given list. It adds a new ul so adds a dropdown menu, that can have childs.
     */
    function addSubMenu(li) {
        var ul = li.children('ul');
        if (!ul.length) {
            var ul = $("<ul class='sortable droptrue connectedSortable'></ul>");
            li.append(ul);
        }
        addChild(ul);
        showSaveMenu()
    }
    function saveMenuCSS() {
        var css = "background-color:" + $('#bg_color').val() + ';';
        css += "color:" + $('#text_color').val() + ';';
        css += "font-family:" + $('#font-family').val() + ';';
        css += "font-size:" + $('#font-size').val() + ';';
        css += "padding-top:" + $('#padding-top').val() + ';';
        css += "padding-right:" + $('#padding-right').val() + ';';
        css += "padding-bottom:" + $('#paddint-bottom').val() + ';';
        css += "padding-left:" + $('#padding-left').val() + ';';
        $('#css_<?php echo $object->id ?>').val(css);
    }

    /**
     *Edit the given menuitem/li
     */

    function editMenuItem(li) {
        _li = li;
        var div_name = 'editMenuItemPopUp';
        createPopUpBoxDiv('editMenuItemPopUp');
        $("#" + div_name + 'Data').html(loadingDivHTML());
        overlay = $('#' + div_name).overlay({
            api: true,
            mask: '#000'
        });
        overlay.load();
        //Set the form values// 
        $("#" + div_name + 'Data').html($('#editMenuItem').html());
        $('#menuItemTitle').val(_li.children("div[rel='menuItemTitle']").html().replace(/"/g, "'"));
        $('#menuItemLink').val(_li.attr('link'));
        $('#classNameMenus').val(_li.attr('classNameMenus'));
        if ((_li.attr("visible_to")) !== '' || (_li.attr("visible_to")) !== undefined) {
            var visible_To_All = _li.attr("visible_to").split(",");
            $(visible_To_All).each(function (i) {
                $('select#selectUserRoleMenu').find("option[value=\"" + visible_To_All[i] + "\"]").prop('selected', 'selected');
            });
        }
        var linkOptions = _li.attr("link_options").split(" ");
        if (linkOptions[0]) {
            $('#editMenuItemPopUp').find("input:radio[value=\"" + linkOptions[0] + "\"]").attr('checked', 'checked');
            if (linkOptions[1]) { //Set Additional Option
                $("#editMenuItemPopUp input[name='ajaxifiedDivName']").val(linkOptions[1]);
            }
        } else { //Set None Option
            $('#editMenuItemPopUp').find("input:radio[eq(3)]").attr('checked', 'checked');
        }

        //Save The form//
        $('#editMenuItemOK').click(function () {
            _li.children("div[rel='menuItemTitle']").text($('#menuItemTitle').val());
            _li.attr('link', $('#menuItemLink').val());
            _li.attr('classNameMenus', $('#classNameMenus').val());
            var visibleTo = [];
            $('select#selectUserRoleMenu option:selected').map(function (i, selected) {
                visibleTo[i] = $(selected).val();
            });
            _li.attr('visible_to', visibleTo);
            if ($("input[name=linkOption]:checked").val()) {
                linkOptions = $("input[name=linkOption]:checked").val();
                linkOptions = $("input[name='ajaxifiedDivName']").val() ? linkOptions + " div_name='" + $("input[name='ajaxifiedDivName']").val() + "' " : linkOptions;
            }
            _li.attr('link_options', linkOptions);
            overlay.close();
            showSaveMenu()
        });
        $('#editMenuItemCancel').click(function () {
            overlay.close();
        });
    }

    /**
     * Add the options to add /edit /remove the given li.
     */
    function addEditOptions(li) {

        var menuItemTitle = li.children("div[rel='menuItemTitle']");
        //Add Child Link
        var addChildLink = $("<div class='btn btn-warning br2 pull-right mr10 handler-box'><span class='fa fa-arrows-h'></span></div><div class='btn btn-success br2 pull-right mr10'><span class='fa fa-plus'></span></div>");
        (addChildLink).insertBefore(menuItemTitle);
        addChildLink.click(function () {
            addSubMenu(li);
        });
        //Remove Child Link
        var removeMeLink = $("<div class='btn btn-danger br2 pull-right mr10'><span class='fa fa-close'></span></div><div class='clearfix'></div>");
        removeMeLink.insertAfter(menuItemTitle);
        removeMeLink.click(function () {
            var div_name = 'popUpDiv';
            $("#" + div_name + 'Data').html(loadingDivHTML());
            overlay = $('#popUpDiv').overlay({
                api: true,
                mask: '#000'
            });
            overlay.load();
            $("#" + div_name + 'Data').html('');
            var message = $(this).attr('message') ? $(this).attr('message') : "Are you sure, you want to remove this.<div class='clearfix mb20'></div>";
            var yesButton = $("<input type='button' value='Yes' class='button btn-success mr15' />");
            var cancelButton = $("<input type='button' value='No' class='button btn-danger'/>");
            $("#" + div_name + 'Data').append("<div class='panel'><div class='panel-heading'><span class='panel-title'><i class='fa fa-gear'></i>Confirm Action</span></div><div class='panel-body p25 admin-form'>");
            $("#" + div_name + 'Data .panel-body').append(message);
            $("#" + div_name + 'Data .panel-body').append(yesButton);
            $("#" + div_name + 'Data .panel-body').append(cancelButton);
            $("#" + div_name + 'Data').append('</div></div>');
            url = $(this);
            yesButton.click(function () {
                li.remove();
                showSaveMenu();
                overlay.close();
            });
            cancelButton.click(function () {
                overlay.close()
            });
            return false;
        });
        //Edit Link//
        var editMeLink = $("<div class='btn btn-info br2 pull-right mr10 '><span class='fa fa-pencil'></span></div>");
        editMeLink.insertAfter(menuItemTitle);
        editMeLink.click(function () {
            editMenuItem(li);
        });
        var spacer = $("<div class='spacer'>&nbsp;</div>");
        spacer.insertAfter(removeMeLink);
        //        li.children("div[rel='menuItemTitle']").editable(function(value, settings) {
        //            showSaveMenu();
        //            return(value);
        //        },{ submit  : 'OK',type    : 'textarea'});

    }
    /**
     * refreshes the sortable with new li/ul tags added.
     */
    function sortIt() {
        sortable = $("ul.sortable").sortable({
            connectWith: ".connectedSortable",
            dropOnEmpty: true,
            placeholder: " blueBackground",
            handle: '.handler-box',
            update: function () {
                showSaveMenu()
            }
        });
    }
    /**
     * Save the edited menu.
     * This serializes the data of li, adds hidden inputs to store the ul/li tag, id,link etc.
     */
    $('#editObject<?php echo $object->id ?>').find('#saveMenuItem, #saveMenuItem-1').click(function () {
        var count = 0;
        $("#menuEditor  ul ").each(function () {

            var ul = $(this);
            $(this).children('li').each(function () {
                count++;
                var title = $(this).children("div[rel='menuItemTitle']").html().replace(/"/g, "'");
                var link = $(this).attr('link');
                var linkOptions = $(this).attr('link_options');
                var visible_To = ($(this).attr('visible_to') !== undefined) ? $(this).attr('visible_to') : '';
                var classNameMenus = $(this).attr('classNameMenus');
                var liID = 'li' + count;
                $(this).attr('id', liID);
                if ($(this).children('ul').length) {
                    $(this).children('ul').each(function () {
                        $(this).attr('childOf', liID);
                    })
                }
                var menuItem = $("<input type='hidden' name='menuItemData[" + liID + "][title]' value=\"" + title + "\" />");
                $('#menuItemDataDiv').append(menuItem);
                var menuItemLink = $("<input type='hidden' name='menuItemData[" + liID + "][link]' value='" + link + "' />");
                $('#menuItemDataDiv').append(menuItemLink);
                var menuItemLinkOptions = $("<input type='hidden' name='menuItemData[" + liID + "][link_options]' value=\"" + linkOptions + "\" />");
                $('#menuItemDataDiv').append(menuItemLinkOptions);
                var menuItemClassName = $("<input type='hidden' name='menuItemData[" + liID + "][classNameMenus]' value=\"" + classNameMenus + "\" />");
                $('#menuItemDataDiv').append(menuItemClassName);
                var menuItemVisibleTo = $("<input type='hidden' name='menuItemData[" + liID + "][visible_to]' value=\"" + visible_To + "\" />");
                $('#menuItemDataDiv').append(menuItemVisibleTo);
            });
            var childOf = ul.attr('childOf');
            var input = $("<input type='hidden' name='menuItems[" + childOf + "]' value='" + ul.sortable('toArray') + "' />");
            $('#menuItemDataDiv').append(input);
        });
        $('#editObject<?php echo $object->id ?>').submit();
        $('#saveMenu, #saveMenu-1').hide();
    });
    /**
     * Make the menu sortable/draggable etc.
     * Makes it editable.
     */
    $().ready(function () {
        $('#menuEditor ul').addClass('sortable droptrue connectedSortable');
        $('#menuEditor li').each(function () {
            var li = $(this);
            li.addClass('ui-state-default');
            addEditOptions(li); //Add the options to edit/add extra child etc.
        });
        sortIt();
        $('input').bind('change keyup', function () {
            showSaveMenu()
        });
    })
</script>



