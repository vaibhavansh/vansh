<?php
global $page;
$sideMenus = $object->getChild('li0', $object->items);
if (!empty($sideMenus)) {
    ?>
    <!--    <aside class="nano nano-light affix">    -->
    <div class="sidebar-left-content nano-content">
        <ul class="nav sidebar-menu">
            <li class="sidebar-label pt20"></li>
            <?php
            foreach ($sideMenus as $sideMenu) {
                if (!empty($sideMenu->visible_to)) {
                    $sideVisibleTo = explode(',', $sideMenu->visible_to);
                } else {
                    $sideVisibleTo = array();
                }
                if (in_array($page->currentUser->webUserRole, $sideVisibleTo) || empty($sideVisibleTo)) {
                    ?>            
                    <li><a class="accordion-toggle"><span class="<?php if (!empty($sideMenu->classNameMenus)) echo $sideMenu->classNameMenus; ?>"></span><span class="sidebar-title"><?php echo $sideMenu->title; ?></span><span class="caret"></span></a>
                        <ul class="nav sub-nav">
                            <?php
                            $sideMenuChilds = $object->getChild($sideMenu->id, $object->items);
                            if (!empty($sideMenuChilds)) {
                                foreach ($sideMenuChilds as $sideMenuChild) {
                                    if (!empty($sideMenuChild->visible_to)) {
                                        $sideChildVisibleTo = explode(',', $sideMenuChild->visible_to);
                                    } else {
                                        $sideChildVisibleTo = array();
                                    }
                                    if (in_array($page->currentUser->webUserRole, $sideChildVisibleTo) || empty($sideChildVisibleTo)) {
                                        ?>
                                        <li><a href="<?php echo $sideMenuChild->link; ?>" <?php echo $sideMenuChild->link_options; ?>><span class="<?php if (!empty($sideMenu->classNameMenus)) echo $sideMenu->classNameMenus; ?>"></span><?php echo $sideMenuChild->title; ?></a>
                                        </li>                                    
                                        <?php
                                    }
                                }
                            }
                            ?>
                        </ul>
                    </li>
                    <?php
                }
            }
            ?>
        </ul>
        <div class="sidebar-toggle-mini"><a href="#"><span class="fa fa-sign-out"></span></a></div>
    </div>
    <!--    </aside>-->
<?php } ?>
