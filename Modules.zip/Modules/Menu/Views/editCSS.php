<div id="menuCSSEdit">
    <h2>Edit CSS for <?php echo $object->title; ?></h2>
    <div id="menuEditCSSResult"></div>
    <div class="grid_12">
        <?php echo "<style>" . str_replace('#' . $object->unique_id, '#previewMenu', $object->style) . '</style>'; ?>
        <ul class="nav" id="previewMenu" >
            <li><a href="#">Menu Item</a></li>
        </ul>
        <div class="spacer20"></div>
        <div class="grid_4">Background:</div>
        <input class="grid_6" type="text" rel="colorpicker" name="background" id="background"  value="<?php echo isset($object->cssArray['li']['background']) ? $object->cssArray['li']['background'] : '' ?>" />
        <div class="spacer"></div>
        <div class="grid_4"><label for='text_color'>Text Color</label></div>
        <input class="grid_6" type="text" rel="colorpicker" name="text_color" id="text_color" value="<?php echo isset($object->cssArray['li']['color']) ? $object->cssArray['li']['color'] : '' ?>" />
        <div class="spacer"></div>
        <div class="grid_4"><label for='hover'>Hover Color</label></div>
        <input class="grid_6" type="text" rel="colorpicker" name="hover-color" id="hover-color" value="<?php echo isset($object->cssArray['li:hover']['background-color']) ? $object->cssArray['li:hover']['background-color'] : '' ?>" />
        <div class="spacer"></div>

        <div class="grid_4"><label for='font-family'>Font-family:</label></div>
        <input class="grid_6" type="textbox" name="font-family" id="font-family" value="<?php echo isset($object->cssArray['li']['font-family']) ? $object->cssArray['li']['font-family'] : '' ?>" />
        <div class="spacer"></div>
        <div class="grid_4"><label for='font-size'>Font-size:</label></div>
        <input  class="grid_5" type="textbox" name="font-size" id="font-size" value="<?php echo isset($object->cssArray['li']['font-size']) ? rtrim($object->cssArray['li']['font-size'], 'px') : '' ?>" />
        <div class="grid_2 omega alpha">- px</div>
        <div class="spacer"></div>
        <div class="grid_4"><label for='text-align'>Text Align:</label></div>
        <input  class="grid_5" type="textbox" name="text-align" id="text-align" value="<?php echo isset($object->cssArray['li']['text-align']) ? rtrim($object->cssArray['li']['text-align'], 'px') : 'center' ?>" />

        <div class="spacer"></div>
        <div class="grid_4"><label for='line-height'>Line Height:</label></div>
        <input  class="grid_5" type="textbox" name="line-height" id="line-height" value="<?php echo isset($object->cssArray['li']['line-height']) ? rtrim($object->cssArray['li']['line-height'], 'px') : '' ?>" />
        <div class="grid_2 omega alpha">- px</div>
        <div class="spacer"></div>
        <div class="grid_4"><label for='top-item-width'>Top Item Width:</label></div>
        <input class="grid_5" type="textbox" name="top-item-width" id="top-item-width" value="<?php echo isset($object->cssArray['li']['width']) ? rtrim($object->cssArray['li']['width'], 'px') : '' ?>" />
        <div class="grid_2 omega alpha">- px</div>
        <div class="spacer"></div>
        <div class="grid_4"><label for='border'>Border:</label></div>
        <input class="grid_5" type="textbox" name="border" id="border" value="<?php echo isset($object->cssArray['li']['border']) ? ($object->cssArray['li']['border']) : '' ?>" />
        <div class="spacer"></div>
        <div class="grid_4"><label for='sub-item-width'>Sub-Item Width:</label></div>
        <input class="grid_5" type="textbox" name="sub-item-width" id="sub-item-width" value="<?php echo isset($object->cssArray['li ul li']['width']) ? rtrim($object->cssArray['li ul li']['width'], 'px') : '' ?>" />
        <div class="grid_2 omega alpha">- px</div>
        <div class="spacer"></div>
        <?php /*
        <div class="grid_4"><label for='font-size'>Padding:</label></div>

        <input type="textbox" class="grid_1" name="padding-top" id="padding-top" value="<?php echo isset($object->cssArray['li']['padding-top']) ? rtrim($object->cssArray['li']['padding-top'], 'px') : '' ?>" />

        <input type="textbox" class="grid_1" name="padding-right" id="padding-right" value="<?php echo isset($object->cssArray['li']['padding-right']) ? rtrim($object->cssArray['li']['padding-right'], 'px') : '' ?>" />

        <input type="textbox" class="grid_1" name="padding-bottom" id="padding-bottom" value="<?php echo isset($object->cssArray['li']['padding-bottom']) ? rtrim($object->cssArray['li']['padding-bottom'], 'px') : '' ?>" />

        <input type="textbox" class="grid_1" name="padding-left" id="padding-left" value="<?php echo isset($object->cssArray['li']['padding-left']) ? rtrim($object->cssArray['li']['padding-left'], 'px') : '' ?>" />


        <div class="spacer"></div>
         */?>
        <input type="button" id="preview" value="Preview" />
        <input type="button" id="save" value="Save" />
    </div>
</div>
<script>
    $('#preview').click(function(){
        $('#previewMenu a').css('background-color','#' + $('#bg_color').val());
        $('#previewMenu a').css('color','#' + $('#text_color').val());
        $('#previewMenu a').css('font-family',$('#font-family').val());
        $('#previewMenu a').css('font-size',$('#font-size').val()+'px');
        $('#previewMenu a').css('padding-top',$('#padding-top').val()+'px');
        $('#previewMenu a').css('padding-right',$('#padding-right').val()+'px');
        $('#previewMenu a').css('padding-bottom',$('#padding-bottom').val()+'px');
        $('#previewMenu a').css('padding-left',$('#padding-left').val()+'px');
        $('#previewMenu a').css('width',$('#top-item-width').val()+'px');
        $('#previewMenu a').css('border',$('#border').val());
    });
    $('#save').click(function(){
        var css ='';
        var paddingRight =0;
        var paddingLeft =0;
        var background = '';
        var color = '';
        var width = 0;
        var borderThickness = 0;
        var textAlign = 'center';
        var textColor = '';
        $('#preview').trigger('click');
        if($('#background').val()){
            background = $('#background').val();
            css += "background:#"+background+';';
        }
        if($('#text_color').val()){
            color = $('#text_color').val();
            css += "color:#"+ $('#text_color').val()+';';
        }
        if($('#font-family').val()){
            css += "font-family:"+ $('#font-family').val()+';';
        }else{
            css += "font-family:'Oswald', sans-serif";
        }
        if($('#font-size').val())
            css += "font-size:"+ $('#font-size').val()+'px;';
        if($('#text-align').val()){
            textAlign = $('#text-align').val();
            css += "text-align:"+textAlign +';';
        }
        if($('#line-height').val())
            css += "line-height:"+ $('#line-height').val()+'px;';
        if($('#padding-top').val())
            css += "padding-top:"+ $('#padding-top').val()+'px;';
        if($('#padding-right').val()){
            paddingRight = $('#padding-right').val();
            css += "padding-right:"+ paddingRight +'px;';
        }
        if($('#padding-bottom').val())
            css += "padding-bottom:"+ $('#padding-bottom').val()+'px;';
        if($('#padding-left').val())
        {
            paddingLeft = $('#padding-left').val();
            css += "padding-left:"+ paddingLeft +'px;';
        }


        if($('#border').val()){
            border = $('#border').val();
            css += 'border:'+border+';';
            borderThickness = (border.substr(0,border.search('px')));
        }
        $('#previewMenuItem a').attr('style',css);
        if($('#top-item-width').val())
            css += "width:"+ $('#top-item-width').val()+'px;';

        if(css != ''){
            css = 'li{ '+css+' }';
        }
        if(color !='')
        css += 'a{color:#'+color+'}';
        if($('#sub-item-width').val()){
            width = $('#sub-item-width').val();
        }
        css += "li ul li{width:"+width+"px;}";
        css += "li ul ul{left:"+ (parseInt(width) + parseInt(borderThickness) + parseInt(paddingRight) + parseInt(paddingLeft) ) +'px;}';
        if($('#hover-color').val()){
            css += "li:hover{background-color:#"+$('#hover-color').val()+"}";
            css += "a:hover{background-color:#"+$('#hover-color').val()+"}";
        }

        $.post('/menu_menus/save', {
            id:'<?php echo $object->id; ?>',
            css:css,
            pageRequestType:'ajax'
        }, function(data){
            $('#menuEditCSSResult').html(data);
        });

    });
</script>