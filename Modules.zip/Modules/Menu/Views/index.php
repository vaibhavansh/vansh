<section id="content_wrapper">
    <section id="content" class="">
        <div id="animation-switcher" class="col-xs-12">
            <div class="panel mb25 mt5">
                <div class="panel-heading">
                    <span class="panel-title"> <i class="fa fa-th-list"></i> <?php echo $header ?></span>
                    <span class="pull-right fix-right">
                        <div class="btn-group text-right">
                            <a class="btn btn-info br2 btn-xs" href="/<?php echo $objects->coreURL ?>/edit/0" oncloseFunction="reloadDiv('/<?php echo $objects->coreURL; ?>/index','mainContent');" rel="ajaxRequest"><span class="fa fa-plus"></span></a>
                        </div>
                    </span>
                </div>
                <div class="panel-menu admin-form theme-primary">
                    <div class="row">
                        <div class="col-md-12">
                            <label for="name" class="field prepend-icon">
                                <input id="fooFilter_0" type="text" name="name" placeholder="Type to filter" class="event-name gui-input br-light light">
                                <label for="name" class="field-icon"><i class="fa fa-gear"></i></label>
                            </label>
                        </div>
                    </div>
                </div>
                <div class="panel-body pn">
                    <div class="col-sm-12">
                        <?php echo $objects->pageLinks(array('url' => "/{$objects->coreURL}/index", 'ajaxRequest' => true)); ?>
                    </div><div class="clearfix"> </div>
                    <div class="table-responsive of-a">
                        <table data-filter="#fooFilter_0" class="table admin-form theme-warning tc-checkbox-1 fs13 footable">
                            <thead>
                                <tr class="bg-light">
                                    <th>Menu Name</th>
                                    <th class="text-right">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if (!empty($objects->data))
                                    foreach ($objects->data as $object) {
                                        ?>
                                        <tr id="row_<?php echo $object->id ?>">
                                            <td class="text-left"><a href="/<?php echo $objects->coreURL . '/edit/' . $object->id ?>" oncloseFunction="reloadDiv('/<?php echo $objects->coreURL; ?>/listmenus','mainContent');" rel="ajaxRequest"  > <?php echo $object->title; ?></a></td>
                                            <td class="text-right">
                                                <div class="btn-group text-right">
                                                    <button type="button" data-toggle="dropdown" aria-expanded="false" class="btn btn-info br2 btn-xs fs12 dropdown-toggle">Action<span class="caret ml5"></span></button>
                                                    <ul role="menu" class="dropdown-menu">
                                                        <li><a href="/<?php echo $objects->coreURL . '/edit/' . $object->id ?>" oncloseFunction="reloadDiv('/<?php echo $objects->coreURL; ?>/listmenus','mainContent');" rel="ajaxRequest" >Edit</a></li>
                                                        <li><a href="/<?php echo $objects->coreURL . '/duplicate/' . $object->id ?>" rel="confirmClickURL" confirmTrueFunction="reloadDiv('/<?php echo $objects->coreURL . '/index' ?>','mainContent')" message="Are you sure you want to duplicate '<?php echo $object->title; ?>'." >Duplicate</a></li>
                                                        <li><a href="/<?php echo $objects->coreURL . '/delete/' . $object->id ?>" rel="confirmClickURL" confirmTrueFunction="$('#row_<?php echo $object->id ?>').hide()" message="Are you sure you want to remove '<?php echo $object->title; ?>'." >Delete</a></li>
                                                    </ul>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="clearfix"></div>
    </section>
</section>