<h2>Import CSS</h2>
<div class="spacer20"></div>
<textarea class="grid_11" style="height:300px" id="generatedMenu"></textarea>
<br />
<script>
    $('#generatedMenu').change(function(){$(this).text(makeReadable($('#generatedMenu').text()))});
</script>
<input type="button" name="import" id="import" value ="Test Import"/>
