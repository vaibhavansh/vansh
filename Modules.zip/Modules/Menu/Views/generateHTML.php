<h2>Generated HTML for <?php echo $object->title ?></h2>
<div class="spacer20"></div>
<textarea class="grid_11" style="height:300px" id="generatedMenu">
<style>
    /**General CSS **/
    <?php echo Menu_Models_Menu::$generalCSS;?>

    /**Menu Specific CSS **/
    <?php echo $object->css;?>

</style>
<ul class='nav'>
        <?php echo $object->printMenu($object->getChild('li0', $object->items), $object->items); ?>
</ul>
</textarea>
<br />
<script>
    $('#generatedMenu').text(makeReadable($('#generatedMenu').text()));
</script>
