<?php

class Leave_Controllers_LeavesController extends Core_Controllers_SitesController {

    var $layoutId = 43;

    function leaveView($user_id = '') {
        global $page;
        $variables = array();
        $allotedleaves = array();
        $where = '';
        $tags = func_get_args();
        $variables['pageNumber'] = array_pop($tags);
        if (!(substr($variables['pageNumber'], 0, 5) == 'page_')) {
            $tags[] = $variables['pageNumber'];
            $variables['pageNumber'] = 'page_1';
        }

        if ($page->currentUser->userLoggedIn) {
            $webUserRole = $page->currentUser->webUserRole;
            $userId = !empty($user_id) ? $user_id : array_pop($tags);
            if (is_numeric($userId)) {
                $variables['fullname'] = User_Models_User::getFullNameById($userId);
                $variables['users_id'] = $userId;
                $where .= "(leaves.userId = '" . $userId . "')";
            } else if ($webUserRole == 1) {
                $where .= "leaves.userId = '" . $page->currentUser->id . "'";
            }
        } if (isset($_POST['searchTitle']) && $_POST['searchTitle']) {
            if (!empty($where)) {
                $where .= "and";
            }
            $variables['searchTitle'] = (trim(str_replace(array('/', '.'), '', ($_POST['searchTitle']))));
            $leavetypeids = array();
            foreach (Leave_Models_Leave::$leaveTypes as $leavetypeid => $leavetype) {
                if (strpos(strtolower($leavetype), strtolower($variables['searchTitle'])) !== false) {
                    $leavetypeids[] = $leavetypeid;
                }
            }
            if (!empty($leavetypeids)) {
                $where .= "(leaves.leavetype in (" . implode(',', $leavetypeids) . ") OR users.name like '%" . $variables['searchTitle'] . "%' OR users.lastname like '%" . $variables['searchTitle'] . "%')";
            } else {
                $where .= "(users.name like '%" . $variables['searchTitle'] . "%' OR users.lastname like '%" . $variables['searchTitle'] . "%') ";
            }
        }
        if ($webUserRole == 2) {
            $paginatedContent = Leave_Models_Leave::getPaginatedData(array('where' => $where,
                        'join' => "users on users.id = leaves.userId",
                        'cols' => "leaves.*,concat(name,' ' ,lastName) as fullName,users.webUserRole as userRole,users.image as image",
                        'orderBy' => "leaves.id desc",
                        'pageNumber' => $variables['pageNumber']
            ));
            $variables['leaves'] = $paginatedContent;
        } else if ($webUserRole == 3 || $webUserRole == 1) {
            $paginatedContent = Leave_Models_Leave::getPaginatedData(array('where' => $where,
                        'join' => "users on users.id = leaves.userId and users.webUserRole != 2",
                        'cols' => "leaves.*,concat(name,' ' ,lastName) as fullName,users.webUserRole as userRole,users.image as image",
                        'orderBy' => "leaves.id desc",
                        'pageNumber' => $variables['pageNumber']
            ));
            $variables['leaves'] = $paginatedContent;
        }
        return $variables;
    }

    function editLeave($id = '') {
        global $page;
        $variables = array();
        $getLeaves = array();
        $getvar = func_get_args();
        $variables['restrict'] = array_pop($getvar);
        if (!empty($id)) {
            $variables['editLeave'] = new Leave_Models_Leave($id);
        }
        $editStartDateYearly = date('Y-m-d', strtotime($page->currentUser->created . '+' . $_SESSION['years'] . ' years'));
        $editEndDateYearly = date('Y-m-d', strtotime($editStartDateYearly . '+1 year' . '-1 day'));
        if (!empty($_POST['leaveTypeVal']) && !empty($_POST['leaveTypeName']) && ($_POST['joiningYear'] != '')) {
            $getDuration = Leave_Models_Leave::find_all(array('where' => "leavetype = '" . $_POST['leaveTypeVal'] . "' and userId = '" . $page->currentUser->id . "' and (status = '2' OR status = '1') and startdate >= '{$editStartDateYearly}' and enddate <= '{$editEndDateYearly}'",
                        'cols' => "leaves.duration"));
            foreach ($getDuration as $duration) {
                $getLeaves[] = $duration->duration;
            }
            $leaveTypeName = $_POST['leaveTypeVal'];
            if (2 >= $_POST['joiningYear']) {
                $totalLeaves = Leave_Models_Leave::$allowedLeaves[$leaveTypeName]['0_2_years'];
            } else if (2 < $_POST['joiningYear'] && $_POST['joiningYear'] <= 6) {
                $totalLeaves = Leave_Models_Leave::$allowedLeaves[$leaveTypeName]['3_6_years'];
            } else if (7 <= $_POST['joiningYear'] && $_POST['joiningYear'] <= 10) {
                $totalLeaves = Leave_Models_Leave::$allowedLeaves[$leaveTypeName]['7_10_years'];
            } elseif (10 < $_POST['joiningYear']) {
                $totalLeaves = Leave_Models_Leave::$allowedLeaves[$leaveTypeName]['10_+_years'];
            }
            echo $usedLeaves = $totalLeaves - array_sum($getLeaves);
            exit;
        }
        return $variables;
    }

    function saveLeave($id = '') {
        global $page;
        $variables = array();
        $saveLeaves = new Leave_Models_Leave($id);
        $_POST['currentdate'] = date('Y-m-d');
        if (!empty($_FILES['fileToUpload'])) {
            if (($_FILES['fileToUpload']['tmp_name'])) {
                $images = $_FILES['fileToUpload'];
                $postleaveid = !empty($id) ? $id : '';
                $target_file = "dropboxapi/user_documents/{$page->currentUser->username}/user_upload/" . "MedicalDocument" . $images['name'];
                if (file_exists($target_file)) {
                    $target_file = "dropboxapi/user_documents/{$page->currentUser->username}/user_upload/" . rand(10, 1000) . "_MedicalDocument" . $images['name'];
                }
                if (!empty($target_file)) {
                    if (move_uploaded_file($images['tmp_name'], $target_file)) {
                        $_POST['medicaldoc'] = $target_file;
                    }
                }
            }
        }
        $_POST['status'] = isset($_POST['status']) ? $_POST['status'] : '1';
        if ($id != '') {
            $msgTitle = 'Modify Requested Leave';
            $saveLeaves->save($_POST);
        } else {
            $msgTitle = 'Requested Leave';
            $id = $saveLeaves->save($_POST);
        }
        $html = serialize(array('Leave_Models_Leave' => $id));
        Notification_Models_Notification::AddNotifications($_POST['userId'], Leave_Models_Leave::$leaveTypes[$_POST['leavetype']], $msgTitle, 'admin', $html);
        echo json_encode(array('status' => 'success', 'msg' => "Leave Send Successfully"));
        return $variables;
    }

    function medicaldoc($leaveid = '') {
        $variables['leaveid'] = $leaveid;
        return $variables;
    }

    function allowedLeaves($userId = '') {
        global $page;
        if (!empty($userId)) {
            $variables['user'] = new User_Models_User($userId);
        } else {
            $variables['user'] = $page->currentUser;
        }
        $startDateYearly = date('Y-m-d', strtotime($variables['user']->created . '+' . $_SESSION['years'] . ' years'));
        $endDateYearly = date('Y-m-d', strtotime($startDateYearly . '+1 year' . '-1 day'));
        $variables['allotedLeaves'] = Leave_Models_Leave::getUserAllowedLeaves($variables['user']->id);
        $variables['leaves'] = Leave_Models_Leave::find_all(array('where' => "userId = '{$variables['user']->id}' and status = '2' and startdate >= '{$startDateYearly}' and enddate < '{$endDateYearly}'",
                    'cols' => "leaves.id,leaves.duration as usedLeaves,leaves.leavetype"));
        if (!empty($variables['leaves'])) {
            foreach ($variables['leaves'] as $leave) {
                $variables['usedLeaves'][$leave->leavetype][] = $leave->usedLeaves;
            }
        }
        return $variables;
    }
    
    function employeeLeaves () {
        global $page;
        $variables = array();
        $variables['leaves'] = Leave_Models_Leave::find_all(array('where' => "status = 2"));
        return $variables;
    }

}

?>
