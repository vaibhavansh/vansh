<?php

/**
 *
 * @author saurabhgandhe
 */
class Leave_Models_Leave extends Core_Models_DbTable {

    static $table = 'leaves';
    static $fields = NULL;
    static $requestLeave = array(
        1 => 'Pending',
        2 => 'Approved',
        3 => 'Rejected',
        4 => 'Canceled'
    );
    static $leaveActionClass = array(1=>'btn-warning',2=>'btn-success',3=>'btn-danger',4=>'btn-info');
    static $leaveTypes = array(
        1 => 'Paid Vacation',
        2 => 'Personal Leave',
        3 => 'Emergency Leave',
        4 => 'Wedding Leave',
        5 => 'Sick Leave',
        6 => 'Work From Home',
        7 => 'Half Day'
    );
    static $allowedLeaves = array(
        '1' => array(
            '0_2_years' => 3,
            '3_6_years' => 5,
            '7_10_years' => 5,
            '10_+_years' => 7),
        '3' => array(
            '0_2_years' => 3,
            '3_6_years' => 3,
            '7_10_years' => 3,
            '10_+_years' => 3),
        '4' => array(
            '0_2_years' => 10,
            '3_6_years' => 10,
            '7_10_years' => 10,
            '10_+_years' => 10),
        '5' => array(
            '0_2_years' => 3,
            '3_6_years' => 3,
            '7_10_years' => 3,
            '10_+_years' => 3),
        '6' => array(
            '0_2_years' => 0,
            '3_6_years' => 1,
            '7_10_years' => 1,
            '10_+_years' => 1),
        '2' => array(
            '0_2_years' => 0,
            '3_6_years' => 2,
            '7_10_years' => 3,
            '10_+_years' => 4),
        '7' => array(
            '0_2_years' => 12,
            '3_6_years' => 12,
            '7_10_years' => 12,
            '10_+_years' => 12)
    );

    function setSelected($selected) {
        $this->setSelected = $selected;
    }

    function selectleaveType() {
        if (!empty($this->selectleaveType) && is_array($this->selectleaveType)) {
            foreach ($this->selectleaveType as $key => $val) {
                if ($this->setSelected == $key) {
                    return $val;
                }
            }
        }
    }

    function getUserAllowedLeaves($userid) {
        global $page;
        $user = !empty($userid) ? new User_Models_User($userid) : new User_Models_User($page->currentUser->id);
        $joinDate = new DateTime(date($user->created));
        $currentDate = new DateTime(date("Y-m-d"));
        $interval = date_diff($joinDate, $currentDate);
        $years = $interval->format('%y');
        $_SESSION['years'] = $years;
        $array = self::$allowedLeaves;
        if (2 >= $years) {
            foreach ($array as $key => $value) {
                $allotedleaves[$key] = $value['0_2_years'];
            }
        } else if (2 < $years && $years <= 6) {
            foreach ($array as $key => $value) {
                $allotedleaves[$key] = $value['3_6_years'];
            }
        } else if (7 <= $years && $years <= 10) {
            foreach ($array as $key) {
                $allotedleaves[$key] = $value['7_10_years'];
            }
        } elseif (10 < $years) {
            foreach ($array as $key => $value) {
                $allotedleaves[$key] = $value['10_+_years'];
            }
        }
        return $allotedleaves;
    }

    /**
     * Get different types of leave available.
     * Returns the name, if passed the ID, or returns the array with all.
     * @param type $leaveTypeId
     * @return type
     */
    static function getLeaveType($leaveTypeId = '') {
        if (is_numeric($leaveTypeId)) {
            return self::$leaveTypes[$leaveTypeId];
        } else {
            return self::$leaveTypes;
        }
    }

}

?>
