<?php
global $page;
$webUserRole = $page->currentUser->webUserRole;
$joining_year = $page->currentUser->created;
$userid = !empty($users_id) ? $users_id : '';
?>

<section id="content" class="">
    <div id="animation-switcher" class="col-md-12 col-sm-12">
        <div class="clearfix mb15"></div>

        <?php
        if (!empty($userid)) {
            User_Controllers_UsersController::userProfileMenus($userid);
        }
        ?>
        <div class="clearfix"></div>
        <div id="view_profile" name="view_profile">
            <div class="panel mb25">
                <div class="panel-heading"><span class="panel-title"> <i class="fa fa-th-list hidden-xs"></i><span><?php echo $fullname; ?> Requested Leave List</span>
    <!--                <span class="pull-right fix-right">
                        <div class="btn-group">
                          <button type="button" class="btn btn-default light"><i class="fa"></i> Request Leave</button>
                        </div>--><div class="clearfix"></div>
                    </span>
                </div>
                <div class="panel-menu admin-form theme-primary pbn p5">
                    <div class="row">
                        <form resultDiv='mainContent' name="searchLeaves" id="searchLeaves" method="post" class="form-inline col-xs-12 pln pb5" keepVisible="1" keepResult="1" action="/leaveview/<?php echo $userid; ?>" rel="ajaxifiedForm">      
                            <div class="col-lg-12 prn">
                                <label for="name" class="field prepend-icon">
                                    <input class="event-name gui-input br-light light mbn search-input" type="text" name="searchTitle" placeholder="Search" value="<?php echo $searchTitle = ( isset($_POST['searchTitle']) && $_POST['searchTitle'] != '' ) ? $_POST['searchTitle'] : ''; ?>" />
                                    <label for="name" class="field-icon"><i class="fa fa-search"></i></label>
                                    <div class="btn-fix-right">
                                        <button type="submit" class="submit-btn button btn-success pull-left mr5"><i class="fa fa-search hidden-lg"></i><span class="visible-lg">Search</span></button>
                                        <button type="reset" class="reset-btn button btn-danger"><i class="fa fa-refresh hidden-lg"></i><span class="visible-lg">Reset</span></button>    
                                    </div>
                                </label>
                            </div>
                        </form>
                    </div>
                </div>
                <?php
                if (!empty($leaves->data)) {
                    ?>
                    <div class="panel-body pn">
                        <div class="list-com" id="list-com">
                            <div class="no-tpad upperCase">
                                <div class="panel-body pn">
                                    <div class="com-detail "> 
                                        <div class="col-sm-12">
                                            <div class="col-lg-1 visible-lg">
                                                <p><strong>Avatar</strong></p>
                                            </div>
                                            <div class="col-lg-8 col-md-7 col-sm-9 pn">
                                                <div class="col-md-3 col-sm-3">
                                                    <p><strong>Name</strong></p>
                                                </div>
                                                <div class="col-md-4 col-sm-4">
                                                    <p><strong>Leave Type</strong></p>
                                                </div>
                                                <div class="col-md-3 col-sm-3">
                                                    <p><strong>Dates</strong></p>
                                                </div>
                                            </div>
                                            <div class="col-lg-1 col-md-2 hidden-sm">
                                                <p> <strong>Duration</strong></p>
                                            </div>

                                            <div class="col-lg-2 col-md-3 col-sm-3 text-right">
                                                <p> <strong>Action</strong></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php
                            foreach ($leaves->data as $leave) {
                                if ($page->currentUser->id == $leave->userId || $webUserRole == 3 || $webUserRole == 2) {
                                    ?>
                                    <div class="list-com-data p5">
                                        <div class="panel-body p5">
                                            <div class="com-detail">
                                                <div class="col-sm-12 pn">
                                                    <div class="col-lg-1 visible-lg">
                                                        <img title="user" src="<?php echo!empty($leave->image) ? '/images/' . $leave->image . '_thumb.jpg' : '/img/avatars1.jpg'; ?>" class="img-responsive mw30 ib mr10">
                                                    </div>
                                                    <div class="col-lg-8 col-md-7 col-sm-9 pn">
                                                        <div class="col-md-3 col-sm-3 ">
                                                            <?php echo $leave->fullName; ?>
                                                        </div> 
                                                        <div class="col-md-4 col-sm-4 ">
                                                            <?php
                                                            echo Leave_Models_Leave::getLeaveType($leave->leavetype);
                                                            if ($leave->leavetype == 5) {
                                                                if ($page->currentUser->id == $leave->userId) {
                                                                    echo '<br/><a href="/medicaldoc/' . $leave->id . '/1" rel="popUpBox" class="btn btn-warning br2 btn-xs fs12 dropdown-toggle"><i class="fa fa-file">  Upload Medical</i></a> ';
                                                                }
                                                                if (!empty($leave->medicaldoc)) {
                                                                    $class = 'info';
                                                                    $link = $leave->medicaldoc;
                                                                    $targetnlank = 'target="_blank"';
                                                                    echo "<a href='{$link}' {$targetnlank}><i class='fa fa-search'> View Medical</i> </a>";
                                                                }
                                                            }
                                                            ?>
                                                        </div> 
                                                        <div class="col-md-5 col-sm-5 ">

                                                            <?php Core_Models_Utility::printFormatedDates(array('startDate' => $leave->startdate, 'endDate' => $leave->enddate)); ?> 

                                                        </div>

                                                    </div>
                                                    <div class="col-lg-1 col-md-2 hidden-sm">
                                                        <?php echo $leave->duration; ?>
                                                    </div>

                                                    <div class="col-lg-2 col-md-3 col-sm-3 text-right">                                            
                                                        <div class="btn-group text-right">
                                                            <button type="button" data-toggle="dropdown" aria-expanded="false" class="btn <?php echo Leave_Models_Leave::$leaveActionClass[$leave->status]; ?> br2 btn-xs fs12 dropdown-toggle">
                                                                <?php
                                                                echo Leave_Models_Leave::$requestLeave[$leave->status];
                                                                if ($leave->status != 4 && $webUserRole == 2) {
                                                                    echo '<span class="caret"></span>';
                                                                } else if ($leave->status != 4 && $leave->status != 3) {
                                                                    echo '<span class="caret"></span>';
                                                                }
                                                                ?>
                                                            </button>
                                                            <?php if (($webUserRole == 2 || $webUserRole == 3) && $page->currentUser->id != $leave->userId && $leave->status != 2 && $leave->status != 3 && $leave->status != 4) { ?>
                                                                <ul role="menu" class="dropdown-menu">
                                                                    <li><a href="/editleave/<?php echo $leave->id; ?>/view" rel="popUpBox">View</a></li>
                                                                    <li><a href="Javascript:void(0);" onclick="return toggleStatus('Leave_Models_Leave', '<?php echo $leave->id ?>', '2', '/leaveview')">Approve</a></li>
                                                                    <li><a href="Javascript:void(0);" onclick="return toggleStatus('Leave_Models_Leave', '<?php echo $leave->id ?>', '3', '/leaveview')">Reject</a></li>
                                                                </ul>
                                                            <?php } else if (($webUserRole == 2 || $webUserRole == 3) && $page->currentUser->id != $leave->userId && $leave->status != 1 && $leave->status != 3 && $leave->status != 4) { ?>
                                                                <ul role="menu" class="dropdown-menu">
                                                                    <li><a href="/editleave/<?php echo $leave->id; ?>/view" rel="popUpBox">View</a></li>
                                                                    <li><a href="Javascript:void(0);" onclick="return toggleStatus('Leave_Models_Leave', '<?php echo $leave->id ?>', '3', '/leaveview')">Reject</a></li>
                                                                </ul>
                                                            <?php } else if ($page->currentUser->id == $leave->userId && $leave->status != 3 && $leave->status != 4) { ?>
                                                                <ul role="menu" class="dropdown-menu">
                                                                    <li><a href="/editleave/<?php echo $leave->id; ?>/edit" rel="popUpBox">Edit</a></li>
                                                                    <li><a href="/editleave/<?php echo $leave->id; ?>/view" rel="popUpBox">View</a></li>
                                                                    <li><a href="Javascript:void(0);" onclick="return toggleStatus('Leave_Models_Leave', '<?php echo $leave->id ?>', '4', '/leaveview')">Cancel</a></li>
                                                                </ul>
                                                            <?php } else if ($webUserRole == 2 && $leave->status != 1 && $leave->status != 2 && $leave->status != 4) { ?>
                                                                <ul role="menu" class="dropdown-menu">
                                                                    <li><a href="/editleave/<?php echo $leave->id; ?>/view" rel="popUpBox">View</a></li>
                                                                    <li><a href="Javascript:void(0);" onclick="return toggleStatus('Leave_Models_Leave', '<?php echo $leave->id ?>', '2', '/leaveview')">Approve</a></li>
                                                                </ul>
                                                            <?php } ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                }
                            }
                            ?>
                        </div>
                        <div class="list-com-data pn">
                            <div class="panel-body pn">
                                <div class="com-detail ">
                                    <div class="col-lg-12 pt5">
                                        <div class="pull-left">                             
                                            <h5><?php echo $leaves->getCurrentPageInfo(); ?></h5>
                                        </div>
                                        <div class="pull-right" >                                          
                                            <?php echo $leaves->printPageNumbers(array('url' => "/leaveview/{$userid}", 'div_id' => 'mainContent', 'ajaxRequest' => true)); ?>
                                        </div>                           
                                    </div>
                                </div> 
                            </div>
                        </div>
                    </div>
                <?php } else { ?>
                    <div class="list-com-data pn">
                        <div class="panel-body pn">
                            <div class="com-detail ">
                                <div class="col-lg-12 p25">
                                    Requested Leave Not Found
                                </div>
                            </div> 
                        </div>
                    </div>
                <?php } ?>
            </div>
        </div>
    </div>
</section>
<script>
    $(".reset-btn").click(function () {
        $(this).parents("form").find(".search-input").val("");
        $(this).parents("form").find(".submit-btn").click();
    });
</script>