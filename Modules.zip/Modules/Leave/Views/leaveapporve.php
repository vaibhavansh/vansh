
<div id="editObject<?php //echo $object->id ?>ResultDiv"></div>
<div class="container">
    <div class="row">
        <div class="col-lg-6"><label>Filtered By <?php echo $usersObject->username;?></label></div>
        <div class="col-lg-6">      
            <form name ="" id="editObject<?php //echo $object->id ?>" method="post" keepVisible="1" keepResult="1" action="/adminLeaveView" rel="ajaxifiedForm">
                <div class="form-group">
                    <label for="select" class="col-lg-3 control-label">Selects User</label>
                    <div class="col-lg-6">
                        <select class="form-control" id="userId" name="userId" onchange="filter_tickets()">
                            <option value="0">Select User</option> 
                            <option value="0">All User</option> 
                            <?php foreach ($users as $userss) { ?>
                                <option value="<?php echo $userss->id; ?>"><?php echo $userss->username; ?></option>          
                            <?php } ?>
                        </select>  
                    </div>
                    <div class="col-lg-2">
                        <a id="update" href="Leave-Managment" rel="ajaxRequest"><i class="glyphicon glyphicon-refresh"></i></a>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-11">
            <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>username</th>
                        <th>Leave type</th>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>Duration</th>
                        <th>Cause</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>#</th>
                        <th>username</th>
                        <th>Leave type</th>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>Duration</th>
                        <th>Cause</th>
                        <th>Status</th>
                        <th>Action</th>
                        

                    </tr>
                </tfoot>
                <tbody>
                    <?php $i = 1;   foreach ($leaves as $leavess) {   ?>
                        <tr id="section_<?php echo $leavess->id ?>">
                            <td><?php echo $i; ?></td>
                            <td><?php echo $leavess->username; ?></td>
                            <td><?php echo $leavess->leaveType; ?></td>
                            <td><?php echo $leavess->startdate; ?></td>
                            <td><?php echo $leavess->enddate; ?></td>
                            <td><?php echo $leavess->duration; ?></td>
                            <td><?php echo $leavess->cause; ?></td>
                            <td><?php if($leavess->status == 0){
                                      echo '<span class="label label-warning">Pending</span>';
                                     }else{
                                         if($leavess->status == 1){
                                      echo '<span class="label label-success">Accepted</span>';
                                     }else{
                                         echo '<span class="label label-important" style="background-color: #ff0000;">Rejected</span>';
                                     }
                                         
                                     } ?></td>
                            <td>
                                <p>
                                    <a  href="/<?php echo 'adminLeaveViewByUser/' . $leavess->id ?>" oncloseFunction="reloadDiv('/adminLeaveView','mainContent');" rel="popUpBox">
                                        <span class="glyphicon glyphicon-eye-open"></span>
                                    </a>
                                    <a  href="/<?php echo 'leaveApporve/1/' .$leavess->id.'/'. $leavess->uid ?>" oncloseFunction="reloadDiv('/adminLeaveView','mainContent');" rel="ajaxRequest">
                                        <span class="glyphicon glyphicon-ok"></span>
                                    </a>
                                      <a  href="/<?php echo 'leaveApporve/2/' .$leavess->id.'/'. $leavess->uid ?>" oncloseFunction="reloadDiv('/adminLeaveView','mainContent');" rel="ajaxRequest">
                                        <span class="glyphicon glyphicon-remove"></span>
                                    </a>
                                </p>
                            </td>
                        </tr>
                        <?php
                        $i = $i + 1;
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>      
</div>


<script type="text/javascript">
    function filter_tickets() {
        var users = $("#userId").val();
        if (users == 0) {
            var url = 'Leave-Managment';
        } else {
            var url = '/adminLeaveView/' + users;
        }
        var splited = url.split("/");
        window.location.hash = '#' + splited.join(".");
    }
    $(document).ready(function () {
        $('#example').DataTable();
    });
</script>