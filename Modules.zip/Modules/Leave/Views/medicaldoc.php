<?php
global $page;
if ($page->currentUser->userLoggedIn) {
    $userid = $page->currentUser->id;
}
?> 
<div id="modal-form" class="admin-form mfp-with-anim">
    <div class="panel">
            <div id="medicaldocResultDiv" class="resultDiv"></div>
        <div class="panel-heading"><span class="panel-title"><i class="fa fa-file"></i>Medical Document</span></div>
 
             <form method="POST" resultDiv="medicaldocResultDiv" id="medicaldoc" close_popup="1"  keepvisible="1" role="form" action="/leave_leaves/saveLeave/<?php echo $leaveid; ?>" rel="ajaxifiedForm" autocomplete="off" backToPage="/leaveview" successMsg="Document Upload Successfully!">   
          
            <div class="panel-body p25">
                <input type="hidden" name="id" value="<?php echo $leaveid; ?>">
                <div class="col-md-12">
                    <h5>Select Medical Document to upload:</h5>
                    <label for="userprofile" class="field file"><span class="button btn-success"> Choose File</span>
                        <input id="medicaldoc" type="file" name="fileToUpload" onchange="document.getElementById('uploadmedicaldoc').value = this.value;" class="gui-file required">
                        <input id="uploadmedicaldoc" type="text" placeholder="no file selected" readonly="" class="gui-input">
                    </label> 
                </div> 
            </div>
            <div class="panel-footer">
                <button type="submit" class="button btn-success pull-right">Save</button>
                <div class="clearfix"></div>
            </div>
        </form>
    </div>
</div>
