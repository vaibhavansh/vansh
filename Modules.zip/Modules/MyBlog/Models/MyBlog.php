<?php

class MyBlog_Models_MyBlog
{}

