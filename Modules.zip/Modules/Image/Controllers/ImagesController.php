<?php

class Image_Controllers_ImagesController extends Core_Controllers_SitesController {

    function save() {
        $_POST = array_merge($_POST, Image_Models_Image::readImageFile('image'));
        return parent::save();
    }

    function displayImage($imageId) {
        $image = new Image_Models_Image($imageId);
        $image->display();
        return array();
    }

    function displayImageThumb($imageId) {
        $image = new Image_Models_Image($imageId);
        $image->display('image_thumb');
        return array();
    }

    function imageGallary($objectId, $pageNumber =1 ) {
        $variables =  parent::index($pageNumber);
        $variables['objectId'] = $objectId;
        return $variables;
    }
    function createImages(){
        $images = Image_Models_Image::find_all(array('orderBy'=>"id desc",'limit'=>1000));
        foreach($images as $image){
            if(!file_exists(PUBLIC_FOLDER.DS.'/tmp/'.$image->id.'_main.jpg')){
            $image->save(array('image'=>$image->image,'image_thumb'=>$image->image_thumb));
            }
        }
        return array();
    }

}

