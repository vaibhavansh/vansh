<?php

class Image_Models_Image extends Core_Models_DbTable {

    static $table = 'images';
    static $fields = null;
    static $imageTypes = array('image/jpeg' => 'jpeg', 'image/pjpeg' => 'jpeg', 'image/png' => 'png', 'image/gif' => 'gif');

    static function readImageFile($inputFieldName) {
        $imageData['image'] = self::scaleImage($_FILES[$inputFieldName]['tmp_name']);
        $imageData['image_thumb'] = self::scaleImage($_FILES[$inputFieldName]['tmp_name']);
        $imageData['type'] = self::$imageTypes[$_FILES[$inputFieldName]['type']];
        return $imageData;
    }

    function save($data) {
        parent::save($data);
        if (!empty($data['image'])) {
            $aImage = imagecreatefromstring($data['image']);
            imagejpeg($aImage, PUBLIC_FOLDER . DS . 'images' . DS . $this->id . '_main.jpg', 70);
            // imagejpeg($aImage, '/var/www/vhosts/live.bollyduniya.com/public_html/Sites/BollyDuniya/public/images' . DS . $this->id . '_main.jpg', 70);
        }
        if (!empty($data['image_thumb'])) {
            $aImage = imagecreatefromstring($data['image_thumb']);
            imagejpeg($aImage, PUBLIC_FOLDER . DS . 'images' . DS . $this->id . '_thumb.jpg', 70);
            //imagejpeg($aImage, '/var/www/vhosts/live.bollyduniya.com/public_html/Sites/BollyDuniya/public/images' . DS . $this->id . '_thumb.jpg', 70);
        }
        return $this->id;
    }

    /**
     * Get results of query
     * This wont' strip slashes for image blob data.
     * I could check the blob field type and have it in database,
     * but not really performance friendly.
     *
     * @param    string   Return as object or array
     * @return   result   Result of query
     */
    function get($type = 'object') {

        $type = $type == 'object' ? 'mysqli_fetch_object' : 'mysqli_fetch_array';
        $imageFieldNames = array('image', 'image_thumb');
        if ($this->last_query instanceof mysqli_result) {
            while ($rows = $type($this->last_query)) {
                foreach ($rows as $key => & $row) {
                    if (!in_array($key, $imageFieldNames))
                        $row = stripslashes($row); //added so all data spitted out is good for display..
                }
                $results[] = $rows;
            }
        } else
            $this->error();
        return (!empty($results)) ? $results : null;
    }

    public function display($fieldName = 'image') {
        header("Content-Type: image/" . $this->type);
        header("Cache-Control: no-cache, must-revalidate");
//        header("Pragma: no-cache");
        $aImage = imagecreatefromstring($this->$fieldName);
        $image = 'image' . $this->type;
        switch ($this->type) {
            case 'jpeg':
            case 'jpg':
                imagejpeg($aImage, null, 70);

                break;
            default:
                $image = $image($aImage);
                break;
        }
    }

    public static function scaleImage($file, $maxWidth = 1280, $maxHeight = 720) {

        list($orgImgWidth, $orgImgHeight, $imageType) = getimagesize($file);

        //Check for scaling ratios
        $xRatio = $maxWidth / $orgImgWidth;
        $yRatio = $maxHeight / $orgImgHeight;

        //The image is smaller than the max width and height.
        if (($orgImgWidth <= $maxWidth) && ($orgImgHeight <= $maxHeight)) {
            $newImgWidth = $orgImgWidth;
            $newImgHeight = $orgImgHeight;
        } elseif (($xRatio * $orgImgHeight) <= $maxHeight) {
            $newImgWidth = $maxWidth;
            $newImgHeight = ceil($xRatio * $orgImgHeight);
        } else {
            $newImgHeight = $maxHeight;
            $newImgWidth = ceil($yRatio * $orgImgWidth);
        }

        $offest_x = ($maxWidth - $newImgWidth) / 2;
        $offest_y = ($maxHeight - $newImgHeight) / 2;
        //Create the temporary image
        $tmpImage = imagecreatetruecolor($maxWidth, $maxHeight);

        //If this is a GIF or PNG preserve it's transparency
        if (($imageType == 1) || ($imageType == 3)) {
            imagealphablending($tmpImage, false);
            imagesavealpha($tmpImage, true);
            $trans = imagecolorallocatealpha($tmpImage, 255, 255, 255, 255);
            imagefilledrectangle($tmpImage, 0, 0, $newImgWidth, $newImgHeight, $trans);
        }

        //Sample source and apply to new thumb
        switch ($imageType) {
            case 1: $src = imagecreatefromgif($file);
                break;
            case 2: $src = imagecreatefromjpeg($file);
                break;
            case 3: $src = imagecreatefrompng($file);
                break;
            default: return '';
                break;
        }

        imagecopyresampled($tmpImage, $src, $offest_x, $offest_y, 0, 0, $newImgWidth, $newImgHeight, $orgImgWidth, $orgImgHeight);

        // The create image function doesn't give you the chance to alter the data stream so I'll use the buffer.
        ob_start();

        switch ($imageType) {
            case 1: imagegif($tmpImage);
                break;
            case 2: imagejpeg($tmpImage, null, 70);
                break;
            case 3: imagepng($tmpImage, NULL, 0);
                break;
            default: echo '';
                break;
        }

        $scaledImage = ob_get_contents();

        ob_end_clean();

        return $scaledImage;
    }

    public static function generateThumb($file, $thumbWidth = 150, $thumbHeight = 150) {
        //Background color is RGB.
        $red = 255;
        $green = 255;
        $blue = 255;

        list($orgImgWidth, $orgImgHeight, $imageType) = getimagesize($file);

        //Check for scaling ratios
        $xRatio = $thumbWidth / $orgImgWidth;
        $yRatio = $thumbHeight / $orgImgHeight;

        //The image is smaller than the thumb to be generated.
        if (($orgImgWidth < $thumbWidth) && ($orgImgHeight < $thumbHeight)) {
            $newImgWidth = $orgImgWidth;
            $newImgHeight = $orgImgHeight;
            $x = round(($thumbWidth - $newImgWidth) / 2);
            $y = round(($thumbHeight - $newImgHeight) / 2);
        } elseif (($xRatio * $orgImgHeight) <= $thumbHeight) {
            $newImgWidth = $thumbWidth;
            $newImgHeight = ceil($xRatio * $orgImgHeight);
            $x = 0;
            $y = round(($thumbHeight - $newImgHeight) / 2);
        } else {
            $newImgWidth = ceil($yRatio * $orgImgWidth);
            $newImgHeight = $thumbHeight;
            $x = round(($thumbWidth - $newImgWidth) / 2);
            $y = 0;
        }

        //Create the temporary image
        $tmpImage = imagecreatetruecolor($thumbWidth, $thumbHeight);

        //Fill the background
        $bgColor = imagecolorallocate($tmpImage, $red, $green, $blue);
        imagefill($tmpImage, 0, 0, $bgColor);

        //Sample source and apply to new thumb
        switch ($imageType) {
            case 1: $src = imagecreatefromgif($file);
                break;
            case 2: $src = imagecreatefromjpeg($file);
                break;
            case 3: $src = imagecreatefrompng($file);
                break;
            default: return '';
                break;
        }

        imagecopyresampled($tmpImage, $src, $x, $y, 0, 0, $newImgWidth, $newImgHeight, $orgImgWidth, $orgImgHeight);

        // The create image function doesn't give you the chance to alter the data stream so I'll use the buffer.
        ob_start();

        switch ($imageType) {
            case 1: imagegif($tmpImage);
                break;
            case 2: imagejpeg($tmpImage, NULL, 65);
                break;
            case 3: imagepng($tmpImage, NULL, 5);
                break;
            default: echo '';
                break;
        }

        $thumb = ob_get_contents();

        ob_end_clean();

        return $thumb;
    }

    function printImageThumb() {
        ?>
        <a id="displayImageThumb<?php echo $this->id ?>" href="#displayImage<?php echo $this->id ?>"
           onclick="$('#displayImage<?php echo $this->id ?>').html('<img src=\'/DEV2 images/<?php echo $this->id ?>_thumb.jpg\' />');" rel="popUpBox">
            <img src='/images/<?php echo $this->id ?>_thumb.jpg' />
        </a>
        <div id="displayImage<?php echo $this->id ?>" style="display:none;"></div>
        <?php
    }

    function imageURL() {
        return "/images/" . $this->id . "_main.jpg";
    }

    function imageThumbURL() {
        return "/images/" . $this->id . "_thumb.jpg";
    }

    function getImageDirectory() {
        
    }

}
