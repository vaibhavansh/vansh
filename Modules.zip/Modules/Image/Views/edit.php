<div id="editObject<?php echo $object->id ?>ResultDiv"></div>
<form name ="editObject<?php echo $object->id ?>" id="editObject<?php echo $object->id ?>" method="post"
      keepVisible="1" keepResult="1" action="/<?php echo $object->coreURL ?>/save" rel="ajaxifiedForm">
    <div class="grid_16">
        <h2><?php echo $header ?></h2>
        <div class="grid_4">
            <?php $object->printImageThumb();?>
        </div>
        <div class="spacer"></div>
        <div class="grid_4"><label for='title'>Title</label></div>
        <div class="grid_6">
            <input type="textbox" name="title" id="title" value="<?php echo $object->title ?>" />
        </div>
        <div class="spacer"></div>
        <div class="grid_4"><label for='image'>Image</label></div>
        <div class="grid_6">
            <input type="file" name="image" id="image" class="required"  />
        </div>
        <div class="spacer"></div>

        <input type="hidden" name="id" value="<?php echo $object->id ?>"/>
        <input type="submit" value ="submit" rel="submitButton" />
    </div>
</form>