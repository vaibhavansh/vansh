<h3>Upload Image</h3>
<a href="#">Upload New</a> || <a href="#">Media Library</a>



<div id="selectedImageDiv">
    
    <a href="#">Insert into Body</a>
</div>