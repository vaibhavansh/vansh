<div id="imageGallerySearchResultDiv">
    <div class="grid_16 omega">
        <a href="/image_images/index/"><h2><?php echo $header ?></h2></a>
    </div>
    <div class="grid_8 alpha">
        <h4><a href="/<?php echo $objects->coreURL ?>/edit/0" oncloseFunction="reloadDiv('/<?php echo $objects->coreURL; ?>/index','mainContent');" rel="popUpBox">Create New </a></h4>
    </div>
    <div class="spacer"></div>
    <form name ="imageGallerySearch" id="imageGallerySearch" method="post"
          keepVisible="1" keepResult="1" action="/image_images/index/" rel="ajaxifiedForm" class="form-inline">
        <input type="text" name="searchTitle"  />
        <input type="button" onclick="$('#imageGallerySearch').submit()" value="Search" />
    </form>
    <div class="grid_24">
        <?php echo $objects->pagination(array('url' => "/{$objects->coreURL}/index/", 'ajaxRequest' => '1')); ?>
    </div>
    <div class='grid_24 omega alpha'><?php
        if (!empty($objects->data))
            foreach ($objects->data as $object) {
                ?>
                <div class="grid_3 omega alpha" style="height:200px;overflow: hidden">
                    <?php
                    $object->printImageThumb();
                    ?>
                    <br />
                    <a href="/image_images/edit/<?php echo $object->id; ?>" oncloseFunction="reloadDiv('/<?php echo $objects->coreURL; ?>/index','mainContent');" rel="popUpBox" onclose="">Edit</a>
                </div>
                <?php
            }
        ?>
    </div>
    <div class="spacer10"></div>
</div>