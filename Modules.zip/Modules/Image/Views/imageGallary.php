<div id="imageGallerySearchResultDiv">
    <div class="grid_11 omega">
        <h2><?php echo $header ?></h2>
    </div>
    <form name ="imageGallerySearch" id="imageGallerySearch" method="post"
          keepVisible="1" keepResult="1" action="/image_images/imageGallary/<?php echo $objectId ?>" rel="ajaxifiedForm" class="form-inline">
        <input type="text" name="searchTitle"  />
        <input type="button" onclick="$('#imageGallerySearch').submit()" value="Search" />
    </form>
    <div class="grid_16">
        <?php echo $objects->pageLinks(array('url' => "/{$objects->coreURL}/imageGallary/{$objectId}", 'ajaxRequest' => 'popUpBox')); ?>
    </div>
    <div class='grid_15 omega alpha' id="imageGallary" style="height:300px;overflow: scroll"><?php
        if (!empty($objects->data))
            foreach ($objects->data as $object) {
                ?>
                <a id="image_gallary_<?php echo $object->id ?>" href="javascript:selectImage(<?php echo $object->id ?>);"><img src="/image_images/displayimagethumb/<?php echo $object->id ?>"/></a>
                <?php
            }
        ?>
    </div>
    <div class="spacer10"></div>
    <input type="hidden" id="selectedImage" value="" />
    <input type="button" value="Select this" onclick="saveSelectedImage()"/>

    <script>
        function selectImage(id){
            $('#imageGallary img').css('border','');
            $('#image_gallary_'+id+' img').css('border','solid 3px');
            $('#selectedImage').val(id);
        }

        function saveSelectedImage(){
            $('#image_<?php echo $objectId ?>').val($('#selectedImage').val());
            $('#image_preview_<?php echo $objectId ?>').html("<img src='/image_images/displayimagethumb/"+$('#selectedImage').val()+"' />");
            $('.close').trigger('click');
        }
    </script>
</div>