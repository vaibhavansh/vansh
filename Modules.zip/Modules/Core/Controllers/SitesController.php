<?php
require_once SITES_MODULE_DIRECTORY.'/../public/dropboxapi/start.php';
class Core_Controllers_SitesController {

    var $layoutId = 2; # Layout 2 is one Column Layout

    /**
     * Default Header Div
     */

    function testCode() {
        
    }

    function header() {
        
    }

    /**
     * Default Footer Div
     */
    function footer() {
        
    }

    /**
     * Default home div
     * @return type
     */
    function loginform() {
        $this->layoutId = 37;
        return array();
    }

    /**
     * List all of the items for given class
     * @param type $pageNumber
     * @return type
     */
    function index($pageNumber = 1) {
        list($plugin, $model, $controller, $title, $coreURL) = Core_Models_Utility::parseClassName(get_called_class());
        $variables['header'] = "List all {$title}s";
        $data['pageNumber'] = $pageNumber;
        if (isset($_POST['searchTitle'])) {
            $data['where'] = " title like '%{$_POST['searchTitle']}%' ";
            $data['recordsPerPage'] = 200;
        }
        $data['recordsPerPage'] = 50;
        $data['orderBy'] = 'id desc';
        $variables['objects'] = $model::getPaginatedData($data);
        $variables['objects']->coreURL = $coreURL;

        return $variables;
    }

    /**
     * Edit the given item for given class
     * @param type $id
     * @return type
     */
    function edit($id = 0) {
        list($plugin, $model, $controller, $title, $coreURL) = Core_Models_Utility::parseClassName(get_called_class());
        $variables['object'] = new $model($id);
        $variables['header'] = !empty($variables['object']->id) ? 'Edit ' . $variables['object']->title : "Create New {$title}";
        if (!$id) {
            $variables['object']->save(array());
        }
        $variables['object']->coreURL = $coreURL;

        $webuseRole = array_shift(User_Models_User::find_all(array('cols' => 'user_roles.title,user_roles.level,users.email', 'join' => ' user_roles on users.webUserRole=user_roles.level', 'where' => ' users.id=' . $id)));
        $variables['webuserlevel'] = $webuseRole;
        return $variables;
    }


    /**
     * Default Save the item
     * @return type
     */
    function save() {
        list($plugin, $model, $controller, $title, $coreURL) = Core_Models_Utility::parseClassName(get_called_class());
        $variables['object'] = new $model($_POST['id']);
        if ($variables['object']->save($_POST)) {
            echo Core_Models_Utility::flashMessage("{$title} Saved Successfully", 'valid');
        } else {
            echo Core_Models_Utility::flashMessage("{$title} Can not be saved.", 'error');
        }
        return $variables;
    }

    function delete($id = 0) {
        list($plugin, $model, $controller, $title, $coreURL) = Core_Models_Utility::parseClassName(get_called_class());
        $variables['object'] = new $model($id);
        if ($variables['object']->delete()) {
            echo Core_Models_Utility::flashMessage("{$title} Deleted Successfully", 'valid');
        } else {
            echo Core_Models_Utility::flashMessage("{$title} Can not be deleted.", 'error');
        }
        return array();
    }

    function createModuleForm() {

        $moduleDirectories = array('Modules' => 'Core');
        foreach (glob(ROOT . DS . 'Sites' . DS . "*", GLOB_ONLYDIR) as $site) {
            $site = basename($site);
            $moduleDirectories['Sites' . DS . $site . DS . 'Modules'] = $site;
        }
        $variables['moduleLocationSelector'] = new OptionBox(array('optionBoxData' => $moduleDirectories, 'id' => "moduleLocation", 'name' => 'moduleLocation', 'className' => 'required form-control'));

        $moduleModels = array_merge(glob(ROOT . DS . 'Sites' . DS . "*/Modules/*", GLOB_ONLYDIR), (glob(ROOT . DS . 'Modules' . DS . "*")));
        foreach ($moduleModels as $moduleModel) {
            $modules[] = basename($moduleModel);
        }
        $variables['moduleSelector'] = new OptionBox(array('optionBoxData' => $modules, 'id' => "modelLocation", 'className' => 'grid_6 alpha', 'name' => 'modelLocation'));

        return $variables;
    }

    function createModuleAction() {
        $moduleName = ucfirst($_POST['moduleName']);
        $directories = array(
            'Modules' => ROOT . DS . $_POST['moduleLocation'] . DS . $moduleName,
            'Controllers' => ROOT . DS . $_POST['moduleLocation'] . DS . $moduleName . DS . 'Controllers',
            'Models' => ROOT . DS . $_POST['moduleLocation'] . DS . $moduleName . DS . 'Models',
            'Views' => ROOT . DS . $_POST['moduleLocation'] . DS . $moduleName . DS . 'Views'
        );
        $resultOk = '';
        $resultError = '';
        $table = strtolower(preg_replace('/([a-z])([A-Z])/', '$1_$2', $moduleName)) . 's';
        foreach ($directories as $key => $value) {
            if (!is_dir($value)) {
                $resultOk .= mkdir($value) ? $key . ' Directory Created<br />' : "Error creating {$key} directory<br />";
            } else {
                $resultError .= "$key Directory already exists.<br />";
            }
        }

        if (!file_exists($directories['Controllers'] . DS . $moduleName . 'sController.php')) {
            if (Core_Models_Site::createController(ROOT . DS . $_POST['moduleLocation'] . DS . $moduleName, $moduleName . 'sController')) {
                $resultOk .= $moduleName . '_Controllers_' . $moduleName . 'sController Class created<br />';
            } else {
                $resultError .= $moduleName . 'sController.php already exits.<br />';
            }
        }
        if (!file_exists($directories['Models'] . DS . $moduleName . '.php')) {
            if (Core_Models_Site::createModel(ROOT . DS . $_POST['moduleLocation'] . DS . $moduleName, $moduleName)) {
                $resultOk .= $moduleName . '_Models_' . $moduleName . ' Class created<br />';
            } else {
                $resultError .= 'Error creating ' . $moduleName . '.php' . '.<br />';
            }
        } else {
            $resultError .= $moduleName . '.php' . ' already exits.<br />';
        }
        if (Core_Models_Site::createTable($table)) {
            $resultOk .= "Created table {$table}";
        } else {
            $resultError .= $table . ' table already exits.<br />';
        }
	Core_Models_Utility::createFile($directories['Modules'].DS.'README.txt',$_POST['moduleDescription']);
        if (!empty($resultError)) {
            echo Core_Models_Utility::flashMessage($resultError, 'error');
        }
        if (!empty($resultOk)) {
            echo Core_Models_Utility::flashMessage($resultOk);
        }
        return array();
    }

    function createClassForm() {
        $variables = self::edit(1);
        $variables['classSelector'] = new OptionBox(array('optionBoxData' => array('controller' => 'Controller', 'model' => 'Model'), 'id' => "classSelector", 'name' => 'classSelector', 'className' => 'form-control required col-sm-12'));
        $variables['moduleSelector'] = new OptionBox(array('optionBoxData' => Core_Models_Site::getModules(), 'id' => "moduleLocation", 'name' => 'moduleLocation', 'className' => 'form-control required  col-sm-12'));
        $variables['modelSelector'] = new OptionBox(array('optionBoxData' => Core_Models_Site::getModels(), 'id' => "modelSelector", 'name' => 'modelSelector', 'className' => 'form-control  col-sm-12 required'));
        return $variables;
    }

    function editModelFields($modelClassName = '') {
        if (!empty($modelClassName)) {
            $model = new $modelClassName;
            foreach ($model->fields as $field) {
                
            }
        }
    }

    function createClassAction() {
        $resultOk = '';
        $resultError = '';
        $className = ucfirst($_POST['modelName']);
        $moduleName = basename($_POST['moduleLocation']);
        switch ($_POST['classSelector']) {
            case 'model':

                if (!file_exists(ROOT . DS . $_POST['moduleLocation'] . DS . 'Models' . DS . $className . '.php')) {
                    if (Core_Models_Site::createModel(ROOT . DS . $_POST['moduleLocation'], $className)) {
                        $resultOk .= $moduleName . '_Models_' . $className . ' Class created<br />';
                    } else {
                        $resultError .= 'Error creating ' . $className . '.php' . '.<br />';
                    }
                } else {
                    $resultError .= $className . '.php' . ' already exits.<br />';
                }

                $table = strtolower(preg_replace('/([a-z])([A-Z])/', '$1_$2', $className)) . 's';
                $fields = array('id' => ("id int(11) NOT NULL AUTO_INCREMENT"));
                foreach ($_POST['fieldTypeSelector'] as $key => $fieldType) {
//                array('id'=>array('id','Id of Object','int(11)')
                    switch ($fieldType) {
                        case 'varchar':
                            $fields[] = ("{$_POST['fieldName'][$key]} varchar(500) default NULL");
                            break;
                        case 'text':
                            $fields[] = ("{$_POST['fieldName'][$key]} text");
                            break;
                        case 'foreignKey':
                            $columnName = rtrim($_POST['modelSelector'][$key]::$table, 's') . '_id';
                            $fields[] = ("{$columnName} int(11)");
                            break;
                    }
                }
                if (Core_Models_Site::createTable($table, $fields)) {
                    $resultOk .= "Created table {$table}";
                } else {
                    $resultError .= $table . ' table already exits.<br />';
                }
                break;
            case 'controller':
                if (!file_exists(ROOT . DS . $_POST['moduleLocation'] . DS . 'Controllers' . DS . $className . 'sController.php')) {
                    if (Core_Models_Site::createController(ROOT . DS . $_POST['moduleLocation'], $className . 'sController')) {
                        $resultOk .= $moduleName . '_Models_' . $className . 'sController Class created<br />';
                    } else {
                        $resultError .= 'Error creating ' . $className . 'sController.php' . '.<br />';
                    }
                } else {
                    $resultError .= $className . 'sController.php' . ' already exits.<br />';
                }
                break;
        }
        if (!empty($resultError)) {
            echo Core_Models_Utility::flashMessage($resultError, 'error');
        }
        if (!empty($resultOk)) {
            echo Core_Models_Utility::flashMessage($resultOk);
        }
        return array();
    }

    function createSiteForm() {

        return array();
    }

    function createSiteAction() {
        $variables = array();
        $resultOk = '';
        $resultError = '';
        $siteName = ucfirst($_POST['siteName']);
        if (!is_dir(SITES_DIRECTORY . DS . $siteName)) {
            $resultOk .= mkdir(SITES_DIRECTORY . DS . $siteName) ? $siteName . ' Directory Created<br />' : "Error creating {$siteName} directory<br />";
        } else {
            $resultError .= "$siteName Directory already exists.<br />";
        }
        $directories = array(
            'Config' => SITES_DIRECTORY . DS . $siteName . DS . 'Config',
            'Modules' => SITES_DIRECTORY . DS . $siteName . DS . 'Modules',
            'Public' => SITES_DIRECTORY . DS . $siteName . DS . 'public',
            'CSS' => SITES_DIRECTORY . DS . $siteName . DS . 'public' . DS . 'css',
            'JS' => SITES_DIRECTORY . DS . $siteName . DS . 'public' . DS . 'js',
            'Img Directory' => SITES_DIRECTORY . DS . $siteName . DS . 'public' . DS . 'img',
            'Images' => SITES_DIRECTORY . DS . $siteName . DS . 'public' . DS . 'images',
            'tmp' => SITES_DIRECTORY . DS . $siteName . DS . 'public' . DS . 'tmp',
            'zendcache' => SITES_DIRECTORY . DS . $siteName . DS . 'public' . DS . 'tmp'  . DS . 'zendcache',
        );

        foreach ($directories as $key => $value) {
            if (!is_dir($value)) {
                $resultOk .= mkdir($value) ? $key . ' Directory Created<br />' : "Error creating {$key} directory<br />";
            } else {
                $resultError .= "$key Directory already exists.<br />";
            }
        }
        //Create Files//
        if (!file_exists($directories['Config'] . DS . 'config.php')) {
            if (Core_Models_Site::createConfig($siteName, $_POST['db_host'], $_POST['db_user'], $_POST['db_pass'], $_POST['siteDomain'])) {
                $resultOk .= 'Config File Created<br />';
            } else {
                $resultError .= 'Error creating Config file.<br />';
            }
        } else {
            $resultError .= 'Config File already exits.<br />';
        }
        if (!file_exists($directories['Config'] . DS . 'Route.php')) {
            if (Core_Models_Site::createRoute($siteName)) {
                $resultOk .= 'Route File Created<br />';
            } else {
                $resultError .= 'Error creating Route file.<br />';
            }
        } else {
            $resultError .= 'Route File already exits.<br />';
        }
        //CREATE JAVASCRIPT/CSS/.HTACCESS FILES//
        fopen(SITES_DIRECTORY . DS . $siteName . DS . 'public' . DS . 'js' . DS . 'general_utils_site.js', 'w');
        fopen(SITES_DIRECTORY . DS . $siteName . DS . 'public' . DS . 'css' . DS . 'global_site.css', 'w');
       $htaccessFile = fopen(SITES_DIRECTORY . DS . $siteName . DS . 'public' . DS . '.htaccess', 'w');
	$htaccessCode = "<IfModule mod_rewrite.c>
RewriteEngine On
RewriteBase /
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d

RewriteRule ^(.*)$ index.php?url=$1 [PT,L]

</IfModule>";
	fwrite($htaccessFile, $htaccessCode);

        //CREATE INDEX FILE//
        $indexFile = fopen(SITES_DIRECTORY . DS . $siteName . DS . 'public' . DS . 'index.php', 'w');
        $code = '<?php
define(\'DS\', DIRECTORY_SEPARATOR);
define(\'ROOT\', dirname(dirname(dirname(dirname(__FILE__)))));
define(\'PUBLIC_FOLDER\', dirname(__FILE__));

$url = isset($_GET[\'url\']) ? rtrim($_GET[\'url\'], \'/\') : \'\';

#include config file first#
require_once (ROOT . DS . \'Sites\'.DS.\'' . $siteName . '\'.DS. \'Config\' . DS . \'config.php\');
require_once (ROOT . DS . \'Modules\' . DS .\'Core\'.DS.\'Models\'.DS. \'Page.php\');
require_once (ROOT . DS . \'Sites\'.DS.SITE_NAME.DS. \'Config\' . DS . \'Route.php\');

global $page;
$page = new Core_Models_Page($url);
$page->generate();
';
        
        $htAccessCode = '<IfModule mod_rewrite.c>
                  RewriteEngine On
                  RewriteBase /
                  RewriteCond %{REQUEST_FILENAME} !-f
                  RewriteCond %{REQUEST_FILENAME} !-d
                  RewriteRule ^(.*)$ index.php?url=$1 [PT,L]
                  </IfModule>';
        
        fwrite($indexFile, $code);

        if (!empty($resultError)) {
            echo Core_Models_Utility::flashMessage($resultError, 'error');
        }
        if (!empty($resultOk)) {
            echo Core_Models_Utility::flashMessage($resultOk);
        }
        return $variables;
    }

    function createWidgetForm() {
        $directory = ROOT . DS . 'Modules/';
        $files = glob($directory . "*", GLOB_ONLYDIR);
        foreach ($files as $file) {
            echo $file . '<br />';
        }
    }

    function duplicate($id) {
        list($plugin, $model, $controller, $title, $coreURL) = Core_Models_Utility::parseClassName(get_called_class());
        $originalObject = new $model($id);
        $duplicateObject = new $model;
        foreach ($model::fields() as $field) { #Copy all the fields from original to duplicate
            $data[$field->Field] = $originalObject->{$field->Field};
        }
        $data['id'] = 0; #Create a new one

        if (isset($data['title'])) {
            $data['title'] = 'Copy of ' . $data['title'];
        }
        if ($duplicateObject->save($data)) {
            echo Core_Models_Utility::flashMessage("duplicated successfully", 'valid');
        } else {
            echo Core_Models_Utility::flashMessage("Can not be saved.", 'error');
        }
        return array();
    }

    /**
     * Log any request to google and click.
     * post url and title. BOTH
     * @return type
     */
    public function logToGoogle() {
        if (Config::getConfig('ENVIRONMENT') != 'DEVELOPMENT') {
            Core_Models_Utility::googleTrackingCode($_POST['url'], $_POST['title']);
        }
        return array();
    }

    /**
     * Get the methods in particular controller.
     * called from layout edit form
     *
     */
    function getMethods() {
        $controller = $_POST['controller'];
        $c = new $controller;
        $methods = get_class_methods($c);
        echo json_encode($methods);
        return array();
    }

    /**
     * List all of the sites on this framework.
     */
    function manageSites() {
        $variables['sites'] = glob(ROOT . DS . 'Sites' . DS . "*", GLOB_ONLYDIR);
        return $variables;
    }

    function userContent() {
        //echo 'Devesh Kale';
        global $page;

        $variables['uploaded'] = Asset_Models_Asset::find_all(array('where' => "uploaded_by = {$page->currentUser->id}"));
        //echo "<pre>";print_r($abc);die;
        return $variables;
    }

    function moviepage() {
        
    }
}
