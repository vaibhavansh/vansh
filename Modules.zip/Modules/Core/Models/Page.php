<?php

/**
 * Description of Page
 *
 * @author admin
 */
class Core_Models_Page {

    var $controller;
    var $model;
    var $action;
    #parameters pased from url.
    var $queryString = array();
    # set the view for the main Content div. page view. by default, it's the name of action
    var $view;
    #set the type of request. ajax  | image | page
    var $pageRequestType;
    #Set if you want to render the layout or not
    var $renderLayout = true;
    #set the current user for page
    var $currentUser;
    #page layout
    var $layout;
    var $html;
    var $url;
    var $pageTitle = '';
    var $metaKeywords = '';
    var $metaDescription = '';

    #cache options for zend ends#

    public function __construct($url) {
        $this->todayDate = date('Y-m-d');
        ini_set('display_errors', 'Off');
        ini_set('log_errors', 'true');
        ini_set('error_log', PUBLIC_FOLDER . DS . 'tmp' . DS . 'errorlogfile.log');
        #Set Compression#
        ini_set("zlib.output_compression", "On");
        ini_set("zlib.output_compression_level", "-1");
        if (Config::getConfig('ENVIRONMENT') == 'DEVELOPMENT') {
            ini_set('display_errors', 'On');
        }

        $this->url = $url;
        set_include_path(get_include_path() . PATH_SEPARATOR . FRAMEWORKS_DIRECTORY);
        #Prepare Page owner#
        $this->currentUser = new User_Models_User();
        if (!($this->currentUser->isLoggedIn())) {
            $this->currentUser->title = 'Guest';
            $this->currentUser->userLoggedIn = false;
            $this->currentUser->webUserRole = 4; #4 is for guest with level 0
        }
        $this->setMVC($url);
        $this->setMainContent();
        #set cache variable
        global $cache;
        $cache = Zend_Cache::factory('Core', 'File', array('lifetime' => 1000000, 'automatic_serialization' => true), array('cache_dir' => CACHE_DIR)
        );
        #set cache url for this page#
        $this->cacheUrl = empty($this->url) ? 'home' : str_replace(array('/', ' ', '-'), '', $this->url);
        self::autoLoadClass('Core_Models_Utility');
    }

    /**
     * Set the values of controller,model for main content of the layout.
     */
    function setMainContent() {
        $this->mainContent = new stdClass;
        $this->mainContent->layoutItemId = 'mainContent';
        $this->mainContent->layoutItemView = $this->mainContent->layoutItemAction = $this->action;
        $this->mainContent->layoutItemController = new $this->controller;
        $this->mainContent->layoutItemQueryString = $this->queryString;
        $this->mainContent->model = $this->model;
        $this->mainContent->layoutItemController->layoutId = '43';
    }

    /**
     * This method will call the main content method
     */
    function generate() {
        if ((int) method_exists($this->controller, $this->action)) {
            if (!($this->currentUser->allowed($this))) {
                $this->mainContent = new stdClass;
                $this->mainContent->layoutItemId = 'mainContent';
                $this->mainContent->layoutItemView = $this->mainContent->layoutItemAction = 'hrsite';
                $this->mainContent->layoutItemController = new User_Controllers_UsersController;
                $this->mainContent->layoutItemQueryString = $this->queryString;
                $this->mainContent->model = 'User_Models_User';
                $this->mainContent->variables['message'] = 'Access Declined';
            }
            switch ($this->pageRequestType()) {
                case 'ajax':

                    $this->mainContent->variables = array_merge(isset($this->mainContent->variables) ? $this->mainContent->variables : array(), call_user_func_array(array($this->mainContent->layoutItemController, $this->mainContent->layoutItemAction), ($this->mainContent->layoutItemQueryString)));
                    if (!empty($this->logToGoogle) && Config::getConfig('ENVIRONMENT') != 'DEVELOPMENT') {
                        Core_Models_Utility::googleTrackingCode();
                    }
                    Layout_Models_Layout::showDivContent($this->mainContent);
                    break;
                case 'image':

                    $this->mainContent->variables = array_merge(isset($this->mainContent->variables) ? $this->mainContent->variables : array(), call_user_func_array(array($this->mainContent->layoutItemController, $this->mainContent->layoutItemAction), ($this->mainContent->layoutItemQueryString)));
                    Layout_Models_Layout::showDivContent($this->mainContent);

                    break;
                case 'jsondata':
                    $this->mainContent->variables = array_merge(isset($this->mainContent->variables) ? $this->mainContent->variables : array(), call_user_func_array(array($this->mainContent->layoutItemController, $this->mainContent->layoutItemAction), ($this->mainContent->layoutItemQueryString)));
                    echo json_encode($this->mainContent->variables);
                    break;
                default:
                    $this->mainContent->variables = array_merge(isset($this->mainContent->variables) ? $this->mainContent->variables : array(), call_user_func_array(array($this->mainContent->layoutItemController, $this->mainContent->layoutItemAction), ($this->mainContent->layoutItemQueryString)));
                    $this->render();
                    break;
            }
        }
    }

    /**
     * LOAD CLASSES AUTOMATICALLY
     * @param type $className
     * @return type
     */
    public static function autoLoadClass($className) {
        $fileName = str_replace('_', DS, $className) . '.php';
        $folders = array(
            SITES_MODULE_DIRECTORY,
            CORE_MODULE_DIRECTORY,
            FRAMEWORKS_DIRECTORY . DS . 'Utilities',
            FRAMEWORKS_DIRECTORY . DS . 'cakephp' . DS . 'lib' . DS . 'Cake' . DS . 'Core',
            FRAMEWORKS_DIRECTORY . DS . 'cakephp' . DS . 'lib' . DS . 'Cake' . DS . 'Controller',
            FRAMEWORKS_DIRECTORY . DS . 'cakephp' . DS . 'app' . DS . 'Controller'
        );
        foreach ($folders as $folder) {
            if (file_exists($folder . DS . $fileName)) {
                require_once $folder . DS . $fileName;
                return true;
            }
        }
        $modulesDir = array(FRAMEWORKS_DIRECTORY);
        if (in_array('ZEND', Config::getConfig('Frameworks')) && substr($className, 0, 4) == 'Zend') {
            if (self::loadFile(str_replace('_', DS, $className) . '.php', $modulesDir)) {
                return true;
            }
        }
        if (in_array('CAKE', Config::getConfig('Frameworks'))) {
            App::load($className); #LOAD CAKE PHP CLASSES
        }
        if ($className[0] == '\\') {
            $className = substr($className, 1);
        }

        // Leave if class should not be handled by this autoloader
        if (strpos($className, 'UnitedPrototype\\GoogleAnalytics') !== 0)
            return;
        echo $className;
        $classPath = strtr(substr($className, strlen('UnitedPrototype')), '\\', '/') . '.php';

        require(FRAMEWORKS_DIRECTORY . $classPath);
    }

    /**
     * Loads a PHP File.
     * pass the filename AND directories.
     * USAGE:
     * Site::loadFile(utility.php,array(RODMAN_SERVER.DS.'library'.DS));
     * Site::loadFile(utility.php,explode(PATH_SEPERATOR,get_include_path));
     * @param <type> $filename
     * @param <type> $dirs
     * @return <type>
     */
    public static function loadFile($filename, $dirs) {
        foreach ($dirs as $dir) {
            if (file_exists($dir . DS . $filename)) {
                require_once $dir . DS . $filename;
                return true;
            }
        }
        return false;
    }

    /**
     * Parse the browser url to get controller/action/queryString.
     * @param <string> $url
     * @param <array> $options
     * @return <array>
     */
    function setMVC($url) {
        if (Core_Models_Page::validateURL($url)) {
            $urlArray = routeURL(explode('/', $url));
            if (!empty($urlArray[0])) {
                list($plugin, $model) = explode('_', array_shift($urlArray));
                $plugin = ucfirst($plugin);
                $model = ucfirst(rtrim($model, 's'));
                $this->model = $plugin . '_Models_' . $model;
                $this->controller = $plugin . '_Controllers_' . $model . 'sController';
                $this->view = $this->action = !empty($urlArray[0]) ? array_shift($urlArray) : 'home';
                $this->queryString = isset($urlArray[0]) ? ($urlArray) : array();
            } else {
                $this->controller = Config::getConfig('DefaultController');
                $this->model = Config::getConfig('DefaultModel');
                $this->view = $this->action = Config::getConfig('DefaultAction');
                $this->queryString = Config::getConfig('DefaultQueryString');
            }
            $this->setViewFolder();
        }
    }

    function setViewFolder() {
        $detect = new Core_Models_MobileDetect;
        $this->currentBrowser = $detect;
        $this->viewFolder = 'views';
        $this->mobileVersion = false;

        if ($detect->isMobile() && !($detect->isTablet())) {
            $this->viewFolder = 'mobileViews';
            $this->mobileVersion = true;
        }
    }

    function validateURL($url) {
        return true;
        $url = strtolower(str_replace(array('/', '_', '-'), '', $url));
        if (Core_Models_Utility::webSafeString($url) == $url) {
            return true;
        } else {
            return false;
        }
    }

    function canonicalURL() {
        $this->canonicalURL = isset($this->canonicalURL) ? $this->canonicalURL : $this->url;
        return str_replace('//', '/', '/' . $this->canonicalURL);
    }

    function render() {
        echo $this->docType();

        echo '<head>';
        if ($this->layout()->renderType != 'email') {
            $pageTitle = (!empty($this->pageTitle)) ? $this->pageTitle : ucfirst(str_replace('_', ' ', $this->mainContent->layoutItemView));
            echo "<title>{$pageTitle}</title>";
            echo "<meta name='description' content='{$this->metaDescription}' />";
            echo "<meta name='keywords' content='{$this->metaKeywords}' />";
            echo '<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">';
            echo "<link rel='canonical' href='" . BASE_PATH_ROOT . '' . $this->canonicalURL() . "' />";
            echo '<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">';

            #Include CSS Files#

            echo Core_Models_Utility::includeCSS('//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css', 'url');
            echo Core_Models_Utility::includeCSS('//maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css', 'url');
            Core_Models_Utility::includeCSSFiles(array_merge(array('core', 'jquery.fancybox', 'admin-forms', 'chosen', 'jquery-ui-1.9.0.custom', 'global', 'fine-uploader.min', 'summernote', 'theme', 'monthly', 'global_site'), explode(', ', $this->layout()->css)), 'generatedCSS');

            if (!empty($this->logToGoogle) && Config::getConfig('ENVIRONMENT') != 'DEVELOPMENT') {
                Core_Models_Utility::googleTrackingCode();
            }

            echo Core_Models_Utility::includeJS('//code.jquery.com/jquery-3.1.1.min.js', 'url');
            echo Core_Models_Utility::includeJS('//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js', 'url');
            echo Core_Models_Utility::includeJS('//cdn.jquerytools.org/1.2.7/full/jquery.tools.min.js', 'url');
            echo Core_Models_Utility::includeJS('//cdnjs.cloudflare.com/ajax/libs/chosen/1.6.2/chosen.jquery.min.js', 'url');
            echo Core_Models_Utility::includeJS('//code.jquery.com/ui/1.12.1/jquery-ui.js', 'url'); //this is use for datepicker
        }
        echo '</head>';
        flush();
        echo '<body>';
        echo $this->layout()->render();
        Core_Models_Utility::includeJSFiles(array_merge(array('jquery.ui.monthpicker', 'jquery.jeditable.mini', 'jquery.form', 'jquery.validate', 'summernote.min', 'jquery.fancybox.pack', 'jquery-scrollLock.min', 'general_utils', 'utility', 'jquery.nanoscroller.min', 'demo', 'main', 'jquery.fine-uploader.min','timer.jquery','jquery.mousewheel','jquery.ui.touch-punch', 'monthly','general_utils_site'), explode(',', $this->layout()->js)), 'generatedJS');
        echo '</body>';
        echo '</html>';
    }

    function docType() {
        $str = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">";
        $str .= "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
        return $str;
    }

    /**
     * Returns the layout.
     * @return \Layout
     */
    function layout() {
        if (empty($this->layout)) {
            $this->layout = new Layout_Models_Layout($this->mainContent->layoutItemController->layoutId);
            if ($this->mobileVersion && !empty($this->layout->mobileLayoutId)) {
                $this->layout = new Layout_Models_Layout($this->layout->mobileLayoutId);
            }
        }
        $this->currentLayoutId = $this->layout->id;
        return $this->layout;
    }

    function pageRequestType() {
        $this->pageRequestType = isset($_POST['pageRequestType']) ? $_POST['pageRequestType'] : 'page';
        if (in_array($this->mainContent->layoutItemAction, array('displayimage', 'displayimagethumb'))) {
            $this->pageRequestType = 'image';
        }
        return $this->pageRequestType;
    }

}

function __autoload($className) {
    Core_Models_Page::autoLoadClass($className);
}

?>
