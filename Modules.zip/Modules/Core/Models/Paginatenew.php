<?php

class Core_Models_Paginatenew {

    public $pageNumber = 1;
    public $class_name;
    public $total_pages=50;
    public $records_per_page = 10;
    public $total_records;
    public $list_options;
    public $where;
    public $cols;
    public $div_name;
    public $orderby;

    /**
     *
     */
    function __construct($options) {
        $this->class_name = $options['class_name'];
    }

    /**
     * This is a new function created. simillar to paginate. but according to new mvc.
     *
     */
    function getPaginatedData($options) {    
        $this->pageNumber = !empty($options['pageNumber']) ? preg_replace('/page_/', '', $options['pageNumber']) : 1;
        $this->recordsPerPage = isset($options['recordsPerPage']) ? $options['recordsPerPage'] : 10;
        $where = isset($options['where']) ? $options['where'] : '';
        $join = isset($options['join']) ? $options['join'] : '';
        $groupBy = isset($options['groupBy']) ? $options['groupBy'] : '';
        $sqlTags = isset($options['sqlTags']) ? $options['sqlTags'] : array();
        $sqlId = isset($options['sqlID']) ? $options['sqlID'].'_count' : '';
        $cacheSQL = isset($options['CACHESQL']) ? $options['CACHESQL'] : false;
        $table_object = new $this->class_name;
        if (empty($this->total_records)) {
            $recordsCount = $table_object->select(array(
                'join' => $join, 'where' => $where, 'cols' => 'count(*) as total_records', 'groupBy' => $groupBy,
                'CACHESQL'=>$cacheSQL,'sqlTags'=>$sqlTags,'sqlID'=>$sqlId
                ));
            
            $recordCountnew = array_shift($recordsCount);           
              $count_rows=($recordCountnew->total_records);          
            if( $count_rows>1 )
            {
                $this->total_records = $count_rows;
            }else
            {
                $this->total_records = (isset($recordsCount[0]->total_records)) ? $recordsCount[0]->total_records:0;
            }
        }
        
        $offset = ($this->pageNumber - 1) * $this->recordsPerPage;       
        $options['limit'] = $offset . ', ' . $this->recordsPerPage;      
        $data = $table_object->select($options);
        //$this->sql = $table_object->last_sql;
        return $data;
    }
        
    /**
     * Removes the limit from end of sql and returns a sql to get all the data for this paginator.
     * @return type
     */
    function allDataSql() {
        return substr($this->sql, 0, strpos($this->sql, 'LIMIT'));
    }

    /**
     * This function is to get the paginated links. similary to paginateLInks
     */
    //FIXME: if items are less then 1 page or when it goes to last page not with enough content, it wont' show. or some bug like ths.
    function getPageLinks($options) {
        $divId = !empty($options['div_id'])?$options['div_id']:'mainContent';
        $class = (!empty($options['class'])) ? $options['class'] : '';
        $prevNextOnly = (!empty($options['prevNextOnly'])) ? $options['prevNextOnly'] : 0;
        $links = array();
        $this->recordsPerPage = (!empty($options['recordsPerPage']) && is_numeric($options['recordsPerPage'])) ? $options['recordsPerPage'] : $this->recordsPerPage;
        $this->total_pages = ceil($this->total_records / $this->recordsPerPage);
        $this->total_pages = ($this->total_pages > 1) ? $this->total_pages : 0;
        $offset = ($this->pageNumber - 1) * $this->recordsPerPage + 1;
        $offset2 = ($this->total_pages == $this->pageNumber) ? $this->total_records : $offset + $this->recordsPerPage - 1;
        $html = '';
        if ($this->total_pages) {
            $rand_numb = rand(999, 10000);
            $ajax_request = !empty($options['ajaxRequest']) ? "rel='ajaxRequest' div_name='{$divId}'" : '';
            $this->url = empty($options['url']) ? $this->url : $options['url'];
            $html .="<div class='pagination {$class}'>";
            if (!isset($options['noTotalRecords']))
                $html .="<div class='results'><strong>{$offset} - {$offset2}</strong> of <strong>{$this->total_records}</strong> results</div>";
            $html .= "<div class='pages'>";
            $prevPageNumber = $this->pageNumber - 1;
            if (substr($this->url, -1) == '/') {
                $this->url = substr($this->url, 0, -1);
            }
            if ($this->pageNumber > 1) {
                $html .= "<a href='{$this->url}/page_{$prevPageNumber}/' {$ajax_request}  ><div id='pageNumberScrollerPrev_{$rand_numb}' class='paginationScrollerPrev'>Prev</div></a>";
                if ($prevNextOnly) {
                    $links['prev'] = "<a href='{$this->url}/page_{$prevPageNumber}/' {$ajax_request}  ><div id='pageNumberScrollerPrev_{$rand_numb}'><img src='http://c182709.r9.cf1.rackcdn.com/triangle-left.png' alt='' /></div></a>";
                }
            }
            $html .= "<div id='pageNumberScroller_{$rand_numb}' class='paginationScroller'>";
            $html .="<div class='items'>";

            if ($this->pageNumber < 3) {

                for ($i = 1; $i <= $this->total_pages; $i++) {
                    $css_class = ($this->pageNumber == $i ) ? "class='active'" : "";
                    $html .= " <a href='{$this->url}/page_{$i}/'  {$ajax_request}  {$css_class}>{$i}</a> ";
                }
            } else {
                for ($i = ($this->pageNumber) - 2; $i <= $this->total_pages; $i++) {
                    $css_class = ($this->pageNumber == $i ) ? "class='active'" : "";
                    $html .= " <a href='{$this->url}/page_{$i}/'  {$ajax_request}  {$css_class}>{$i}</a> ";
                }
            }

            $html .= '</div>';
            $html .= '</div>';
            $nextPageNumber = $this->pageNumber + 1;
            if ($this->pageNumber < $this->total_pages) {
                $html .= "<a href='{$this->url}/page_{$nextPageNumber}/'  {$ajax_request}><div id='pageNumberScrollerNext_{$rand_numb}' class='paginationScrollerNext'>Next</div></a>";
                if ($prevNextOnly) {
                    $links['next'] = "<a href='{$this->url}/page_{$nextPageNumber}/'  {$ajax_request}><div id='pageNumberScrollerNext_{$rand_numb}'><img src='http://c182709.r9.cf1.rackcdn.com/triangle-right.png' alt='' /></div></a>";
                }
            }
            $html .= "</div><div class='spacer'></div></div><div class='spacer'></div>";
        }
        return ($prevNextOnly) ? $links : $html;
    }

    /**
     * Prints the text for current page. Example 15-30 of 100.
     */
    function getCurrentPageInfo() {
        $offset = ($this->pageNumber - 1) * $this->recordsPerPage + 1;
        $offset2 = ($this->total_pages == $this->pageNumber) ? $this->total_records : $offset + $this->recordsPerPage - 1;
        if($this->total_pages > 1){
        echo "<strong>{$offset} - {$offset2}</strong> of <strong>{$this->total_records}</strong> results.";
        }
    }

    /**
     * Print the page numbers.
     */
    function printPageNumbers($options = array()) {      
        $this->total_pages = ceil($this->total_records / $this->recordsPerPage);
        $this->total_pages = ($this->total_pages > 1) ? $this->total_pages : 0;              
        $ajax_request = !empty($options['ajaxRequest']) ? "rel='ajaxRequest' div_name='{$options['div_id']}'" : '';
        $ajax_request .= !empty($options['rel'])?$options['rel']:'';
        $this->url = empty($options['url']) ? $this->url : $options['url'];
        echo "<ul class='pagination wrap'>";
        if ($this->pageNumber - 1) {
            echo "<li ><a href='{$this->url}/page_" . ($this->pageNumber - 1) . "/'  {$ajax_request}><<</a></li>";
        }
        $i =1;
        if($this->pageNumber > 5){
           $i =  $this->pageNumber -4;
        }
        if($i + 5 < $this->total_pages){
           $end =  $i + 5;
        }else{
            $end = $this->total_pages;
        }

        for ($i; $i <= $end ; $i++) {
            $css_class = ($this->pageNumber == $i ) ? "class='active'" : "";
            echo "<li {$css_class}><a href='{$this->url}/page_{$i}/'  {$ajax_request}  >{$i}</a></li>";
        }

        if ($this->total_pages - $this->pageNumber > 1) {
            echo "<li ><a href='{$this->url}/page_" . ($this->pageNumber + 1) . "/'  {$ajax_request}>>></a></li>";
        }

        echo "</ul>";
    }

}

?>
