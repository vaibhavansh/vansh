<?php

class Core_Models_Route {

    function routeURL($options = array()) {
        switch($options[0]):
            case 'admins':
                $options[0] = 'admin_admins';
                break;
            case 'bollywoodtorrentzone':
                $options[0] = 'bollywoodtorrentzone_bollywoodtorrentzones';
                break;


        endswitch;
        return $options;
    }

}
