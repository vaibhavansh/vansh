<?php
class Core_Models_SessionNamespace extends Zend_Session_Namespace {

}