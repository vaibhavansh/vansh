<?php


class Core_Models_OptionBox extends FormField implements IGeneratable {

    protected $properties = array(
        'name' => null,
        'id' => null,
        'className' => null,
        'disabled' => false,
        'optionBoxData' => array(),
        'dBTableOptions' => array(),
        'defaultValue' => null,
        'multiSelect' => false,
        'noneOption' => false,
        'noneOptionText' => 'None',
        'size' => 5,
    );
    private $_options = array();

// constructor
    function __construct($options = array()) {
// invoke super class constructor
        parent::__construct($options);
        if (!empty($this->properties['noneOption'])) {
            $this->_options[0] = $this->properties['noneOptionText'];
        }
#first get the options#
        if (!empty($this->properties['optionBoxData'])) {
            foreach ($this->properties['optionBoxData'] as $value => $text) {
                $this->_options[$value] = $text;
            }
        }
        if (!empty($this->properties['dBTableOptions'])) {
            if (empty($this->properties['dBTableOptions']['className']))
                throw new NullElementException();
            $orderBy = !empty($this->properties['dBTableOptions']['orderBy']) ? $this->properties['dBTableOptions']['orderBy'] :
                    $this->properties['dBTableOptions']['cols'] . ' asc ';
            $where = !empty($this->properties['dBTableOptions']['where']) ? $this->properties['dBTableOptions']['where'] : '';
            $join = !empty($this->properties['dBTableOptions']['join']) ? $this->properties['dBTableOptions']['join'] : '';
            $valueField = !empty($this->properties['dBTableOptions']['valueField']) ? $this->properties['dBTableOptions']['valueField'] : 'id';
            $limit = !empty($this->properties['dBTableOptions']['limit']) ? $this->properties['dBTableOptions']['limit'] : '';
            $optionBoxClass = new $this->properties['dBTableOptions']['className'];
            $optionBoxData = $optionBoxClass->find_all(array(
                'cols' => $this->properties['dBTableOptions']['cols'] . ', ' . $optionBoxClass->table . '.' . $valueField,
                'where' => $where, 'orderBy' => $orderBy, 'join' => $join, 'limit' => $limit));
            foreach ($optionBoxData as $item) {
                $this->_options[$item->$valueField] = $item->{$this->properties['dBTableOptions']['cols']};
            }
        }
    }

    function generate() {
        $optionBoxHTML = '';
        $optionBoxDataCount = count($this->_options);
        $selectBoxOptions = array('name' => $this->name, 'id' => $this->id, 'className' => $this->className);
        if ($optionBoxDataCount <= 5) { #checkbox/radio
            if (!($this->multiSelect)) { #radio
                foreach ($this->_options as $value => $text) {
                    $selectBoxOptions['checked'] = false;
                    if (is_array($this->defaultValue) && in_array($value, $this->defaultValue)) {
                        $selectBoxOptions['checked'] = true;
                    }
                    $selectBoxOptions['text'] = $text;
                    $selectBoxOptions['value'] = $value;
                    $item = new Radio($selectBoxOptions);
                    $optionBoxHTML .= "<div class=' {$this->className}'>";
                    $optionBoxHTML .= $item->generate();

                    $optionBoxHTML .= "</div>";
                }
            } else { #checkbox
                foreach ($this->_options as $value => $text) {
                    $selectBoxOptions['checked'] = false;
                    if (is_array($this->defaultValue) && in_array($value, $this->defaultValue)) {
                        $selectBoxOptions['checked'] = true;
                    }
                    $selectBoxOptions['text'] = $selectBoxOptions['value'] = $text;
                    $item = new CheckBox($selectBoxOptions);
                    $optionBoxHTML .= "<div class=' {$this->className}'>";
                    $optionBoxHTML .= $item->generate();
                    $optionBoxHTML .= "</div>";
                }
            }
        } else { #simple dropdown/multiselect drop down
            $selectBoxOptions['multiSelect'] = $this->multiSelect;
            $item = new SelectBox($selectBoxOptions);
            foreach ($this->_options as $value => $text) {
                $selected = false;
                if (is_array($this->defaultValue) && in_array($value, $this->defaultValue)) {
                    $selected = true;
                }
                $item->addOption(array('selected' => $selected, 'value' => $value, 'text' => $text, 'key' => $value));
            }
            $optionBoxHTML .= $item->generate();
            /*z$optionBoxHTML .= "<script>$('#{$this->id}').chosen();</script>";*/
        }
#ToDO : add search option/ fancy add/vremove box for multiselect when items are more than 10
        return $optionBoxHTML;
    }

}

