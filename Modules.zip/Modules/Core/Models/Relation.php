<?php
class Core_Models_Relation extends Core_Models_Database {


    static $table = 'object_relations';
    static $fields = NULL;
}