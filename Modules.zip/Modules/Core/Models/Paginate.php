<?php

class Core_Models_Paginate {

    public $pageNumber = 1;
    public $className = '';
    public $totalPages = 0;
    public $recordsPerPage = 10;
    public $totalRecords = 0;
    public $pageLinks = '';

    /**
     * Constructor for Paginate.
     * ClassName is required. This class is the extended class from dbtable.
     */
    function __construct($className) {
        $this->className = $className;
    }

    /**
     * Gets the rows for given page.
     * @param array $options
     * @return type
     */
    function getPaginatedData($options) {
        $this->pageNumber = !empty($options['pageNumber']) ? preg_replace(array('/page-/', '/page_/'), '', $options['pageNumber']) : 1;

        $this->recordsPerPage = isset($options['recordsPerPage']) ? $options['recordsPerPage'] : $this->recordsPerPage;
        $className = $this->className;
        if (empty($this->totalRecords)) {
            $this->totalRecords = array_shift($className::find_all(
                                    array_merge($options, array('cols' => "count(*) as total_records"))
                    ))->total_records;
        }
        $this->totalPages = ceil($this->totalRecords / $this->recordsPerPage);
        $offset = ($this->pageNumber - 1) * $this->recordsPerPage;
        $options['limit'] = $offset . ', ' . $this->recordsPerPage;
        $this->data = $className::find_all($options);
        return $this->data;
    }

    /**
     *
     * Get the page links for the paginated data.
     * url is required in an array.
     * ajaxRequest, className for a tag can be passed
     * $assets is in ojbect of paginate class.
     * @usage $assets->pageLinks(array('url'=>'/asset_assets/index/','ajaxRequest'=>true));
     * @global type $page
     * @param type $options
     * @return type
     */
    function pageLinks($options = array()) {
        $divId = isset($options['div_id']) ? $options['div_id'] : 'mainContent';
        $options['className'] = (!empty($options['className'])) ? $options['className'] : '';
//        $options['ajaxRequest'] = !empty($options['ajaxRequest']) ? "rel='ajaxRequest' div_name='{$divId}'" : '';
        if (!empty($options['ajaxRequest'])) {
            if ($options['ajaxRequest'] === 'popUpBox') {
                $options['ajaxRequest'] = " rel='popUpBox' ";
            } else {
                $options['ajaxRequest'] = "rel='ajaxRequest' div_name='{$divId}'";
            }
        }
        $this->url = empty($options['url']) ? $this->url : $options['url'];
        if ($this->totalPages > 1 && empty($this->pageLinks)) {
            for ($i = 1; $i <= $this->totalPages; $i++) {
                $this->pageLinks .= " <li><a href='{$this->url}/page-{$i}/'  {$options['ajaxRequest']} ";
                $this->pageLinks .= "class='" . (($this->pageNumber == $i ) ? "{$options['className']}  active" : $options['className']) . "' ";
                $this->pageLinks .= ">{$i}</a></li>";
            }
        }
        return $this->pageLinks;
    }

    function printPageNumbers($options = array()) {
        $this->total_pages = ($this->totalPages >= 1) ? $this->totalPages : 0;
        $ajax_request = !empty($options['ajaxRequest']) ? "rel='ajaxRequest' div_name='{$options['div_id']}'" : '';
        $ajax_request .=!empty($options['rel']) ? $options['rel'] : '';
        $this->url = empty($options['url']) ? $this->url : $options['url'];
        if ($this->total_pages > 1) {
            echo "<ul class='pagination wrap'>";
            if ($this->pageNumber - 1) {
                echo "<li ><a href='{$this->url}/page_" . ($this->pageNumber - 1) . "/'  {$ajax_request}><<</a></li>";
            }
            $i = 1;
            if ($this->pageNumber > 5) {
                $i = $this->pageNumber - 4;
            }
            if ($i + 5 < $this->total_pages) {
                $end = $i + 5;
            } else {
                $end = $this->total_pages;
            }
            for ($i; $i <= $end; $i++) {
                $css_class = ($this->pageNumber == $i ) ? "class='active'" : "";
                echo "<li {$css_class}><a href='{$this->url}/page_{$i}/'  {$ajax_request}  >{$i}</a></li>";
            }
            if ($this->total_pages - $this->pageNumber > 1) {
                echo "<li ><a href='{$this->url}/page_" . ($this->pageNumber + 1) . "/'  {$ajax_request}>>></a></li>";
            }
            echo "</ul>";
        }
    }

    function getCurrentPageInfo() {
        $offset = ($this->pageNumber - 1) * $this->recordsPerPage + 1;
        $offset2 = ($this->totalPages == $this->pageNumber) ? $this->totalRecords : $offset + $this->recordsPerPage - 1;
        if ($this->totalPages >= 1) {
            echo "<strong>{$offset} - {$offset2}</strong> of <strong>{$this->totalRecords}</strong> results.";
        }
    }
    /**
     * Get the next page link, so you can show just one Load More button instead of all page numbers.
     * it only returns the link .
     * @param type $options
     */
    function getNextPageLink($options = array()) {
        $this->url = empty($options['url']) ? $this->url : $options['url'];
        return "{$this->url}/page_" . ($this->pageNumber + 1) . "/";
    }

    function nextPageExists() {
        if ($this->totalPages > $this->pageNumber) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Set the ajax request option for current paginated list.
     * It will return the rel tag and div name if passed.
     * 
     * @param type $options
     * @return type
     */
    function setAjaxRequest($options) {
        $ajaxRequestTag= '';
        if (!empty($options['ajaxRequest'])) {
            $ajaxRequestTag = "rel='ajaxRequest' ";
            if (!empty($options['div_id'])) {
                $ajaxRequestTag .=" div_name='{$options['div_id']}'";
            }
        }
        return $ajaxRequestTag;
    }

}

?>
