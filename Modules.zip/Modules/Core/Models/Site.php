<?php

/**
 *
 * @author Saurabh
 */
class Core_Models_Site {

    /**
     * Create a model for the given module.
     * it adds the proper table name.
     * @param type $modulePath
     * @param type $model
     * @return type
     */
    static function createModel($modulePath, $model) {
        $moduleName = basename($modulePath);
        $class = new Zend_CodeGenerator_Php_Class();
        $table = strtolower(preg_replace('/([a-z])([A-Z])/', '$1_$2', $model)) . 's';
        $class->setName($moduleName . '_Models_' . $model)->setExtendedClass('Core_Models_DbTable')->setProperties(array(
            array(
                'name' => 'table',
                'visibility' => 'static',
                'defaultValue' => $table
            ),
            array(
                'name' => 'fields',
                'visibility' => 'static',
                'defaultValue' => null
            )
        ));
        $file = new Zend_CodeGenerator_Php_File();
        $file->setClass($class);
        return file_put_contents($modulePath . DS . 'Models' . DS . $model . '.php', $file->generate());
    }

    /**
     * Create a model for the given module.
     * it adds the proper table name.
     * @param type $modulePath
     * @param type $model
     * @return type
     */
    static function createConfig($siteName,$dbHost,$dbPass,$dbUser,$siteDomain) {
        $class = new Zend_CodeGenerator_Php_Class();
        $class->setName('Config');
        $class->setProperties(array(
            array(
                'name' => 'Frameworks',
                'visibility' => 'static',
                'defaultValue' => array('ZEND')
            ),
            array(
                'name' => 'ENVIRONMENT',
                'visibility' => 'static',
                'defaultValue' => 'DEVELOPMENT'
            ),
            array(
                'name' => 'SOME_SECRET_SALT',
                'visibility' => 'static',
                'defaultValue' => 'ASDFASDFADSFASDFSAFDASDF'
            ),
            array(
                'name' => 'DefaultController',
                'visibility' => 'static',
                'defaultValue' => 'User_Controllers_UsersController'
            ), array(
                'name' => 'DefaultModel',
                'visibility' => 'static',
                'defaultValue' => 'User_Models_User'
            ),
            array(
                'name' => 'DefaultAction',
                'visibility' => 'static',
                'defaultValue' => 'loginForm'
            ),
            array(
                'name' => 'DefaultQueryString',
                'visibility' => 'static',
                'defaultValue' => array()
            ),
            array(
                'name' => 'pageTitle',
                'visibility' => 'static',
                'defaultValue' => 'Welcome to Your Default Site: ' . $siteName
            )
        ));
        $method = new Zend_CodeGenerator_Php_Method();
	$method->setName('getConfig')->setVisibility('static')->setParameters(array(new Zend_CodeGenerator_Php_Parameter(array('name' => 'name'))))->setBody(sprintf('return self::$$name;'));

	$class->setMethod($method);
        $phpCode = new Zend_CodeGenerator_Php_File();
        $phpCode->setClass($class);
        $file = fopen(SITES_DIRECTORY . DS . $siteName . DS . 'Config' . DS . 'config.php', 'w');
        fwrite($file, "<?php \n define('DB_HOST', 'localhost');
define('DB_NAME', '{$dbHost}');
define('DB_USER', '{$dbUser}');
define('DB_PASSWORD', '{$dbPass}');
define('BASE_PATH_ROOT', '{$siteDomain}');
define('CORE_MODULE_DIRECTORY',ROOT.DS.'Modules');
define('FRAMEWORKS_DIRECTORY',ROOT.DS.'Frameworks');
define('SITES_DIRECTORY',ROOT.DS.'Sites');
define('SITES_MODULE_DIRECTORY',ROOT.DS.'Sites'.DS.'{$siteName}'.DS.'Modules');
define('UTILITIES_DIRECTORY',ROOT.DS.'Utilities');
define('CACHE_DIR',PUBLIC_FOLDER . DS . 'tmp' . DS . 'zendcache' . DS);
define('SITE_NAME','{$siteName}');#this is the folder name this site is in.
define('GLOBAL_RESOURCES',ROOT.DS.'resources');?>\n");
        return fwrite($file, $phpCode->generate());
    }

    /**
     * Create Controller for given module
     * @param type $modulePath
     * @param type $controller
     * @return type
     */
    static function createRoute($siteName) {
        $code = '<?php' . "\n";
        $code .= 'function routeURL($options = array()){' . "\n";
        $code .='$options[0] = isset($options[0]) ? $options[0] : \'\';' . "\n";
        $code .= 'switch ($options[0]):' . "\n" . 'endswitch;'."\n";
        $code .= 'return $options;' . "\n";
        $code .= '}';
        return file_put_contents(SITES_DIRECTORY . DS . $siteName . DS . 'Config' . DS . 'Route.php', $code);
    }

    /**
     * Create Controller for given module
     * @param type $modulePath
     * @param type $controller
     * @return type
     */
    static function createController($modulePath, $controller) {
        $moduleName = basename($modulePath);
        $class = new Zend_CodeGenerator_Php_Class();
        $class->setName($moduleName . '_Controllers_' . $controller)->setExtendedClass('Core_Controllers_SitesController');
        $file = new Zend_CodeGenerator_Php_File();
        $file->setClass($class);
        return file_put_contents($modulePath . DS . 'Controllers' . DS . $controller . '.php', $file->generate());
    }

    /**
     * Creates teh table for given name.
     * This should be in dbtable class?
     * @param type $table
     * @return type
     */
    static function createTable($table,$fields = array('id'=>'int(11)')) {
        $db = new Core_Models_Database();
        $db->query("Show tables like '{$table}';");
        $tableExist = $db->get();
        if (empty($tableExist)) {
            echo " Create table {$table} (".implode(',', $fields).", PRIMARY KEY (id))";
            $db->query(" Create table {$table} (".implode(',', $fields).", PRIMARY KEY (id))");
            return true;
        } else {
            return false;
        }
    }

    /**
     * Returns an associative array of list of all controllers in the framework.
     * $controller[CLASSNAME] = CONTROLLERNAME
     * $controller['Core_Controllers_SitesController'] = SitesController;
     * @return type
     */
    static function getControllers() {
        $files = array_merge(glob(ROOT . DS . 'Sites' . DS . "*" . DS . 'Modules' . DS . '*' . DS . 'Controllers/*.php'), (glob(ROOT . DS . 'Modules' . DS . "*/Controllers/*")));
        foreach ($files as $file) {

            $file = str_replace(array(ROOT, '.php'), '', $file);

            preg_match('/\/Modules\/(.*)\/Controllers/', $file, $matches);

            $file = basename($file);

            $controllers[$matches[1] . '_Controllers_' . $file] = $file;
            // echo '<pre>';print_r($matches);
        }
        return $controllers;
    }

    /**
     * Get a list of all models in site and core framework.
     * @return $array
     */
    static function getModels() {
        $files = array_merge(glob(ROOT . DS . 'Sites' . DS . "*" . DS . 'Modules' . DS . '*' . DS . 'Models/*.php'), (glob(ROOT . DS . 'Modules' . DS . "*/Models/*")));
        foreach ($files as $file) {
            $file = str_replace(array(ROOT, '.php'), '', $file);
            preg_match('/\/Modules\/(.*)\/Models/', $file, $matches);
            $file = basename($file);
            $models[$matches[1] . '_Models_' . $file] = $file;
        }
        return $models;
    }

    /**
     * Get a list of all modules in Core and all sites.
     * @return type
     */
    static function getModules() {
        $moduleModels = array_merge(glob(ROOT . DS . 'Sites' . DS . "*/Modules/*", GLOB_ONLYDIR), (glob(ROOT . DS . 'Modules' . DS . "*", GLOB_ONLYDIR)));
        foreach ($moduleModels as $moduleModel) {
            $module = str_replace(ROOT, '', $moduleModel);
            $moduleName = basename($moduleModel);
            $modules[$module] = $moduleName;
        }
        return $modules;
    }
    static function getTableModels(){
        $dbTableModels = array();
        foreach(Core_Models_Site::getModels() as $modelClass => $modelName){

            if(get_parent_class($modelClass) == 'Core_Models_DbTable'){
                $dbTableModels[$modelClass] = $modelName;
            }
        }
        return $dbTableModels;
    }

}

?>
