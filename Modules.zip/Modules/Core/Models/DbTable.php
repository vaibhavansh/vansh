<?php

/**
 * This is objectification of a table. This used with the database class offers the basic operations in built to all.
 * original copy got from :: http://www.phpclasses.org/browse/package/5129.html
 * Last Modified: Jul 14 2010
 * Added edit function to generate form.
 * Last Modifier: Saurabh
 */
class Core_Models_DbTable extends Core_Models_Database {

    static $table;
    var $id;
    var $pageNumber;
    var $offset;
    var $totalPages;
    static $fields;
    protected $className;

    /**
     * Constructor function, gets table name, sets the ID of a current row
     * and gets all field names from the table
     *
     * @param   integer   ID of row to update or delete
     */
    function Core_Models_DbTable($id = '') {
        $className = get_called_class();
        $this->table = !empty($this->table) ? $this->table : $className::getDefaultTable($className);
        $this->className = $className;

        if (!empty($id)) {
            global $cache;
            if ((Config::getConfig('ENVIRONMENT') == 'DEVELOPMENT') || ($record = $cache->load($this->table.'_'.$id)) === false) {
            $where = "  id ='{$id}' ";
            $temp = parent::select(array('where' => $where, 'limit' => 1));
            $record = $this->get();
            $cache->save($record, $this->table . '_'.$id);
            }
            if (!empty($record)) {
                foreach ($record[0] as $key => $value) {
                    $this->$key = $value;
                }
            }
        }
    }

    static function getDefaultTable($className) {
        return strtolower($className::$table);
        ;
    }

    static function fields() {
        $className = get_called_class();
        if (empty($className::$fields)) {
            $db = new Core_Models_Database();
            $db->query("SHOW COLUMNS FROM {$className::$table} ");
            $className::$fields = $db->get();
        }
        return $className::$fields;
    }

    function coreURL() {
        list($plugin, $model, $controller, $title, $coreURL) = Core_Models_Utility::parseClassName(get_called_class());
        return $plugin . '_' . $model;
    }

    function editURL() {
        list($plugin, $model) = Core_Models_Utility::getCalledModel(get_called_class());
        return "/{$plugin}_{$model}s/edit/{$this->id}/";
    }

    function getIndexURL($className) {
        list($plugin, $model) = Core_Models_Utility::getCalledModel($className);
        return "/{$plugin}_{$model}s/index";
    }

    /**
     * Very simple select. This select returns an obect of that classs.
     *
     * @param    string   What to order by
     * @param    string   Where statement
     * @param    string   Columns to select
     * @return   result   Result of query
     */
    function select($options = '') {
        parent::select($options);
        $objects = array();
        if ($this->last_query instanceof mysqli_result) {
            while ($row = mysqli_fetch_object($this->last_query)) {
                $object = $this->createObject($row);
                $objects[$object->id] = $object;
            }
        } else {
            $this->error();
        }
        return $objects;
    }

    function createObject($record) {
        $object = new $this->className;
        foreach ($record as $key => $value)
            $object->$key = stripslashes($value);
        return $object;
    }

    /**
     * Insert a new record, or update existing
     *
     * @param   array   Data to insert (usually $_POST)
     */
    function save($data) {
        if (!is_array($data)) {
            return false;
        }
        $set = array();
        foreach ($this->fields as $fields) {
            if (isset($data[$fields->Field])) {
                $set[$fields->Field] = $data[$fields->Field];
                $this->{$fields->Field} = $data[$fields->Field];
            }
        }
        if (!empty($set)) {
            if (empty($this->id)) {
                $this->id = $this->insert($this->table, $set);
                return $this->id;
            } else {
                #Clean the record#
                global $cache;
                $cache->remove($this->table.'_'.$this->id);
                return  $this->update($this->table, $set, " id = '$this->id'");
            }
        }
    }

    /**
     * Delete row or rows
     *
     * @param   string   Where clause
     */
    function delete($where = '') {

        if (!empty($this->id) && empty($where))
            $where .= "id = $this->id";

        return parent::delete($this->table, $where);
    }

    /**
     * Get all rows from a given table
     * @param type $options
     * @return type
     */
    public static function find_all($options = '') {
        $className = get_called_class();
        $object = new $className;
        $objects = $object->select($options);
        return $objects;
    }

    /**
     * Get all rows*(15 max by default) for a given table
     * @global type $page
     * @param type $variables
     * @return \Paginate
     */
    static function getPaginatedData($variables) {
        $variables['recordsPerPage'] = !empty($variables['recordsPerPage']) ? $variables['recordsPerPage'] : 10;
        $variables['pageNumber'] = !empty($variables['pageNumber']) ? $variables['pageNumber'] : 1;
        $variables['paginator'] = new Core_Models_Paginate(get_called_class());
        $variables['paginator']->data = $variables['paginator']->getPaginatedData($variables);

        return $variables['paginator'];
    }

    function __get($name) {
        return (!empty($this->$name)) ? $this->$name : (method_exists($this, $name)) ? $this->$name() : '';
    }
    function customFields($key = '', $field = 'value') {
        
        if (!is_object($this->custom_fields)) {
            $this->custom_fields = json_decode(stripslashes($this->custom_fields));
        }
        if (!empty($key))
            return isset($this->customFields->$key->$field) ? $this->customFields->$key->$field : false;
        else
            return $this->custom_fields;
    }
    /**
     * Method to update a particular row of table without creating instance
     * This way a select query is not required for update.
     * Static, so row id needs to be passed.
     * @param type string $where > "id ='1' "
     * @param type array $data > associative array for column names with values.
     * @return  true for update.
     */
    static function updateRow($where = '', $data){
	$className = get_called_class();
	$tableName = $className::$table;	
        if(!empty($tableName) && !empty($data) && !empty($where)){
            $db = new Core_Models_Database();
            return $db->update($tableName, $data, $where);
        }
    }
}
