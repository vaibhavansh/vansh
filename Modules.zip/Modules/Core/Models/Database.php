<?php

/**
 * PHP 5 Database Class
 * Performs basic MySQL database interactions
 * original copy got from ::http://www.phpclasses.org/browse/package/5129.html
 */
class Core_Models_Database {

    private $host = DB_HOST;
    private $user = DB_USER;
    private $pass = DB_PASSWORD;
    private $db = DB_NAME;
    protected $last_query; // Results of last query
    protected $last_sql; // String that contains last sql query
    protected $show_errors = true; // Whether or not to show error messages
    #Single instance of database connection.
    static $dbConnection;

    /**
     * Constructor function
     * Connects and selects database
     *
     * @param    string   MySQL Host
     * @param    string   MySQL Username
     * @param    string   MySQL Password
     * @param    string   MySQL Database name
     * @return   link     Connection link
     */
    function Core_Models_Database($options = '') {

        $host = !empty($options['host']) ? $options['host'] : $this->host;
        $user = !empty($options['user']) ? $options['user'] : $this->user;
        $pass = !empty($options['pass']) ? $options['pass'] : $this->pass;
        $db = !empty($options['db']) ? $options['db'] : $this->db;
        if (empty(self::$dbConnection)) {
            self::$dbConnection = mysqli_connect($host, $user, $pass, $db) or $this->error('Could not connect to database. Make sure settings are correct.');
            return self::$dbConnection;
        } else {
            return self::$dbConnection;
        }

        return false;
    }

    /**
     * Execute a query on the database
     *
     * @param    string   SQL query to execute
     * @return   query    The query executed
     */
    function query($sql) {

        is_resource(self::$dbConnection) || $this->Core_Models_Database();
        $this->last_sql = $sql;
        $this->last_query = mysqli_query( self::$dbConnection,$sql) or $this->error();
        return $this->last_query;
    }

    /**
     * Very simple select
     *
     * @param    string   Table name to select from
     * @param    string   What to order by
     * @param    string   Where statement
     * @param    string   Columns to select
     * @return   result   Result of query
     */
    function select($options) {
        $orderby = !empty($options['orderBy']) ? "ORDER BY {$options['orderBy']} " : '';
        $join = !empty($options['join']) ? "JOIN {$options['join']} " : '';
        $leftjoin = !empty($options['leftjoin']) ? " LEFT JOIN {$options['leftjoin']} " : '';
        $where = !empty($options['where']) ? "WHERE {$options['where']} " : '';
        $limit = !empty($options['limit']) ? "LIMIT {$options['limit']}" : '';
        $table = !empty($options['table']) ? " {$options['table']}" : $this->table;
        $cols = !empty($options['cols']) ? " {$options['cols']}" : '*';
        $groupBy = !empty($options['groupBy']) ? " group by {$options['groupBy']}" : '';
        return $this->query("SELECT $cols FROM $table $join $leftjoin $where $groupBy $orderby $limit");
    }

    /**
     * Get results of query
     *
     * @param    string   Return as object or array
     * @return   result   Result of query
     */
    function get($type = 'object') {

        $type = $type == 'object' ? 'mysqli_fetch_object' : 'mysqli_fetch_array';

        if ($this->last_query instanceof mysqli_result){
            while ($rows = $type($this->last_query)) {
                foreach ($rows as &$row) {
                    $row = stripslashes($row); //added so all data spitted out is good for display..
                } // Was Commented out . added again. keep an eye.
                $results[] = $rows;
            }
        }

        else
            $this->error();

        return (!empty($results)) ? $results : null;
    }

    /**
     * Performs an insert query
     *
     * @param    string   Table name to query
     * @param    array    Associative array of Column => Value to insert
     * @return   result   Result of query
     */
    function insert($table, $data) {

        if (!is_array($data))
            return false;

        foreach ($data as $col => $value)
            $data[$col] = $this->escape($value);

        $cols = array_keys($data);
        $vals = array_values($data);

        $this->query("INSERT INTO $table (" . implode(',', $cols) . ") VALUES (" . implode(',', $vals) . ")");
        return mysqli_insert_id(self::$dbConnection);
    }

    /**
     * Updates a row
     *
     * @param    string   Table name to query
     * @param    array    Associtive array of columns to update
     * @param    string   Where clause
     * @return   result   Result of query
     */
    function update($table, $data, $where) {

        if (!is_array($data))
            return false;

        foreach ($data as $col => $value) {
            $vals[] = $col . ' = ' . $this->escape($value);
        }
        if (!empty($vals)) {
            return $this->query("UPDATE $table SET " . implode(',', $vals) . " WHERE $where");
        } else {
            return;
        }
    }

    /**
     * Delete a single row
     *
     * @param    string   Table name to query
     * @param    string   The column to match against
     * @param    string   Value to match against column
     * @return   result   Result of query
     */
    function delete($table, $where) {

        return $this->query("DELETE FROM $table WHERE $where");
    }

    /**
     * Escape strings
     *
     * @param    mixed    String to escape
     * @return   string   Escaped string, ready for SQL insertion
     */
    function escape($data) {

        switch (gettype($data)) {
            case 'string':
                $data = "'" . mysqli_real_escape_string(self::$dbConnection, $data) . "'";
                break;
            case 'boolean':
                $data = (int) $data;
                break;
            case 'double':
                $data = sprintf('%F', $data);
                break;
            default:
                $data = ($data === null) ? 'null' : $data;
        }

        return (string) $data;
    }

    /**
     * Show simple error messages to help aid development process
     *
     * @param    string   Custom error message to show
     * @return   death    Error page
     */
    function error($msg = '') {
        if ($this->show_errors === true) {
            $error = '<h1>Error!</h1>';

            if (!empty($msg))
                $error .= "$msg<br />";

            if (mysqli_error(self::$dbConnection))
                $error .= '<b>MySQL Error:</b> ' . mysqli_error(self::$dbConnection) . '<br />';

            if (isset($this->last_sql))
                $error .= '<b>SQL Statement:</b> ' . $this->last_sql;

            die($error);
        }
    }

}
