<section id="content_wrapper">
    <section id="content" class="">
        <div id="animation-switcher" class=" col-md-12">
            <div id="createModuleFormResultDiv"></div>
            <form name ="createModuleForm" id="createModuleForm" method="post"
                  keepVisible="1" keepResult="1" action="/core_sites/createModuleAction" rel="ajaxifiedForm">
                <div class="mw1000 center-block">
                    <div class="panel panel-warning panel-border top mt20 mb35">
                        <div class="panel-heading">
                            <span class="panel-title"> <i class="fa fa-pencil"></i>Create a Module</span>
                            <p>This will create the required folders and classes for a module.</p><div class="clearfix"></div>
                        </div>
                        <div class="panel-body p20 pb10">
                            <div class="pn br-n admin-form">
                                <div class="section row">
                                    <div class="col-md-12">
                                        <label class="col-md-7 control-label">Please Select the location.(It's a core module, or you want to create it for a site?)</label>
                                        <div class="col-md-5">         
                                            <?php echo $moduleLocationSelector->generate(); ?>
                                        </div>               
                                    </div>                
                                </div>
                                <div class="section row">
                                    <div class="col-md-12">
                                        <label class="col-md-7 control-label">Name of Module(Camel Case Preferred)</label>
                                        <div class="col-md-5">         
                                            <label for="moduleName" class="field prepend-icon">
                                                <input type="textbox" name="moduleName" id="moduleName" class="required event-name gui-input br-light light" />
                                                <label for="moduleName" class="field-icon"><i class="fa fa-info"></i></label>
                                            </label>
                                        </div>               
                                    </div>                
                                </div>
                            </div>
                        </div>
                        <div class="section panel-footer bg-wild-sand mbn admin-form">
                            <div class="pull-right">
                                <button type="submit" class="button btn-success col-xs-12 pull-right">Create Module</button>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </section>
</section>
