<section id="content_wrapper">
    <section id="content" class="">
        <div id="animation-switcher" class=" col-md-12">
            <div id="createClassFormResultDiv"></div>
            <div class="mw1000 center-block">
                <div class="panel panel-warning panel-border top mt20 mb35">
                    <form name ="createClassForm" id="createClassForm" method="post" keepVisible="1" keepResult="1" action="/core_sites/createClassAction" rel="ajaxifiedForm">
                        <div class="panel-heading">
                            <span class="panel-title"> <i class="fa fa-pencil"></i>Create a Class</span><div class="clearfix"></div>
                        </div>
                        <div class="panel-body p20 pb10">
                            <div class="pn br-n admin-form">
                                <div class="section row">
                                    <div class="col-md-12">
                                        <label class="col-md-7 control-label">Select the module, you want to create class for</label>
                                        <div class="col-md-4">         
                                            <?php echo $moduleSelector->generate(); ?>
                                        </div>               
                                    </div>                
                                </div>
                                <div class="section row">
                                    <div class="col-md-12">
                                        <label class="col-md-7 control-label">Select the Class type(Controller/Model)</label>
                                        <div class="col-md-4">         
                                            <?php echo $classSelector->generate(); ?>
                                        </div>               
                                    </div>                
                                </div>
                                <div class="section row">
                                    <div id="modelFieldsForm" class='well col-md-12' style="display: none;">
                                        <input type='button' onclick="$('#fieldSelectDiv').clone(true).insertBefore($(this)).show().removeAttr('id');" value='Add Fields for the table' class="button btn-danger pull-right"/>
                                    </div>
                                </div>
                                <div class="section row">
                                    <div class="col-md-12">
                                        <label class="col-md-7 control-label">Enter name of class(Use Camel Case Singular Word)</label>
                                        <div class="col-md-4"> 
                                            <label for="modelName" class="field prepend-icon">
                                                <input type="textbox" name="modelName" id="modelName" class="required event-name gui-input br-light light" />
                                                <label for="modelName" class="field-icon"><i class="fa fa-info"></i></label>
                                            </label>
                                        </div>               
                                    </div>                
                                </div>
                            </div>
                        </div>
                        <div class="section panel-footer bg-wild-sand mbn admin-form">
                            <div class="pull-right">
                                <button type="submit" class="button btn-success col-xs-12 pull-right">Create Model</button>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    </form>
                    <div id="fieldSelectDiv" name ="fieldSelectDiv" style="display:none">
                        <select class="form-control" name='fieldTypeSelector[]'>
                            <option value='0' >Please select type of field.</option>
                            <optgroup label="Basic Options">
                                <option value="varchar">Text(500 Characters)</option>
                                <option value='text'>Text(>500 Characters)</option>
                                <option value='foreignKey'>Model ID</option>
                            </optgroup>
                            <optgroup label="Advanced Options">
                                <option>INT</option>
                                <option>TINYINT</option>
                                <option>MEDIUMINT</option>
                                <option>BIGINT</option>
                                <option>DOUBLE</option>
                                <option>FLOAT</option>
                                <option>DATE</option>
                                <option>DATETIME</option>
                                <option>TIMESTAMP</option>
                                <option>YEAR</option>
                                <option>BLOB</option>
                                <option>MEDIUMBLOB</option>
                                <option>LONGBLOB</option>
                                <option>LONGTEXT</option>
                                <option>ENUM</option>
                            </optgroup>
                        </select>
                        
                    <script type="text/javascript">
                        $('input[name=classSelector]').change(function () {
                            if ($(this).val() == 'model') {
                                $('#modelFieldsForm').show();
                            } else {
                                $('#modelFieldsForm').hide();
                            }

                        });
                        $("select[name='fieldTypeSelector[]']").change(function () {
                            $(this).parent().find("select[name='modelSelector[]']").hide();
                            $(this).parent().find('div[name=fieldInfo]').hide();
                            switch ($(this).val()) {
                                case 'foreignKey':
                                    $(this).parent().find("select[name='modelSelector[]']").show();
                                    break;
                                default:
                                    $(this).parent().find('div[name=fieldInfo]').show();
                                    break;

                            }
                        });
                    </script>
                </div>
            </div>
        </div>
    </section>
</section>
