<div class="container">
    <div class="col-md-4 ">
        <h2>
            Features:
        </h2>
        <ul>
            <li>Drag 'n' Drop Menu Editor</li>
            <li>Drag 'n' Drop Layout Editor</li>
            <li>Ajax, built in.</li>
            <li>Responsive Design.</li>
            <li>History Plugin Support</li>
            <li>Accordion, Tooltips, Ajax Forms, <br />Color Picker, Confirm Box, Form Validation, Pop Up Box.<br /> and the list goes on....</li>
        </ul>
        <h4>This is what it comes with. <br />Now imagine, what you can do with it.</h4>
    </div>
    <div class="col-md-4">
        <h2>Best of the world, built in:</h2>
        <ul>
            <li>PHP 5.3</li>
            <li>MVC Architecture</li>
            <li>Modular System</li>
            <li>jQuery UI </li>
            <li>jQuery Tools </li>
            <li>Bootstrap 3 </li>
            <li>Zend Framework</li>
            <li>Cake PHP</li>
        </ul>
        <h4>It's all in there.<br /> What else you want?</h4>
    </div>
    <div class="col-md-4">

        <h2>But Why:</h2>
        <p>This is why I built it.</p>
    </div>
    <div class="spacer"></div>
    <a href="/admin_admins/home" class="btn btn-primary btn-lg">Demo Here</a>
</div>
<script type="text/javascript">
    $(document).ready(function () {
        $('body').addClass('sb-l-c no-side-bar');
    });
</script>