<div id="editObject<?php echo $object->id ?>ResultDiv"></div>
<form name ="editObject<?php echo $object->id ?>" id="editObject<?php echo $object->id ?>" method="post"
      keepVisible="1" keepResult="1" action="/<?php echo $object->coreURL ?>/save" rel="ajaxifiedForm">
    <div class="grid_16">
        <h2><?php echo $header ?></h2>
        <?php foreach ($object->fields as $field) { ?>
            <div class="grid_4"><label for='<?php echo $field->Field ?>'><?php echo $field->Field ?></label></div>
            <div class="grid_6">
                <input type="textbox" name="<?php echo $field->Field ?>" id="<?php echo $field->Field ?>" value="<?php echo $object->{$field->Field} ?>" />
            </div>
            <div class="spacer"></div>
        <?php }
        ?>
        <input type="hidden" name="id" value="<?php echo $object->id ?>"/>
        <input type="submit" value ="submit" rel="submitButton" />
    </div>
</form>
