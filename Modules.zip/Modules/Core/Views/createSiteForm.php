<section id="content_wrapper">
    <section id="content" class="">
        <div id="animation-switcher" class=" col-md-12">
            <div id="createSiteFormResultDiv"></div>
            <form name ="createSiteForm" id="createSiteForm" method="post" keepResult="1" action="/core_sites/createSiteAction" rel="ajaxifiedForm">
                <div class="mw1000 center-block">
                    <div class="panel panel-warning panel-border top mt20 mb35">
                        <div class="panel-heading">
                            <span class="panel-title"> <i class="fa fa-pencil"></i>Create a Site</span>
                            <p>This will create the required folders and classes for a Site.</p><div class="clearfix"></div>
                        </div>
                        <div class="panel-body p20 pb10">
                            <div class="pn br-n admin-form">
                                <h3>General Info:</h3>
                                <div class="section row mbn">
                                    <div class="col-md-12 pl15">
                                        <div class="section row mb15">
                                            <div class="col-xs-12"><h5 class="text-left"><small>Name of Site</small></h5>
                                                <label for="title" class="field prepend-icon">
                                                    <input type="textbox" name="siteName" id="siteName" class="required event-name gui-input br-light light" />
                                                    <label for="title" class="field-icon"><i class="fa fa-info"></i></label>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="section row mb15">
                                            <div class="col-xs-12"><h5 class="text-left"><small>Domain for the site</small></h5>
                                                <label for="title" class="field prepend-icon">
                                                    <input type="textbox" name="siteDomain" id="siteDomain" class="required event-name gui-input br-light light" />
                                                    <label for="title" class="field-icon"><i class="fa fa-pencil"></i></label>
                                                </label>
                                            </div>
                                        </div>
                                        <h3>Database Details:</h3>
                                        <div class="section row mb15">
                                            <div class="col-xs-12"><h5 class="text-left"><small>Database Name</small></h5>
                                                <label for="title" class="field prepend-icon">
                                                    <input type="textbox" name="db_host" id="db_host" class="required event-name gui-input br-light light" />
                                                    <label for="title" class="field-icon"><i class="fa fa-info"></i></label>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="section row mb15">
                                            <div class="col-xs-12"><h5 class="text-left"><small>Database Username</small></h5>
                                                <label for="title" class="field prepend-icon">
                                                    <input type="textbox" name="db_user" id="db_user" class="required event-name gui-input br-light light" />
                                                    <label for="title" class="field-icon"><i class="fa fa-pencil"></i></label>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="section row mb15">
                                            <div class="col-xs-12"><h5 class="text-left"><small>Database Password</small></h5>
                                                <label for="title" class="field prepend-icon">
                                                    <input type="textbox" name="db_pass" id="db_pass" class="required event-name gui-input br-light light" />
                                                    <label for="title" class="field-icon"><i class="fa fa-info"></i></label>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="section panel-footer bg-wild-sand mbn admin-form">
                            <div class="pull-right">
                                <button type="submit" class="button btn-success col-xs-12 pull-right">Create Site</button>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </section>
</section>