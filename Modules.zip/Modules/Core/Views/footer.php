<!--INFOLINKS_OFF-->
<div class="grid_16 omega">
    <p>All rights reserved. Saurabh Gandhe</p>
</div>
<div class="grid_8 alpha">
    <p></p>
</div>