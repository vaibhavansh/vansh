<div class="col-sm-9 col-xs-6">
    <h3>Manage Sites</h3>
</div>
<div class="col-sm-3 col-xs-6 rightAlign">
    <h3><a href="#">Create New </a></h3>
</div>

<div class="spacer"></div>

<div class='col-sm-12'><?php
    if (!empty($sites))
        foreach ($sites as $site) {
            ?>
    <h3><?php echo basename($site);?></h3>
            <?php
        }
    ?>
</div>