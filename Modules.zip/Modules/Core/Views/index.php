<section class="animated fadeIn mt20">
    <div id="animation-switcher">
        <div class="mw1000 center-block">
            <div class="panel panel-warning panel-border top mt20 mb35">
                <div class="panel-heading"><span class="panel-title"> <i class="fa fa-th-list"></i> <?php echo $header ?></span>
                    <span class="pull-right fix-right">
                        <div class="btn-group">
                            <a class="btn btn-success" href="/<?php echo $objects->coreURL ?>/edit/0" oncloseFunction="reloadDiv('/<?php echo $objects->coreURL; ?>/index','mainContent');" rel="popUpBox">Create New </a>
                        </div>
                    </span><div class="clearfix"></div>
                </div>
                <div class="spacer"></div>
                <div class="panel-body pn">
                    <?php echo $objects->pageLinks(array('url' => "/{$objects->coreURL}/index", 'ajaxRequest' => true)); ?>
                </div>


                <div class='panel-body pn'>
                    <div class="list-com" id="list-com">
                        <?php
                        if (!empty($objects->data))
                            foreach ($objects->data as $object) {
                                ?>
                                <div class="col-sm-12 com-detail pt5" id="row_<?php echo $object->id ?>">
                                    <div class="col-sm-8">
                                        <a href="/<?php echo $objects->coreURL . '/edit/' . $object->id ?>" oncloseFunction="reloadDiv('/<?php echo $objects->coreURL; ?>/index','mainContent');" rel="popUpBox"  > <?php echo $object->title; ?></a>
                                    </div>
                                    <div class="col-sm-4 pb5 text-right">
                                        <a href="/<?php echo $objects->coreURL . '/delete/' . $object->id ?>" rel="confirmClickURL" confirmTrueFunction="$('#row_<?php echo $object->id ?>').hide()" message="Are you sure you want to remove '<?php echo $object->title; ?>'." class="btn btn-danger br2 btn-xs" ><span class="fa fa-close"></span></a>
                                    </div>
                                </div>
                                <?php
                            }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>