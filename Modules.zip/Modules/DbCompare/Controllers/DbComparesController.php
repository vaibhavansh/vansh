<?php

class DbCompare_Controllers_DbComparesController extends Core_Controllers_SitesController {

    public function home() {
        $this->layoutId = 2;
        return array();
    }

    public function compareAction() {
        $variables = array();
        switch ($_POST['compareaction']) {
            case 'table_structure':
                ?>
                <h3>Table Structure</h3>
                <?php
               $variables = DbCompare_Models_DbCompare::compareTableStructure();
                break;
            case 'table_structure_data':
                ?>
                <h3>Table Structure & Data</h3>
                <?php
               $variables = DbCompare_Models_DbCompare::compareDatabaseTables();
                break;
            case 'database_structure':
                ?>
                <h3>Database Structure</h3>
                <?php
             $variables = DbCompare_Models_DbCompare::comapreDatabaseStructure();
                break;
        }
        return $variables;
    }

}