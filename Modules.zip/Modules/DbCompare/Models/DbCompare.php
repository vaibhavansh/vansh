<?php

class DbCompare_Models_DbCompare {

    /**
     * Given two different database and table names, shows changes in table data, and any additional rows created.
     * @return <type>
     */
    function compareDatabaseTables() {
        $host = $_POST['host'];
        $user = $_POST['user'];
        $pass = $_POST['pass'];
        $db1Name = $_POST['db1'];
        $db2Name = $_POST['db2'];
        $table1 = $_POST['table1'];
        $table2 = $_POST['table2'];

        $db1 = new Core_Models_Database(array('host' => $host, 'user' => $user, 'pass' => $pass, 'db' => $db1Name));

        $sql = "";
        //Compare Table structure//
        $variables = self::compareTableStructure();
        //Core_Models_Utility::printRecord($variables);
        //Prepare table 1
        $table1Fields = array();
        foreach ($variables[$db1Name][$table1]['Fields'] as $field) {
            $table1FieldsArray[] = $field;
            $table1Fields[] = $db1Name . '.' . $table1 . '.' . $field . ' as ' . $db1Name . '_' . $table1 . '_' . $field . ' ';
        }
        $table1FieldsString = implode(',', $table1Fields);
        //Prepare table 2
        $table2Fields = array();
        foreach ($variables[$db2Name][$table2]['Fields'] as $field) {
            $table2FieldsArray[] = $field;
            $table2Fields[] = $db2Name . '.' . $table2 . '.' . $field . ' as ' . $db2Name . '_' . $table2 . '_' . $field . ' ';
        }
        $table2FieldsString = implode(',', $table2Fields);
        //Merge different Fields
        $differentFieldsArray = array_merge($variables[$db1Name][$table1]['ExtraFieldsArray'], $variables[$db2Name][$table2]['ExtraFieldsArray']);

        //Compare Data//

        $sql = "select ";
        $sql .= $table1FieldsString . ', ' . $table2FieldsString;
        $sql .= " from " . $db1Name . '.' . $table1;
        $sql .= " left join " . $db2Name . '.' . $table2 . " on " . $db1Name . '.' . $table1 . '.id = ' . $db2Name . '.' . $table2 . '.id ';
        $sql .= " where ";
        //First le'ts add something for the new rows added.
        foreach ($variables[$db1Name][$table1]['Fields'] as $field) {
            if (!in_array($field, $differentFieldsArray)) {
                $colIsNull[] = $db1Name . '.' . $table1 . '.' . $field . ' is null ';
            }
        }

        foreach ($variables[$db1Name][$table1]['Fields'] as $field) {
            if (!in_array($field, $differentFieldsArray)) {
                $notEqualArray[] = $db1Name . '.' . $table1 . '.' . $field . ' != ' . $db2Name . '.' . $table2 . '.' . $field;
            }
        }
        $sql .= ' ( ';
        $sql .= implode(' and ', $colIsNull);
        $sql .= ' ) ';
        $sql .= ' or ';
        $sql .= implode(' or ', $notEqualArray);
//        $sql .=' ) ';
        $db1->query($sql);
        $rows = $db1->get();

        if ($rows) {
            echo "<h3>Different Rows found: " . count($rows) . '</span></h3>';
            foreach ($rows as $row) {
                echo "<h3>Row</h3>";

                foreach ($variables[$db1Name][$table1]['Fields'] as $field) {
                    $fieldName1 = $db1Name . '_' . $table1 . '_' . $field;
                    $fieldName2 = $db2Name . '_' . $table2 . '_' . $field;
                    if (!in_array($field, $differentFieldsArray)) {
                        $v1 = $row->$fieldName1;
                        $v2 = $row->$fieldName2;
                        if ($v1 != $v2) {
                            $idFieldName = $db1Name . '_' . $table1 . '_id';
                            echo "[Row ID] => " . $row->$idFieldName . '<br />';
                            echo "[Field]  =>" . $field . '<br />';
                            echo "[{$db1Name}][{$table1}] Value =>" . $v1 . '<br />';
                            echo "[{$db2Name}][{$table2}] Value =>" . $v2 . '<br />';
                        }
                    } else {
                        echo 'Ignoring Field' . $field . '<br />';
                    }
                }
            }
        }
        //check if any of table has new rows.
        $left2rightSql = "SELECT $db1Name.$table1.* FROM $db1Name.$table1 LEFT JOIN $db2Name.$table2 ON $db1Name.$table1.id=$db2Name.$table2.id WHERE $db2Name.$table2.id IS NULL ";
        $right2leftSql = "SELECT $db2Name.$table2.* FROM $db2Name.$table2 LEFT JOIN $db1Name.$table1 ON $db2Name.$table2.id=$db1Name.$table1.id WHERE $db1Name.$table1.id IS NULL ";
        $db1->query($left2rightSql);
        $rows = $db1->get();
        if (count($rows)) {
            echo "<h3>Additional Rows found in " . $db1Name . ' : ' . $table1 . '</h3>';
            Core_Models_Utility::printRecord($rows);
        }
        $db1->query($right2leftSql);
        $rows2 = $db1->get();
        if (count($rows2)) {
            echo "<h3>Additional Rows found in " . $db2Name . ' : ' . $table2 . '</h3>';
            Core_Models_Utility::printRecord($rows2);
        }
        return $_POST;
    }

    /**
     * Displays the additional tables in first database, and additional tables in second database
     * @return <type>
     */
    function comapreDatabaseStructure() {
        $variables = array();
        $host = $_POST['host'];
        $user = $_POST['user'];
        $pass = $_POST['pass'];
        $db1Name = $_POST['db1'];
        $db2Name = $_POST['db2'];
        //Push these variables to vie//
        $variables['db1Name'] = $db1Name;
        $variables['db2Name'] = $db2Name;
        $db = new Core_Models_Database(array('host' => $host, 'user' => $user, 'pass' => $pass, 'db' => $db1Name));

        $sql = "show tables from " . $db1Name;
        $db->query($sql);
        $db1Tables = $db->get();
        $tableIn1 = 'Tables_in_' . $db1Name;
        foreach ($db1Tables as $db1table) {
            $tables1[] = $db1table->$tableIn1;
        }
        $sql = "show tables from " . $db2Name;
        $db->query($sql);
        $db2Tables = $db->get();

        $tableIn2 = 'Tables_in_' . $db2Name;
        foreach ($db2Tables as $db2Table) {
            $tables2[] = $db2Table->$tableIn2;
        }
        $differentFields = Core_Models_Utility::arrayDiff($tables1, $tables2);
        $variables[$db1Name]['ExtraTables'] = $differentFields['ExtraFieldsArray1'];
        if ($variables[$db1Name]['ExtraTables']) {
            echo '<h2>Extra Table in ' . $db1Name . '</h2>';
            Core_Models_Utility::printRecord($variables[$db1Name]['ExtraTables']);
        }

        $variables[$db2Name]['ExtraTables'] = $differentFields['ExtraFieldsArray2'];
        if ($variables[$db2Name]['ExtraTables']) {
            echo '<h2>Extra Table in ' . $db2Name . '</h2>';
            Core_Models_Utility::printRecord($variables[$db2Name]['ExtraTables']);
        }

        $variables['CommonTables'] = array_intersect($tables1, $tables2);
        echo '<h2>Common Tables in both databases.</h2>';
        Core_Models_Utility::printRecord($variables['CommonTables']);
        foreach ($variables['CommonTables'] as $table) {
            $_POST['table1'] = $_POST['table2'] = $table;
            self::compareTableStructure();
        }
        return $variables;
    }

    function compareTableStructure($options = '') {
        $variables = array();
        $host = $_POST['host'];
        $user = $_POST['user'];
        $pass = $_POST['pass'];
        $db1Name = $_POST['db1'];
        $db2Name = $_POST['db2'];
        $table1 = $_POST['table1'];
        $table2 = $_POST['table2'];
        //Push these variables to vie//
        $variables['db1Name'] = $db1Name;
        $variables['db2Name'] = $db2Name;
        $variables['table1'] = $table1;
        $variables['table2'] = $table2;
        $db = new Core_Models_Database(array('host' => $host, 'user' => $user, 'pass' => $pass, 'db' => $db1Name));

        $sql = "";
        //get fields from table 1//
        $sql = "show columns from " . $db1Name . '.' . $table1;
        $db->query($sql);
        $fields1 = $db->get();
        //Prepare table 1
        $table1Fields = array();
        foreach ($fields1 as $field) {
            $table1FieldsArray[] = $field->Field;
            $table1Fields[] = $db1Name . '.' . $table1 . '.' . $field->Field . ' as ' . $db1Name . '_' . $field->Field . ' ';
        }
        $table1FieldsString = implode(',', $table1Fields);
        //get fields from table 2//
        $sql = "show columns from " . $db2Name . '.' . $table2;
        $db->query($sql);
        $fields2 = $db->get();
        //Prepare table 2
        $table2Fields = array();
        foreach ($fields2 as $field) {
            $table2FieldsArray[] = $field->Field;
            $table2Fields[] = $db2Name . '.' . $table2 . '.' . $field->Field . ' as ' . $db2Name . '_' . $field->Field . ' ';
        }
        $table2FieldsString = implode(',', $table2Fields);
        //COMPARE STRUCTURE//
        $differentFields = Core_Models_Utility::arrayDiff($table1FieldsArray, $table2FieldsArray);
        $differentFieldsArray = array();
//        if(Core_Models_Utility::isArrayEmpty($differentFields)) {
        $differentFieldsArray = array_merge($differentFields['ExtraFieldsArray1'], $differentFields['ExtraFieldsArray2']);
        $variables[$db1Name][$table1]['Fields'] = $table1FieldsArray;
        $variables[$db2Name][$table2]['Fields'] = $table2FieldsArray;
        $variables[$db1Name][$table1]['ExtraFieldsArray'] = $differentFields['ExtraFieldsArray1'];
        $variables[$db2Name][$table2]['ExtraFieldsArray'] = $differentFields['ExtraFieldsArray2'];
        if (Core_Models_Utility::isArrayEmpty($differentFields)) {
            $variables['compareTableStructureResult'] = true;
        } else {
            $variables['compareTableStructureResult'] = false;
        }
        if (!empty($variables['compareTableStructureResult'])) {
            echo '<h3>Different table structure found</h3>';
            echo "<div class='grid_12'>";
            echo "<div class='grid_6 alpha'>";
            echo "<h3>{$db1Name}-{$table1}</h3>";
            Core_Models_Utility::printRecord($table1FieldsArray);
            echo "</div>";
            echo "<div class='grid_6 omega'>";
            echo "<h3>{$db2Name}-{$table2}</h3>";
            Core_Models_Utility::printRecord($table2FieldsArray);
            echo '</div>';
            echo "<div class='clear'></div>";
            echo "<div class='grid_6 alpha'>";
            echo '<h4>Extra Fields</h4>';
            Core_Models_Utility::printRecord($differentFields['ExtraFieldsArray1']);
            echo '</div>';
            echo "<div class='grid_6 alpha'>";
            echo '<h4>Extra Fields</h4>';
            Core_Models_Utility::printRecord($differentFields['ExtraFieldsArray2']);
            echo "</div>";
            echo "</div>";
            echo "<div class='clear'></div>";
        } else {
            echo "<h3>{$db1Name}.{$table1} and {$db2Name}.{$table2} have same structure.</h3>";
        }
        return $variables;
    }

    function compareTableData($options = '') {
        $host = $_POST['host'];
        $user = $_POST['user'];
        $pass = $_POST['pass'];
        $db1Name = $_POST['db1'];
        $db2Name = $_POST['db2'];
        $table1 = $_POST['table1'];
        $table2 = $_POST['table2'];
        $db1 = new Core_Models_Database(array('host' => $host, 'user' => $user, 'pass' => $pass, 'db' => $db1Name));
        $sql = "";
        //Compare Table structure//
        $variables = self::compareTableStructure();
        //Core_Models_Utility::printRecord($variables);
        //Prepare table 1
        $table1Fields = array();
        foreach ($variables[$db1Name][$table1]['Fields'] as $field) {
            $table1FieldsArray[] = $field;
            $table1Fields[] = $db1Name . '.' . $table1 . '.' . $field . ' as ' . $db1Name . '_' . $field . ' ';
        }
        $table1FieldsString = implode(',', $table1Fields);
        //Prepare table 2
        $table2Fields = array();
        foreach ($variables[$db2Name][$table2]['Fields'] as $field) {
            $table2FieldsArray[] = $field;
            $table2Fields[] = $db2Name . '.' . $table2 . '.' . $field . ' as ' . $db2Name . '_' . $field . ' ';
        }
        $table2FieldsString = implode(',', $table2Fields);
        //Merge different Fields
        $differentFieldsArray = array_merge($variables[$db1Name][$table1]['ExtraFieldsArray'], $variables[$db2Name][$table2]['ExtraFieldsArray']);

        //Compare Data//

        $sql = "select ";
        $sql .= $table1FieldsString . ', ' . $table2FieldsString;
        $sql .= " from " . $db1Name . '.' . $table1;
        $sql .= " left join " . $db2Name . '.' . $table2 . " on " . $db1Name . '.' . $table1 . '.id = ' . $db2Name . '.' . $table2 . '.id ';
        $sql .= " where ";
        //First le'ts add something for the new rows added.
        foreach ($variables[$db1Name][$table1]['Fields'] as $field) {
            if (!in_array($field, $differentFieldsArray)) {
                $colIsNull[] = $db1Name . '.' . $table1 . '.' . $field . ' is null ';
            }
        }

        foreach ($variables[$db1Name][$table1]['Fields'] as $field) {
            if (!in_array($field, $differentFieldsArray)) {
                $notEqualArray[] = $db1Name . '.' . $table1 . '.' . $field . ' != ' . $db2Name . '.' . $table2 . '.' . $field;
            }
        }
        $sql .= ' ( ';
        $sql .= implode(' and ', $colIsNull);
        $sql .= ' ) ';
        $sql .= ' or ';
        $sql .= implode(' or ', $notEqualArray);
        $db1->query($sql);
        $rows = $db1->get();
        if ($rows) {
            foreach ($rows as $row) {
                foreach ($variables[$db1Name][$table1]['Fields'] as $field) {
                    $fieldName1 = $db1Name . '_' . $field;
                    $fieldName2 = $db2Name . '_' . $field;
                    if (!in_array($field, $differentFieldsArray)) {
                        $v1 = $row->$fieldName1;
                        $v2 = $row->$fieldName2;
//                        echo $v1. ' - '. $v2.'<br />';
                        if ($v1 != $v2) {
                            $idFieldName = $db1Name . '_id';
                            $variables['unMatchedRows'][$row->$idFieldName][$field] = array(
                                $db1Name . '_value' => $v1,
                                $db2Name . '_value' => $v2,
                            );
                        }
                    }
                }
            }
        }
        //check if any of table has new rows.
        $left2rightSql = "SELECT $db1Name.$table1.* FROM $db1Name.$table1 LEFT JOIN $db2Name.$table2 ON $db1Name.$table1.id=$db2Name.$table2.id WHERE $db2Name.$table2.id IS NULL ";
        $right2leftSql = "SELECT $db2Name.$table2.* FROM $db2Name.$table2 LEFT JOIN $db1Name.$table1 ON $db2Name.$table2.id=$db1Name.$table1.id WHERE $db1Name.$table1.id IS NULL ";
        $db1->query($left2rightSql);
        $rows = $db1->get();
        if (count($rows)) {
            $variables[$db1Name][$table1]['ExtraRows'] = $rows;
        }
        $db1->query($right2leftSql);
        $rows2 = $db1->get();
        if (count($rows2)) {
            $variables[$db2Name][$table2]['ExtraRows'] = $rows2;
        }
//        Core_Models_Utility::printRecord($variables);
        return $variables;
    }



}

