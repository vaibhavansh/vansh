<div class="grid_8 omega">
    <h3>DB Information:</h3>
    <input type="text" name="host" id='host' value="localhost" /><div class="spacer"></div>
    <input type="text" name="user" id ="user" value="username" /><div class="spacer"></div>
    <input type="text" name="pass" id="pass" value="password"/><div class="spacer"></div>
    <h3>Database 1</h3>
    <input type="text" name="db1" id="db1" value="db1"/><div class="spacer"></div>

    <h3>Database 2</h3>
    <p><input type="checkbox" name="copyDatabase" id="copyDatabase" value="1"/>Same as Database 1</p>
    <input type="text" name="db2" id="db2" value="db2"/><div class="spacer10"></div>
    <p><input type="checkbox" name="differentDbHost" id="differentDbHost" value="1"/>Different Host/Login?</p>
    <div id="database2HostInfo" style="display:none">
        <h3>Login Info:</h3>
        <input type="text" name="host2" id='host2' value="localhost" /><div class="spacer"></div>
        <input type="text" name="user2" id ="user2" value="username" /><div class="spacer"></div>
        <input type="text" name="pass2" id="pass2" value="password"/><div class="spacer"></div>
    </div>
    <input type="button" value="Database Structure" id="database_structure" rel="compareDatabaseButton"/>

    <div class="spacer10"></div>
    <h3>Table Information</h3>

    <p>Table 1(Database 1)</p>
    <input type="text" name="table1" id="table1" value="table1" /><div class="spacer"></div>
    <p>Table 2(Database 2)</p>
    <input type="text" name="table2" id="table2" value="table2" /><div class="spacer"></div>
    <div class="spacer10"></div>
    <input type="button" value="Tables Structure" id="table_structure" rel="compareDatabaseButton" />

    <div class="spacer10"></div>
    <input type="button" value="Table Structure and Data" id="table_structure_data" rel="compareDatabaseButton"/>

</div>
<div class="grid_16 alpha">
    <h3>Compare Results</h3>
    <div id="compareResults">
        Please Enter the information on left to get the results here.
        I do not store any information here, i just compare and print the results. <br/> This script is provided as is, and implies no warranty or any thing. I made it for myself, and posted to share it, if it's useful for any one.<br />


    </div>
</div>
<script>
    $("input[rel=compareDatabaseButton]").click(function(){
        $('#compareResults').html(loadingDivHTML());
        //Copy Db1 Info to Db2 Info
        if($('#differentDbHost').is(':checked')){
            $('#host2').val($('#host').val());
            $('#user2').val($('#user').val());
            $('#pass2').val($('#pass').val());
        }
        $.post('/dbcompare_dbcompares/compareAction', {
            pageRequestType: 'ajax',
            compareaction:$(this).attr('id'),
            db1:$('#db1').val(),
            db2:$('#db2').val(),
            host:$('#host').val(),
            user:$('#user').val(),
            pass:$('#pass').val(),
            table1:$('#table1').val(),
            table2:$('#table2').val()


        }, function(data){
            $("#compareResults").html(data);
        });
    });
    $('#copyDatabase').change(function(){
        if($(this).is(':checked')){
            $('#db2').val($('#db1').val()).hide();

        }else{
            $('#db2').show();
        }
    });
    $('#differentDbHost').change(function(){
        if($(this).is(':checked')){
            $('#database2HostInfo').show();
        }else{
            $('#database2HostInfo').hide();
        }
    });

</script>