<?php
echo 'you are in view file;';
if (!empty($compareTableStructureResult)) {
    echo '<h3>Different table structure found</h3>';
    echo "<div class='grid_12'>";
    echo "<div class='grid_6 alpha'>";
    echo "<h3>{$db1Name}-{$table1}</h3>";
    Core_Models_Utility::printRecord($table1FieldsArray);
    echo "</div>";
    echo "<div class='grid_6 omega'>";
    echo "<h3>{$db2Name}-{$table2}</h3>";
    Core_Models_Utility::printRecord($table2FieldsArray);
    echo '</div>';
    echo "<div class='clear'></div>";
    echo "<div class='grid_6 alpha'>";
    echo '<h4>Extra Fields</h4>';
    Core_Models_Utility::printRecord($differentFields['ExtraFieldsArray1']);
    echo '</div>';
    echo "<div class='grid_6 alpha'>";
    echo '<h4>Extra Fields</h4>';
    Core_Models_Utility::printRecord($differentFields['ExtraFieldsArray2']);
    echo "</div>";
    echo "</div>";
    echo "<div class='clear'></div>";
} else {
    echo "<h3>{$db1Name}.{$table1} and {$db2Name}.{$table2} have same structure.</h3>";
}

