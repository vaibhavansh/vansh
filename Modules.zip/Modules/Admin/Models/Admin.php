<?php

class Admin_Models_Admin extends User_Models_User
{

}

