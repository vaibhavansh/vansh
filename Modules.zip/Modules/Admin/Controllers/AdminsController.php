<?php

class Admin_Controllers_AdminsController extends Core_Controllers_SitesController {

    function dashboard() {
        $variables = array();
        global $page;
        if ($page->currentUser->webUserRole == '5') {
            $this->layoutId = 43;
        } else {
            $this->layoutId = 38;
        }
        $forms = Form_Models_Form::find_all(array('where' => "forms.showform Like '%1%'"));
        if (!empty($forms)) {
            foreach ($forms as $form) {
                if (!empty($form->showform)) {
                    $userData = User_Models_UserData::getDataByFormId($form->id);
                    if (empty($userData)) {
                        $showForms = explode(',', $form->showform);
                        if (!empty($showForms)) {
                            foreach ($showForms as $showForm) {
                                if ($showForm == '1') {
                                    $webUserRole = explode(',', $form->user_role_id);
                                    $formId = $form->id;
                                }
                            }
                        }
                    }
                }
            }
            $variables['webUserRole'] = isset($webUserRole) ? $webUserRole : '';
            $variables['formId'] = isset($formId) ? $formId : '';
        }
        return $variables;
    }

    function home() {
        $this->layoutId = 2;
        return array();
    }

    function runRawCode($someVariable = 1) {
        $this->layoutId = 2;
        global $cache;
        $cache->clean(Zend_Cache::CLEANING_MODE_ALL);
        return array();
    }

    function cleanCache() {
        global $cache;
        if ($cache->clean(Zend_Cache::CLEANING_MODE_ALL)) {
            echo 'Cache Cleaned';
        }
        return array();
    }

}
