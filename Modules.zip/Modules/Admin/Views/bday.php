<section id="content" class="table-layout">      
              <!-- message reply form-->
              <div class="message-reply">
                <div class="summernote">Write your response here...</div>
              </div>
            </div>
          </div>
        </section>

<script type="text/javascript">
      jQuery(document).ready(function () {
        "use strict";
        // Init Theme Core

        // Init Summernote
        $('.summernote').summernote({
          height: 290, //set editable area's height
          focus: false, //set focus editable area after Initialize summernote
          oninit: function () {
          },
          onChange: function (contents, $editable) {
          },
        });
      });
    </script>