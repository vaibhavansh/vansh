<?php
global $page;
if ($page->currentUser->userLoggedIn) {
    $webUserRole = $page->currentUser->webUserRole;
    if ($webUserRole == 2) {
        ?>
        <section id="content_wrapper">
            <!-- Begin: Content-->
            <section id="content" class="">
                <div>
                    <div id="animation-switcher" class="tray-center col-sm-9">
                        <div id="" class="resultDiv1"></div>                           
                        <div id="my-tab-content" class="tab-content">
                            <?php $i = 1;
                            foreach ($viewcertificate as $viewcertificates) { ?>
                                <div class="tab-pane <?php if ($i < 2) {
                                    echo "active";
                                } ?>" id="<?php echo $viewcertificates->id; ?>">
                                    <div class="panel panel-success panel-border top mb25 mt5">
                                        <!-- recent orders table-->
                                        <div class="panel-heading certificate">
                                            <a class="editfocus">
                                                <i class="fa fa-pencil"></i></a>
                                            <span class="panel-title certificatetitle1" contenteditable="true">   <?php echo $viewcertificates->title; ?></span>
                                            
                                        </div>
                                        <div class="message-reply">
                                            <div class="summernote">
                                              <?php echo $viewcertificates->description; ?>
                                            </div>
                                        </div>
                                        <div class="panel-footer text-right bg-wild-sand">
                                            <button type="button" class="btn btn-success btn-sm ph15"  onclick="certificates(<?php echo $viewcertificates->id; ?>);">Update Certificates</button>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                </div>     
                              <?php $i = $i + 1; } ?>    
                        </div>
                    </div>
                    <aside data-tray-height="match" class="tray tray-center col-md-3 col-sm-3 __web-inspector-hide-shortcut__" style="height: 250px;">


                        <div class="<?php echo $coloums; ?> changeclass" id="">
                            <div id="<?php //echo $object->id ?>notessResultDiv" class="resultDiv3"></div> 
                            <div class="panel mb25 mt5">
                                <div class="panel-heading"><span class="panel-title"> <i class="fa fa-th-list"></i> List Certificate Templates</span>
                                </div>
                                  <div class="panel-menu admin-form theme-primary">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <label for="title1" class="field prepend-icon">
                                                <input id="fooFilter_1" type="text" name="title1" placeholder="Filter" class="event-name gui-input br-light light">
                                                <label for="title1" class="field-icon"><i class="fa fa-gear"></i></label>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                         
                                <div class="panel-body pn task-widget">
                                    <div class="table-responsive of-a">
                                           <table data-filter="#fooFilter_1" data-page-navigation=".pagination" data-page-size="8" class="table admin-form theme-warning tc-checkbox-1 fs13 footable">
                                            <thead>
                                                <tr class="bg-light">
                                                    <th class="footable-sortable">Certificate<span class="footable-sort-indicator"></span></th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                 <?php if (empty($viewcertificate)) { ?> <tr> <td>Notes List Not Found</td> </tr> <?php  } else { $i = 1; ?>
                                                  
                                                    <?php $i = 1; foreach ($viewcertificate as $viewcertificates) { ?>
                                            <tr id="section_<?php echo $notesLists->id ?>">
                                                <td class="text-left">                                                 
                                                  
                                                       
                                                    <a href="#<?php echo $viewcertificates->id; ?>"  data-toggle="tab" class="<?php
                                                 if ($i < 2) {  echo "active"; } ?>"><?php echo $viewcertificates->title; ?></a>
                                               </td>
                                            </tr>
                                              <?php  $i = $i + 1; }} ?>
                                            </tbody>
                                           <tfoot class="footer-menu">
                                            <tr>
                                                <td colspan="5">
                                                    <nav class="text-right">
                                                        <ul class="pagination"></ul>
                                                    </nav>
                                                </td>
                                            </tr>
                                        </tfoot>
                                        </table>
                                    </div>            
                                </div>
                            </div>
                            <!vaib-->                
                        </div> 
                    </aside>                     
                </div>
            </section>
        </section>
    <?php }
} ?>




<script type="text/javascript">
    function certificates(assetid = '') {
        if (assetid) {
            title = $('.tab-pane.active .certificatetitle1').html();
            description = $('.tab-pane.active .note-editable').html();
        } else {
            title = $('.certificate .certificatetitle').html();
            description = $('.certificatediscription').html();
        }
        $.ajax({
            type: "POST",
            url: 'admin_admins/certificates',
            data: ({assetid: assetid, title: title, description: description}),
            success: function (data) {
                $('.resultDiv1').html(data);
                setTimeout(function () {
                    reloadDiv("certificates", "mainContent", 'ajax');
                }, 1000);

            }
        });
    }

    jQuery(document).ready(function () {
        "use strict";
        $('.summernote').summernote({
            height: 290, //set editable area's height
            focus: false, //set focus editable area after Initialize summernote
            oninit: function () {
            },
            onChange: function (contents, $editable) {
            },
        });        
        $('#tabs').tab();       
    });
    
    $("tbody tr td a").click(function(){
        $("tbody tr td").removeClass("a");
        $(this).parent('td').addClass("a"); 
     
    });
    
       $('.certificatetitle1').keypress( // firefox ,crome, safari
        function(event){
         if (event.which == '13') {
            event.preventDefault();           
          }
        });    
//        <a href="javascript: void(0" class="editfocus"><i class="fa fa-pencil"></i></a>
        $('.editfocus').click(function() {
         $(".certificatetitle1").focus()
        });
  
</script>    
<style>
    .a{
        width: inherit;
        display: block;
        background-color: rgba(100,100,205,.2);
    }
</style>
