<?php
global $page;
if (isset($webUserRole) && !empty($webUserRole)) {
    ?>
    <?php if (in_array($page->currentUser->webUserRole, $webUserRole)) { ?>
        <div style="display:none;">
            <a href='/form_forms/informationcollectedform/<?php echo $formId; ?>/' rel='popUpBox'>
                <span id="informationform"></span>
            </a>
        </div>
        <script type="text/javascript">
            $(document).ready(function () {
                setTimeout(function () {
                    $('#informationform').click();
                }, 1000);
            });
        </script>
        <?php
    }
}?>
<script type="text/javascript">
        $("body").addClass("sb-l-o");
</script>
