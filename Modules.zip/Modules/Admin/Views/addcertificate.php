<?php
global $page;
if ($page->currentUser->userLoggedIn) {
    $webUserRole = $page->currentUser->webUserRole;
    if ($webUserRole == 2) {
        ?>
        <section id="content_wrapper">
            <!-- Begin: Content-->
            <section id="content" class="">
                <div>
                    <div id="animation-switcher" class="tray-center col-sm-12">
                        <div id="ResultDiv" class="resultDiv1"></div>
                        <!-- recent orders table-->
                        <div>
                            <div class="panel panel-success panel-border top mb25 mt5">
                                <div class="panel-heading"><span class="panel-title"> <i class="fa fa-certificate"></i> Add New Certificates Templates</span>
                                </div>
                                <div class="panel-body pn">
                                    <!-- recent orders table-->
                                    <div class="panel-heading certificate">
                                        <a class="editfocus"><i class="fa fa-pencil"></i></a>
                                        <span class="panel-title certificatetitle" contenteditable="true"> Enter Certificate Title</span>
                                    </div>
                                    <div class="message-reply">
                                        <div class="summernote">

                                        </div>
                                    </div>
                                    <div class="panel-footer text-right bg-wild-sand">
                                        <button type="button" class="btn btn-success btn-sm ph15"  onclick="certificates();">Save Certificates</button>
                                    </div>
                                    <div class="clearfix"></div>

                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </section>
        <?php
    }
}
?>


<script>
    $('.certificatetitle').keypress(function(event){
        if (event.which == '13') {
           event.preventDefault();           
        }
    });    
    $('.editfocus').click(function() {
        $(".certificatetitle").focus()
    });
    function certificates(assetid = '') {
             title = $('.certificate .certificatetitle').html();
            description = $('.note-editable').html();   

        $.ajax({
            type: "POST",
            url: 'admin_admins/certificates',
            data: ({assetid: assetid, title: title, description: description}),
            success: function (data) {
                $('.resultDiv1').html(data);
                setTimeout(function () {
                    reloadDiv("addcertificate", "mainContent", "ajax");
                }, 2500);

            }
        });
    }

    jQuery(document).ready(function () {
        "use strict";
        $('.summernote').summernote({
            height: 290, //set editable area's height
            focus: false, //set focus editable area after Initialize summernote
            oninit: function () {
            },
            onChange: function (contents, $editable) {
            },
        });
    });

</script>
   
