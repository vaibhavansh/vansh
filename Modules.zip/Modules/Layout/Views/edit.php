<section id="content_wrapper">
    <section id="content" class="">
        <div id="animation-switcher" class=" col-md-12">
            <div id="editObject<?php echo $object->id ?>ResultDiv"></div>
            <form name ="editObject<?php echo $object->id ?>" id="editObject<?php echo $object->id ?>" method="post" keepVisible="1" action="/<?php echo $object->coreURL ?>/save" rel="ajaxifiedForm">
                <div class="center-block">
                    <div class="panel panel-warning panel-border top mt20">
                        <div class="panel-heading"><span class="panel-title"> <i class="fa fa-pencil"></i> <?php echo $header ?></span><div class="clearfix"></div>
                        </div>
                        <div class="panel-body p20 pb10">
                            <div class="pn br-n admin-form">
                                <div class="col-xs-12" id="saveLayout" style="display:none">
                                    <div class="warningBox">You have Unsaved Changes.
                                        <a href="javascript:void(0)" id="saveLayoutItem">Save</a> || <a href="/layout_layouts/index/" rel="ajaxRequest" >Cancel & Go Back</a>
                                    </div>
                                </div>
                                <div class="section row mbn">
                                    <div class="col-md-12 pl15">
                                        <div class="section row mb15">
                                            <div class="col-xs-12"><h5 class="text-left"><small> Title</small></h5>
                                                <label for="title" class="field prepend-icon">
                                                    <input type="textbox" name="title" id="title" value="<?php echo $object->title ?>" class="required event-name gui-input br-light light" />
                                                    <label for="title" class="field-icon"><i class="fa fa-info"></i></label>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="section row mb15">
                                            <div class="col-xs-12">
                                                <h5 class="text-left">
                                                    <small>CSS</small>
                                                </h5>
                                                <label for="css" class="field prepend-icon">
                                                    <input type="textbox" name="css" id="css" class="event-name gui-input br-light light" value="<?php echo $object->css ?>" />
                                                    <label for="css" class="field-icon"><i class="fa fa-pencil"></i></label>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="section row mb15">
                                            <div class="col-xs-12">
                                                <h5 class="text-left">
                                                    <small>Javascript</small>
                                                </h5>
                                                <label for="js" class="field prepend-icon">
                                                    <input type="textbox" class=" event-name gui-input br-light light" name="js" id="js" value="<?php echo $object->js; ?>" />
                                                    <label for="js" class="field-icon"><i class="fa fa-info"></i></label>
                                                </label>
                                            </div>
                                        </div>
                                         <div class="section row mb15">
                                            <div class="col-xs-12">
                                                <h5 class="text-left">
                                                    <small>MobileLayout</small>
                                                </h5>
                                                <label for="js" class="field prepend-icon">
                                                    <input type="textbox" class=" event-name gui-input br-light light" name="mobileLayoutId" id="mobileLayoutId" value="<?php echo $object->mobileLayoutId; ?>" />
                                                    <label for="mobileLayoutId" class="field-icon"><i class="fa fa-info"></i></label>
                                                </label>
                                            </div>
                                        </div>
                                        
                                        <input type="hidden" name="id" value="<?php echo $object->id ?>"/>
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                        <hr class="mb5 mt5">
                        <div class="clearfix"></div>
                        <div class="panel-border mt20 mb35">
                            <div class="panel-heading">
                                <div class="col-sm-6 col-xs-12 ">
                                    <h4><?php echo $header . '\'s Layout Items' ?></h4>
                                </div>
                                <div class="col-sm-3 col-xs-6">
                                    <h4><a href="javascript:void(0)" onclick="addChild($('#layoutEditor > parent'), '12')">Add A Layout Item</a></h4>
                                </div>
                                <div class="col-sm-3 col-xs-6">
                                    <h4><a href="/layout_layouts/generateTemplate/<?php echo $object->id ?>" rel="popUpBox">Generate Template</a></h4>
                                </div><div class="clearfix"></div>
                            </div>
                            <div class="panel-body pn pt15 pb10">
                                <div class="col-sm-12" >
                                    <div id="layoutEditor">
                                        <parent class='sortable droptrue connectedSortable' childOf="li0" >
                                            <?php
                                            $object->getLayout($object->getChild('li0', $object->items), $object->items);
                                            ?>
                                        </parent>
                                    </div>
                                </div>
                                <div id="layoutItemDataDiv" class="grid_16"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </section>
</section>
<div id="editLayoutItem" style ="display:none" class="col-sm-8 col-xs-12" title="Edit Layout Item">
    <div id="modal-form" class="admin-form mfp-with-anim">
        <div class="panel">
            <div class="panel-heading">
                <span class="panel-title">
                    <i class="fa fa-pencil"></i>Edit Div</span><div class="clearfix"></div>
            </div>
            <div class="panel-body p25 ">
                <div class="section row">
                    <div class="col-md-12">
                        <label class="col-md-3 control-label">Title</label>
                        <div class="col-md-8">         
                            <input type="textbox" name="title" id="layoutItemTitle" class="gui-input form-control"/>
                        </div>               
                    </div>                
                </div>
                <div class="section row">
                    <div class="col-md-12">
                        <label class="col-md-3 control-label">ID(Unique to the layout)</label>
                        <div class="col-md-8">         
                            <input type="textbox" name="id" id="layoutItemId" class="gui-input form-control"/>
                        </div>               
                    </div>                
                </div>
                <div class="section row">
                    <div class="col-md-12">
                        <label class="col-md-3 control-label">Controller</label>
                        <div class="col-md-8">         
                            <?php echo $layoutItemController->generate(); ?>
                        </div>               
                    </div>                
                </div>
                <div class="section row">
                    <div class="col-md-12">
                        <label class="col-md-3 control-label">Action</label>
                        <div class="col-md-8">         
                            <input type="textbox" name="action" id="layoutItemAction" class="gui-input form-control"/>
                        </div>               
                    </div>                
                </div>
                <div class="section row">
                    <div class="col-md-12">
                        <label class="col-md-3 control-label">Query String</label>
                        <div class="col-md-8">         
                            <input type="textbox" name="queryString" id="layoutItemQueryString" class="gui-input form-control"/>
                        </div>               
                    </div>                
                </div>
                <div class="section row">
                    <div class="col-md-12">
                        <label class="col-md-3 control-label">View</label>
                        <div class="col-md-8">         
                            <input type="textbox" name="view" id="layoutItemView" class="gui-input form-control"/>
                        </div>               
                    </div>                
                </div>
                <div class="section row">
                    <div class="col-md-12">
                        <label class="col-md-3 control-label">Class Name</label>
                        <div class="col-md-8">         
                            <input type="textbox" name="className" id="className" class="gui-input form-control"/>
                        </div>               
                    </div>                
                </div>
                <div class="section row">
                    <div class="col-md-12">
                        <label class="col-md-3 control-label">Use Cache</label>
                        <div class="col-md-8">         
                            <input type="checkbox" name="useCache" id="useCache"  value="1" />
                        </div>               
                    </div>                
                </div>
                <div class="section row mb5">
                    <div class="mr10 pull-right">
                        <button id='editLayoutItemCancel' class="button btn-danger col-xs-12 pull-right">Cancel</button>
                    </div>
                    <div class="mr10 pull-right">
                        <button type="button" id="editLayoutItemOK" class="button btn-success col-xs-12 pull-right">Save Changes</button>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    /**
     * Add a Child to a given list
     */
    function addChild(ul, className) {
        var width = 240;
        var count = $('#layoutEditor').find('child').length;
        var newLI = $("<child class='ui-state-default col-xs-12 lightGreyBackground handler-box' className='col-xs-" + className + "'  style = 'width:" + width + "px' title='item' layoutItemId='layoutItem" + count + "' layoutItemController='' layoutItemAction = '' layoutItemQueryString='' layoutItemView='' ></child>");
        ul.prepend(newLI);
        var layoutItemTitle = ("<div rel='layoutItemTitle' class='grid_5 omega'>New Div</div>");
        newLI.prepend(layoutItemTitle);
        makeItResizable(newLI);
        addEditOptions(newLI);
        sortIt();
        showSaveLayout()
    }
    function showSaveLayout() {
        $('#saveLayout').show();
    }
    /**
     * Add a sublayout to a given list. It adds a new ul so adds a dropdown layout, that can have childs.
     */
    function addSubLayout(li) {
        var ul = li.children('parent');
        if (!(ul.length)) {
            var ul = $("<parent class='sortable droptrue connectedSortable'></parent>");
            li.append(ul);
        }
        addChild(ul, '3');
        showSaveLayout()
    }

    /**
     *Edit the given layoutitem/li
     */

    function editLayoutItem(li) {
        _li = li;
        var div_name = 'editLayoutItem';
        //        $("#" + div_name).html(loadingDivHTML());
        overlay = $('#editLayoutItem').overlay({
            api: true,
            mask: '#000'
        });
        overlay.load();
        //        $("#" + div_name+'Data').html($('#editLayoutItem').html());
        $('#layoutItemTitle').val(_li.children("div[rel='layoutItemTitle']").text());
        $('#layoutItemId').val(_li.attr('layoutItemId'));
        $('#layoutItemController').val(_li.attr('layoutItemController')).trigger('liszt:updated');
        $('#layoutItemAction').val(_li.attr('layoutItemAction'));
        $('#layoutItemView').val(_li.attr('layoutItemView'));
        $('#layoutItemQueryString').val(_li.attr('layoutItemQueryString'));
        $('#className').val(_li.attr('className'));
        if (_li.attr('useCache') == 1) {
            $('#useCache').attr('checked', true);
        } else {
            $('#useCache').attr('checked', false);
        }

        $('#editLayoutItemOK').click(function () {
            _li.children("div[rel='layoutItemTitle']").text($('#layoutItemTitle').val());
            _li.attr('layoutItemId', $('#layoutItemId').val());
            _li.attr('layoutItemController', $('#layoutItemController').val());
            _li.attr('layoutItemAction', $('#layoutItemAction').val());
            _li.attr('layoutItemView', $('#layoutItemView').val());
            _li.attr('layoutItemQueryString', $('#layoutItemQueryString').val());
            _li.attr('className', $('#className').val());
            if ($('#useCache').is(":checked")) {
                _li.attr('useCache', '1');
            } else {
                _li.attr('useCache', '0');
            }


            overlay.close();
            showSaveLayout()
        });
        $('#editLayoutItemCancel').click(function () {
            overlay.close();
        });

    }
    /**
     * Add the options to add /edit /remove the given li.
     */
    function addEditOptions(li) {

        var layoutItemTitle = li.children("div[rel='layoutItemTitle']");
        //Add Child Link
       // var addChildLink = $("<div class='btn btn-warning btn-xs br2 pull-right mr10 handler-box'><span class='fa fa-arrows-h'></span></div><div class='btn btn-success btn-xs br2 pull-right mr10'><span class='fa fa-plus'></span></div>");
        var addChildLink = $("<div class='btn btn-success btn-xs br2 pull-right mr10'><span class='fa fa-plus'></span></div>");
        (addChildLink).insertBefore(layoutItemTitle);
        addChildLink.click(function () {
            addSubLayout(li);
            showSaveLayout()

        });
        //Remove Child Link
        var removeMeLink = $("<div class='btn btn-danger btn-xs br2 pull-right mr10'><span class='fa fa-close'></span></div><div class='clearfix'></div>");
        removeMeLink.insertAfter(layoutItemTitle);
        removeMeLink.click(function () {
            li.remove();
            showSaveLayout()
        });
        //Edit Link//
        var editMeLink = $("<div class='btn btn-info btn-xs br2 pull-right mr10 '><span class='fa fa-pencil'></span></div>");
        editMeLink.insertAfter(layoutItemTitle);
        editMeLink.click(function () {
            editLayoutItem(li);
        });

       // var spacer = $("<div class='spacer'>&nbsp;</div>");
       // spacer.insertAfter(removeMeLink);

        li.children("div[rel='layoutItemTitle']").editable(function (value, settings) {
            showSaveLayout();
            return(value);
        }, {submit: 'OK'});


    }
    function makeItResizable(li) {
        li.resizable({
            //            grid: 24,#removed to avoid issues with multiple divs and border width.
            containment: "#layoutEditor",
            resize: function (event, ui) {
            //    ui.size.height = ui.originalSize.height;

            },
            stop: function (event, ui) {
                showSaveLayout();
            }
        });

    }
    /**
     * refreshes the sortable with new li/ul tags added.
     */
    function sortIt() {
        sortable = $("parent.sortable").sortable({
            connectWith: ".connectedSortable", 
            dropOnEmpty: true,
            update: function () {
                showSaveLayout()
            }
        });
    }
    /**
     * Save the edited layout.
     * This serializes the data of li, adds hidden inputs to store the ul/li tag, id,link etc.
     */
    $('#editObject<?php echo $object->id ?>').find('#saveLayoutItem').click(function () {
        var count = 0;
        $("#layoutEditor  parent ").each(function () {

            var ul = $(this);
            $(this).children('child').each(function () {
                count++;
                var title = $(this).children("div[rel='layoutItemTitle']").text();
                var liID = 'child' + count;

                $(this).attr('id', liID);
                if ($(this).children('parent').length) {
                    $(this).children('parent').each(function () {
                        $(this).attr('childOf', liID);
                    })
                }
                var layoutItem = $("<input type='hidden' name='layoutItemData[" + liID + "][title]' value='" + title + "' />");
                $('#layoutItemDataDiv').append(layoutItem);
                var className = $("<input type='hidden' name='layoutItemData[" + liID + "][className]' value='" + $(this).attr('className') + "' />");


                $('#layoutItemDataDiv').append(className);
                var layoutItemStyle = $(this).attr('style');
                var width = $(this).attr('style').match("width: [0-9]+");
                if (width != null && width[0]) {
                    width = $("<input type='hidden' name='layoutItemData[" + liID + "][width]' value='" + width[0].replace('width: ', '') + "' />");
                    $('#layoutItemDataDiv').append(width);
                }
                var layoutItemId = $("<input type='hidden' name='layoutItemData[" + liID + "][layoutItemId]' value='" + $(this).attr('layoutItemId') + "' />");
                $('#layoutItemDataDiv').append(layoutItemId);

                var layoutItemQueryString = $("<input type='hidden' name='layoutItemData[" + liID + "][layoutItemQueryString]' value='" + $(this).attr('layoutItemQueryString') + "' />");
                $('#layoutItemDataDiv').append(layoutItemQueryString);
                var useCache = $("<input type='hidden' name='layoutItemData[" + liID + "][useCache]' value='" + $(this).attr('useCache') + "' />");
                $('#layoutItemDataDiv').append(useCache);

                var controller = $("<input type='hidden' name='layoutItemData[" + liID + "][layoutItemController]' value='" + $(this).attr('layoutItemController') + "' />");
                $('#layoutItemDataDiv').append(controller);
                var action = $("<input type='hidden' name='layoutItemData[" + liID + "][layoutItemAction]' value='" + $(this).attr('layoutItemAction') + "' />");
                $('#layoutItemDataDiv').append(action);
                var view = $("<input type='hidden' name='layoutItemData[" + liID + "][layoutItemView]' value='" + $(this).attr('layoutItemView') + "' />");
                $('#layoutItemDataDiv').append(view);

            });
            var childOf = ul.attr('childOf');
            var input = $("<input type='hidden' name='layoutItems[" + childOf + "]' value='" + ul.sortable('toArray') + "' />");
            $('#layoutItemDataDiv').append(input);
        });
        $('#editObject<?php echo $object->id ?>').submit();
        $('#saveLayout').hide();
    });

    /**
     * Make the layout sortable/draggable etc.
     * Makes it editable.
     */
    $().ready(function () {
        $('#layoutEditor parent').addClass('sortable droptrue connectedSortable');
        $('#layoutEditor child').each(function () {
            var li = $(this);
            li.addClass('ui-state-default');
            makeItResizable(li);
            addEditOptions(li);//Add the options to edit/add extra child etc.
        });
        sortIt();
        //        $('#layoutEditor > input').change(function(){showSaveLayout()});
        $('input').bind('change keyup', function () {
            showSaveLayout()
        });
    })
</script>
<style>
    .connectedSortable, .ui-resizable{ min-height: 100px; min-width: 100px; display: block;}
</style>