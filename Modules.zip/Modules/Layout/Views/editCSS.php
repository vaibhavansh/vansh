//Font<br />
//Color<br />
//Text Decoration<br />
//Alignment<br />
//Text Transformation<br />
//Margin
//Padding
//border
//min-height
//max-height
//line-height
//text-shadow
//list CSS(ul/li)
//list-style
