<h2>Generated HTML for <?php echo $object->title ?></h2>
<div class="spacer20"></div>
<textarea class="grid_11" style="height:300px" id="generatedHTML"><?php $object->getTemplate($object->getChild('li0', $object->items)); ?></textarea>
<br />
<script>
    $('#generatedHTML').text(makeReadable($('#generatedHTML').text()));
</script>
