<div id="editLayoutItem"  style ="display:none" title="Edit Layout Item">
    <div class="grid_12 omega alpha">
        <h2>Edit Div</h2>
        <div class="spacer20"></div>
        <div class="grid_4 omega">
            Title
        </div>
        <input type="textbox" name="title" id="layoutItemTitle"  class="grid_6 alpha"/>
        <div class="spacer"></div>
        <div class="grid_4 omega">
            ID(Unique to the layout)
        </div>
        <input type="textbox" name="id" id="layoutItemId"  class="grid_6 alpha"/>
        <div class="spacer"></div>
        <div class="grid_4 omega">
            Controller
        </div>
        <input type="textbox" name="controller" id="layoutItemController"  class="grid_6 alpha"/>
        <div class="spacer"></div>
        <div class="grid_4 omega">
            Action
        </div>
        <input type="textbox" name="action" id="layoutItemAction"  class="grid_6 alpha"/>
        <div class="spacer"></div>
        <div class="grid_4 omega">
            QueryString
        </div>
        <input type="textbox" name="queryString" id="layoutItemQueryString"  class="grid_6 alpha"/>
        <div class="spacer"></div>
        <div class="grid_4 omega">
            View
        </div>
        <input type="textbox" name="view" id="layoutItemView"  class="grid_6 alpha"/>
        <div class="spacer"></div>
        <div class="grid_4 omega">
            Classname
        </div>
        <input type="textbox" name="className" id="className"  class="grid_6 alpha"/>
        <div class="spacer"></div>
        <div class="grid_12 omega alpha">
            <input type="button" value ="OK" id='editLayoutItemOK'/>
            <input type="button" value ="Cancel" id='editLayoutItemCancel'/>
        </div>

    </div>
</div>