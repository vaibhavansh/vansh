<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Layout
 *
 * @author admin
 */
class Layout_Models_Layout extends Core_Models_DbTable {

    static $table = 'layouts';
    static $renderTypes = array('Website', 'Email', 'Mobile');

    /**
     * Render the actual page
     */
    function render() {
        echo "<div id='main'>";
        echo "<div id='pageWrapper'>";
        echo "<div class='col-xs-12 floatingDiv' id='resultDiv'></div>";
        echo "<div class='col-sm-8 col-xs-10 popUpDiv' id='popUpDiv'><div id='popUpDivData'></div></div>";
        $this->renderLayoutItems($this->getChild('li0', $this->items));
        echo "</div>";
        echo "</div>";
    }

    /**
     * Display a div and it's child divs, recursively.
     * Function used on front end to render page.
     * @param type $divs
     */
    function renderLayoutItems($divs) {
        foreach ($divs as $div) {
            if ($div->layoutItemId == 'mainContent') {
                self::getMainContent($div);
            } else if (!empty($div->layoutItemController) && !empty($div->layoutItemAction) && $div->layoutItemController != 'undefined') {
                if (!self::isCached($div))
                    self::getDivContent($div);
            }
            echo "<div id='{$div->layoutItemId}' style='' class='{$div->className}'>";
            self::showDivContent($div);
            $childs = $this->getChild($div->id, $this->items);
            if (!empty($childs)) {
                $this->renderLayoutItems($childs);
            }
            echo "<div style='clear:both'></div>";
            echo '</div>';
            flush();
        }
    }

    /**
     * Call the actual action in controller and set the variables for the div.
     * @param type $div
     */
    static function getDivContent(&$div) {
        if (empty($div->variables)) {
            $div->variables = call_user_func_array(array(new $div->layoutItemController, $div->layoutItemAction), explode(',', $div->layoutItemQueryString));
        }
    }

    /**
     * Include the view of the file on layout.
     * @param type $div
     */
    function showDivContent(&$div) {
        if (!self::isCached($div)) {
            if (!empty($div->variables)) {
                extract($div->variables);
            }

            #Check if view is set in controller action#
            $div->layoutItemView = isset($view) ? $view : $div->layoutItemView;
            $pluginName = explode('_', isset($div->model) ? $div->model : str_replace('sController', '', $div->layoutItemController));
            $viewFolders[] = 'Views';
            global $page;
            if($page->mobileVersion){
                array_unshift($viewFolders, 'mobileViews');
//               $viewFolders[] = 'mobileViews';
            }
            ob_start();
            foreach($viewFolders as $viewFolder){
            if (file_exists(SITES_MODULE_DIRECTORY . DS . $pluginName[0] . DS . $viewFolder . DS . $div->layoutItemView . '.php')) {
                include (SITES_MODULE_DIRECTORY . DS . $pluginName[0] . DS . $viewFolder . DS . $div->layoutItemView . '.php');

//                echo '<code class="hidden-code" style="display:none;">Edit me here: ' . SITES_MODULE_DIRECTORY . DS . $pluginName[0] . DS . $viewFolder . DS . $div->layoutItemView . '.php</code>';
                 break;
            } elseif (file_exists(CORE_MODULE_DIRECTORY . DS . $pluginName[0] . DS . $viewFolder . DS . $div->layoutItemView . '.php')) {
                include (CORE_MODULE_DIRECTORY . DS . $pluginName[0] . DS . $viewFolder . DS . $div->layoutItemView . '.php');

//                 echo '<code class="hidden-code" style="display:none;">Edit me here: ' . CORE_MODULE_DIRECTORY . DS . $pluginName[0] . DS . $viewFolder . DS . $div->layoutItemView . '.php</code>';
                 break;
            } elseif (file_exists(CORE_MODULE_DIRECTORY . DS . 'Core' . DS . $viewFolder . DS . $div->layoutItemView . '.php')) {
                include (CORE_MODULE_DIRECTORY . DS . 'Core' . DS . $viewFolder . DS . $div->layoutItemView . '.php');break;
//                echo '<code class="hidden-code" style="display:none;">Edit me here: ' . ROOT . DS . 'modules' . DS . 'Core' . DS . $viewFolder . DS . $div->layoutItemView . '.php</code>';
            }
            }
            $divData = ob_get_contents();
            ob_clean();
            echo $divData;
            if (Config::getConfig('ENVIRONMENT') == 'DEVELOPMENT' || !empty($div->useCache)) {
                self::cacheDiv($divData, $div->layoutItemId);
            }
        } else {
            self::showCachedDiv($div);
        }
    }

    function cacheDiv($html, $layoutItemId) {
        global $page;
        global $cache;
        if(!Config::getConfig('ENVIRONMENT') == 'DEVELOPMENT'){
        $cache->save($html, $page->cacheUrl . '_' . str_replace(array(' ', '-'), '', $layoutItemId));
        }
    }

    function isCached(&$div) {
        if (isset($div->cached))
            return true;
        if (!empty($div->useCache)) { // so I can use cache
            //Let's see if the cached data exists and is not expired.
            global $cache;
            global $page;
            if (($data = $cache->load($page->cacheUrl . '_' . str_replace('-', '', $div->layoutItemId))) === false) {
                return false;
            } else {
                $div->cached = true;
                return true;
            }
        }
        return false;
    }

    function showCachedDiv($div) {
        global $page;
        global $cache;
        echo $cache->load($page->cacheUrl . '_' . str_replace('-', '', $div->layoutItemId));
    }

    /**
     * Load CSS for the given layout
     */
    function loadCSS() {
        foreach (explode(', ', $this->css) as $cssFile) {
            Core_Models_Utility::includeCSS($cssFile);
        }
    }

    /**
     * Load the Javascript Files for given layout.
     */
    function loadJS() {
        foreach (explode(', ', $this->js) as $jsFile) {
            Core_Models_Utility::includeJS($jsFile);
        }
    }

    /**
     * Get the maincontent div for the layout from page class.
     * The main content is set in page class
     * @global type $page
     * @param type $div
     */
    static function getMainContent(&$div) {
        global $page;
        foreach ($page->mainContent as $k => $v) {
            $div->$k = $v;
        }
        return $div;
    }

    /**
     * Function to get the layout items in parent/child tag
     * Used for editing layout. NOT FOR PRINTING. NO AHREF TAG
     * @param type $mainLayout
     * @param type $layoutItems
     */
    public function getLayout($mainLayout) {
        if (!empty($mainLayout))
            foreach ($mainLayout as $layoutItem) {
                echo "<child
                id='$layoutItem->id' title='{$layoutItem->title}' class='col-xs-12 lightGreyBackground' className='{$layoutItem->className}' layoutItemController='{$layoutItem->layoutItemController}' layoutItemAction='{$layoutItem->layoutItemAction}' layoutItemView='{$layoutItem->layoutItemView}' layoutItemId='{$layoutItem->layoutItemId}' layoutItemQueryString='{$layoutItem->layoutItemQueryString}' style='width: {$layoutItem->width}px' useCache='" . (isset($layoutItem->useCache) ? $layoutItem->useCache : 0) . "'>";
                echo "<div rel='layoutItemTitle' class='col-sm-4 col-xs-12 '>{$layoutItem->title}</div>";

                $childs = $this->getChild($layoutItem->id, $this->items);
                if (!empty($childs)) {
                    echo "<parent>";
                    $this->getLayout($childs, $this->items);
                    echo "</parent>";
                }
                echo '</child>';
            }
    }

    /**
     * Get Just the template from layout. Used on edit layout to print the template html.
     * won't generate data, just html for layout divs.
     * @param type $divs
     */
    function getTemplate($divs) {
        foreach ($divs as $div) {
            echo "<div id='{$div->layoutItemId}' style='float:left; width:{$div->width}px' class='{$div->className}'>";
            echo $div->title . '<br />';
            $childs = $this->getChild($div->id, $this->items);
            if (!empty($childs)) {
                $this->getTemplate($childs);
            }
            echo "<div style='clear:both'></div>";
            echo '</div>';
        }
    }

    /**
     * ITERATE THROUGH LAYOUT ITEMS AND GET THE CHILDS OF GIVEN LAYOUT ITEM.
     *
     * @param type $itemID
     * @param type $layoutItems
     * @return array
     */
    public function getChild($itemID, $layoutItems) {
        $childs = array();
        if (!empty($layoutItems))
            foreach ($layoutItems as $item) {
                if ($item->child_of == $itemID)
                    array_push($childs, $item);
            }
        return $childs;
    }

    /**
     * RETURNS ALL THE Divs FOR A Layout. JSON DECODES THE DATA FROM TABLE.
     * @return type
     */
    function items() {
        $this->items = json_decode($this->layout_items);
        return $this->items;
    }
    /*
     * 
     * @param type $controller
     * @param type $action
     * @param type $view
     * @param type $queryString
     * @return HMTL of view according to controller and action 
     * $variables['notificationsHtml']=Layout_Models_Layout::getWidget('Notification_Controllers_NotificationsController','index','index');
     *
     */
    function getWidget($controller,$action='index',$view='index',$queryString='')
    {
        $div= (object) array('layoutItemId'=>$view,'layoutItemController'=>$controller,'layoutItemAction'=>$action,'layoutItemView'=>$view,'layoutItemQueryString'=>$queryString);
        ob_start();
        self::getDivContent($div);
        self::showDivcontent($div);
        $div_data=  ob_get_contents();
        ob_clean();
        return $div_data;
    }
}

?>
