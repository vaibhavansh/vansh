<?php

class Layout_Controllers_LayoutsController extends Core_Controllers_SitesController {

    function edit($id=0) {
        $variables = parent::edit($id);
        $variables['layoutItemController'] = new OptionBox(array('optionBoxData' => Core_Models_Site::getControllers(), 'id' => "layoutItemController", 'name' => 'controller', 'className' => 'grid_6 alpha required','noneOption'=>1));
        return $variables;
    }

    /**
     * SAVE LAYOUT AND LAYOUT ITEMS.
     * @return type
     */
    function save() {
        $layout = new Layout_Models_Layout($_POST['id']);
        $layout_items = array();
        if (!empty($_POST['layoutItems'])) {
            foreach ($_POST['layoutItems'] as $key => $ul) {
                if (!empty($ul)) {
                    $lis = explode(',', $ul);
                    if (!empty($lis))
                        foreach ($lis as $li) {
                            if (!empty($li)) {
                                $layout_items[$li] = array('id' => $li, 'title' => $_POST['layoutItemData'][$li]['title'], 'width' => isset($_POST['layoutItemData'][$li]['width']) ? $_POST['layoutItemData'][$li]['width'] : '', 'useCache' => isset($_POST['layoutItemData'][$li]['useCache']) ? $_POST['layoutItemData'][$li]['useCache'] : 0, 'layoutItemController' => $_POST['layoutItemData'][$li]['layoutItemController'], 'layoutItemId' => $_POST['layoutItemData'][$li]['layoutItemId'], 'layoutItemAction' => $_POST['layoutItemData'][$li]['layoutItemAction'], 'layoutItemQueryString' => $_POST['layoutItemData'][$li]['layoutItemQueryString'], 'layoutItemView' => $_POST['layoutItemData'][$li]['layoutItemView'], 'className' => $_POST['layoutItemData'][$li]['className'], 'child_of' => $key, 'layout_id' => $layout->id);
                            }
                        }
                }
            }
        }
        $_POST['layout_items'] = json_encode($layout_items);
        $variables = parent::save($_POST);
        return array();
    }

    function generateTemplate($layoutId) {
        $variables['object'] = new Layout_Models_Layout($layoutId);
        return $variables;
    }

}
