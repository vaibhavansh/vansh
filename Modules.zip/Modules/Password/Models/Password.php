<?php

/**
 *
 * @author saurabhgandhe
 */
class Password_Models_Password extends Core_Models_DbTable {

    static $table = 'passwords';
    static $fields = NULL;
    static $passwordTypes = array('administration' => 'Admin Only', 'employee' => 'All Employees', 'user_specific' => 'Employee Specific');

    public function getPasswordByID($passwordId) {
        $passwordName = array_shift(Password_Models_Password::find_all(array('where' => "id = '{$passwordId}'",
            'cols' => "passwords.title")));
        return $passwordName->title;
    }

    public function getPasswords($where = '', $paged = 1) {
        $passwordLists = new Core_Models_Paginatenew(array('class_name' => 'Password_Models_Password'));
        $query = array('where' => $where, 'pageNumber' => $paged);
        $passwordLists->data = $passwordLists->getPaginatedData($query);
        return $passwordLists;
    }

    public function getPasswordRequest($where = '', $paged = 1) {
        $viewRequestPasswords = new Core_Models_Paginatenew(array('class_name' => 'Password_Models_Password'));
        $viewRequestPasswords->data = $viewRequestPasswords->getPaginatedData(array('where' => "user_passwords.status = 2 {$where}",
            'pageNumber' => $paged,
            'join' => "user_passwords on user_passwords.password_id = passwords.id join users on users.id = user_passwords.user_id",
            'cols' => "passwords.*, user_passwords.status, concat(name,' ' ,lastName) as fullName"));
        return $viewRequestPasswords;
    }

    public function getEmployeePasswords($userid = '', $paged = 1) {
        $empPasswordList = new Core_Models_Paginatenew(array('class_name' => 'Password_Models_Password'));
        $query = array(
            'where' => "users.id = '" . $userid . "'",
            'join' => "user_passwords on user_passwords.password_id = passwords.id join users on users.id = user_passwords.user_id",
            'cols' => "passwords.*, user_passwords.reason, user_passwords.status,users.image, user_passwords.id as passwordtagId, concat(name,' ' ,lastName) as fullName",
            'pageNumber' => $paged
        );
        $empPasswordList->data = $empPasswordList->getPaginatedData($query);
        return $empPasswordList;
    }

    public function getPasswordTypes() {
        return self::$passwordTypes;
    }

}

?>
