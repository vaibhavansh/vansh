<?php global $page; ?>
<section id="content_wrapper">
    <section id="content">
        <div class="spacer20"></div>
        <div id="animation-switcher">
            <?php User_Controllers_UsersController::userProfileMenus($userid); ?>
            <div class="clearfix"></div>
            <div id="view_profile" name="view_profile">
                <div class="col-md-9 col-sm-8">
                    <div class="panel mb25 mtn">
                        <div class="panel-heading">
                            <span class="panel-title"> 
                                <i class="fa fa-th-list hidden-xs"></i> 
                                <?php echo $header; ?>
                            </span>
                        </div>
                        <?php if (!empty($sharedPasswords->data)) { ?>
                            <div class="panel-body pn">
                                <div class="list-com" id="list-com">
                                    <div class="col-sm-12 com-detail pt10">
                                        <div class="col-sm-4 col-xs-12"><p><strong>Password Title</strong></p></div>
                                        <div class="col-sm-5 hidden-xs"><p><strong>Reason</strong></p></div>
                                        <div class="col-sm-3 hidden-xs text-right"><p><strong>Action</strong></p></div>
                                        <div class="clearfix"></div>
                                    </div><div class="clearfix"></div><div class="clearfix"></div>
                                    <?php
                                    foreach ($sharedPasswords->data as $sharedPassword) {
                                        ?>
                                        <div class="col-sm-12 com-detail p5" id="section_<?php echo $sharedPassword->id ?>">
                                            <div class="col-sm-4 col-xs-12">
                                                <p><?php echo $sharedPassword->title; ?></p>
                                            </div>
                                            <div class="col-md-5 col-xs-12">
                                                <p><?php echo $sharedPassword->reason; ?></p>
                                            </div>
                                            <div class="col-md-3 col-xs-12 text-right">
                                                <div class="btn-group text-right">
                                                    <?php
                                                    if ($sharedPassword->status == 1) {
                                                        $class = 'btn-warning';
                                                    } else
                                                    if ($sharedPassword->status == 2) {
                                                        $class = 'btn-success';
                                                    } else
                                                    if ($sharedPassword->status == 3) {
                                                        $class = 'btn-danger';
                                                    }
                                                    ?>
                                                    <button type="button" data-toggle="dropdown" aria-expanded="false" class="btn <?php echo $class; ?> br2 btn-xs fs12 dropdown-toggle">
                                                        <?php echo Password_Models_UserPassword::$requestStatus[$sharedPassword->status]; ?>
                                                        <span class="caret ml5"></span>
                                                    </button>
                                                    <?php if (($page->currentUser->id == $sharedPassword->current_user_id) && ($page->currentUser->webUserRole != '2') && ($sharedPassword->status == 2)) { ?>
                                                        <ul role="menu" class="dropdown-menu">
                                                            <?php if ($page->currentUser->id == $sharedPassword->pwdUserId) {
                                                                ?>
                                                                <li><a href="/editpassword/<?php echo $sharedPassword->password_id; ?>/" rel="popUpBox">Edit</a></li>
                                                            <?php }
                                                            ?>
                                                            <li><a href="/viewpassword/<?php echo $sharedPassword->password_id; ?>/" rel="popUpBox">View</a></li>
                                                        </ul>
                                                        <?php
                                                    } else if ($page->currentUser->webUserRole == '2') {
                                                        if ($sharedPassword->status != 3 && $sharedPassword->status != 2) {
                                                            ?>
                                                            <ul role="menu" class="dropdown-menu">
                                                                <li><a href="Javascript:void(0);" onclick="return toggleStatus('Password_Models_UserPassword', '<?php echo $sharedPassword->id ?>', '2', '<?php echo $_SERVER['REQUEST_URI']; ?>', '<?php echo $userid; ?>', 'Accept successfully')">Accept</a></li>
                                                                <li><a href="Javascript:void(0);" onclick="deleteRow('<?php echo $sharedPassword->id ?>', '<?php echo $sharedPassword->fullName; ?>', 'deletesharepassword', '<?php echo $_SERVER['REQUEST_URI']; ?>', 'from this passwrod list');">Reject</a></li>
                                                            </ul>
                                                        <?php } else if ($sharedPassword->status == 3 || $sharedPassword->status == 2) {
                                                            ?>
                                                            <ul role="menu" class="dropdown-menu">
                                                                <li><a href="Javascript:void(0);" onclick="deleteRow('<?php echo $sharedPassword->id ?>', '<?php echo $sharedPassword->fullName; ?>', 'deletesharepassword', '<?php echo $_SERVER['REQUEST_URI']; ?>', 'from this passwrod list');">Remove</a></li>
                                                            </ul>
                                                            <?php
                                                        }
                                                    }
                                                    ?>
                                                </div>
                                            </div>
                                            <div class="clearfix"></div>
                                        </div><div class="clearfix"></div><div class="clearfix"></div>
                                    <?php } ?>
                                    <div class="list-com-data pn">
                                        <div class="panel-body pn">
                                            <div class="com-detail ">
                                                <div class="col-xs-12 pt5">
                                                    <div class="pull-left">                             
                                                        <h5><?php echo $sharedPasswords->getCurrentPageInfo(); ?></h5>
                                                    </div>
                                                    <div class="pull-right" >   
                                                        <?php echo $sharedPasswords->printPageNumbers(array('url' => '/employeesharedpasswords/' . $userid, 'div_id' => 'mainContent', 'ajaxRequest' => true)); ?>
                                                    </div>
                                                </div>
                                            </div> 
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } else { ?>
                            <div class="list-com-data pn">
                                <div class="panel-body pn">
                                    <div class="com-detail ">
                                        <div class="col-lg-12 p25">
                                            Passwords Not Found.
                                        </div>
                                    </div> 
                                </div>
                            </div>
                        <?php } ?>
                    </div>
                </div>
                <?php if (!empty($shareUserPassword) && $page->currentUser->webUserRole == '2') { ?>
                    <aside data-tray-height="match" class="tray tray-center side-div pn">
                        <?php echo $shareUserPassword; ?>
                    </aside>
                <?php } else if (!empty($requestUserPassword) && $page->currentUser->webUserRole != '2') { ?>
                    <aside data-tray-height="match" class="tray tray-center side-div pn">
                        <?php echo $requestUserPassword; ?>
                    </aside>
                    <?php
                }
                ?>
            </div>
        </div>
    </section>
</section>