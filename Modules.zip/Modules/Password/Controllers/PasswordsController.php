<?php

class Password_Controllers_PasswordsController extends Core_Controllers_SitesController {

    function viewPasswords($currentUser = '') {
        global $page;
        $tags = func_get_args();
        $where = '';
        $requestWhere = '';
        $variables['pageNumber'] = array_pop($tags);
        if (!(substr($variables['pageNumber'], 0, 5) == 'page_')) {
            $tags[] = $variables['pageNumber'];
            $variables['pageNumber'] = 'page_1';
        }
        if ($page->currentUser->webUserRole != '2') {
            $requestWhere = "and user_passwords.user_id = '{$page->currentUser->id}'";
            if (isset($_POST['searchTitle']) && $_POST['searchTitle']) {
                $variables['searchTitle'] = $_POST['searchTitle'];
                $where .= " and (passwords.password_tags like '%" . $variables['searchTitle'] . "%' OR passwords.title like '%" . $variables['searchTitle'] . "%')";
            }
            $paginatedContent = Password_Models_Password::getPaginatedData(array('where' => "user_passwords.status = '2' and user_passwords.user_id = '{$page->currentUser->id}'" . $where,
                        'join' => "user_passwords on user_passwords.password_id = passwords.id",
                        'cols' => "passwords.*",
                        'orderBy' => "passwords.id desc",
                        'pageNumber' => $variables['pageNumber']
            ));
            $variables['passwords'] = $paginatedContent;
            $variables['header'] = 'Password List';
        }
        if ($page->currentUser->webUserRole == '2') {
            if (isset($_POST['searchTitle']) && $_POST['searchTitle']) {
                $variables['searchTitle'] = $_POST['searchTitle'];
                $where .= "(passwords.password_tags like '%" . $variables['searchTitle'] . "%' OR passwords.title like '%" . $variables['searchTitle'] . "%')";
            }
            $paginatedContent = Password_Models_Password::getPaginatedData(array('where' => $where,
                        'orderBy' => "passwords.id desc",
                        'pageNumber' => $variables['pageNumber']
            ));
            $variables['passwords'] = $paginatedContent;
            $variables['header'] = 'Password List';
        }
        $paginatedContentRequest = Password_Models_UserPassword::getPaginatedData(array('where' => "user_passwords.status = 1 {$requestWhere}",
                    'join' => "passwords on passwords.id = user_passwords.password_id join users on users.id = user_passwords.user_id",
                    'orderBy' => "user_passwords.id desc",
                    'cols' => "user_passwords.*,users.image,concat(name,' ' ,lastName) as fullName,passwords.title",
                    'pageNumber' => $variables['pageNumber']
        ));
        $variables['requestPasswords'] = $paginatedContentRequest;
        $variables['requestHeader'] = 'Requested Password List';
        $variables['addform'] = Layout_Models_Layout::getWidget('Password_Controllers_PasswordsController', 'editpassword', 'editpassword');
        $variables['requestSharePassword'] = Layout_Models_Layout::getWidget('Password_Controllers_PasswordsController', 'requestSharePassword', 'requestsharepassword');
        $variables['currentUser'] = array_pop($tags);
        return $variables;
    }

    function editPassword($passwordId = '') {
        $tags = func_get_args();
        $variables = array();
        $variables['secured'] = array_pop($tags);
        if (!empty($passwordId)) {
            $variables['editpassword'] = new Password_Models_Password($passwordId);
            $variables['header'] = 'Edit Password';
        } else {
            $variables['header'] = 'Add New Password';
            $variables['view'] = 'createpassword';
        }
        return $variables;
    }

    function savePassword($passwordId = '') {
        global $page;
        $userId = $page->currentUser->id;
        $tags = func_get_args();
        $passwordId = (!empty($passwordId)) ? $passwordId : array_pop($tags);
        $createPasswordId = '';
        $_POST['password'] = base64_encode($_POST['passwordDecode']);
        if (isset($_POST['users']) && $_POST['privacy_level'] == 'user_specific') {
            $_POST['user_specific_ids'] = implode(',', $_POST['users']);
        }
        if (!empty($passwordId)) {
            $updatePassword = new Password_Models_Password($passwordId);
            $updatePassword->save($_POST);
            echo json_encode(array('status' => 'success', 'msg' => "Password Updated"));
            if ($_POST['privacy_level'] == 'user_specific') {
                foreach ($_POST['users'] as $postUsers) {
                    $noticeUser[]['id'] = $postUsers;
                }
            } else if ($_POST['privacy_level'] == 'administration') {
                $noticeUser = 'admin';
            } elseif ($_POST['privacy_level'] == 'employee') {
                $noticeUser = 'all';
            }
            $html = serialize(array('Password_Models_Password' => $passwordId));
            Notification_Models_Notification::AddNotifications($userId, $_POST['title'], 'Updated Password', $noticeUser, $html);
        } else {
            $createPassword = new Password_Models_Password();
            $createPasswordId = $createPassword->save($_POST);
            if (!empty($createPasswordId) && $_POST['webUserRole'] != '2') {
                $createUserPassword = new Password_Models_UserPassword();
                $createUserPassword->save(array('user_id' => $_POST['userId'], 'password_id' => $createPasswordId, 'status' => '2'));
            }
            if ($_POST['privacy_level'] == 'user_specific') {
                foreach ($_POST['users'] as $postUsers) {
                    $noticeUser[]['id'] = $postUsers;
                }
            } else if ($_POST['privacy_level'] == 'administration') {
                $noticeUser = 'admin';
            } elseif ($_POST['privacy_level'] == 'employee') {
                $noticeUser = 'all';
            }
            echo json_encode(array('status' => 'success', 'msg' => "Password Saved"));
            $html = serialize(array('Password_Models_Password' => $createPasswordId));
            Notification_Models_Notification::AddNotifications($userId, $_POST['title'], 'created new password', $noticeUser, $html);
        }
        return array();
    }

    function requestSharePassword() {
        $variables = array();
        global $page;
        $variables['webUserRole'] = $page->currentUser->webUserRole;
        if ($variables['webUserRole'] == '2') {
            $variables['passwords'] = Password_Models_Password::find_all();
        } else {
            $variables['passwords'] = Password_Models_Password::find_all(array('where' => "passwords.id NOT IN (SELECT password_id FROM user_passwords WHERE user_id = '{$page->currentUser->id}') and ((privacy_level LIKE 'employee')  OR (privacy_level LIKE 'user_specific' and user_specific_ids LIKE '%{$page->currentUser->id}%'))",
                        'cols' => "passwords.*",
                        'orderBy' => "passwords.id asc"));
        }
        if (isset($_POST['sharedbyadmin']) && !empty($_POST['sharedbyadmin']) && $_POST['sharedbyadmin'] == 'Shared By Admin') {
            if (!empty($_POST['employee']) && empty($_POST['passwords'])) {
                foreach ($_POST['employee'] as $employee) {
                    $tagUserPassword = new Password_Models_UserPassword();
                    $tagUserPassword->save(array('user_id' => $employee, 'password_id' => $_POST['password'], 'status' => '2'));
                    $noticeUserEmployee[]['id'] = $employee;
                }
                $html = serialize(array('Password_Models_UserPassword' => $_POST['password']));
                $passwordTitle = Password_Models_Password::getPasswordByID($_POST['password']);
                Notification_Models_Notification::AddNotifications($page->currentUser->id, $passwordTitle, 'Shared Password', $noticeUserEmployee, $html);
            } else if (!empty($_POST['passwords']) && empty($_POST['employee'])) {
                foreach ($_POST['passwords'] as $password) {
                    $tagUserPassword = new Password_Models_UserPassword();
                    $tagUserPassword->save(array('user_id' => $_POST['userid'], 'password_id' => $password, 'status' => '2'));
                    $html = serialize(array('Password_Models_UserPassword' => $password));
                    $passwordTitle = Password_Models_Password::getPasswordByID($password);
                    Notification_Models_Notification::AddNotifications($page->currentUser->id, $passwordTitle, 'Shared Password', $_POST['userid'], $html);
                }
            }
            echo json_encode(array('status' => 'success', 'msg' => "Password Shared With User."));
            die();
        }
        if (isset($_POST['requestbyuser']) && !empty($_POST['requestbyuser']) && $_POST['requestbyuser'] == 'requestbyuser') {
            $requestTagUser = new Password_Models_UserPassword();
            $requestTagUser->save(array('user_id' => $page->currentUser->id, 'password_id' => $_POST['password_id'], 'status' => '1', 'reason' => $_POST['reason']));
            echo json_encode(array('status' => 'success', 'msg' => "Your Password Sharing Request Sent Successfully."));
            $html = serialize(array('Password_Models_UserPassword' => $_POST['password_id']));
            $passwordTitle = Password_Models_Password::getPasswordByID($_POST['password_id']);
            Notification_Models_Notification::AddNotifications($page->currentUser->id, $passwordTitle, 'Shared Password', 'admin', $html);
            die();
        }
        return $variables;
    }

    public function getUntaggedUser($password) {
        $variables = parent::edit($password);
        $tags = func_get_args();
        $view = array_pop($tags);
        $taggedUsersId = array();
        $optionBoxData = array();
        $taggedUsers = User_Models_User::find_all(array('where' => "passwords.id = '" . $password . "' and user_passwords.status =2",
                    'join' => 'user_passwords on user_passwords.user_id = users.id join passwords on passwords.id = user_passwords.password_id',
                    'cols' => 'users.id'));
        if (!empty($taggedUsers)) {
            foreach ($taggedUsers as $taggedUser) {
                $taggedUsersId[] = $taggedUser->id;
            }
        }
        $users = User_Models_User::find_all(array('where' => 'users.webUserRole != 0 and users.webUserRole != 2 and users.status != 2 and users.status != 3',
                    'cols' => "concat(name,' ' ,lastName) as fullName,id"));
        foreach ($users as $user) {
            if (!in_array($user->id, $taggedUsersId)) {
                $optionBoxData[$user->id] = $user->fullName;
            }
        }
        $userSelector = new OptionBox(array('name' => 'employee[]',
            'id' => 'employees' . rand(10, 1000),
            'multiSelect' => true,
            'optionBoxData' => $optionBoxData,
            'className' => 'form-control select-primary',
            'noneOption' => 0,
            'noneOptionText' => 'Select User'));
        if (isset($_POST['popup'])) {
            echo $userSelector->generate();
        } else {
            $variables['userSelector'] = $userSelector->generate();
            $variables['password'] = $password;
        }
        if ($view == 'shareusers') {
            $variables['view'] = 'shareusers';
        }
        return $variables;
    }

    function viewShare() {
        $variables = array();
        global $page;
        $where = '';
        $tags = func_get_args();
        $variables['pageNumber'] = array_pop($tags);
        if (!(substr($variables['pageNumber'], 0, 5) == 'page_')) {
            $tags[] = $variables['pageNumber'];
            $variables['pageNumber'] = 'page_1';
        }
        if (isset($_POST['searchTitle']) && $_POST['searchTitle']) {
            $variables['searchTitle'] = $_POST['searchTitle'];
            $where .= "and ((users.name like ('%" . $variables['searchTitle'] . "%') OR (users.lastname like ('%" . $variables['searchTitle'] . "%'))) ) ";
        }
        $variables['passwordId'] = array_pop($tags);
        if (is_numeric($variables['passwordId'])) {
            $paginatedContent = Password_Models_Password::getPaginatedData(array('where' => "user_passwords.status = '2' and user_passwords.password_id = '{$variables['passwordId']}'" . $where,
                        'join' => "user_passwords on user_passwords.password_id = passwords.id join users on users.id = user_passwords.user_id",
                        'cols' => "user_passwords.*,users.image,concat(name,' ' ,lastName) as fullName,passwords.title",
                        'orderBy' => "user_passwords.user_id desc",
                        'pageNumber' => $variables['pageNumber']
            ));
            $variables['viewShares'] = $paginatedContent;
            $variables['header'] = 'Shared List';
        }
        $variables['addform'] = Layout_Models_Layout::getWidget('Password_Controllers_PasswordsController', 'editpassword', 'createpassword', $variables['passwordId']);
        $variables['requestSharePassword'] = Layout_Models_Layout::getWidget('Password_Controllers_PasswordsController', 'getUntaggedUser', 'shareusers', $variables['passwordId']);
        return $variables;
    }

    function employeeSharedPasswords() {
        $variables = array();
        global $page;
        $tags = func_get_args();
        $variables['pageNumber'] = array_pop($tags);
        if (!(substr($variables['pageNumber'], 0, 5) == 'page_')) {
            $tags[] = $variables['pageNumber'];
            $variables['pageNumber'] = 'page_1';
        }
        $variables['userid'] = array_pop($tags);
        $paginatedsharedPasswords = Password_Models_Password::getPaginatedData(array('where' => "user_passwords.user_id = '{$variables['userid']}'",
                    'join' => "user_passwords on user_passwords.password_id = passwords.id join users on users.id = user_passwords.user_id",
                    'orderBy' => "user_passwords.id desc",
                    'cols' => "user_passwords.*,users.image,concat(name,' ' ,lastName) as fullName,passwords.userId as pwdUserId,users.id as current_user_id,passwords.title",
                    'pageNumber' => $variables['pageNumber']
        ));
        if ($page->currentUser->webUserRole == '2') {
            $variables['superAdminView'] = Layout_Models_Layout::getWidget('Password_Controllers_PasswordsController', 'viewpasswords', 'viewpasswords');
        }
        $variables['sharedPasswords'] = $paginatedsharedPasswords;
        $variables['header'] = User_Models_User::getFullNameById($variables['userid']) . ' Shared Password List';
        $variables['shareUserPassword'] = Layout_Models_Layout::getWidget('Password_Models_UserPassword', 'getpasswordnotshared', 'shareusers', $variables['userid']);
        $variables['requestUserPassword'] = Layout_Models_Layout::getWidget('Password_Controllers_PasswordsController', 'requestSharePassword', 'requestSharePassword');
        return $variables;
    }
    
    function deletepassword($id = 0) {
        $password = new Password_Models_Password($id);
        if(!empty($password)) {
            global $page;
            $passwordId = new Password_Models_Password($password->id);
            Notification_Models_Notification::AddNotifications($page->currentUser->id, $passwordId->title, 'Remove shared password with you', $UserPassword->user_id, '');
        }
        parent::delete($id);
        return array();
    }

}

?>