<?php

class SiteMap_Controllers_SiteMapsController extends Core_Controllers_SitesController {

    function generateSiteMap() {
        set_time_limit(0);
                $this->layoutId = 2;

        global $page;
        $sitemap = new SiteMap_Models_SiteMap('sitemap.xml');
        define('SITEMAPDOMAIN','http://bollyduniya.com');
        #add main menu#
        #Home, Hindi Movies,Marathi Movies, Tv Show Home, Bollywood News.
        $mainMenu = array(SITEMAPDOMAIN, SITEMAPDOMAIN . '/movies/hindi', SITEMAPDOMAIN . '/movies/marathi', SITEMAPDOMAIN . '/tv-shows', SITEMAPDOMAIN . '/bollywood-news');
        foreach ($mainMenu as $item) {
            $sitemap->addItem(array('loc' => $item, 'lastmod' => $page->todayDate, 'changefreq' => 'daily'));
        }

        #Add Assets#
        #Movies(28), TV Shows(31), TV Episodes(786).
        $assets = Asset_Models_Asset::find_all(array('where' => 'published=1 and asset_type_id in (28,31,786,36)'));
        foreach ($assets as $asset) {
            $sitemap->addItem(array('loc' => SITEMAPDOMAIN . $asset->viewURL(), 'lastmod' => $asset->lastModified(), 'changefreq' => $asset->changeFrequency()));

        }
        #Add Tags
        #add star-cast,layout-category,genre, with hindi and marathi #
//       Star Cast
//       Genre
//       TV Channels
//       Layout Category(Home)
        #Star Cast Movies Hindi# 17,28,hi
        #added director pages.
        $tags = Tag_Models_Tag::find_all(array('where' => "child_of=17 or child_of=1573", 'join' => "asset_tags on asset_tags.tag_id = tags.id join assets on assets.id=asset_tags.asset_id and assets.lang = 'hi' and assets.asset_type_id=28 and assets.published=1", 'orderBy' => 'assets.modified desc', 'cols' => 'tags.id,tags.slug,date(assets.modified) as lastmod', 'groupBy' => 'tags.id'));
        foreach ($tags as $tag) {
            $sitemap->addItem(array('loc' => SITEMAPDOMAIN . '/movies/' . $tag->slug . '/hindi', 'lastmod' => $tag->lastmod));
        }
        #Star Cast Movies Marathi# 17,28,mr.
        #Added director pages.
        $tags = Tag_Models_Tag::find_all(array('where' => "child_of=17 or child_of=1573", 'join' => "asset_tags on asset_tags.tag_id = tags.id join assets on assets.id=asset_tags.asset_id and assets.lang = 'mr' and assets.asset_type_id=28 and assets.published=1", 'orderBy' => 'assets.modified desc', 'cols' => 'tags.id,tags.slug,date(assets.modified) as lastmod', 'groupBy' => 'tags.id'));
        foreach ($tags as $tag) {
            $sitemap->addItem(array('loc' => SITEMAPDOMAIN . '/movies/' . $tag->slug . '/marathi', 'lastmod' => $tag->lastmod));
        }
        #Genres Movies Hindi# 14,28,hi
        $tags = Tag_Models_Tag::find_all(array('where' => "child_of=14", 'join' => "asset_tags on asset_tags.tag_id = tags.id join assets on assets.id=asset_tags.asset_id and assets.lang = 'hi' and assets.asset_type_id=28 and assets.published=1", 'orderBy' => 'assets.modified desc', 'cols' => 'tags.id,tags.slug,date(assets.modified) as lastmod', 'groupBy' => 'tags.id'));
        foreach ($tags as $tag) {
            $sitemap->addItem(array('loc' => SITEMAPDOMAIN . '/movies/' . $tag->slug . '/hindi', 'lastmod' => $tag->lastmod));
        }
        #Genres Movies Marathi# 14,28,hi
        $tags = Tag_Models_Tag::find_all(array('where' => "child_of=14", 'join' => "asset_tags on asset_tags.tag_id = tags.id join assets on assets.id=asset_tags.asset_id and assets.lang = 'mr' and assets.asset_type_id=28 and assets.published=1", 'orderBy' => 'assets.modified desc', 'cols' => 'tags.id,tags.slug,date(assets.modified) as lastmod', 'groupBy' => 'tags.id'));
        foreach ($tags as $tag) {
            $sitemap->addItem(array('loc' => SITEMAPDOMAIN . '/movies/' . $tag->slug . '/marathi', 'lastmod' => $tag->lastmod));
        }
        #TV Channels TV Shows Hindi# 5925,31,hi
        $tags = Tag_Models_Tag::find_all(array('where' => "child_of=5925", 'join' => "asset_tags on asset_tags.tag_id = tags.id join assets on assets.id=asset_tags.asset_id and assets.lang = 'hi' and assets.asset_type_id=31 and assets.published=1", 'orderBy' => 'assets.modified desc', 'cols' => 'tags.id,tags.slug,date(assets.modified) as lastmod', 'groupBy' => 'tags.id'));
        foreach ($tags as $tag) {
            $sitemap->addItem(array('loc' => SITEMAPDOMAIN . '/tv-shows/' . $tag->slug . '/hindi', 'lastmod' => $tag->lastmod));
        }
        #TV Channels TV Shows marathi# 5925,31,hi
        $tags = Tag_Models_Tag::find_all(array('where' => "child_of=5925", 'join' => "asset_tags on asset_tags.tag_id = tags.id join assets on assets.id=asset_tags.asset_id and assets.lang = 'mr' and assets.asset_type_id=31 and assets.published=1", 'orderBy' => 'assets.modified desc', 'cols' => 'tags.id,tags.slug,date(assets.modified) as lastmod', 'groupBy' => 'tags.id'));
        foreach ($tags as $tag) {
            $sitemap->addItem(array('loc' => SITEMAPDOMAIN . '/tv-shows/' . $tag->slug . '/marathi', 'lastmod' => $tag->lastmod));
        }
        #Layout category Movies Hindi# 773,28,hi
        $tags = Tag_Models_Tag::find_all(array('where' => "child_of=773", 'join' => "asset_tags on asset_tags.tag_id = tags.id join assets on assets.id=asset_tags.asset_id and assets.lang = 'hi' and assets.asset_type_id=28 and assets.published=1", 'orderBy' => 'assets.modified desc', 'cols' => 'tags.id,tags.slug,date(assets.modified) as lastmod', 'groupBy' => 'tags.id'));
        foreach ($tags as $tag) {
            $sitemap->addItem(array('loc' => SITEMAPDOMAIN . '/movies/' . $tag->slug . '/hindi', 'lastmod' => $tag->lastmod));
        }


        echo 'URL Count: ' . $sitemap->urlCount;
        return array();
    }


}

