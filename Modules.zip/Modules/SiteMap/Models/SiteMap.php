<?php

class SiteMap_Models_SiteMap extends Core_Models_DbTable {

    static $table = 'site_maps';
    static $fields = null;
    public $urlCount = 0;

    public function __construct($fileName = 'sitemap.xml') {
        $this->xml = new DOMDocument();
        $this->xml->formatOutput = false;
        $this->xml->preserveWhiteSpace = false; #need this to have formatoutput work
        $this->xml->validateOnParse = true;
        $this->sitemapFile = PUBLIC_FOLDER . DS . $fileName;
        $this->loadSiteMapFile();
        $this->xPath = new DOMXPath($this->xml);
    }

    /**
     * Creates a new xml file with urlset.
     */
    function createNewSiteMap() {
        $data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
        $data .= "<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">";
        $data.="</urlset>";
        $xmlfile = fopen($this->sitemapFile, 'w');
        if ($xmlfile) {
            fwrite($xmlfile, $data);
            fclose($xmlfile);
        }
    }

    function loadSiteMapFile() {
        if (1 || !file_exists($this->sitemapFile)) { #Create a new sitemap every time.
            $this->createNewSiteMap();
        }
        $this->xml->load($this->sitemapFile);
    }

    /**
     * Add Item to Sitemap
     * @param type $item[['loc']
     */
    function addItem($item) {
        if (!empty($item['loc'])) {
            $urlLoc = 'url[loc="' . $item['loc'] . '"]';
            if (!$this->isDuplicateURL($urlLoc)) {
                $sitemap = $this->xml->createElement("url");
                foreach ($item as $key => $value) {
                    if (!empty($item[$key])) {
                        $$key = $this->xml->createElement($key);
                        $$key->nodeValue = $item[$key];
                        $sitemap->appendChild($$key);
                    }
                }
                $this->xml->documentElement->appendChild($sitemap);
                $this->urlCount++;
                $this->xml->formatOutput = true;
                $this->xml->save($this->sitemapFile);
            }
        } else {
            echo "URL Empty";
        }
    }

    /**
     * Search the url in all sitemaps.
     * Currently it's only searching in current sitemap.
     * @param type $url
     * @return type
     */
    function isDuplicateURL($urlLoc) {
        return $this->xPath->query($urlLoc)->length;
    }

    /**
     * Remove Item from Sitemap
     * @param type $item['loc'] to remove
     */
    function removeItem($item) {
        $searchSiteMap = 'url[loc="' . $item['url'] . '"]';
        $items = $this->xPath->query($searchSiteMap);
        if ($items->length) {
            $this->xml->documentElement->removeChild($items->item(0));
            $this->xml->formatOutput = true;
            $this->xml->save($this->sitemapFile);
        } else {
            echo 'URL Not Found';
        }
    }

}

