<?php

class File_Models_File extends Core_Models_DbTable
{

    static $table = 'files';

    static $fields = null;


}

