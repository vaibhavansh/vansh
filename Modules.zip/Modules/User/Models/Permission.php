<?php

/**
 *
 * @author saurabhgandhe
 */
class User_Models_Permission extends Core_Models_DbTable {
static $table = 'permissions';
    static $fields = NULL;



}

?>
