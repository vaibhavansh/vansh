<?php

/**
 *
 * @author saurabhgandhe
 */
class User_Models_Attendance extends Core_Models_DbTable {

    static $table = 'attendances';
    static $fields = NULL;
    static function employeeLocation($ip = '') {
        if(empty($ip)){
            $ip = $_SERVER['REMOTE_ADDR'];
        }
       
        $ipaddresss = Asset_Models_Asset::find_all(array('where' => "assets.asset_type_id = '8' and status = 1 and description = '{$ip}' "));
        if (!empty($ipaddresss)) {
            return "Office";
        }else{
            return "Home";
        }
    }

}

?>
