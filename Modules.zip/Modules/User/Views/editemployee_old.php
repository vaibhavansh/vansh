<div class="panel mb25 mt5">
 <div id="editEmployeeResultDiv" class="resultDiv"></div>
    <div class="panel-heading"><span class="panel-title"> <i class="fa fa-user"></i> Edit Employee Details</span>
    </div>
    <div class="panel-body p20 pb10">
      
        <div class="tab-content pn br-n admin-form">
            <div id="tab1_1" class="tab-pane active">

                <div class="section row mbn">
                    <div class="col-md-12 pn">
                          <form keepVisible="1" role="form" resultDiv="editEmployeeResultDiv" action="/user_users/save" method="POST" id='<?php echo $employee->id; ?>editEmployee' rel='ajaxifiedForm' autocomplete="off" close_popup="1"  backToPage="/listusers" successMsg="Update User Details Successfully!">   
                            <input id="name" type="hidden" name="id" value="<?php echo $employee->id; ?>">
                            <input type="hidden" name="user_form_type" value="user_details_save">
                            <div class="section row mb15">
                                <div class="col-xs-12">
                                    <label for="name1" class="field prepend-icon">
                                        <input id="name" type="text" name="name" placeholder="First Name" value="<?php echo $employee->name; ?>" class="event-name gui-input br-light light required" autocomplete="off">
                                        <label for="name1" class="field-icon"><i class="fa fa-user"></i></label>
                                    </label>
                                </div>
                            </div>
                            <div class="section row mb15">
                                <div class="col-xs-12">
                                    <label for="name2" class="field prepend-icon">
                                        <input id="lastname" type="text" name="lastname" placeholder="Last Name"  value="<?php echo $employee->lastname; ?>" class="event-name gui-input br-light light required" autocomplete="off">
                                        <label for="name2" class="field-icon"><i class="fa fa-user"></i></label>
                                    </label>
                                </div>
                            </div>
                            <div class="section row mb15">
                                <div class="col-xs-12">
                                    <label for="email" class="field prepend-icon">
                                        <input id="email" type="email" name="email" placeholder="Email Address"  value="<?php echo $employee->email; ?>" class="event-name gui-input br-light light required" autocomplete="off">
                                        <label for="email" class="field-icon"><i class="fa fa-envelope-o"></i></label>
                                    </label>
                                </div>
                            </div>
                            <div class="section row mb15">
                                <div class="col-xs-12">
                                    <label for="phoneno" class="field prepend-icon">
                                        <input  id="phoneno1" type="text" name="phoneno" placeholder="Contact No" value="<?php echo $employee->phoneno; ?>" class="event-name gui-input br-light light phoneno alphanumeric required" autocomplete="off" maxlength="10"minlength="10">
                                        <label for="phoneno" class="field-icon"><i class="fa fa-mobile"></i></label>
                                        <p class="phonenoerror1"></p>
                                    </label>
                                </div>
                            </div>  
                            <div class="section row mb15">
                            <div class="col-xs-12">
                                <label for="password" class="field prepend-icon">
                                    <input id="password" type="password" name="password" placeholder="Password" value="<?php echo $employee->password; ?>" class="password event-name gui-input br-light light required" autocomplete="off">
                                    <label for="password" class="field-icon"><i class="fa fa-lock"></i></label>
                                    <p class="passworderror"></p>
                                </label>
                            </div>
                             </div> 
                            <div class="section row mb15">
                                <div class="col-xs-12">
                                    <label for="role" class="field select">
                                        <select class="event-name gui-input br-light light" name="webUserRole" id="webUserRole">
                                <option value="<?php echo $employee->webUserRole; ?>" disabled="" selected="">
                                                        <?php if ($employee->webUserRole == 1) {?>
                                                          Employee
                                                        <?php } ?>
                                                           <?php if ($employee->webUserRole == 2) {?>
                                                           Super Admin
                                                        <?php } ?>
                                                        <?php if ($employee->webUserRole == 3) {?>
                                                         Admin
                                                          <?php } ?>
                                   
                                </option>
                                            <option value="1">Employee</option>
                                            <option value="2">Super Admin</option>
                                            <option value="3">Admin</option>
                                        </select>
                                        <i class="arrow"></i>
                                    </label>
                                </div>
                            </div>
                               <div class="section row mb5">
                                            <div class="mr10 pull-right">
                                                <button class="button btn-danger col-xs-12 pull-right" onclick="cancel_onClick()"> Cancel </button>
                                            </div>
                                            <div class="mr10 pull-right">
                                                <button  type="submit" class="button btn-success col-xs-12 pull-right">Update</button>
                                            </div>
                                        </div>
                          
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    function cancel_onClick() { $('.close').click(); }
    
        $(document).on('keypress', ".alphabets1", function (e) {  
        if(e.keyCode > 58 && e.keyCode > 48) {         
          return false;
         }         
       });
</script>