<?php
global $page;
$rand = rand(10, 100);
?>
<div id="modal-form" class="mfp-with-anim">
    <?php
    if (!empty($column)) {
        ?>
        <div class="panel">
            <div id="save<?php echo $column; ?>ResultDiv" class="resultDiv"></div>
            <div class="panel-heading">
                <span class="panel-title">
                    <i class="fa fa-pencil hidden-xs"></i>
                    <?php echo $header; ?> Your Tagline
                </span><div class="clearfix"></div>
            </div>
            <form keepVisible="1" id="save<?php echo $column; ?>" role="form" name="save<?php echo $column; ?>" resultDiv="save<?php echo $column; ?>ResultDiv" close_popup="1" method="POST" rel='ajaxifiedForm' autocomplete="off" backToPage="/viewprofile" successMsg="Your <?php echo $column; ?> saved." action="/user_users/saveProfile/<?php echo $userdetailcol->id; ?>">
                <div class="panel-body p25 admin-form">
                    <div class="section row mb15">
                        <div class="col-xs-12">
                            <label for="<?php echo $column; ?>" class="field prepend-icon">
                                <input id="<?php echo $column; ?>" type="text" name="<?php echo $column; ?>" placeholder="<?php echo $column; ?>" class="event-name gui-input br-light light" value="<?php echo $userdetailcol->$column; ?>">
                                <label for="<?php echo $column; ?>" class="field-icon"><i class="fa fa-pencil"></i></label>
                            </label>
                        </div>
                    </div>
                    <div class="section row mb15">
                        <div class="col-xs-12">
                            <input type="submit" name="save" value="Save" class="button btn-success col-xs-12 pull-right">
                        </div>
                    </div>
                </div>
            </form>
        </div>
    <?php } else if ($header == "Edit") { ?>        
        <div class="panel">
            <div id="saveUserDetails<?php echo $rand; ?>ResultDiv" class="resultDiv"></div>
            <div class="panel-heading">
                <span class="panel-title">
                    <i class="fa fa-pencil hidden-xs"></i>
                    <?php echo $header; ?> User Details 
                </span><div class="clearfix"></div>
            </div>
            <form keepVisible="1" id="saveUserDetails<?php echo $rand; ?>" role="form" name="saveUserDetails" resultDiv="saveUserDetails<?php echo $rand; ?>ResultDiv" close_popup="1" method="POST" rel='ajaxifiedForm' autocomplete="off" backToPage="/listusers" successMsg="Details Update Successfully." action="/user_users/save/<?php echo $userdetailcol->id; ?>">
                <input type="hidden" name="sendMail" value="<?php echo $userdetailcol->send_mail; ?>">
                <input type="hidden" name="id" value="<?php echo $userdetailcol->id; ?>">
                <input type="hidden" name="user_form_type" value="user_details_save">
                <div class="panel-body p25 admin-form">
                    <div class="section row mb15">
                        <div class="col-xs-12">
                            <label for="firstname" class="field prepend-icon">
                                <input id="name" type="text" name="name" placeholder="First Name" class="event-name gui-input br-light light required" value="<?php echo $userdetailcol->name; ?>">
                                <label for="firstname" class="field-icon"><i class="fa fa-user"></i></label>
                            </label>
                        </div>
                    </div>
                    <div class="section row mb15">
                        <div class="col-xs-12">
                            <label for="lastname" class="field prepend-icon">
                                <input id="lastname" type="text" name="lastname" placeholder="Last Name" class="event-name gui-input br-light light required" value="<?php echo $userdetailcol->lastname; ?>">
                                <label for="lastname" class="field-icon"><i class="fa fa-user"></i></label>
                            </label>
                        </div>
                    </div>
                    <div class="section row mb15">
                        <div class="col-xs-12">
                            <label for="email" class="field prepend-icon">
                                <input id="email" type="text" name="email" placeholder="Email Address" class="event-name gui-input br-light light required" value="<?php echo $userdetailcol->email; ?>">
                                <label for="email" class="field-icon"><i class="fa fa-envelope"></i></label>
                            </label>
                        </div>
                    </div>
                    <div class="section row mb15">
                        <div class="col-xs-12">
                            <label for="phoneno" class="field prepend-icon">
                                <input id="contact" type="text" name="phoneno" placeholder="Contact" class="event-name gui-input br-light light phoneno alphanumeric required" value="<?php echo $userdetailcol->phoneno; ?>" maxlength="10" minlength="10">
                                <label for="phoneno" class="field-icon"><i class="fa fa-mobile"></i></label>
                            </label>
                        </div>
                    </div>
                    <?php if ($userdetailcol->webUserRole == '5') { ?>
                        <div class="section row mb15">
                            <div class="col-xs-12">
                                <label for="password" class="field prepend-icon">
                                    <input id="password" type="text" name="password" placeholder="Password(Default: <?php echo $userdetailcol->temp_pass_form; ?>)" class="event-name gui-input br-light light phoneno alphanumeric required" value="<?php echo $userdetailcol->temp_pass_form; ?>">
                                    <label for="password" class="field-icon"><i class="fa fa-mobile"></i></label>
                                </label>
                            </div>
                        </div>
                        <input type="hidden" name="status" value="2">
                    <?php } else { ?> 
                        <input type="hidden" name="password" value="<?php echo $userdetailcol->password; ?>">
                        <input type="hidden" name="status" value="<?php echo $userdetailcol->status; ?>">
                    <?php }
                    ?>
                    <div class="section row mb15">
                        <div class="col-xs-12">
                            <label for="role" class="field select">
                                <?php
                                $userRoles = User_Models_UserRole::find_all();
                                if (!empty($userRoles)) {
                                    ?>
                                    <select class="event-name gui-input br-light light required" name="webUserRole" id="webUserRole1">
                                        <option value="1" disabled="" selected="">Select User Role</option>
                                        <?php
                                        foreach ($userRoles as $userRole) {
                                            $selected = ($userRole->id == $userdetailcol->webUserRole) ? 'selected="selected"' : '';
                                            ?>
                                            <option value="<?php echo $userRole->id; ?>" <?php echo $selected; ?>><?php echo $userRole->title; ?></option>
                                        <?php } ?>
                                    </select>
                                    <i class="arrow"></i>
                                <?php } ?>
                            </label>
                        </div>
                    </div>
                    <div class="section row mb15">
                        <div class="col-xs-12">
                            <input type="submit" name="save" value="Save" class="button btn-success col-xs-12 pull-right">
                        </div>
                    </div>
                </div>
            </form>
        <?php } else { ?>
            <div class="panel mb25 mt5">
                <div id="registrationformResultDiv" class="resultDiv"></div>
                <div class="panel-heading"><span class="panel-title"> <i class="fa fa-user hidden-xs"></i> <?php echo $header; ?> New Employee</span><div class="clearfix"></div>
                </div>
                <div class="panel-body p20 pb10 admin-form">
                    <div class="tab-content pn br-n ">
                        <div id="tab1_1" class="tab-pane active">
                            <div class="section row mbn">
                                <div class="col-md-12 pn">                                    
                                    <form method="POST" resultDiv="registrationformResultDiv" id="registrationform" close_popup="1" keepvisible="1" role="form" action="/userssave/" rel="ajaxifiedForm" autocomplete="off" backToPage="/listusers" successMsg="User Save Successfully!"> 
                                        <input type="hidden" name="user_form_type" value="user_details_save">
                                        <input type="hidden" name="sendMail" value="0">
                                        <div class="section row mb15">
                                            <div class="col-xs-12">
                                                <label for="name" class="field prepend-icon">
                                                    <input id="name1" type="text" name="name" placeholder="First Name" class="name event-name gui-input br-light light required" autocomplete="off">
                                                    <label for="name" class="field-icon"><i class="fa fa-user"></i></label>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="section row mb15">
                                            <div class="col-xs-12">
                                                <label for="lastname" class="field prepend-icon">
                                                    <input id="lastname1" type="text" name="lastname" placeholder="Last Name" class="lastname event-name gui-input br-light light required" autocomplete="off">
                                                    <label for="lastname" class="field-icon"><i class="fa fa-user"></i></label>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="section row mb15">
                                            <div class="col-xs-12">
                                                <label for="email1" class="field prepend-icon">
                                                    <input id="email" type="email" name="email" placeholder="Email Address" class="emails event-name gui-input br-light light required" autocomplete="off">
                                                    <label for="email" class="field-icon"><i class="fa fa-envelope-o"></i></label>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="section row mb15">
                                            <div class="col-xs-12">
                                                <label for="password" class="field prepend-icon">
                                                    <input id="password" type="password" name="password" placeholder="Password" class="emails event-name gui-input br-light light required" autocomplete="off">
                                                    <label for="password" class="field-icon"><i class="fa fa-lock"></i></label>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="section row mb15">
                                            <div class="col-xs-12">
                                                <label for="phoneno" class="field prepend-icon">
                                                    <input id="phoneno1" type="text "name="phoneno" placeholder="Contact No" class=" event-name gui-input br-light light phoneno alphanumeric required" autocomplete="off" maxlength="10"minlength="10">
                                                    <label for="phoneno" class="field-icon"><i class="fa fa-mobile"></i></label>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="section row mb15">
                                            <div class="col-xs-12">
                                                <label for="company" class="field prepend-icon">
                                                    <input id="company" type="text" name="company" placeholder="Example: utest_bezoar(Default: bezoar)" class="event-name gui-input br-light light" autocomplete="off">
                                                    <label for="company" class="field-icon"><i class="fa fa-user"></i></label>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="section row mb15">
                                            <div class="col-xs-12">
                                                <label for="role" class="field select">
                                                    <?php
                                                    $userRoles = User_Models_UserRole::find_all();
                                                    if (!empty($userRoles)) {
                                                        ?>
                                                        <select class="event-name gui-input br-light light required" name="webUserRole" id="webUserRole1">
                                                            <option value="" disabled="" selected="">Select User Role</option>
                                                            <?php foreach ($userRoles as $userRole) { ?>
                                                                <option value="<?php echo $userRole->id; ?>"><?php echo $userRole->title; ?></option>
                                                            <?php } ?>
                                                        </select>
                                                        <i class="arrow"></i>
                                                    <?php } ?>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="section row mb15">
                                            <div class="col-xs-12">                                                   
                                                <button type="submit"  class="button btn-success col-xs-12 pull-right">Add Employee</button>

                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php } ?>
    </div>
</div>

