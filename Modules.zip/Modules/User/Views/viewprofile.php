<?php global $page; ?> 
<section id="content_wrapper">
    <!-- Begin: Content-->
    <section id="content" class="">
        <!-- Begin .page-heading-->
        <div id="animation-switcher">
            <div class="clearfix"></div>
            <?php User_Controllers_UsersController::userProfileMenus($user->id); ?>
            <div id="view_profile" name="view_profile" class="col-sm-12 pn">
                <?php
                if (!empty($userGroups)) {
                    ?>
                    <div class="col-md-12">
                        <div class="panel">
                            <div class="panel-heading">
                                <span class="panel-icon">
                                    <i class="fa fa-pencil hidden-xs"></i>
                                </span>
                                <span class="panel-title"><?php echo $header; ?></span>
                                <div class="clearfix"></div>
                            </div>
                            <div class="panel-body pb5">
                                <?php
                                $i = 1;
                                foreach ($userGroups as $userGroup) {
                                    $userGroupChild[] = $userGroup->child_group_id;
                                    ?>
                                    <div class="col-md-12">
                                        <?php if (!in_array($userGroup->id, $userGroupChild)) { ?>
                                            <h3 class="media-right">
                                                <?php echo $userGroup->group_title; ?>                                            
                                            </h3>
                                            <span> 
                                                <?php if ($page->currentUser->id === $user->id && $userGroup->form_id == '1') { ?>
                                                    <a href="/user_users/edituserdata/<?php echo $userGroup->id; ?>/<?php echo $user->id; ?>/" rel="popUpBox" class="pull-right btn btn-danger popup" data-effect="mfp-flipInY" oncloseFunction="reloadDiv('viewprofile', 'mainContent', 'ajax');"><i class="fa fa-pencil"></i>
                                                    </a>
                                                <?php } ?>
                                            </span>
                                            <hr class="short br-lighter mb5 mt5">
                                            <?php
                                        }
                                        if (!empty($userFields)) {
                                            $newFlag = '';
                                            foreach ($userFields as $userField) {
                                                $userFieldGroup[] = $userField->group_id;
                                                if ($userField->group_id == $userGroup->id) {
                                                    if ($userField->fieldType == 'file') {
                                                        if ($userField->form_id == '9') {
                                                            ?>
                                                            <div class="col-md-12 pt10 pb10">
                                                                <a href="<?php echo $userField->data; ?>" target="_blank"><?php echo $userField->field_title; ?></a>
                                                                <div class="clearfix"></div>
                                                            </div>
                                                            <div class="clearfix"></div>
                                                        <?php } else {
                                                            ?>
                                                            <strong><?php echo isset($userField->field_title) ? $userField->field_title . ':' : ''; ?></strong>
                                                            <?php if (!empty($userField->data)) {
                                                                ?>
                                                                <a href="<?php echo $userField->data; ?>" target="_blank"><?php echo $userField->field_title; ?></a>
                                                                <?php if (!empty($userField->date_modified)) { ?>
                                                                    <strong class="pl15">Modified: </strong>
                                                                    <?php echo $userField->date_modified; ?>
                                                                    <?php
                                                                }
                                                            } else if ($i % 1 == 0) {
                                                                echo 'No Doc Upload';
                                                            }
                                                            echo '<div class="clearfix"></div>';
                                                        }
                                                    } else if ($userGroup->add_more_group != 1) {
                                                        ?>
                                                        <p class="text-muted pb10 col-md-4 col-sm-6">
                                                            <strong><?php echo $userField->field_title; ?>: </strong>
                                                            <?php echo $userField->data; ?></p>
                                                        <?php
                                                    } else if ($userGroup->add_more_group == 1) {
                                                        if ($newFlag != $userField->multi_val_group) {
                                                            $newFlag = $userField->multi_val_group;
                                                            ?>
                                                            <div class="clearfix"></div>
                                                            <h4 class="pl15"><?php
                                                                echo $userField->data;
                                                                if ($page->currentUser->id === $user->id) {
                                                                    ?>
                                                                    <span>
                                                                        <a href="/user_users/editsection/<?php echo $userField->multi_val_group; ?>/<?php echo $userGroup->id; ?>/" rel="popUpBox"><i class="fa fa-pencil  popup" data-effect="mfp-flipInY"></i></a>
                                                                    </span>
                                                                <?php } ?>
                                                            </h4>
                                                            <?php
                                                            echo '<div class="clearfix"></div>';
                                                        } else {
                                                            ?>
                                                            <p class="text-muted pb10 col-md-4 col-sm-6">
                                                                <strong><?php echo isset($userField->field_title) ? $userField->field_title . ':' : ''; ?></strong>
                                                                <?php echo $userField->data; ?>
                                                            </p>
                                                            <?php
                                                        }
                                                    }
                                                }
                                            }
                                        } else {
                                            if (!in_array($userGroup->id, $userGroupChild)) {
                                                ?>
                                                <div class="col-md-12">
                                                    <h4>No Data Found</h4>
                                                </div>  
                                                <?php
                                            }
                                        }
                                        ?>
                                        <div class="clearfix"></div>
                                    </div>
                                    <?php
                                    if ($i % 2 == 0) {
                                        echo '<div class="clearfix spacer20"></div>';
                                    }
                                    $i++;
                                    if (!empty($userFieldGroup)) {
                                        if ((!in_array($userGroup->id, $userFieldGroup)) && (!in_array($userGroup->id, $userGroupChild))) {
                                            ?>
                                            <div class="col-md-12">
                                                <h4>No Data Found</h4>
                                            </div>
                                            <?php
                                        }
                                    }
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                    <?php
                }
                ?>
            </div>
        </div>
        <div class="clearfix"></div>
    </section>
</section>
