<?php global $page; ?>
<div class="">
    <!-- Start: Content-Wrapper-->
    <section id="content_wrapper">
        <!-- begin canvas animation bg-->
        <div id="canvas-wrapper">
            <canvas id="demo-canvas"></canvas>
        </div>
        <!-- Begin: Content-->
        <section id="content">
            <div id="login1" class="admin-form theme-info">
                <div class="row mb15 table-layout">
                    <div class="col-xs-12 va-m pln"><a title="Return to Dashboard">
                            <img src="/img/bezoar-logo.png" title="Logo" class="img-responsive w250" style="margin:auto;">
                        </a></div>
                </div>
                <div class="panel panel-info mt10 br-n">
                    <div class="panel-heading heading-border bg-white" style="padding:5px;">
                    </div>
                    <?php if (empty($page->currentUser->userLoggedIn)) { ?>
                        <div id="loginResultDiv" class="resultDiv"></div>
                        <form keep_visible="1" keepVisible="1" role="form" action="/user_users/authenticate" method="POST" name='login' id='login' rel='ajaxifiedForm'>
                            <input type="hidden" name="redirectTo" value="<?php echo (isset($_SERVER['REQUEST_URI'])) ? $_SERVER['REQUEST_URI'] : ''; ?>" /> 
                            <div class="panel-body bg-light p30">
                                <div class="row">
                                    <div class="col-sm-12 pr30">
                                        <div class="section">
                                            <label for="username" class="field-label text-muted fs18 mb10">Username</label>
                                            <label for="username" class="field prepend-icon">
                                                <input class="gui-input required" placeholder="Enter Username" name="userName" type="text" required="">
                                                <label for="username" class="field-icon"><i class="fa fa-user"></i></label>
                                            </label>
                                        </div>
                                        <div class="section">
                                            <label for="username" class="field-label text-muted fs18 mb10">Password</label>
                                            <label for="password" class="field prepend-icon">
                                                <input class="gui-input required" placeholder="Password" name="password" type="password">
                                                <label for="password" class="field-icon"><i class="fa fa-lock"></i></label>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="panel-footer clearfix p10 ph15">
                                <button type="submit" class="button btn-primary mr10 pull-right">Sign In</button>
                            </div>
                        </form>
                    <?php } else { ?>
                        <?php if ($page->currentUser->webUserRole != 2) { ?>
                            <h3><?php echo isset($message) ? $message : ''; ?></h3>
                        <?php } ?>
                        <h4>Welcome <?php echo $page->currentUser->name; ?> || <a href="/logout/">Logout</a></h4>
                    <?php }
                    ?>

                </div>
            </div>
        </section>
    </section>
</div><script type="text/javascript">
    jQuery(document).ready(function()
    {
        "use strict";
        // Init Theme Core
        Core.init();
        // Init Demo JS
        Demo.init();
        // Init CanvasBG and pass target starting location
        CanvasBG.init({
            Loc:{
                x:window.innerWidth/2,
                y:window.innerHeight/3.3
            },
        });
        $("body.sb-r-c").addClass("external-page");
    });

</script>