<section id="content_wrapper">
    <!-- Begin: Content-->
    <section id="content" class="">
        <div>
            <!-- begin: .tray-center-->
            <div id="animation-switcher" class="tray-center col-md-9 col-sm-8">
                <!-- recent orders table-->
                <div class="panel mb25 mt5">
                    <div class="panel-heading"><span class="panel-title"> <i class="fa fa-group"></i> Employee List</span>
                    </div>
                    <div class="panel-menu admin-form theme-primary">
                        <div class="row">
                            <div class="col-md-12">
                                <label for="name" class="field prepend-icon">
                                    <input id="fooFilter" type="text" name="name" placeholder="Filter By Name" class="event-name gui-input br-light light">
                                    <label for="name" class="field-icon"><i class="fa fa-user"></i></label>
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="panel-body pn">
                        <div class="table-responsive of-a">
                            <table data-filter="#fooFilter"  data-page-navigation=".pagination" data-page-size="5"  class="table admin-form theme-warning tc-checkbox-1 fs13 footable">
                                <thead>
                                    <tr class="bg-light">
                                        <th>Avatar</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Joining Date</th>
                                        <th class="text-right">Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    if (!empty($objects->data)) {
                                        foreach ($objects->data as $object) {
                                            ?>
                                            <tr id="section_<?php echo $object->id ?>">
                                                <td class="w75"><img title="user" src="assets/img/avatars/1.jpg" class="img-responsive mw30 ib mr10"></td>
                                                <td>
                                                    <a href="/<?php echo $objects->coreURL . '/edit/' . $object->id ?>" oncloseFunction="reloadDiv('/<?php echo $objects->coreURL; ?>/index','mainContent');" rel="popUpBox"  > <?php echo $object->name . '<br />'; ?></a>
                                                </td>
                                                <td><?php echo $object->email; ?></td>
                                                <td><?php echo $object->created; ?></td>

                                                <td class="text-right">
                                                    <div class="btn-group text-right">
                                                        <button type="button" data-toggle="dropdown" aria-expanded="false" class="btn btn-success br2 btn-xs fs12 dropdown-toggle">Active<span class="caret ml5"></span></button>
                                                        <ul role="menu" class="dropdown-menu">
                                                            <li><a href="/leaveview/<?php echo $object->id ?>" rel="ajaxRequest">Leaves</a></li>
                                                            <li><a href="/managepasswordview/<?php echo $object->id ?>" rel="ajaxRequest">Passwords</a></li>
                                                            <li class="divider"></li>
                                                            <li><a href="#">View</a></li>
                                                            <li><a href="/<?php echo $objects->coreURL . '/edit/' . $object->id ?>" rel="popUpBox" onclosefunction="reloadDiv('employees', 'mainContent', 'ajax');">Edit</a></li>
                                                            <li class="active"><a href="#">Active</a></li>
                                                        </ul>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php }
                                    }
                                    ?>
                                </tbody>
                                <tfoot class="footer-menu">
                                    <tr>
                                        <td colspan="5">
                                            <nav class="text-right">
                                                <ul class="pagination"></ul>
                                            </nav>
                                        </td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- begin: .tray-right-->
            <aside data-tray-height="match" class="tray tray-center col-md-3 col-sm-4">
                <!-- create new order panel-->
                <div id="<?php echo $object->id ?>ResultDiv" class="resultDiv"></div>
                <div class="panel mb25 mt5">
                    <div class="panel-heading"><span class="panel-title"> <i class="fa fa-user"></i> Add New Employee</span>
                    </div>
                    <div class="panel-body p20 pb10">
                        <div class="tab-content pn br-n admin-form">

                            <form id="<?php echo $object->id ?>" name="passwordChanged8" method="POST" keep_visible="1" keepvisible="1" role="form" action="/user_users/save/" rel="ajaxifiedForm" autocomplete="off" novalidate="novalidate">
                                <input id="created"  type="hidden" name="createddate" value="<?php echo date("Y-m-d"); ?>">
                                <div id="tab1_1" class="tab-pane active">
                                    <div class="section row mbn">
                                        <div class="col-md-12 pl15">
                                            <div class="section row mb15">
                                                <div class="col-xs-12">
                                                    <label for="name" class="field prepend-icon">
                                                        <input id="name" type="text" name="name" placeholder="First Name" class="event-name gui-input br-light light" required="">
                                                        <label for="name1" class="field-icon"><i class="fa fa-user"></i></label>
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="section row mb15">
                                                <div class="col-xs-12">
                                                    <label for="lastname" class="field prepend-icon">
                                                        <input id="lastname" type="text" name="lastname" placeholder="Last Name" class="event-name gui-input br-light light" required="">
                                                        <label for="name2" class="field-icon"><i class="fa fa-user"></i></label>
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="section row mb15">
                                                <div class="col-xs-12">
                                                    <label for="email" class="field prepend-icon">
                                                        <input id="email" required="" type="email" name="email" placeholder="Email Address" class="event-name gui-input br-light light">
                                                        <label for="email" class="field-icon"><i class="fa fa-envelope-o"></i></label>
                                                    </label>
                                                </div>
                                            </div>                       
                                            <div class="section row mb15">
                                                <div class="col-xs-12">
                                                    <label for="role" class="field select">
                                                        <select class="event-name gui-input br-light light" name="webUserRole">   
                                                            <option value="0">Select UserRole</option>                           
                                                            <option value="1">Employee</option>
                                                            <option value="2">Super Admin</option>                                
                                                        </select>
                                                        <i class="arrow"></i>
                                                    </label>

                                                    <!--<label for="role" class="field prepend-icon">
                                                      <input id="role" type="password" name="password2" placeholder="Confirm Password" class="event-name gui-input br-light light">
                                                      <label for="role" class="field-icon"><i class="fa fa-unlock"></i></label>
                                                    </label>-->
                                                </div>
                                            </div>
                                            <div class="section row mb15">
                                                <div class="col-xs-12">
                                                    <button class="button btn-success col-xs-12 pull-right">Add Employee</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- menu quick links-->
            </aside>
        </div>
        <div class="clearfix"></div>
        <div id="modal-content" class="row table-layout table-clear-xs">
            <div class="hidden"><a href="#modal-form" class="holder-style holder-active p15 mb20">Form</a></div>
        </div>
        <!-- Admin Form Popup-->
        <div id="modal-form" class="popup-basic popup-lg admin-form mfp-with-anim mfp-hide">
            <div class="panel">
                <div class="panel-heading"><span class="panel-title"><i class="fa fa-pencil"></i>Edit Employee</span></div>
                <form id="comment" method="post" action="/">
                    <div class="panel-body p25">
                        <div class="section row">
                            <div class="col-md-6">
                                <label for="firstname" class="field prepend-icon">
                                    <input id="firstname" type="text" name="firstname" placeholder="First name..." class="gui-input">
                                    <label for="firstname" class="field-icon"><i class="fa fa-user"></i></label>
                                </label>
                            </div>
                            <div class="col-md-6">
                                <label for="lastname" class="field prepend-icon">
                                    <input id="lastname" type="text" name="lastname" placeholder="Last name..." class="gui-input">
                                    <label for="lastname" class="field-icon"><i class="fa fa-user"></i></label>
                                </label>
                            </div>
                        </div>
                        <div class="section row">
                            <div class="col-md-6">
                                <label for="email" class="field prepend-icon">
                                    <input id="email" type="email" name="email" placeholder="Email address" class="gui-input">
                                    <label for="email" class="field-icon"><i class="fa fa-envelope"></i></label>
                                </label>
                            </div>
                            <div class="col-md-6">
                                <label for="role" class="field select">
                                    <select class="event-name gui-input br-light light">
                                        <option>Employee</option>
                                        <option>Admin</option>
                                        <option>Super Admin</option>
                                    </select>
                                    <i class="arrow"></i>
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="panel-footer">
                        <button type="submit" class="button btn-success pull-right">Save Changes</button>
                        <div class="clearfix"></div>
                    </div>
                </form>
            </div>
        </div>
    </section>
</section>
<script>
    function deleteRow(tableclass,rowId,div_id,resourceId)
    {
        resource=resourceId?resourceId:'';
        var msg=($('#'+div_id+'_delete').attr('confirm_message'))?($('#'+div_id+'_delete').attr('confirm_message')):'Are you sure to delete.\nThis will delete this content';
        if(confirm(msg))
        {
            var deleteTimer=setTimeout(function()
            {
                $.post('/user_users/deleteRow/'+tableclass+'/'+rowId+'/'+resource+'/',{
                    'id':rowId,
                    ajax_request:1
                },function(data)
                {
                    if(data.indexOf('Delete Success')!==-1)
                    {
                        alert("Delete Succssful");
                        $('#'+div_id).hide();
                    }
                    $('#delete_undo_'+div_id).remove();
                });
            },0000);
        }
        return false;
    }
</script>
