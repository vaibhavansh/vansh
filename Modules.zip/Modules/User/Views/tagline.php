<?php global $page;
if ($page->currentUser->userLoggedIn) {
    $userid = $page->currentUser->id;
} ?> 
<div id="modal-form" class="admin-form mfp-with-anim">
    <div class="panel">
        <div id="taglineResultDiv" class="resultDiv"></div>
        <div class="panel-heading">           
            <span class="panel-title"><i class="fa fa-pencil"></i>Tagline</span></div>             
           <form method="POST" resultDiv="taglineResultDiv" id="tagline" close_popup="1"  keepvisible="1" role="form" action="/taglinesave/" rel="ajaxifiedForm" autocomplete="off" backToPage="viewprofile" successMsg="Tagline Save Successfully!">   
            <input type="hidden" name="user_form_type" value="type_tagline">
            <input type="hidden" name="id" value="<?php echo $userid; ?>">   
            <div class="panel-body p25">
                <div class="col-md-12">
                    <label for="taglinestatus" class="field ">
                        <input type="text" name="tagline" name="tagline" class="event-name gui-input br-light light required" placeholder="Please Enter your Tagline..." value="<?php if($usersdetails->tagline){ echo $usersdetails->tagline; }?>"> 
                    </label>                   
                </div> 
            </div>
            
            <div class="panel-footer">
                <div class="mr10 pull-right">
                  <button class="button btn-danger col-xs-12 pull-right" type="button" onclick="cancel_onClick()"> Cancel </button>
                </div>
                <div class="mr10 pull-right">
                    <button type="submit" class="button btn-success pull-right">Save</button>
                </div>
              
                <div class="clearfix"></div>
            </div>
        </form>
    </div>
</div>