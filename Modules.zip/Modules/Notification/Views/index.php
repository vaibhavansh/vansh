<?php
global $page;
if ($page->currentUser->userLoggedIn) {
    $webUserRole = $page->currentUser->webUserRole;
}
?>
<section class="">
    <div class="col-md-12">
        <div class="panel">
            <div id="<?php //echo $object->id  ?>notificationResultDiv" class="resultDiv1"></div>
            <div class="panel-heading"><span class="fa fa-bell hidden-xs"></span>
                <span class="panel-title"> Notification</span>
                <?php   if (!empty($notifications->data)) { ?>
                <span class="pull-right fix-right">
                    <div class="btn-group">
                        <button type="button" class="btn btn-default light div-slider"><i class="fa"></i></button>
                    </div>
                    <div class="btn-group">
                        <button type="button" onclick="notificationsallhide('<?php echo $page->currentUser->id; ?>');" class="btn btn-danger btn-xs fs12 light"><i class="fa fa-close"></i> Hide All</button>
                    </div>
                </span>
                <?php } ?>
            </div>
            <div class="panel-body ptn pbn p10">
                <ol class="timeline-list notificationlist"><?php
                    if (!empty($notifications->data)) {
                        foreach ($notifications->data as $singlenotification) {
                            $html = '';
                            if (!empty($singlenotification->extra_html)) {
                                $HtmlArray = unserialize($singlenotification->extra_html);
                                if (array_key_exists('Password_Models_UserPassword', $HtmlArray)) {
                                    $passwordtagid = $HtmlArray['Password_Models_UserPassword'];
                                    $viewRequestPassword = array_shift(Password_Models_UserPassword::find_all(array('where' => 'id=' . $passwordtagid)));
                                    if (!empty($viewRequestPassword)) {
                                        $html .= '<div class="btn-group text-right">';
                                        if ($viewRequestPassword->status == 1) {
                                            $class = 'btn-warning btn-dropdown';
                                        } else
                                        if ($viewRequestPassword->status == 2) {
                                            $class = 'btn-success btn-dropdown';
                                        } else
                                        if ($viewRequestPassword->status == 3) {
                                            $class = 'btn-danger';
                                        }
                                        if ($viewRequestPassword->status == 3) {
                                            $changedropdown = '';
                                        } else {
                                            $changedropdown = '<span class="caret"></span>';
                                        }
                                        $html .= '<button type="button" data-toggle="dropdown" aria-expanded="false" class="btn ' . $class . ' br2 btn-xs fs12"> ' . Password_Models_UserPassword::$requestStatus[$viewRequestPassword->status] . "$changedropdown" . '</button>';

                                        if ($viewRequestPassword->status == 2) {
                                            $html .= '<ul role="menu" class="dropdown-menu"><li><a href="Javascript:void(0);" onclick="deleteRow( \'' . $viewRequestPassword->id . '\', \'' . $singlenotification->username . '\',\'deletesharepassword\',\'notifications\',\'from this passwrod \');">Remove</a></li></ul>';
                                            // $html.='<ul role="menu" class="dropdown-menu"><li><a href="Javascript:void(0);" onclick="return toggleStatus(\'Password_Models_UserPassword\', \'' . $viewRequestPassword->id . '\', \'3\', \'notifications\')">Remove Tag</a></li></ul>';
                                        } else if ($viewRequestPassword->status == 3) {
                                            //  $html.='<ul role="menu" class="dropdown-menu"><li><a href="Javascript:void(0);" onclick="deleteRow(\'Password_Models_UserPassword\', \'' . $viewRequestPassword->id . '\', \'section_' . $viewRequestPassword->id . '\');">Remove</a></li></ul>';
                                        } else {
                                            $html .= '<ul role="menu" class="dropdown-menu"><li><a href="Javascript:void(0);" onclick="return toggleStatus(\'Password_Models_UserPassword\', \'' . $viewRequestPassword->id . '\', \'2\', \'notifications\')">Accept</a></li><li><a href="Javascript:void(0);" onclick="return toggleStatus(\'Password_Models_UserPassword\', \'' . $viewRequestPassword->id . '\', \'3\', \'notifications\')">Reject</a></li></ul>';
                                        }
                                        $html .= '</div>';
                                    }
                                } else if (array_key_exists('Leave_Models_Leave', $HtmlArray)) {
                                    $leaveid = $HtmlArray['Leave_Models_Leave'];
                                    $leave = array_shift(Leave_Models_Leave::find_all(array('where' => 'id=' . $leaveid)));
                                    if (!empty($leave)) {
                                        $html .= '<div class="btn-group text-right">';
                                        if ($leave->status == 1) {
                                            $class = 'btn-warning btn-dropdown';
                                        } else
                                        if ($leave->status == 2) {
                                            $class = 'btn-success btn-dropdown';
                                        } else
                                        if ($leave->status == 3) {
                                            $class = 'btn-danger btn-dropdown ';
                                        } else if ($leave->status == 4) {
                                            $class = 'btn-info';
                                        }
                                        if ($leave->status == 4) {
                                            $changedropdown1 = '';
                                        } else {
                                            $changedropdown1 = '<span class="caret"></span>';
                                        }

                                        $html .= '<button type="button" data-toggle="dropdown" aria-expanded="false" class="btn ' . $class . ' br2 btn-xs fs12"> ' . Leave_Models_Leave::$requestLeave[$leave->status] . "$changedropdown1" . '</button>';

                                        if ($webUserRole == 2 && $leave->status != 3 && $leave->status != 4 && $leave->status != 2) {
                                            $html .= '<ul role="menu" class="dropdown-menu">
                                                    <li><a href="Javascript:void(0);" onclick="return toggleStatus(\'Leave_Models_Leave\', \'' . $leave->id . '\', \'2\', \'notifications\')">Accept</a></li>
                                                    <li><a href="Javascript:void(0);" onclick="return toggleStatus(\'Leave_Models_Leave\', \'' . $leave->id . '\', \'3\', \'notifications\')">Reject</a></li>
                                                </ul>';
                                        } else if ($webUserRole == 2 && $leave->status == 3) {
                                            $html .= '<ul role="menu" class="dropdown-menu">
                                                    <li><a href="Javascript:void(0);" onclick="return toggleStatus(\'Leave_Models_Leave\', \'' . $leave->id . '\', \'2\', \'notifications\')">Accept</a></li>
                                                </ul>';
                                        } else if ($webUserRole != 2 && $leave->status == 2) {
                                            $html .= '<ul role="menu" class="dropdown-menu">
                                                    <li><a href="/editleave/' . $leave->id . '/1" rel="popUpBox">View</a></li>
                                                    <li><a href="/editleave/' . $leave->id . '/" rel="popUpBox">Edit</a></li>
                                                    <li><a href="Javascript:void(0);" onclick="return toggleStatus(\'Leave_Models_Leave\', \'' . $leave->id . '\', \'4\', \'notifications\')">Cancelled</a></li>
                                                </ul>';
                                        } else if ($webUserRole == 2 && $leave->status == 1) {
                                            $html .= ' <ul role="menu" class="dropdown-menu">
                                                        <li><a href="/editleave/' . $leave->id . '/" rel="popUpBox">Edit</a></li>
                                                        <li><a href="Javascript:void(0);" onclick="return toggleStatus(\'Leave_Models_Leave\', \'' . $leave->id . '\', \'4\', \'notifications\')">Cancelled</a></li>
                                                    </ul>';
                                        } else if ($webUserRole == 2 && $leave->status == 2) {
                                            $html .= '<ul role="menu" class="dropdown-menu">
                                                        <li><a href="Javascript:void(0);" onclick="return toggleStatus(\'Leave_Models_Leave\', \'' . $leave->id . '\', \'3\', \'notifications\')">Reject</a></li>
                                                    </ul>';
                                        }
                                        $html .= '</div>';
                                    }
                                } elseif (array_key_exists('Password_Models_Password', $HtmlArray)) {
                                    $passwordid = $HtmlArray['Password_Models_Password'];
                                    $html .= '<a class="btn btn-info br2 btn-xs fs12" href="/editpassword/' . $passwordid . '/1/1" rel="popUpBox">View</a>';
                                } elseif (array_key_exists('Password_View_Only', $HtmlArray)) {
                                    $html .= '<a class="btn btn-info br2 btn-xs fs12" rel="ajaxRequest" href="passwords">View</a>';
                                } elseif (array_key_exists('Projects', $HtmlArray)) {
                                    $ProjectId = $HtmlArray['Projects'];
                                    $html .= '<a class="btn btn-info br2 btn-xs fs12" href="/lists/' . $ProjectId . '/" rel="ajaxRequestHR">View</a>';
                                } elseif (array_key_exists('Tickets', $HtmlArray)) {
                                    $TicketId = $HtmlArray['Tickets'];
                                    $html .= '<a class="btn btn-info br2 btn-xs fs12" href="/viewticket/' . $TicketId . '/" rel="popUpBoxHR">View</a>';
                                } elseif (array_key_exists('Blogs', $HtmlArray)) {
                                    $BlogId = $HtmlArray['Blogs'];
                                    $html .= '<a class="btn btn-info br2 btn-xs fs12" href="/viewblog/' . $BlogId . '/" rel="popUpBoxHR">View</a>';
                                }
                            }
                            ?>

                            <li class="timeline-item notification_<?php echo $singlenotification->usernotificationid; ?>"  >
                                <div class="timeline-icon"><span class="fa fa-tags"></span></div>
                                <div class="col-xs-12 time-pad">
                                    <div class="timeline-date pt5"><?php echo date('M j, Y g:i a', strtotime($singlenotification->time)); ?></div>
                                    <div class="note-alt col-xs-12"><b><?php echo $singlenotification->username; ?></b> <?php echo $singlenotification->type; ?> - 
                                        <?php  echo $status_text = preg_replace('#(\A|[^=\]\'"a-zA-Z0-9])(http[s]?://(.+?)/[^()<>\s]+)#i', '\\1<a target="_blank" href="\\2">\\3</a>', $singlenotification->title); ?> 
                                        <div class="clearfix"></div>
                                        <span class="pull-right">
                                            <button type="button" onclick="notificationshide('<?php echo $singlenotification->usernotificationid; ?>');"  class="btn btn-danger br2 btn-xs fs12 pull-right"><span class="fa fa-close"></span></button>
                                        </span>
                                        <span class="timeline-button pull-right mr10"><?php echo $html; ?> </span>  
                                    </div>
                                </div>
                                <!--<div class="clearfix"></div>-->
                                <!--<div class="timeline-date pt5"><?php // echo date('M j, Y g:i a', strtotime($singlenotification->time));  ?></div>-->
                                <div class="clearfix"></div>
                            </li> <?php } ?>  
                        <div class="clearfix"></div>
                        <div class="col-xs-12">
                            <div class="pull-left">
                                <h5><?php echo $notifications->getCurrentPageInfo(); ?></h5>
                            </div>
                            <div class="pull-right" >                               
                                <?php echo $notifications->printPageNumbers(array('url' => "/notifications", 'div_id' => 'mainContent', 'ajaxRequest' => true)); ?>  
                            </div>
                        </div><?php
                            } else {
                                echo '<h4> Notifications not found ! </h4>';
                            }
                            ?>
                    <div class="clearfix"></div>
                    <div class="clearfix"></div>
                    <div class="clearfix"></div>
                    <div class="clearfix"></div><div class="clearfix"></div>
                    <div class="clearfix"></div>
                    <div class="clearfix"></div>
                    <div class="clearfix"></div>
                </ol>

            </div>
        </div>
    </div>
    <script type="text/javascript">
        function notificationshide(notificationId) {
            $.ajax({
                type: "POST",
                url: 'hidenotification/',
                data: ({notificationId: notificationId, pageRequestType: 'ajax'}),
                success: function (data) {
                    $('.resultDiv1').html(data);
                    setTimeout(function () {
                      
                        $('.notificationlist .notification_' + notificationId).hide();
                    }, 1000);
                }
            });
        }

        function notificationsallhide(userid) {
            $.ajax({
                type: "POST",
                url: 'hidenotification/',
                data: ({userid: userid, pageRequestType: 'ajax'}),
                success: function (data) {

                    var msg = 'Are you sure you want to hide all notification';
                    if (confirm(msg)) {
                        $('.resultDiv1').html(data);
                        setTimeout(function () {
                           // $('.resultDiv1').html('');
                            reloadDiv('notifications', 'mainContent', 'ajax');
                        }, 1000);
                    }
                }
            });
        }

        $(document).ready(function () {
            readNotifications();
        });
    </script>
</section>
