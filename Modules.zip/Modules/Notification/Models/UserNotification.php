<?php 
/**
 *
 * 
 */
class Notification_Models_UserNotification extends Core_Models_DbTable {
    static $table = 'user_notifications';
    static $fields = NULL;
    
}
?>
