<?php

class Notification_Models_Notification extends Core_Models_DbTable {
    
    static $table = 'notifications';
    static $fields = NULL;

    public function index() {
        global $page;
        if ($page->currentUser->userLoggedIn) {
            $userId = $page->currentUser->id;
            $tags = func_get_args();
            $variables['pageNumber'] = array_pop($tags);
            if (!(substr($variables['pageNumber'], 0, 5) == 'page_')) {
                $tags[] = $variables['pageNumber'];
                $variables['pageNumber'] = 'page_1';
            }
            $notificationLists = Notification_Models_Notification::getPaginatedData(array('join' => ' user_notifications on user_notifications.notification_id=notifications.id join users on users.id=notifications.created_by ',
                        'where' => ' user_notifications.status<"2" and user_notifications.user_id="' . $userId . '"', 'pageNumber' => $variables['pageNumber'],
                        'cols' => 'notifications.*, users.username as username,user_notifications.id as usernotificationid',
                        'orderBy' => 'notifications.id desc'));

            return $notificationLists;
        }
        return FALSE;
    }

//    public function index($paged=1) {
//        global $page;
//        if ($page->currentUser->userLoggedIn)
//        {
//            $userId = $page->currentUser->id;
//            $notificationLists = new Core_Models_Paginatenew(array('class_name' => 'Notification_Models_Notification'));
//            $query = array('join' => ' user_notifications on user_notifications.notification_id=notifications.id join users on users.id=notifications.created_by ',
//               'where' => ' user_notifications.status<"2" and user_notifications.user_id="' . $userId.'"','pageNumber' => $paged,
//               'cols' => 'notifications.*, users.username as username,user_notifications.id as usernotificationid',
//               'orderBy' => 'notifications.id desc');
//            $notificationLists->data = $notificationLists->getPaginatedData($query);
//            return $notificationLists;
//        }
//        return FALSE;
//    }

    public function AddNotifications($byuser = '', $title = '', $type = '', $users = 'all', $html = '') {
        global $page;
        if ($page->currentUser->userLoggedIn) {
            $currntuserId = $page->currentUser->id;
            $created_by = $currntuserId;
            if (!empty($byuser)) {
                $created_by = $byuser;
            }
            $NotificationOBJ = new Notification_Models_Notification;
            $noti_id = $NotificationOBJ->save(array('title' => $title, 'type' => $type, 'extra_html' => $html, 'created_by' => $created_by));
            if ($users == 'all') {
                $all_users = User_Models_User::find_all(array('where' => "status='1'"));
                if (!empty($all_users)) {
                    foreach ($all_users as $singleUser) {
                        if ($singleUser->id != $currntuserId) {
                            $UserNotificationObj = new Notification_Models_UserNotification();
                            $UserNotificationObj->save(array('notification_id' => $noti_id, 'user_id' => $singleUser->id, 'status' => '0'));
                            unset($UserNotificationObj);
                        }
                    }
                }
            } else if ($users == 'admin') {
                $all_users = User_Models_User::find_all(array('where' => " status='1' AND webUserRole='2' "));
                if (!empty($all_users)) {
                    foreach ($all_users as $singleUser) {
                        if ($singleUser->id != $currntuserId) {
                            $UserNotificationObj = new Notification_Models_UserNotification();
                            $UserNotificationObj->save(array('notification_id' => $noti_id, 'user_id' => $singleUser->id, 'status' => '0' ));
                            unset($UserNotificationObj);
                        }
                    }
                }
             } else if ($users == 'non-admin') {
                $all_users = User_Models_User::find_all(array('where' => " status='1' AND webUserRole='1'"));
                if (!empty($all_users)) {
                    foreach ($all_users as $singleUser) {
                        if ($singleUser->id != $currntuserId) {
                            $UserNotificationObj = new Notification_Models_UserNotification();
                            $UserNotificationObj->save(array('notification_id' => $noti_id, 'user_id' => $singleUser->id, 'status' => '0'));
                            unset($UserNotificationObj);
                        }
                    }
                }
            } else if (!is_array($users)) {
                if ($users != $currntuserId) {
                    $UserNotificationObj = new Notification_Models_UserNotification();
                    $UserNotificationObj->save(array('notification_id' => $noti_id, 'user_id' => $users, 'status' => '0'));
                    unset($UserNotificationObj);
                }
            } else if (!empty($users)) {
                foreach ($users as $singleUser) {
                    if ($singleUser['id'] != $currntuserId) {
                        $UserNotificationObj = new Notification_Models_UserNotification();
                        $UserNotificationObj->save(array('notification_id' => $noti_id, 'user_id' => $singleUser['id'], 'status' => '0'));
                        unset($UserNotificationObj);
                    }
                }
            }
            return true;
        }
        return FALSE;
    }
}

?>
