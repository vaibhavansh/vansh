<?php 
/**
 * 
 * 
 */
class Notification_Controllers_NotificationsController extends Core_Controllers_SitesController {

    public function index($paged=1) {        
        $variables = array();
        global $page; 
        if (!$page->currentUser->userLoggedIn)
        {
            echo "<script>window.location = '/';</script>";
            return array();
        }
        $notObj = new Notification_Models_Notification();
        $notifications = $notObj->index($paged);
        $variables['notifications'] = $notifications;
        return $variables;
    }
    
     public function hidenotification() {
        global $page; 
        $variables = array(); 
        if (!$page->currentUser->userLoggedIn)        { 
            echo "<script>window.location = '/';</script>";
            return array();
        }
       
        if(isset($_POST['notificationId']) && $_POST['notificationId']!='')
        {
            $notification = $_POST['notificationId'];
            $hidenotifications =  new Notification_Models_UserNotification($notification) ;
            $hidenotifications->save(array('status' => '2'));
            echo Core_Models_Utility::flashMessage("Hide successfully.", 'valid');           
        }else{ 
             $where = "user_id = '{$_POST['userid']}'" ;
             Notification_Models_UserNotification::updateRow($where,array('status' => 2));
             echo Core_Models_Utility::flashMessage("Hide All successfully.", 'valid');             
        }
        return $variables;
    }
    
    function readnotification()
    {
        global $page;
        if ($page->currentUser->userLoggedIn)
        {
            $userid = $page->currentUser->id;
            $unreadnotifications = Notification_Models_UserNotification::find_all(array('where' => "user_id = '{$userid}' and status='0' "));
            if(!empty($unreadnotifications))
            foreach ($unreadnotifications as $unreadnotification) {
               $user = new Notification_Models_UserNotification($unreadnotification->id);
               $user->save(array('status' => '1'));
            }
        }
        return array();
    }
    
    function getnotification()
    {
        global $page;
        if ($page->currentUser->userLoggedIn)
        {
            $userid = $page->currentUser->id;
            $unreadnotification = Notification_Models_UserNotification::find_all(array('where' => "user_id = '{$userid}' and status='0'", 'limit' => '1'));
            if (!empty($unreadnotification)) {
                echo '1';
            } else {
                echo '0';
            }
        }
        return array();
    }

   function delete($id) {
        $content = new Notification_Models_UserNotification($id);
        if (!empty($content->id)) {
            if ($content->delete()) {
                $variables['result'] = 'Delete Success';
            } else {

                $variables['result'] = 'Delete Fail';
            }
        } else {
            $variables['result'] = 'Delete Fail';
        }
        echo $variables['result'];
        return $variables;
    }

}
?>