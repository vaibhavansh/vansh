<?php
return[

		'VP_ROLE_ID'=> '4',
		'SP_ROLE_ID'=>'5',
		//'CLIENT_ROLE_ID'=> 3,
];