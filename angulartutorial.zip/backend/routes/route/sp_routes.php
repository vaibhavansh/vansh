<?php

use Illuminate\Http\Request;

//  for User Management routes


     $controller='SPController@';

     Route::post('/add-client',$controller.'addClient');
 
     Route::get('/client-list/{id}',$controller.'clientList');

     Route::post('/change-status', $controller.'changeStatus');

     Route::get('/get-leads/{id}', $controller.'getLeads');
     Route::get('/get-lead-details/{id}', $controller.'getLeadDetails');

     Route::post('/add-office-details', $controller.'addOfficeDetails');
     Route::get('/get-office-details/{id}', $controller.'getOfficeDetails');
     Route::get('/update-office-details/{id}', $controller.'updateOfficeDetails');
     Route::get('/get-dropdown-values/{id}', $controller.'getDropdownValues');
     Route::get('/delete-office/{id}', $controller.'deleteOffice');
     Route::get('/generate-quotation/{id}', $controller.'generateQuotation');

     Route::post('/get-details', $controller.'getDetails');

     Route::post('/update-profile', $controller.'updateProfile');

     Route::post('/get-client', $controller.'getClient');

     Route::post('/update-client', $controller.'updateClient');

     Route::post('/search-client', $controller.'searchClient');

     
