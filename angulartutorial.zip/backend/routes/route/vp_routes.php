<?php

use Illuminate\Http\Request;

//  for User Management routes


    $controller='VPController@';

    Route::get('/clientdata',$controller.'ClientDetails');
    Route::post('/add-salesperson',$controller.'AddSalesPerson');
    Route::post('/set-targets',$controller.'setTargets');
    Route::post('/salespersons-list',$controller.'salesPersonList');
    Route::get('/changestatus/{id}',$controller.'changeStatusSP');
	Route::get('/delete-salesperson/{id}',$controller.'deleteSalesPerson');
	Route::get('/new-leads',$controller.'newLeads');
	Route::post('/assign-salesperson',$controller.'assignSalesPerson');
	Route::post('/reset-password',$controller.'resetPassword');
    Route::get('/get-details/{id}',$controller.'getDetails');
    Route::post('/profile-update',$controller.'profileUpdate');
    Route::get('/sales-person-details/{id}',$controller.'getDetails');
    Route::post('/get-sales-person', $controller.'getSalesPerson');
    Route::post('/update-sales-person', $controller.'updateSalesPerson');
    Route::post('/search-by-username', $controller.'searchByUsername');
    Route::get('/revert-assigned-lead/{id}',$controller.'revertAssignedLead');