<?php

use Illuminate\Http\Request;

//  for User Management routes


    $controller='ClientController@';

    //Route::post('/lead-registration',$controller.'LeadRegistration');
 
 