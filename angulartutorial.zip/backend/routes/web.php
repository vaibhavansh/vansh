<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function ()
// {
// 	//dd("Backend Working");
// 	$a = getAdminVpId(1);
// 	dd($a);exit;
// });
Route::get('/print-pdf', 'SPController@printPDF');
Route::get('/print-pdf/{id}', 'SPController@generateQuotation');