<?php

use Illuminate\Http\Request;
use App\Http\Middleware\Admin;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::prefix('auth')->group(function () {

    $controller = 'AuthController@';

    Route::post('/do-authenticate-user', $controller.'doAuthenticateUser');
     Route::post('/do-authenticate-client', $controller.'doAuthenticateClient');

    Route::post('/do-register-user', $controller.'doRegisterUser');

   // Route::get('/verify-email/{token}', $controller.'verifyEmail');

   // Route::get('/test', $controller.'test');
});

Route::prefix('password')->group(function () {

    $controller = 'ForgotAndResetPasswordController@';

    Route::post('/forgot-password', $controller.'forgotPassword');

    Route::post('/reset-password', $controller.'resetPassword');

    Route::post('/change-password', $controller.'changePassword')->middleware(['auth:api']);

    Route::post('/change-password-by-admin', $controller.'changePasswordByAdmin')->middleware(['auth:api', Admin::class]);
});


/*
*   For VP Sales routes
**/
Route::middleware(['auth:api'])->prefix('VP')->group(function () {
    include_once(__DIR__.'/route/vp_routes.php');
});

/*
*   For SalesPerson routes
**/
Route::middleware(['auth:api'])->prefix('SP')->group(function () {
    include_once(__DIR__.'/route/sp_routes.php');
});

/*
*   For client routes
**/
Route::middleware(['auth:api'])->prefix('Client')->group(function () {
    include_once(__DIR__.'/route/client_routes.php');
});




Route::prefix('master')->group(function () {

    $controller = 'MasterController@';

    Route::get('/get-phone-codes', $controller.'getPhoneCodes');

    Route::get('/get-country-names',$controller.'getCountryNames');

});

//route for client register through website
Route::post('/leads-registration','MasterController@leadRegistration');

//route for changing vP password from cake php to laravel
Route::post('/first-reset-password', 'AuthController@FirstPasswordReset');