<?php

namespace App;

use Laravel\Passport\HasApiTokens;
use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use HasApiTokens, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    public $timestamps = false;
    protected $fillable = [
        'name',
        'username',
        'email',
        'user_id',
        'password',
        'role_id',
        // 'deactivated_at',
         'is_active',
        // 'mobile_code',
         'sp_id',
         'vp_id',
         'domain',
         'image',
         'ip_address',
         'mobile',
         'address',
         'profile_pic',
         'added_by',
         'system_admin_id',
         'first_login'

        // 'email_verified_at',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    public function leads()
    {
        return $this->hasMany('App\Lead');
    }

    public function mobileCode()
    {
        return $this->hasOne('App\Country', 'id', 'mobile_code');
    }
   

}
