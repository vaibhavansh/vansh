<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Lead extends Model
{
    protected $table = 'leads';
	
	 public $timestamps = false;
   
    protected $fillable = [
        'name',
        'email',
        'contact_no',
        'offices_details',
        'system_admin_id'
        
    ];
}
