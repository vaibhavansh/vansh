<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class SendMail extends Mailable
{
    use Queueable, SerializesModels;

    private $data;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($parameters)
    {
        $this->data = $parameters;
        //dd($this->data);exit;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {//return $this->view('$this->data['template_name'])->with($this->data['template_data']')
        return $this->view('welcome')->with('parameters',$this->data);
           
           // ->subject($this->data['subject'])
            ;
    }
}
