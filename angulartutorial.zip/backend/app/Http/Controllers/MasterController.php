<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Validator;
use App\Lead;
use Exception;
use App\Country;
use Carbon\Carbon;
use DB;

class MasterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Master Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the request relatetd to master table data.
    |
    */

    private $request;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(Request $Request)
    {
        $this->request = $Request;
    }

    /**
     *  Function to get phone codes.
     *
     *  @return : phonecode, id.
     *
     *  Created By : RaHHuL | Created On : 21 sept 2018
     **/
    public function getPhoneCodes(Country $Country)
    {
        try {

            $resultSet = $Country::orderBy('iso')->get(['id', 'phonecode', 'iso']);

            return response()->json([
                'status' => 'success',
                'data' => $resultSet
            ], 200);
        } catch (\Exception $ex) {

            return response()->json([
                'status' => 'error',
                'message' => 'Error : ' . $ex->getMessage(),
                'error_details' => 'on line : ' . $ex->getLine() . ' on file : ' . $ex->getFile(),
            ], 200);
        }
    }

    /**
     *  Function to get country names.
     *
     *  @return : countryname, id.
     *
     *  Created By : Yashwant | Created On : 06 oct 2018
     **/
    public function getCountryNames(Country $Country)
    {
        #code
        try {
            $resultSet = $Country->orderBy('name')->get(['id', 'name']);

            return response()->json([
                'status' => 'success',
                'data' => $resultSet
            ], 200);
        } catch (\Exception $ex) {
            return response()->json([
                'status' => 'error',
                'message' => 'Error : ' . $ex->getMessage(),
                'error_details' => 'on line : ' . $ex->getLine() . ' on file : ' . $ex->getFile(),
            ], 200);
        }
    }


 /**
     *  Function to get country names.
     *
     *  @return : countryname, id.
     *
     *  Created By : Sandeep Deorari | Created On :  13 Aug 2019    
     **/

    public function leadRegistration(Request $request)
    {
        
        $validator = Validator::make($request->all(), [
            'name' => 'required|min:3',
            'company' => 'required|min:3',
            'email' => 'required|email',
            'phone' => 'required|max:12',
            
            'location' => 'required|min:3',
            'offices_sites' => 'required',
            'personnel' => 'required',
            'number_of_pages' => 'required',
            'standards' => 'required|min:3',
            'management_system' => 'required',
         ]);
         if ($validator->fails()) 
            { 
                foreach ($validator->messages()->getMessages() as $field_name => $messages){
                    throw new Exception($messages[0], 1);
                }
            }
 //dd($request);exit;
        try{


                $hostId = getAdminHostId();
                $vpId = getAdminVpId($hostId);
             
            
                $obj = new Lead;
                $obj->name = ucwords($request->name);
                $obj->email = $request->email;
                $obj->contact_no = $request->phone;
                $obj->company = $request->company;
                $obj->website = $request->website;
                $obj->location = $request->location;
                $obj->offices_sites = $request->offices_sites;
                $obj->personnel = $request->personnel;
                $obj->proposed_audit = $request->proposed_audit;
                $obj->number_of_pages = $request->number_of_pages;
                $obj->standards = $request->standards;
                $obj->current_frequency = $request->current_frequency;
                $obj->management_system = $request->management_system;
                $obj->message = $request->message;
                $obj->vp_id = !empty($vpId) ? $vpId : '';
                $obj->sp_id = !empty($request->sp_id) ? $request->sp_id : 0;
                $obj->system_admin_id = !empty($hostId) ? $hostId : '';
                $obj->created_at =  Carbon::now();
                $result = $obj->save();
                if($result)
                {
                    return response()->json([
                        'status'=>'success',
                        'message'=>'Lead Registration Successful', 
                        'data'=> $request->all()]);
                }
                  
         } catch (\Exception $ex) {
            return response()->json([
                'status' => 'error',
                'message' => 'Error : ' . $ex->getMessage(),
                'error_details' => 'on line : ' . $ex->getLine() . ' on file : ' . $ex->getFile(),
            ], 200);
        }
       
    }
}
