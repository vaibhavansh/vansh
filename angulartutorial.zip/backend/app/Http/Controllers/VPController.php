<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Validator;
use Illuminate\Support\Facades\Crypt;
use App\Http\Controllers\MailController;
use App\Http\Controllers\Controller;
use App\User;
use DB;
use App\Lead;
use Exception;
use Illuminate\Support\Facades\Mail;
use App\Mail\SendMail;
use App\Mail\SendMailable;
use Illuminate\Support\Facades\Hash;
use File;
use Carbon\Carbon;
class VPController extends Controller
{
    public function __construct(){
        $this->role_id=\Config::get('constants.SP_ROLE_ID');
    }


     public function ClientDetails()
    {
       
        //printing VP role id defined in config/constants
       // dd(\Config::get('constants.VP_ROLE_ID'));exit;

    	try{
    		$newLeads = Client::where('status',0)->get();
    		$assignedClients = Client::where('status',1)->get();

            if(empty($newLeads)){
                throw new Exception("No New Clients", 1);        
            }
            if(empty($assignedClients)){
                throw new Exception("No Assigned Clients", 1);      
            }

            $data = [];
            $data[0] = $newLeads;
            $data[1] = $assignedClients;

             return response()->json([
                'status' => 'success',
                'data' =>$data ,          
            ], 200);

    	}catch(\Exception $ex) {
            
            return response()->json([
                'status' => 'error',
                'message' => 'Error : '.$ex->getMessage(),
                'error_details' => 'on line : '.$ex->getLine().' on file : '.$ex->getFile(),
            ], 200);
        }
	
    }

    /**
     *  Function to get SalesPerson List.
     *
     *  @return : SalesPerson .
     *
     *  Created By : Sachin | Created On : 5 Aug 2019
    **/

    public function salesPersonList(Request $req)
    {
        // dd('here');exit;
        try{
            $salespersons = User::where('role_id',$this->role_id )->get();

            return response()->json([
                'status' => 'success',
                'data' =>$salespersons ,          
            ], 200);
        
        }catch(\Exception $ex) {  
            return response()->json([
                'status' => 'error',
                'message' => 'Error : '.$ex->getMessage(),
                'error_details' => 'on line : '.$ex->getLine().' on file : '.$ex->getFile(),
            ], 200); 
        }     
    }

    

    /**
     *  Function to Add SalesPerson .
     *
     *  @return : void .
     *
     *  Created By : Sachin | Created On : 5 Aug 2019
    **/

    public function AddSalesPerson(Request $request , MailController $MailController)
    {
        $image_name="";
        $random_password=str_random(10);      
        try{
            $validator = Validator::make($request->all(), [
                'name' =>'required',
                'address' =>'required ',
                'system_admin_id' =>'required',
                'added_by' =>'required',
                'email' =>'required | email',
                'mobile' => 'required | numeric',
                 
            ]);

            if ($validator->fails()) 
            {
                foreach ($validator->messages()->getMessages() as $field_name => $messages){
                    throw new Exception($messages[0], 1);
                }
            }
            
            $userCount = User::where(['email' => $request->email]);
            $userCount = $userCount->count();
            if ($userCount > 0)
            {
                throw new Exception("SalePerson already registered with same Email Id.", 1);
            }
            
            if ($request->hasFile('image')) 
            {
                 $validator = Validator::make($request->all(), [
                     'image' => 'image|mimes:jpeg,png,jpg|max:2048',   
                ]);
                $image = $request->file('image');
                $image_name = time().'.'.$image->getClientOriginalExtension();
                $image_path = public_path('/uploads/images/profile_picture');
                $image->move($image_path, $image_name);
                //$image->save();
            }

            DB::beginTransaction();
            
            $userResponseData = User::updateOrCreate(['id' => $request->id], [     
                'role_id' => $this->role_id,
                'name' => ucwords($request->name),
                'email' => $request->email,
                'address' => $request->address,
                'mobile' => $request->mobile,
                'password' => Hash::make($request->password ?: $random_password),
                'system_admin_id' =>$request->system_admin_id,
                'added_by' =>$request->added_by,
                'is_active' => '1',
                'ip_address' => $request->ip(),
                'first_login'=>1,
                'profile_pic' => $image_name,
            ]);

            $MailController->firstLoginCredentialMail([
                'email' => $request->email,
                'name' => $request->name,
                'password' => $random_password,
            ]);
           	
            DB::commit();

            return response()->json([
                'status' => 'success',
                'message' =>'SalePerson Successfully registered' ,          
            ], 200);
        
        }
        catch(\Exception $ex) 
        {  
            DB::rollback();
            return response()->json([
                'status' => 'error',
                'message' => 'Error : '.$ex->getMessage(),
                'error_details' => 'on line : '.$ex->getLine().' on file : '.$ex->getFile(),
            ], 200); 
         }     
    }

 /**
     *  Function to change SalesPerson status.
     *
     *  @return : SalesPerson .
     *
     *  Created By : Sachin | Created On : 5 Aug 2019
    **/


    public function setTargets(Request $request){
    	
    	$a=($request->password ?: str_random(10));
    	dd($a);exit;


    }

    public function changeStatusSP($id){
        try{
            $result = User::where('id','=',$id)->first();
           
            if($result['is_active']==0){
                $result = User::where('id','=',$id)->update(['is_active'=> 1]);
                if($result){
                    return response()->json([
                        'status' => 'success',
                        'message' =>'Sales Person Successfully Activated' , 
                        'value' => 1,
                    ], 200);

                }
            }else{
                $result = User::where('id','=',$id)->update(['is_active'=> 0]);
                if($result){
                    return response()->json([
                        'status' => 'success',
                        'message' =>'Sales Person Successfully Deactivated', 
                         'value' => 0,         
                    ], 200);
                }

            }
            
        }catch(\Exception $ex) {  
            DB::rollback();
            return response()->json([
                'status' => 'error',
                'message' => 'Error : '.$ex->getMessage(),
                'error_details' => 'on line : '.$ex->getLine().' on file : '.$ex->getFile(),
            ], 200); 
        }     

    }
    


     /**
     *  Function to delete SalesPerson .
     *
     *  @return : SalesPerson .
     *
     *  Created By : Sachin | Created On : 5 Aug 2019
    **/


    public function deleteSalesPerson($id){
       try{
            $result = User::where('id','=',$id)->first();
           
            if($result['is_deleted']==0){
                $result = User::where('id','=',$id)->update(['is_deleted'=> 1]);
                if($result){
                    return response()->json([
                        'status' => 'success',
                        'message' =>'SalePerson Successfully Deleted' , 
                       
                    ], 200);

                }
            }else{
                $result = User::where('id','=',$id)->update(['is_deleted'=> 0]);
                if($result){
                    return response()->json([
                        'status' => 'success',
                        'message' =>'SalePerson Successfully Restored',          
                    ], 200);
                }

            }
            
        }catch(\Exception $ex) {  
            DB::rollback();
            return response()->json([
                'status' => 'error',
                'message' => 'Error : '.$ex->getMessage(),
                'error_details' => 'on line : '.$ex->getLine().' on file : '.$ex->getFile(),
            ], 200); 
        }     
    }


 /**
     *  Function to assign SalesPerson to client.
     *
     *  @return : SalesPerson .
     *
     *  Created By : Sachin | Created On : 5 Aug 2019
    **/


    
    public function assignSalesPerson(Request $request){
        //dd($request);exit;
        try{
           // $result = Lead::where('id','=',$request->id)->first();
            if($request->sp_id == 0){
                return response()->json([
                        'status' => 'error',
                        'message' =>'Please select a SalesPerson' , 
                       
                    ], 200);

            }else{
                $result = Lead::where('id','=',$request->id)->update(['sp_id'=> $request->sp_id]);
                if($result){
                    return response()->json([
                        'status' => 'success',
                        'message' =>'SalesPerson Successfully Assigned' , 
                       
                    ], 200);
                }else{
                     return response()->json([
                        'status' => 'error',
                        'message' =>'Something went wrong' , 
                       
                    ], 200);

                }
            }                         
        }catch(\Exception $ex) {  
            DB::rollback();
            return response()->json([
                'status' => 'error',
                'message' => 'Error : '.$ex->getMessage(),
                'error_details' => 'on line : '.$ex->getLine().' on file : '.$ex->getFile(),
            ], 200); 
        }     //dd($id);exit;


    }


 /**
     *  Function to get new Leads on dashboard.
     *
     *  @return : SalesPerson .
     *
     *  Created By : Sachin | Created On : 5 Aug 2019
    **/



    public function newLeads(){
      //  dd( Carbon::now());exit;
        //$time = date('Gi.s', $timestamp);
      try{
            $newleads=[];

            $newleads = Lead::where('sp_id','=',0)->get();

            foreach ($newleads as $sales) {
                    $timediff= new Carbon($sales['created_at']);
                    $timediff=Carbon::now()->diffForHumans($timediff);
                    $timediff=str_replace('after','ago', $timediff);
                       
                 $sales['created_at'] = $timediff;
            }
                 
            
            //dd($newleads['created_at']);exit;

           $salesPerson =[];
           $salesPerson = User::where('role_id','=',5)->where('is_active','=',1)->where('system_admin_id','=',1)->get(['name','id']);
            foreach ($salesPerson as $sales) {
                 $sales['leads'] = Lead::where('sp_id','=',$sales->id)->get()->toArray();
            }

            $leads = ['new'=>$newleads,
            'assigned'=>$salesPerson ];

            return response()->json([
                'status' => 'success',
                'data' =>$leads ,          
            ], 200);
        
        }catch(\Exception $ex) {  
            return response()->json([
                'status' => 'error',
                'message' => 'Error : '.$ex->getMessage(),
                'error_details' => 'on line : '.$ex->getLine().' on file : '.$ex->getFile(),
            ], 200); 
        }     
    }



 /**
     *  Function to get details of SP.
     *
     *  @return : SalesPerson .
     *
     *  Created By : Sachin | Created On : 5 Aug 2019
    **/


    public function getDetails($id){
        //dd($id);exit;
        try{
            $data = User::where('id','=',$id)->first();

            return response()->json([
                'status' => 'success',
                'data' =>$data ,          
            ], 200);
        
        }catch(\Exception $ex) {  
            return response()->json([
                'status' => 'error',
                'message' => 'Error : '.$ex->getMessage(),
                'error_details' => 'on line : '.$ex->getLine().' on file : '.$ex->getFile(),
            ], 200); 
        }    
    }




 /**
     *  Function to update VP profile.
     *
     *  @return : SalesPerson .
     *
     *  Created By : Sachin | Created On : 5 Aug 2019
    **/





    // Creaed by - Sandeep Deorari
    // Data - 21/Aug/2019 



    public function profileUpdate(Request $request)
    {
        try
        {
            if ($request->hasFile('profile_pic')) 
            {
                $image = $request->file('profile_pic');
                $image_name = time().'.'.$image->getClientOriginalExtension();
                $image_path = public_path('/uploads/images/profile_picture');
                $image->move($image_path, $image_name);

                $data = User::where('id', '=', $request->id)->first();
                
                $exist_Image_Path = $image_path.'/'.$data->profile_pic;
                
                if (File::exists($exist_Image_Path)) 
                {
                    File::delete($exist_Image_Path);    
                }
                $result = User::where('id','=',$request->id)->update([
                    'name' => $request->name,
                    'email' => $request->email,
                    'address' => $request->address,
                    'username' => $request->username,
                    'profile_pic' => $image_name,
                ]);

                if($result)
                {
                    $updatedData = User::where('id', '=', $request->id)->first();
                    
                    return response()->json([
                        'status' => 'success',
                        'message' => 'Profile Updated Successfully !',
                        'authData' => $updatedData,  
                    ], 200); 
                }
                else
                {
                    return response()->json([
                        'status' => 'success',
                        'message' => 'Profile Updated Successfully !',
                    ], 200); 
                }       
            }
            else
            {
                $result = User::where('id','=',$request->id)->update([
                    'name'=> $request->name,
                    'email' => $request->email,
                    'address'=> $request->address,
                    'username'=>$request->username
                ]);

                if($result)
                {
                    $updatedData = User::where('id', '=', $request->id)->first();
                    
                    return response()->json([
                        'status' => 'success',
                        'message' => 'Profile Updated Successfully !',
                        'authData' => $updatedData,  
                    ], 200); 
                }
                else
                {
                    return response()->json([
                        'status' => 'success',
                        'message' => 'Profile Updated Successfully !',
                    ], 200); 
                }     
            }
        }
        catch(\Exception $ex) 
        {  
            return response()->json([
                'status' => 'error',
                'message' => 'Error : '.$ex->getMessage(),
                'error_details' => 'on line : '.$ex->getLine().' on file : '.$ex->getFile(),
            ], 200); 
        }    
    }



 /**
     *  Function to update salesperson by VP.
     *
     *  @return : SalesPerson .
     *
     *  Created By : Sachin | Created On : 5 Aug 2019
    **/



    public function updateSalesPerson(Request $request)
    {

        try
        {
            if ($request->hasFile('profile_pic')) 
            {
                $image = $request->file('profile_pic');
                $image_name = time().'.'.$image->getClientOriginalExtension();
                $image_path = public_path('/uploads/images/profile_picture');
                $image->move($image_path, $image_name);

                $data = User::where('id', '=', $request->id)->first();
                
                $exist_Image_Path = $image_path.'/'.$data->profile_pic;
                
                if (File::exists($exist_Image_Path)) 
                {
                    File::delete($exist_Image_Path);    
                }
                $result = User::where('id',$request->id)->update([
                    'name' => $request->name,
                    'address' => $request->address,
                    'mobile' => $request->mobile,
                    'profile_pic' => $image_name,
                   ]);
                //dd($result);exit;
                if($result)
                {
                    return response()->json([
                        'status' => 'success',
                        'message' =>'Sales Person Updated Successfully ',    
                    ], 200);
                }
                else
                {
                    return response()->json([
                        'status' => 'error',
                        'message' =>'Something went wrong ! ',     
                    ], 201);
                }
            }else{
                $result = User::where('id',$request->id)
                ->update([
                        'name'=> $request->name,
                        'address'=> $request->address,
                        'mobile' => $request->mobile,
                    ]);
             // dd($result);exit;
                if($result)
                {
                    return response()->json([
                        'status' => 'success',
                        'message' =>'Sales Person Updated Successfully ',    
                    ], 200);
                }
                else
                {
                    return response()->json([
                        'status' => 'error',
                        'message' =>'Please Enter Some Data To Update ',     
                    ], 201);
                }

            }
         }catch(\Exception $ex) 
         {  
             return response()->json([
             'status' => 'error',
             'message' => 'Error : '.$ex->getMessage(),
             'error_details' => 'on line : '.$ex->getLine().' on file : '.$ex->getFile(),
             ], 200); 
         }      
    }


 /**
     *  Function to filter salesperson list
     *
     *  @return : SalesPerson .
     *
     *  Created By : Sachin | Created On : 5 Aug 2019
    **/



    public function searchByUsername(Request $request)
    {
        try
        {
            $status = $request->status == "active" ? 1 : 0;
            
            if($request->name && $request->status)
            {
                $data = User::where('role_id', $this->role_id)
                ->where('is_active', $status)         
                ->where('is_deleted', 0)
                ->where('name', 'like', '%' . $request->name . '%')->get();

                return response()->json([
                    'status' => 'success',
                    'message' =>'Sales Person Filtered Successfully ',
                    'data' => $data,    
                ], 200);
            }
            else if($request->name)
            {
                $data = User::where('role_id', $this->role_id)         
                ->where('is_deleted', 0)
                ->where('name', 'like', '%' . $request->name . '%')->get();
        
                return response()->json([
                    'status' => 'success',
                    'message' =>'Sales Person Filtered Successfully ',
                    'data' => $data,    
                ], 200);
            }   
            else if($request->status)
            {
                $data = User::where('role_id', $this->role_id)
                ->where('is_active', $status)         
                ->where('is_deleted', 0)->get();

                return response()->json([
                    'status' => 'success',
                    'message' =>'Sales Person Filtered Successfully ',
                    'data' => $data,    
                ], 200);
            } 
        }
        catch(\Exception $ex)
        {
            return response()->json([
                'status' => 'error',
                'message' => 'Error : '.$ex->getMessage(),
                'error_details' => 'on line : '.$ex->getLine().' on file : '.$ex->getFile(),
                ], 200); 
        }
    }

   
 /**
     *  Function to send assigned lead to new lead list...remove assigned salesperson.
     *
     *  @return : SalesPerson .
     *
     *  Created By : Sachin | Created On : 5 Aug 2019
    **/


    public function revertAssignedLead($id){
        try{
            if($id){
                 $result = Lead::where('id','=',$id)->update(['sp_id'=> 0]);
            return response()->json([
                    'status' => 'success',
                    'message' =>'Sales Person removed from the Lead Successfully ',
                    'data' => $result,    
                ], 200);

            }else{
                return response()->json([
                'status' => 'error',
                'message' => 'Error : '.$ex->getMessage(),
                'error_details' => 'on line : '.$ex->getLine().' on file : '.$ex->getFile(),
                ], 200); 

            }
           
        }
        catch(\Exception $ex)
        {
            return response()->json([
                'status' => 'error',
                'message' => 'Error : '.$ex->getMessage(),
                'error_details' => 'on line : '.$ex->getLine().' on file : '.$ex->getFile(),
                ], 200); 
        }

    }

}
