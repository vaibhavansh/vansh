<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Validator;
use Illuminate\Support\Facades\Crypt;
use App\Http\Controllers\MailController;
use App\Http\Controllers\Controller;
use App\Client;
use App\User;
use App\Lead;
use DB;
use Exception;
use Illuminate\Support\Facades\Mail;
use App\Mail\SendMail;
use App\Mail\SendMailable;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use File;
use PDF;

class SPController extends Controller
{

     public function __construct(){
        $this->vp_id=\Config::get('constants.VP_ROLE_ID');
    }
    //
     

     /**
     *  Function to add client by salesPerson.
     *
     *  @return :  .
     *
     *  Created By : Sachin | Created On : 24 Aug 2019
    **/ 



   public function addClient(Request $request){

   		$random_password=str_random(10);
        
        try{
            $validator = Validator::make($request->all(), [
                'client_name' =>'required',
                'company_name' =>'required',
                'contact_name' =>'required',
                'address' =>'required ',
                //'system_admin_id' =>'required',
                'added_by' =>'required',
                'email' =>'required | email',
                'mobile' => 'required | numeric'    
            ]);

            if ($validator->fails())
            {
                foreach ($validator->messages()->getMessages() as $field_name => $messages)
                {
                    throw new Exception($messages[0], 1);
                }
            }

            $userCount = User::where(['email' => $request->email]);
            $userCount = $userCount->count();
            if ($userCount > 0)
            {
                throw new Exception("SalePerson already registered with same Email Id.", 1);
            }
            $spDetails = User::where(['id' => $request->added_by])->first();
            // $host = getAdminHostId($_SERVER['http_HOST']);
            // dd($spDetails);exit;
            
            DB::beginTransaction();
            
            $userResponseData = Client::updateOrCreate(['id' => $request->id], [     
                'role_id' => $spDetails->role_id,
                'user_id' => $spDetails->id,
                'client_name' => ucwords($request->client_name),
                'company_name' => ucwords($request->client_name),
                'contact_name' => ucwords($request->client_name),
                'email' => $request->email,
                'mobile_number' => $request->mobile,
                'system_admin_id' =>$spDetails->system_admin_id,
                'added_by' =>$request->added_by,
                'address' => $request->address,
                'sp_id' => $spDetails->id,
                'vp_id' => $this->vp_id,
                'is_active' => '1',
                'ip_address' => $request->ip(),
                'created_date' => Carbon::now(),
                'first_login'=>1,

            ]);
            //dd($userResponseData);exit;

            // $MailController->firstLoginCredentialMail([
            //     'email' => $request->email,
            //     'name' => $request->name,
            //     'password' => $random_password,
            // ]);
           	
            DB::commit();

            return response()->json([
                'status' => 'success',
                'message' =>'Client Successfully registered' ,          
            ], 200);
        
        }catch(\Exception $ex) {  
            DB::rollback();
            return response()->json([
                'status' => 'error',
                'message' => 'Error : '.$ex->getMessage(),
                'error_details' => 'on line : '.$ex->getLine().' on file : '.$ex->getFile(),
            ], 200); 
         }     
    }
    
 

 /**
     *  Function to get client List.
     *
     *  @return : clientList .
     *
     *  Created By : Sachin | Created On : 26 Aug 2019
    **/



    public function clientList($id)
    {
    	//dd($id);exit;
    	try{
	    	$clientList = Client::where('sp_id','=', $id)->get();
	    	 return response()->json([
	                'status' => 'success',
	                'data' => $clientList ,

	            ], 200); 
    
		    }catch(\Exception $ex) {  
		            DB::rollback();
		            return response()->json([
		                'status' => 'error',
		                'message' => 'Error : '.$ex->getMessage(),
		                'error_details' => 'on line : '.$ex->getLine().' on file : '.$ex->getFile(),
		            ], 200); 
		    }  
    }
    
   

    // Creaed by - Sandeep Deorari
    // Data - 22/Aug/2019 


    public function changeStatus(Request $request)
    {
        try
        {
            $clientData = Client::where('id','=', $request->id)->get();
            $status = $clientData[0]->is_active == 1 ? 0 : 1;
            $result = Client::where('id','=',$request->id)->update([
                        'is_active' => $status,
                ]);
            if($result)
            {
                return response()->json([
                    'status' => 'success',
                    'message' =>'Client Status Changed Succesfully ! ',    
                ], 200);
            }
            else
            {
                return response()->json([
                    'status' => 'error',
                    'message' =>'Something went wrong ! ',     
                ], 201);
            }
         }
         catch(\Exception $ex) 
         {  
             return response()->json([
             'status' => 'error',
             'message' => 'Error : '.$ex->getMessage(),
             'error_details' => 'on line : '.$ex->getLine().' on file : '.$ex->getFile(),
             ], 200); 
         }     
    }


    


     /**
     *  Function to get new Leads List.
     *
     *  @return :  .
     *
     *  Created By : Sachin | Created On : 26 Aug 2019
    **/


    public function getLeads($id)
    {
        //dd($id);exit;
        try
        {
            $Leads = Lead::where('sp_id','=', $id)->get();
            if($Leads)
            {
                return response()->json([
                    'status' => 'success',
                    'data' =>$Leads,    
                ], 200);
            }
            else
            {
                return response()->json([
                    'status' => 'error',
                    'message' =>'Something went wrong ! ',     
                ], 201);
            }
         }
         catch(\Exception $ex) 
         {  
             return response()->json([
             'status' => 'error',
             'message' => 'Error : '.$ex->getMessage(),
             'error_details' => 'on line : '.$ex->getLine().' on file : '.$ex->getFile(),
             ], 200); 
         }     
    }


 /**
     *  Function to get SalesPerson List.
     *
     *  @return : SalesPerson .
     *
     *  Created By : Sachin | Created On : 27 Aug 2019
    **/

    public function getDetails(Request $request)
    {
        try
        {
            $data = User::where('id','=', $request->id)->first();


            return response()->json([
                'status' => 'success',
                'data' =>$data ,          
            ], 200);
        
        }
        catch(\Exception $ex) 
        {  
            return response()->json([
                'status' => 'error',
                'message' => 'Error : '.$ex->getMessage(),
                'error_details' => 'on line : '.$ex->getLine().' on file : '.$ex->getFile(),
            ], 200); 
        }    
    }


    public function getLeadDetails($id)
    {
        try{
            $LeadDetails = Lead::where('id','=', $id)->get();
            if($LeadDetails){
                return response()->json([
                    'status' => 'success',
                    'data' =>$LeadDetails,    
                ], 200);
            }else{
                return response()->json([
                    'status' => 'error',
                    'message' =>'Something went wrong ! ',     
                ], 201);
            }
         }catch(\Exception $ex) {  
             return response()->json([
             'status' => 'error',
             'message' => 'Error : '.$ex->getMessage(),
             'error_details' => 'on line : '.$ex->getLine().' on file : '.$ex->getFile(),
             ], 200); 
         }     
    }

    public function updateProfile(Request $request)
    {
        try
        {
            if ($request->hasFile('profile_pic')) 
            {
                $image = $request->file('profile_pic');
                $image_name = time().'.'.$image->getClientOriginalExtension();
                $image_path = public_path('/uploads/images/profile_picture');
                $image->move($image_path, $image_name);


                $data = User::where('id', '=', $request->id)->first();
                
                $exist_Image_Path = $image_path.'/'.$data->profile_pic;
                
                if (File::exists($exist_Image_Path)) 
                {
                    File::delete($exist_Image_Path);    
                }
                
                $result = User::where('id','=',$request->id)->update([
                    'name' => $request->name,
                    'email' => $request->email,
                    'address' => $request->address,
                    'username' => $request->username,
                    'profile_pic' => $image_name,
                ]);

                if($result)
                {
                    $updatedData = User::where('id', '=', $request->id)->first();
                    return response()->json([
                        'status' => 'success',
                        'message' => 'Profile Updated Successfully !',
                        'authData' => $updatedData,  
                    ], 200); 
                }
                else
                {
                    return response()->json([
                        'status' => 'success',
                        'message' => 'Profile Updated Successfully !',
                    ], 200); 
                }       
            }
            else
            {
                $result = User::where('id','=',$request->id)->update([
                'name'=> $request->name,
                'email' => $request->email,
                'address'=> $request->address,
                'username'=>$request->username
                ]);

                if($result)
                {
                $updatedData = User::where('id', '=', $request->id)->first();
                return response()->json([
                'status' => 'success',
                'message' => 'Profile Updated Successfully !',
                'authData' => $updatedData, 
                ], 200); 
                }
                else
                {
                return response()->json([
                'status' => 'success',
                'message' => 'Profile Updated Successfully !',
                ], 200); 
                }
            }
        }catch(\Exception $ex) {  
                 return response()->json([
                 'status' => 'error',
                 'message' => 'Error : '.$ex->getMessage(),
                 'error_details' => 'on line : '.$ex->getLine().' on file : '.$ex->getFile(),
                 ], 200); 
        }     
    }


/**
     *  Function to add office details by salesperson.
     *
     *  @return : response .

     *  Created By : Sachin | Created On : 27 Aug 2019
    **/

    public function addOfficeDetails(Request $request){
        try{
               $validator = Validator::make($request->all(), [
                'office_name' =>'required',
                'contact_name' =>'required',
                'address' => 'required',
                'city' =>'required ',
                'state' =>'required ',
                'country' =>'required ',
                'system_admin_id' =>'required',
                'lead_id' =>'required',
                'sp_id' =>'required',
                'email' =>'required | email',
                'employees'=>'requiured',
                'phone_number' => 'required | numeric'    
            ]);

               $level = !empty($request->level) ? $request->level : '0';
                if($request->form_id){
                    $Details = DB::table('client_sub_offices')->where('id',$request->form_id)                          -> update([
                                                    'label' =>ucwords($request->office_name),
                                                    'contact_name' =>$request->contact_name,
                                                    'address' => $request->address,
                                                    'city' =>$request->city,
                                                    'state' =>$request->state,
                                                    'country' =>$request->country,
                                                    'system_admin_id' =>$request->system_admin_id,
                                                    'lead_id' =>$request->lead_id,
                                                    'sp_id' =>$request->sp_id,
                                                    'email' =>$request->email,
                                                    'parent_id' => $level,
                                                    'total_employees'=>$request->employees,
                                                    'audit_type'=>$request->audit_type,
                                                    'organization_phone' =>$request->phone_number,
                                                    'cell_phone' =>$request->cell_phone,
                                                    'is_active' =>1,  
                                                    'created_date' => Carbon::now()
                                                            ]);
                }else{
                    $Details = DB::table('client_sub_offices')->insertGetId([
                                                     'label' =>ucwords($request->office_name),
                                                    'contact_name' =>$request->contact_name,
                                                    'address' => $request->address,
                                                    'city' =>$request->city,
                                                    'state' =>$request->region,
                                                    'country' =>$request->country,
                                                    'system_admin_id' =>$request->system_admin_id,
                                                    'lead_id' =>$request->lead_id,
                                                    'sp_id' =>$request->sp_id,
                                                    'email' =>$request->email,
                                                    'parent_id' => $level,
                                                    'total_employees'=>$request->employees,
                                                    'audit_type'=>$request->audit_type,
                                                    'organization_phone' =>$request->phone_number,
                                                    'cell_phone' =>$request->cell_phone,
                                                    'is_active' =>1,  
                                                    'created_date' => Carbon::now()
                                                            ]);

                }
                if($Details){
                    return response()->json([
                        'status' => 'success',
                        'message' =>'Office created successfully',    
                    ], 200);
                }else{
                    return response()->json([
                        'status' => 'error',
                        'message' =>'Something went wrong ! ',     
                    ], 201);
                }
        }catch(\Exception $ex) {  
                 return response()->json([
                 'status' => 'error',
                 'message' => 'Error : '.$ex->getMessage(),
                 'error_details' => 'on line : '.$ex->getLine().' on file : '.$ex->getFile(),
                 ], 200); 
        }     
    }


    /**
     *  Function to get all office details of lead by salesperson.
     *
     *  @return : response .

     *  Created By : Sachin | Created On : 28 Aug 2019
    **/

    

    public function getOfficeDetails($id)
    {
       // dd($id);exit;
        try{
            $LeadDetails = DB::table('client_sub_offices')->where('lead_id','=', $id)->get()->toArray();
            $tree = buildTree($LeadDetails);
             makeOneLevelArray($tree,$outputArray);
            if($outputArray){

                return response()->json([
                    'status' => 'success',
                    'data' =>$outputArray,    
                ], 200);
            }else{
                    return response()->json([
                        'status' => 'error',
                        'message' => 'No Offices Found',
                    ], 200); 
            }     
        }
        catch(\Exception $ex) 
        {  
            return response()->json([
                'status' => 'error',
                'message' => 'Error : '.$ex->getMessage(),
                'error_details' => 'on line : '.$ex->getLine().' on file : '.$ex->getFile(),
            ], 200); 
        }    
    }

    public function getClient(Request $request)
    {
        try
        {
            $data = Client::where('id','=',$request->id)->first();

            return response()->json([
                'status' => 'success',
                'data' =>$data ,          
            ], 200);
        
        }
        catch(\Exception $ex) 
        {  
            return response()->json([
                'status' => 'error',
                'message' => 'Error : '.$ex->getMessage(),
                'error_details' => 'on line : '.$ex->getLine().' on file : '.$ex->getFile(),
            ], 200); 
        }    
    }

    public function updateClient(Request $request)
    {
        try
        {
            $client = Client::where('id','=',$request->id)->first();
            $client->client_name = $request->client_name;
            $client->address = $request->address;
            $client->phone_number = $request->phone_number;
            $result = $client->save();

            if($result)
            {
                return response()->json([
                    'status' => 'success',
                    'message' =>'Client Updated Successfully ',    
                ], 200);
            }
            else
            {

                return response()->json([
                    'status' => 'error',
                    'message' =>'Something went wrong ! ',     
                ], 201);
            }

        }catch(\Exception $ex) 
        {  

             return response()->json([
             'status' => 'error',
             'message' => 'Error : '.$ex->getMessage(),
             'error_details' => 'on line : '.$ex->getLine().' on file : '.$ex->getFile(),
             ], 200); 

        }     
    }


    /**
     *  Function to get office list in dropdown in addoffice form.
     *
     *  @return : response .

     *  Created By : Sachin | Created On : 28 Aug 2019
    **/


   
//     public function getDropdownValues($id)
//     {
//         try{     
//             $elements = DB::table('client_sub_offices')->where('lead_id','=', $id)->get(['id', 'label', 'parent_id'])->toArray();
            
//              $tree = buildTree($elements);
//              makeOneLevelArray($tree,$outputArray);
//             return response()->json([
//                     'status' => 'success',
//                     'data' =>$outputArray,    
//                 ], 200);
// dd($outputArray);exit;
//             if($outputArray){
//                 return response()->json([
//                     'status' => 'success',
//                     'data' =>$outputArray,    
//                 ], 200);
//             }else{
//                 return response()->json([
//                     'status' => 'error',
//                     'message' =>'Something went wrong ! ',     
//                 ], 201);
//             }
//          }catch(\Exception $ex) {  
//              return response()->json([
//              'status' => 'error',
//              'message' => 'Error : '.$ex->getMessage(),
//              'error_details' => 'on line : '.$ex->getLine().' on file : '.$ex->getFile(),
//              ], 200); 
//          }     
//     }


    /**
     *  Function to delete office by salseperson.
     *
     *  @return : response .

     *  Created By : Sachin | Created On : 28 Aug 2019
    **/



     public function deleteOffice($id)
    {
        //dd($id);exit;
        try{
            
            $deleted_office = DB::table('client_sub_offices')->where('id', $id)->first();
            $isParent = DB::table('client_sub_offices')->where('parent_id', $deleted_office->id)->first();
            if($isParent==null){
                $deleted = DB::table('client_sub_offices')->where('id', $isParent->id)->delete();
            
                return response()->json([
                    'status' => 'success',
                    'message' =>'Office successfully Deleted',    
                ], 200);
            }else{
                return response()->json([
                    'status' => 'error',
                    'message' =>'This Category has Child.Can not be deleted',     
                ], 201);
            }
         }catch(\Exception $ex) {  
             return response()->json([
             'status' => 'error',
             'message' => 'Error : '.$ex->getMessage(),
             'error_details' => 'on line : '.$ex->getLine().' on file : '.$ex->getFile(),
             ], 200); 
         }     
    }
    



    public function searchClient(Request $request)
    {
        try
        {
            $status = $request->status == "active" ? 1 : 0;

            if($request->client_name && $request->status)
            {
                $data = Client::where('sp_id', $request->id)
                ->where('is_active', $status)         
                ->where('is_deleted', 0)
                ->where('client_name', 'like', '%' . $request->client_name . '%')->get();

                return response()->json([
                    'status' => 'success',
                    'message' =>'Sales Person Filtered Successfully ',
                    'data' => $data,    
                ], 200);
            }
            else if($request->client_name)
            {
                $data = Client::where('sp_id', $request->id)        
                ->where('is_deleted', 0)
                ->where('client_name', 'like', '%' . $request->client_name . '%')->get();
        
                return response()->json([
                    'status' => 'success',
                    'message' =>'Sales Person Filtered Successfully ',
                    'data' => $data,    
                ], 200);
            }   
            else if($request->status)
            {
                $data = Client::where('sp_id', $request->id)
                ->where('is_active', $status)         
                ->where('is_deleted', 0)->get();

                return response()->json([
                    'status' => 'success',
                    'message' =>'Sales Person Filtered Successfully ',
                    'data' => $data,    
                ], 200);
            } 
        }
        catch(\Exception $ex)
        {
            return response()->json([
                'status' => 'error',
                'message' => 'Error : '.$ex->getMessage(),
                'error_details' => 'on line : '.$ex->getLine().' on file : '.$ex->getFile(),
                ], 200); 
        }
    }




    public function printPDF()
    {
            $abc = 12;
            $xyz = 13;
           // $data[1] = "abcd" ;
        return view('pdf_view',['abc' => $abc,'xyz'=> $xyz]);
       // This  $data array will be passed to our PDF blade
    //    $data = [
    //       'title' => 'First PDF ',
    //       'heading' => 'Hello ',
    //       'content' => "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged."       
    //         ];
        
    //     $pdf = PDF::loadView('pdf_view', $data);  
    //     return $pdf->download('medium.pdf');
     }



    /**
     *  Function to generate Quotation.
     *
     *  @return : response .

     *  Created By : Sachin | Created On : 29 Aug 2019
    **/



    public function generateQuotation($id)
    {
        
        try{
            $LeadDetails = Lead::where('id','=', $id)->first();
            $OfficeDetails = DB::table('client_sub_offices')->where('lead_id','=', $id)->get();
           
            if(!empty($LeadDetails)){
                if(!empty($OfficeDetails)){
                    $pdf = PDF::loadView('pdf_view', ['LeadDetails' => $LeadDetails,
                    'OfficeDetails'=>$OfficeDetails]);  
                    return  $pdf->download('medium.pdf');
                }else{
                    return response()->json([
                        'status' => 'error',
                        'message' => 'office details not found',
                    ], 200);   
                }
                           
            }else{
                    return response()->json([
                        'status' => 'error',
                        'message' => 'Something went wrong!',
                    ], 200);     
            }
        }
        catch(\Exception $ex) 
        {  
            return response()->json([
                'status' => 'error',
                'message' => 'Error : '.$ex->getMessage(),
                'error_details' => 'on line : '.$ex->getLine().' on file : '.$ex->getFile(),
            ], 200); 
        }    
    }



}
