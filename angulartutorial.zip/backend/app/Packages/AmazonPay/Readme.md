Step 1 :	Put AmazonPay folder inside your app/Packages directory.
Step 2 :	Add pieace of code in composer.json file
			"require": {
				"tuurbo/amazon-payment": "^1.5"
			}
Step 3 :	Run composer update command.
Step 4 :	Add

			use App\Packages\AmazonPay\AmazonPay;

			above line of code after your namespace

			ex : 
			<?php

			namespace App\Packages\AmazonPay;

			use App\Packages\AmazonPay\AmazonPay;

			......

Step 4 :	Add pieace of code in services.php available on app/config/services.php
			
			'amazonpayment' => [
		        'sandbox_mode' => true,
		        'store_name' => 'Your store name',
		        'statement_name' => 'Your statement name',
		        'client_id' => 'Your client ID provided by amazon seller account',
		        'seller_id' => 'Your seller ID provided by amazon seller account',
		        'access_key' => 'Your access key provided by amazon seller account',
		        'secret_key' => 'Your secret key provided by amazon seller account',
		    ]

Step 5 :	Now access your functions you want to use

			Ex. $<you variable name> = AmazonPay::<Your function name>

			$<you variable name> will contain response returned from that funvtion call.

			<Your function name> will require some parameter, you can refer AmazonPay class inside app/Packages/AmazonPay/ for detail about parameters.

Step 6 :	All done!
