<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Client extends Model
{
    protected $table = 'clients';
	
	 public $timestamps = false;
   
    protected $fillable = [
        'client_name',
        'company_name',
        'contact_name',
        'role_id',
        'user_id',
        //'company_name',
        'mobile_number',
        'email',

        // 'deactivated_at',
         'is_active',
        // 'mobile_code',
        // 'mobile',
         'address',
         'created_date',
         'sp_id',
         'vp_id',
         'address',
         //'first_login'
         'system_admin_id',

        // 'email_verified_at',
    ];
}
