<?php // Code within app\Helpers\Helper.php

//use DB;

   function getAdminHostId($host=null) {
   // dd("here");exit;
    	if($host){
			$host = $host;
    	}else{
    		$host = $_SERVER['HTTP_HOST'];
    	}    	
       
        $Userdata = DB::table('users')->select('id')->where('domain', $host)->first();   
        return $Userdata->id;        
	}

	 function getAdminVpId($adminId) {   	
        $vpData = DB::table('users')->select('id')->where('system_admin_id', $adminId)->where('role_id', 4)->where('is_active', 1)->first();    
            return $vpData->id;   
                      
	}


    /**
     *  Function to create list of offices having sub offices.
        E.g:
        Ofice
          --suboffice1
          --suboffice2
     *
     *  @return : response .

     *  Created By : Sachin | Created On : 28 Aug 2019
    **/



	 function buildTree( $elements, $parentId=0) {
        $branch = [];
            foreach ($elements as $element) 
            {
                if ($element->parent_id == $parentId) 
                {
                    $children = buildTree($elements, $element->id);
                    if ($children) 
                    {
                        $element->children = $children;
                    }
                    $branch []= $element;
                }
            }       
           return $branch;
        }

    /**
     *  Function to get office list in dropdown in numbered form.
     *   1
     *   1.1
     *   1.1.2
     *  @return : response .

     *  Created By : Sachin | Created On : 28 Aug 2019
    **/


            
            // function makeOneLevelArray($input,&$out, $prefixLevel = '') {
            //      $level = 1;
                
            //     foreach ($input as $v) {

            //         $array=[];
            //        // dd($v);exit;
            //         //$out[$v->parent_id] = $out[ $v->label];
            //         $array['id']=$v->id;
            //         $array['parent_id']=$v->parent_id;
            //         $array['value']=$prefixLevel . $level . ' ' . $v->label;
            //         $out[] = $array;
            //         if (!empty($v->children)) {
            //             makeOneLevelArray($v->children, $out, $prefixLevel . $level . '.');
            //         }
            //         $level++;
            //     }
            // }

// 


  function makeOneLevelArray($in,&$out, $prefixLevel = '') {
        $level = 1;
        $spaceCount = str_repeat("-", $level);
        foreach ($in as $v) {
            //dd($v);exit;
            $array=[];
            $array['contact_name'] = $v->contact_name;
            $array['address'] = $v->address;
            $array['city'] = $v->city;
            $array['state'] = $v->state;
            $array['country'] = $v->country;
            $array['lead_id'] = $v->lead_id;
            $array['sp_id'] = $v->sp_id;
            $array['organization_phone'] = $v->organization_phone;
            $array['cell_phone'] = $v->cell_phone;
                                                    
                                                    
            
            $array['id']=$v->id;
            $array['parent_id']=$v->parent_id;
            $array['email']=$v->email;
            $array['city']=$v->city;
            $array['total_employees']=$v->total_employees;
            $array['audit_type']=$v->audit_type;
            $array['label']=$prefixLevel . $spaceCount . ' ' . $v->label;
            $out[] = $array;
        if (!empty($v->children)) {
        makeOneLevelArray($v->children, $out, $prefixLevel . $spaceCount);
        }
        $level++;
        }
    }