 <html>
 	<body>
        <div class="flex-center position-ref full-height">
    
            <div class="content">
                <div class="title m-b-md">
                    click on this link to reset password
                </div>
               
                <div class="links">
                <a href="{{env('APP_URL')}}/forget-password/{{$token}}"> Link</a>
                   
                </div>
            </div>
        </div>
    </body>
</html>