<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
        <title>Laravel</title>

    </head>
    <body>
       <div class="content-wrapper">
            <section class="dashboard-section">
                <div class="container-fluid">
                    <div class="sales-view-section">
                    
                        <h2 style="font-size: 30px;text-align: center;">QUOTATION</h2>
                        <div class="widthsaleauto">
                            <div class="row" >
                            
                                <div class="col-sm-6">
                                    <div class="contact-mobile">
                                      Name: <span>{{$LeadDetails->name}}</span>
                                    </div>
                                    <div class="contact-mobile">
                                      Mobile Number: <span>{{$LeadDetails->contact_no}}</span>
                                    </div>
                                    <div class="contact-mobile">
                                            E-mail Address: <span>{{$LeadDetails->email}}</span>
                                    </div>
                                    <div class="contact-mobile">
                                            Location: <span>{{$LeadDetails->location}}</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                       <br>
                       <br>
                    
                        <div class="earning-section">
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="table-responsive">
                                        <table class="table table-bordered" >
                                            <thead  >
                                                <tr>
                                                <th>Office Name</th>
                                                <th scope="col">Location</th>
                                                <th scope="col">Email</th>
                                                <th scope="col">Audit Type</th>
                                                <th scope="col">Ammount</th>
                                               
                                                </tr>
                                            </thead>
                                            <tbody> 
                                                @foreach ($OfficeDetails as $data)
                                                    <tr>
                                                        <td>{{$data->label}}</td>
                                                        <td>{{$data->city}}</td>
                                                        <td>{{$data->email}}</td>
                                                        <td>{{$data->audit_type}}</td>
                                                        <td>  </td>
                                                    </tr>  
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>               
                        </div>          
                    </div>  
                </div>
             </section>     
        </div>
    </body>
</html>