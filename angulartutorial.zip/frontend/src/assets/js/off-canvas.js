  // Off Canvas.js
  (function($) {
    'use strict';
    $(function() {
      $('.navbar-toggler-right').on("click", function() {
        $('.sidebar-offcanvas').toggleClass('active');
      });
    });
  })(jQuery);
