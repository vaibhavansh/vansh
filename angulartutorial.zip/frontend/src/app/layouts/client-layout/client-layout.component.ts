import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-client-layout',
  template: `<div class="container-scroller">
  <app-header></app-header>
  <div class="container-fluid page-body-wrapper">
      <app-sidebar></app-sidebar>
      <div class="main-panel">
          <router-outlet></router-outlet>
          <app-footer></app-footer>
      </div>
  </div>
</div>`,
  styleUrls: []
})
export class ClientLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
