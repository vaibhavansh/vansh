import { Component, OnInit } from '@angular/core';
import { OtherService } from 'src/app/services/other.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  image: any;
    userData: any;

    constructor(
        private otherService: OtherService
    ) {
        this.otherService.getUserData().subscribe((result) => {
            this.userData = result;
        });
    }

    ngOnInit() {
    }

    logout() {
        this.otherService.doLogout();
    }

  }
