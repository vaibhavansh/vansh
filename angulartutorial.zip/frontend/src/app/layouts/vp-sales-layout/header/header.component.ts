import { Component, OnInit } from '@angular/core';

import { OtherService } from '../../../services/other.service';
import { AuthService } from '../../../services/auth.service';
import { ToastrService } from 'ngx-toastr';
import { environment } from '../../../../environments/environment';
import { ConfirmationService } from 'primeng/api';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

    image: any;
    userData: any;
    public imageUrl: any;

    constructor(
        private ConfirmationService:ConfirmationService,
        private toastr:ToastrService,
        private otherService: OtherService,
        private authService:AuthService,
        ) {
        this.otherService.getUserData().subscribe((result) => {
            this.userData = result;
        });

        this.imageUrl = environment.imageUrl;
    }

    ngOnInit() {
    }

    logout() {
        this.ConfirmationService.confirm({
            message: 'Are you sure you want to LogOut?',
            accept: () => {
                this.otherService.doLogout();
            }
        });
    }
    toggleSidebar(){
        document.getElementsByTagName('body')[0].classList.toggle('sidebarCollapsed');
      }
    resetPassword(){
        try {
            this.authService.changePassword(this.userData['id']).subscribe(res => {

                if (res['status'] == 'success') {
                   
                } else {
                    this.toastr.error(res['message']);
                }

            }, (error) => {
                this.otherService.unAuthorizedUserAccess(error);
            });

        } catch (err) {
            this.toastr.error(err);
        }
    
    }

}
