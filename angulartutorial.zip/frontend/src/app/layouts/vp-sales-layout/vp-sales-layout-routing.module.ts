import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {VPSalesLayoutComponent} from './vp-sales-layout.component';


const routes: Routes = [{
  path: '',
  component:VPSalesLayoutComponent,
  children:[{
      path:'',
      loadChildren : () => import('../../modules/vp-sales/vp-sales.module').then(m => m.VPSalesModule),
  }]
 
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class VPSalesLayoutRoutingModule { }
