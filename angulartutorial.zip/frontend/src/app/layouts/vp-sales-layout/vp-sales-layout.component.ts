import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vp-sales-layout',
  template: `
 
      <app-header></app-header>
      
          <app-sidebar></app-sidebar>
         
              <router-outlet></router-outlet>
              <app-footer></app-footer>
         
  `,
  styleUrls: []
})
export class VPSalesLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
