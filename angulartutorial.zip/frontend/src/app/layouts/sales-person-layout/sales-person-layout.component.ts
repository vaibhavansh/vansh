import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sales-person-layout',
  template: ` 

    <app-header></app-header>   
        
      <app-sidebar></app-sidebar>
 
        <router-outlet></router-outlet>
          
          <app-footer></app-footer>

    `,
  styleUrls: []
})
export class SalesPersonLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
