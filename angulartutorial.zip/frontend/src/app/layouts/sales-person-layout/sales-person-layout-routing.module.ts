import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SalesPersonLayoutComponent } from './sales-person-layout.component';


const routes: Routes = [{

    path: '',
    component:SalesPersonLayoutComponent,
    children:[{
        path:'',
        loadChildren: () => import('../../modules/sales-person/sales-person.module').then(m => m.SalesPersonModule),
    }]
   
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SalesPersonLayoutRoutingModule { }
