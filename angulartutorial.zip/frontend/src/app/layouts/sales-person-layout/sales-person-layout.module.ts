import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SalesPersonLayoutRoutingModule } from './sales-person-layout-routing.module';
import { SalesPersonLayoutComponent } from './sales-person-layout.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { ConfirmDialogModule } from 'primeng/confirmdialog';


@NgModule({
  declarations: [SalesPersonLayoutComponent, HeaderComponent, FooterComponent, SidebarComponent],
  imports: [
    CommonModule,
    SalesPersonLayoutRoutingModule,
    ConfirmDialogModule,
  ]
})
export class SalesPersonLayoutModule { }
