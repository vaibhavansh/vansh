import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AuthenticationGuard } from './guard/authentication.guard';
import { FirstResetPasswordComponent } from './modules/first-reset-password/first-reset-password.component';
import { ForgetPasswordComponent } from './modules/forget-password/forget-password.component';


const routes: Routes = [
    {
        path: '',
        loadChildren: () => import('./layouts/home-layout/home-layout.module').then(m => m.HomeLayoutModule),
    },
    {
        path: 'VP',
       loadChildren: () => import('./layouts/vp-sales-layout/vp-sales-layout.module').then(m => m.VPSalesLayoutModule),
    },
    {
        path: 'SP',
       loadChildren: () => import('./layouts/sales-person-layout/sales-person-layout.module').then(m => m.SalesPersonLayoutModule),
    },
    {
        path: 'Client',
       loadChildren: () => import('./layouts/client-layout/client-layout.module').then(m => m.ClientLayoutModule),
    },
    {
        path: 'first-reset-password',
       component:FirstResetPasswordComponent,
    },
    {
        path: 'forget-password/:token',
        component:ForgetPasswordComponent,
    },
   
    {
        path: '**',
        loadChildren: () => import('./shared/page-not-found/page-not-found.module').then(m => m.PageNotFoundModule),
    }
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule { }
