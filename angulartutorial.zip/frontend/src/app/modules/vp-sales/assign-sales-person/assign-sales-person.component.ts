import { Component, OnInit } from '@angular/core';
import { VpSalesService } from 'src/app/services/vp-sales.service';
import { Router, ParamMap } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { OtherService } from 'src/app/services/other.service';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { ValidatorList } from 'src/app/services/validator.service';
import { AuthService } from 'src/app/services/auth.service';
import { ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-assign-sales-person',
  templateUrl: './assign-sales-person.component.html',
  styleUrls: ['./assign-sales-person.component.scss']
})
export class AssignSalesPersonComponent implements OnInit {
    defaultValue=0;
  data: any;
  status: string;
  assignSalespersonForm: FormGroup;
  id: string;
    dropdown=[];
 
  constructor(
    private fb: FormBuilder,
    private router: Router,
    private toastr: ToastrService,
    private otherService: OtherService,
    private authService: AuthService,
    private VpSalesService: VpSalesService,
    private route:ActivatedRoute,
  ) { 
   
  
  }

  ngOnInit() {
    this.route.paramMap.subscribe(
      (params: ParamMap) => {
        this.id = params.get('id');
      }
    )
    this.salesPersonList();
    this.createForm();
  }

  createForm() {
    this.assignSalespersonForm = this.fb.group({
      select :  [Validators.required],
       
    });
}
    
    salesPersonList(){
      let values = JSON.parse(localStorage.getItem('authData'));
      this.VpSalesService.salesPersonList(values).subscribe((result) => {
        this.data=result['data'];
       // console.log(this.data);
        this.dropdown = [];
            this.data.forEach(element => {
                if(element['is_active'] == 1 ) {
                    this.dropdown.push(element);
                    
                } 
            });

        if (result['status'] === 'success') {
           
          //this.toastr.success('success');
            
        } else {
            this.toastr.error(result['message']);
        }

    }, (error) => {
        this.otherService.unAuthorizedUserAccess(error);
    });
      
    }
   

  onSubmit(values) {
      if (this.assignSalespersonForm.invalid) 
      {
         // this.validateFields(this.assignSalespersonForm);
          return ;
      }else {
         // console.log("here");
          let added_by = JSON.parse(localStorage.getItem('authData'));
          added_by=added_by['id'];
      
          const updateDataObject = {
            sp_id: this.assignSalespersonForm.value.select,
            id: this.id,
           
           };
          this.VpSalesService.assignSalesperson(updateDataObject).subscribe((result) => {
              //console.log(updateDataObject);
              if (result['status'] === 'success') {
                  this.router.navigate(['VP/dashboard']).then(() => {
                      this.toastr.success('Salesperson assigned successfully');
                  });
              } else {
                  this.toastr.error(result['message']);
              }

          }, (error) => {
              this.otherService.unAuthorizedUserAccess(error);
          });
      }
  }


  validateFields(formGroup: FormGroup) {
      Object.keys(this.assignSalespersonForm.controls).forEach(field => {
          const control = this.assignSalespersonForm.get(field);
          control.markAsTouched({ onlySelf: true });
          control.markAsDirty({ onlySelf: true });
      });
  }


}
