import { Component, OnInit } from '@angular/core';
import { VpSalesService } from 'src/app/services/vp-sales.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { OtherService } from 'src/app/services/other.service';
import { ConfirmationService } from 'primeng/api';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  data: any;
  status: string;
    currentUserId: any;
   date:any;
 
  constructor(
    private ConfirmationService: ConfirmationService,
    private VpSalesService: VpSalesService,
    private router: Router,
    private toastr: ToastrService,
    private otherService: OtherService,
  ) { 
   
  
  }

  ngOnInit() {
    this.newLeads();
    
   

    
  }
   
    newLeads(){
        let values = JSON.parse(localStorage.getItem('authData'));
        this.VpSalesService.newLeads().subscribe((result) => {
            this.data=result['data'];
            if (result['status'] === 'success') {
                this.data=result['data'];

            } else {
                this.toastr.error(result['message']);
            }

        }, (error) => {
            this.otherService.unAuthorizedUserAccess(error);
        });
        
    }

    currentSalesPerson(id: any)
    {
        this.currentUserId = id;
       
    }

    revertAssignedLead(id){

        this.currentUserId = id;
        this.ConfirmationService.confirm({
            message: 'Do you want to revert assigned Lead?',
            accept: () => {
                this.VpSalesService.revertAssignedLead(id).subscribe((result) => {
                    this.data=result['data'];
                    if (result['status'] === 'success') {
                        this.toastr.success(result['message']);
                        this.newLeads();
                    } else {
                        this.toastr.error(result['message']);
                    }
        
                }, (error) => {
                    this.otherService.unAuthorizedUserAccess(error);
                });
            }
   
        });
    }
       
}
