import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { OtherService } from 'src/app/services/other.service';
import { AuthService } from 'src/app/services/auth.service';
import { VpSalesService } from 'src/app/services/vp-sales.service';
import { ValidatorList } from 'src/app/services/validator.service';

@Component({
  selector: 'app-set-targets',
  templateUrl: './set-targets.component.html',
  styleUrls: ['./set-targets.component.scss']
})
export class SetTargetsComponent implements OnInit {
 
  setTargetform: FormGroup;
  public validationMessages = ValidatorList.accountValidationMessages;
  

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private toastr: ToastrService,
    private otherService: OtherService,
    private authService: AuthService,
    private VpSalesService: VpSalesService,
  ) { }

  ngOnInit() {
    this.createsetTargetform();
  }
  
  createsetTargetform(){
    this.setTargetform = this.fb.group({
      email: ['', [Validators.required, ValidatorList.emailValidator]],
      password: ['', ],
  });
  }
  
  validateFields(formGroup:FormGroup) {
    Object.keys(this.setTargetform.controls).forEach(field => {
        const control = this.setTargetform.get(field);
        control.markAsTouched({ onlySelf: true });
        control.markAsDirty({ onlySelf: true });
    });
  }

  onSubmit(values) {
    if (this.setTargetform.valid) {
        //this.router.navigate(['/VP']);
        this.VpSalesService.setTargets(values).subscribe(result => {
            console.log(result);
        }, (error) => {
          this.otherService.unAuthorizedUserAccess(error);
      });
          
    } else {
        this.validateFields(this.setTargetform);
      }
  }
}
