import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-total-earning',
  templateUrl: './total-earning.component.html',
  styleUrls: ['./total-earning.component.scss']
})
export class TotalEarningComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
