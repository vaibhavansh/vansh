import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { VPSalesRoutingModule } from './vp-sales-routing.module';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AddSalespersonComponent } from './add-salesperson/add-salesperson.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SalespersonListComponent } from './salesperson-list/salesperson-list.component';
import { SetTargetsComponent } from './set-targets/set-targets.component';
import { SalsePersonDetailsComponent } from './salesperson-list/salse-person-details/salse-person-details.component';
import { ProfileComponent } from './profile/profile.component';
import { AssignSalesPersonComponent } from './assign-sales-person/assign-sales-person.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { TotalEarningComponent } from './total-earning/total-earning.component';
import {DataTableModule} from "angular-6-datatable";
import { EditSalesPersonComponent } from './salesperson-list/edit-sales-person/edit-sales-person.component';
// import { FirstResetPasswordComponent } from '../first-reset-password/first-reset-password.component';


@NgModule({
  declarations: [
    DashboardComponent,
    AddSalespersonComponent,
    SalespersonListComponent,
    SetTargetsComponent,
    SalsePersonDetailsComponent,
    ProfileComponent,
    AssignSalesPersonComponent,
    ResetPasswordComponent,
    TotalEarningComponent,
    EditSalesPersonComponent,
   
    
       
  ],
  imports: [
    CommonModule,
    VPSalesRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    DataTableModule,
  ]
})
export class VPSalesModule { }
