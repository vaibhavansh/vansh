import { Component, OnInit } from '@angular/core';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { ValidatorList } from 'src/app/services/validator.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { OtherService } from 'src/app/services/other.service';
import { AuthService } from 'src/app/services/auth.service';
import { VpSalesService } from 'src/app/services/vp-sales.service';
import { environment } from '../../../../environments/environment';
import * as $ from 'jquery';

@Component({
    selector: 'app-profile',
    templateUrl: './profile.component.html',
    styleUrls: ['./profile.component.scss']
})
export class ProfileComponent implements OnInit {
    phoneCodeList: any = [];
    editProfileForm: FormGroup;
    public validationMessages = ValidatorList.accountValidationMessages;
    fileError: string;
    image: any;
    id: string;
    public profileImage: any;
    userData: any;
    public imageUrl: any;
    public preimage  = false;

    constructor(
        private fb: FormBuilder,
        private router: Router,
        private toastr: ToastrService,
        private otherService: OtherService,
        private authService: AuthService,
        private VpSalesService: VpSalesService,
    ) {
        this.id = JSON.parse(localStorage.getItem('authData')).id;
        this.imageUrl = environment.imageUrl;
    }

    ngOnInit() {
        this.ProfileForm();
        this.getVPdata();
    }

    ProfileForm() {
        this.editProfileForm = this.fb.group({
            name: ['', [Validators.required, ValidatorList.numberNotRequiredValidator, ValidatorList.avoidEmptyStrigs]],
            email: ['', [Validators.required, ValidatorList.emailValidator]],
            address: ['', [Validators.required, ValidatorList.avoidEmptyStrigs]],
            username: ['', [Validators.required]],
            profile_pic: [''],
        });
    }

    onSubmit() 
    {
        if(this.editProfileForm.invalid) 
        {
            this.validateFields(this.editProfileForm);
            return;
        } 
        else 
        {
            let id = JSON.parse(localStorage.getItem('authData'));
            id = id['id'];

            var formData = new FormData;
            formData.append('profile_pic', this.editProfileForm.get('profile_pic').value);
            formData.append('name', this.editProfileForm.value.name);
            formData.append('username', this.editProfileForm.value.username);
            formData.append('email', this.editProfileForm.value.email);
            formData.append('address', this.editProfileForm.value.address);
            formData.append('id', id);

            this.VpSalesService.updateProfile(formData)
            .subscribe((result) => 
            {
                console.log(result);
                if (result['status'] === 'success') 
                {
                    if(result['authData'])
                    {
                        localStorage.setItem('authData',JSON.stringify(result['authData']));
                    }   
                    this.toastr.success(result['message']);
                    location.reload();
                } 
                else 
                {
                    this.toastr.error(result['message']);
                }

            }, (error) => {
                this.otherService.unAuthorizedUserAccess(error);
            });
        }
    }

    profile() 
    {
        $("#myfile").click();
    }

    onImageSelect(event)
    {
        if(event.target.files.length > 0)
        {
            console.log("Hello Select Image");
            var file = event.target.files[0];
            var mimeType = event.target.files[0].type;
            if (mimeType.match(/image\/*/) == null) 
            {
                this.toastr.error("Only images are supported !");
                return;
            }
            var reader = new FileReader();
            reader.readAsDataURL(event.target.files[0]); 
            reader.onload = (_event) => 
            { 
                this.profileImage = reader.result;
                this.preimage = true;
            } 
            this.editProfileForm.get('profile_pic').setValue(file);  
        }
    }

    validateFields(formGroup: FormGroup) 
    {
        Object.keys(this.editProfileForm.controls).forEach(field => {
            const control = this.editProfileForm.get(field);
            control.markAsTouched({ onlySelf: true });
            control.markAsDirty({ onlySelf: true });
        });
    }
    

    getVPdata() 
    {
        this.VpSalesService.getDetails(this.id)
        .subscribe((result) => {
            if (result['status'] == 'success') {
                //console.log("here")
                if (!result['data']) {
                    this.toastr.error('Something went wrong');
                    return;
                }
                this.userData = result['data'];
                this.editProfileForm.patchValue({
                    name: this.userData.name,
                    username: this.userData.username,
                    email: this.userData.email,
                    address: this.userData.address,
                });

                if(this.userData.profile_pic)
                {
                    this.profileImage=this.imageUrl+'uploads/images/profile_picture/'+this.userData.profile_pic;
                }
            } 
            else 
            {
                this.toastr.error(result['message']);
            }
        }, (error) => {
            this.otherService.unAuthorizedUserAccess(error);
        });

    }



}
