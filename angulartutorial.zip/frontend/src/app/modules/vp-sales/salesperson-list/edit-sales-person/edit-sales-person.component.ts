import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ValidatorList } from 'src/app/services/validator.service';
import { ActivatedRoute, Router } from '@angular/router';
import { VpSalesService } from 'src/app/services/vp-sales.service';
import { OtherService } from 'src/app/services/other.service';
import { ToastrService } from 'ngx-toastr';
import * as $ from 'jquery';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-edit-sales-person',
  templateUrl: './edit-sales-person.component.html',
  styleUrls: ['./edit-sales-person.component.scss']
})
export class EditSalesPersonComponent implements OnInit 
{
  editsalespersonForm: FormGroup;
  public validationMessages = ValidatorList.accountValidationMessages;
  
  public salespersondata : any;
  salespersonID : any;
  imagePath: string | ArrayBuffer;
  profileImage: string;
  imageUrl: string;


  constructor(
    private fb: FormBuilder,
    private activatedRoute: ActivatedRoute,
    private VpSalesService: VpSalesService,
    private otherService: OtherService,
    private toastr: ToastrService,
    private router: Router,
  ) {
    this.imageUrl = environment.imageUrl;
   }

  ngOnInit() 
  {
    this.createForm()
    
    this.salespersonID = this.activatedRoute.snapshot.params.id;

    this.getsalesperson(this.salespersonID);

  }

  createForm() 
  {
      this.editsalespersonForm = this.fb.group({
        name : ['', [Validators.required,ValidatorList.numberNotRequiredValidator, ValidatorList.avoidEmptyStrigs]],
        address : ['', [Validators.required, ValidatorList.avoidEmptyStrigs]],
        mobile: ['', [Validators.required, Validators.minLength(7), Validators.maxLength(15), Validators.pattern('^[0-9]*$')
          ]],
        email: [''],
        id : [''],
        profile_pic: [''],      
      });
  }

  selectedImage()
  {
      $('#profile_pic').click();
  }

  onImageSelect(event)
  {
      if(event.target.files.length > 0)
      {
          //console.log("Hello Select Image");
          var file = event.target.files[0];
          var mimeType = event.target.files[0].type;
          if (mimeType.match(/image\/*/) == null) 
          {
              this.toastr.error("Only images are supported !");
              return;
          }
          var reader = new FileReader();
          reader.readAsDataURL(event.target.files[0]); 
          reader.onload = (_event) => 
          { 
              this.imagePath = reader.result;
          } 
          this.editsalespersonForm.get('profile_pic').setValue(file);       
      }
  }


  getsalesperson(id: any)
  {
    var values = { id: id };
    this.VpSalesService.getDetails(id)
    .subscribe((result) => {
        if (result['status'] === 'success') 
        {
          console.log(result['data']);
          this.salespersondata = result['data'];
          this.editsalespersonForm.patchValue({
            name: this.salespersondata.name,
            mobile: this.salespersondata.mobile,
            address: this.salespersondata.address,
            id: this.salespersondata.id,
          });
          if(this.salespersondata.profile_pic)
            {
              this.imagePath=this.imageUrl+'uploads/images/profile_picture/'+this.salespersondata.profile_pic;
            //console.log(this.profileImage);
            }
        } 
        else 
        {
          this.toastr.error(result['message']);
        }

       }, (error) => {
           this.otherService.unAuthorizedUserAccess(error);
       });
  }

  onSubmit() 
  {
    if(this.editsalespersonForm.invalid) 
    {
        this.validateFields(this.editsalespersonForm);
        return ;
    }
    else 
    {

      var formData = new FormData;
      formData.append('profile_pic', this.editsalespersonForm.get('profile_pic').value);
      formData.append('name', this.editsalespersonForm.value.name);
      formData.append('address', this.editsalespersonForm.value.address);
      formData.append('mobile', this.editsalespersonForm.value.mobile);
      formData.append('id', this.editsalespersonForm.value.id);

      //console.log(this.editsalespersonForm.value);
      this.VpSalesService.updatesalesperson(formData)
      .subscribe((result) => {
        if (result['status'] === 'success') 
        {
          console.log(result);
          this.toastr.success(result['message']);
          this.router.navigate(['/VP/salesperson-list']);
        } 
        else 
        {
          console.log(result);
          this.toastr.error(result['message']);
        }

       }, (error) => {
           this.otherService.unAuthorizedUserAccess(error);
       });
     }
  }


  validateFields(formGroup: FormGroup) 
  {
      Object.keys(this.editsalespersonForm.controls).forEach(field => {
          const control = this.editsalespersonForm.get(field);
          control.markAsTouched({ onlySelf: true });
          control.markAsDirty({ onlySelf: true });
      });
  }


}
