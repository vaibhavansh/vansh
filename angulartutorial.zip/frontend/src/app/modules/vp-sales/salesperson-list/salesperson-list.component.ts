import { Component, OnInit } from '@angular/core';
import { VpSalesService } from 'src/app/services/vp-sales.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { OtherService } from 'src/app/services/other.service';
import { environment } from '../../../../environments/environment';

@Component({
  selector: 'app-salesperson-list',
  templateUrl: './salesperson-list.component.html',
  styleUrls: ['./salesperson-list.component.scss']
})
export class SalespersonListComponent implements OnInit 
{
  data: any;
  status: string;
  username: string;
  filterStatus: string;
  public imageUrl: string;
  public currentUserId: String;
 
  constructor(
    private VpSalesService: VpSalesService,
    private router: Router,
    private toastr: ToastrService,
    private otherService: OtherService,
  ) 
  {  
    this.imageUrl = environment.imageUrl ;
  }

  ngOnInit() {
    this.salesPersonList();
  }
    
    salesPersonList()
    {
      let values = JSON.parse(localStorage.getItem('authData'));
      this.VpSalesService.salesPersonList(values)
      .subscribe((result) => 
      {
        this.data=result['data'];
        
        console.log(this.data);
        if (result['status'] === 'success') {
            this.router.navigate(['VP/salesperson-list']).then(() => {
                //this.toastr.success('Salesperson created successfully');
            });
        } else {
            this.toastr.error(result['message']);
        }

    }, (error) => {
        this.otherService.unAuthorizedUserAccess(error);
    });
      
    }

    changeStatus(values)
    {
        console.log(values);
        this.VpSalesService.changeStatus(values).subscribe((result) => 
        {  
            //console.log(this.data);
            if (result['status'] === 'success') 
            {
                this.toastr.success(result['message']);
                this.ngOnInit();              
            } 
            else 
            {
                this.toastr.error(result['message']);
            }

        }, (error) => {
            this.otherService.unAuthorizedUserAccess(error);
        });
      
    }
    
    DeleteSalesPerson(values){
      this.VpSalesService.DeleteSalesPerson(values).subscribe((result) => {
        
        //console.log(this.data);
        if (result['status'] === 'success') {
            this.router.navigate(['VP/salesperson-list']).then(() => {
                this.toastr.success(result['message']);
                setTimeout(() => {
                    window.location.reload();
                  }, 700); 
            });
        } else {
            this.toastr.error(result['message']);
        }

    }, (error) => {
        this.otherService.unAuthorizedUserAccess(error);
    });
      
    }


    searchByUsername()
    {
       
        if(this.username || this.filterStatus)
        {
            var values = { name: this.username, status: this.filterStatus };
            //console.log(values);
            this.VpSalesService.searchbyusername(values)
            .subscribe((result) => 
            {
                if (result['status'] === 'success') 
                {
                    console.log(result);
                    this.data=result['data'];
                    if(this.data.length > 0)
                    {
                        this.toastr.success(result['message']);
                    }
                    else
                    {
                        this.toastr.error("Sorry ! There is no Sales Person Like "+ this.username );
                    }  
                } 
                else 
                {                
                    console.log(result);
                    this.toastr.error(result['message']);
                }
        
            }, (error) => {
                this.otherService.unAuthorizedUserAccess(error);
            });
        }
        else
        {
            this.ngOnInit();
        }          
    }

    currentSalesPerson(id: any)
    {
        this.currentUserId = id;
    }

   
}
