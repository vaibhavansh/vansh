import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, ParamMap } from '@angular/router';
import { FormBuilder } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { OtherService } from 'src/app/services/other.service';
import { AuthService } from 'src/app/services/auth.service';
import { VpSalesService } from 'src/app/services/vp-sales.service';

@Component({
  selector: 'app-salse-person-details',
  templateUrl: './salse-person-details.component.html',
  styleUrls: ['./salse-person-details.component.scss']
})
export class SalsePersonDetailsComponent implements OnInit {
  id: any;
  data: any;
  

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private toastr: ToastrService,
    private otherService: OtherService,
    private authService: AuthService,
    private VpSalesService: VpSalesService,
    private route:ActivatedRoute,
  ) { 
    
  }

  ngOnInit() {
    this.route.paramMap.subscribe(
      (params: ParamMap) => {
        this.id = params.get('id');
      }
    );
   // this.getSalesPersonDetails(this.id);
  }
  
  // getSalesPersonDetails(params){
  //   //let values = JSON.parse(localStorage.getItem('authData'));
  //   this.VpSalesService.salesPersonDetails(params).subscribe((result) => {
  //     this.data=result['data'];
      
  //     console.log(this.data);
  //     if (result['status'] === 'success') {
         
  //       //this.toastr.success('success');
          
  //     } else {
  //         this.toastr.error(result['message']);
  //     }

  // }, (error) => {
  //     this.otherService.unAuthorizedUserAccess(error);
  // });
    
  // }


}
