import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DashboardComponent } from './dashboard/dashboard.component';
import { SalespersonListComponent } from './salesperson-list/salesperson-list.component';
import { AddSalespersonComponent } from './add-salesperson/add-salesperson.component';
import { AuthenticationGuard } from 'src/app/guard/authentication.guard';
import { SetTargetsComponent } from './set-targets/set-targets.component';
import { SalsePersonDetailsComponent } from './salesperson-list/salse-person-details/salse-person-details.component';
import { ProfileComponent } from './profile/profile.component';
import { AssignSalesPersonComponent } from './assign-sales-person/assign-sales-person.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { TotalEarningComponent } from './total-earning/total-earning.component';
import { EditSalesPersonComponent } from './salesperson-list/edit-sales-person/edit-sales-person.component';


const routes: Routes = [
  {
    path:'dashboard',
    component:DashboardComponent,
    canActivate: [AuthenticationGuard] 
  },
  {
    path:'',
    redirectTo: 'dashboard',
    pathMatch: 'full'
  },
  {
    path:'profile',
    component:ProfileComponent,
    canActivate: [AuthenticationGuard]
    
  },
  {
    path:'add-salesperson',
    component:AddSalespersonComponent,
    canActivate: [AuthenticationGuard]
  },
  {
    path:'salesperson-list',
    component:SalespersonListComponent,
    canActivate: [AuthenticationGuard],
  },
  {
    path:'first-reset-password',
    component:ResetPasswordComponent,
    
  },
  {
    path:'salesperson-list/:id',
    children:[
      {
        path:'details',
        component: SalsePersonDetailsComponent
      },
      {
        path:'edit-salesperson',
        component: EditSalesPersonComponent
      }]
  },
  {
    path:'set-targets',
    component:SetTargetsComponent,
    canActivate: [AuthenticationGuard]
  },
  {
    path:'dashboard/:id/assign-salesperson',
    component:AssignSalesPersonComponent,
    canActivate: [AuthenticationGuard]
  },
  {
    path:'total-earnings',
    component:TotalEarningComponent,
    canActivate: [AuthenticationGuard]
  },
  {
    path:'change-password',
    component:ResetPasswordComponent,
    canActivate: [AuthenticationGuard]
  },
  {

  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class VPSalesRoutingModule { }
