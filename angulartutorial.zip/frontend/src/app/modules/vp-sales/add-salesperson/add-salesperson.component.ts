import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { VpSalesService } from '../../../services/vp-sales.service';
import { ValidatorList } from '../../../services/validator.service';
import { OtherService } from '../../../services/other.service';
import { AuthService } from '../../../services/auth.service';
import { from } from 'rxjs';
import * as $ from 'jquery';

@Component({
  selector: 'app-add-salesperson',
  templateUrl: './add-salesperson.component.html',
  styleUrls: ['./add-salesperson.component.scss']
})
export class AddSalespersonComponent implements OnInit 
{

    phoneCodeList: any = [];
    addSalespersonForm: FormGroup;
    public validationMessages = ValidatorList.accountValidationMessages;
    public imagePath : any;

    constructor(
      private fb: FormBuilder,
      private router: Router,
      private toastr: ToastrService,
      private otherService: OtherService,
      private authService: AuthService,
      private VpSalesService: VpSalesService,
    ) { }

    ngOnInit() {
      this.getPhoneCodes();
      this.createLoginForm();
    }

    createLoginForm() 
    {
        this.addSalespersonForm = this.fb.group({
          name : ['', [Validators.required,ValidatorList.numberNotRequiredValidator, ValidatorList.avoidEmptyStrigs]],
          email: ['', [Validators.required, ValidatorList.emailValidator]],
          address : ['', [Validators.required, ValidatorList.avoidEmptyStrigs]],  
          mobile_code: [''],
          mobile: ['', [Validators.required, Validators.minLength(7), Validators.maxLength(15), Validators.pattern('^[0-9]*$')
          ]],
          image: [''],      
        });
    }
  
    selectedImage()
    {
        $('#image').click();
    }

    onImageSelect(event)
    {
        if(event.target.files.length > 0)
        {
            console.log("Hello Select Image");
            var file = event.target.files[0];
            var mimeType = event.target.files[0].type;
            if (mimeType.match(/image\/*/) == null) 
            {
                this.toastr.error("Only images are supported !");
                return;
            }
            var reader = new FileReader();
            reader.readAsDataURL(event.target.files[0]); 
            reader.onload = (_event) => 
            { 
                this.imagePath = reader.result;
            } 
            this.addSalespersonForm.get('image').setValue(file);       
        }
    }

    onSubmit(values) 
    {
        if (this.addSalespersonForm.invalid) 
        {
            this.validateFields(this.addSalespersonForm);
            return ;
        }
        else 
        {
            // console.log(values);
            let vp_data = JSON.parse(localStorage.getItem('authData'));
            let added_by=vp_data['id'];
            let system_admin_id=vp_data['system_admin_id'];

            var formData = new FormData;
            formData.append('image', this.addSalespersonForm.get('image').value);
            formData.append('name', this.addSalespersonForm.value.name);
            formData.append('email', this.addSalespersonForm.value.email);
            formData.append('address', this.addSalespersonForm.value.address);
            formData.append('mobile', this.addSalespersonForm.value.mobile);
            formData.append('mobile_code', this.addSalespersonForm.value.mobile_code);
            formData.append('added_by', added_by);
            formData.append('system_admin_id', system_admin_id);

            //console.log(formData.get('sp_image'));
            // const updateDataObject = {
            //     name: this.addSalespersonForm.value.name,
            //     email: this.addSalespersonForm.value.email,
            //     address: this.addSalespersonForm.value.address,
            //     mobile: this.addSalespersonForm.value.mobile,
            //     mobile_code: this.addSalespersonForm.value.mobile_code,
            //     added_by:added_by,
            //     system_admin_id:system_admin_id,
            // };

            this.VpSalesService.addSalesperson(formData).subscribe((result) => {
                //console.log(updateDataObject);
                if (result['status'] === 'success') 
                {
                    console.log(result);
                    this.router.navigate(['VP/salesperson-list']).then(() => {
                        this.toastr.success('Salesperson created successfully');
                    });
                } 
                else 
                {
                    this.toastr.error(result['message']);
                }

            }, (error) => {
                this.otherService.unAuthorizedUserAccess(error);
            });
        }
    }


    validateFields(formGroup: FormGroup) {
        Object.keys(this.addSalespersonForm.controls).forEach(field => {
            const control = this.addSalespersonForm.get(field);
            control.markAsTouched({ onlySelf: true });
            control.markAsDirty({ onlySelf: true });
        });
    }


    getPhoneCodes() 
    {
        try {

            this.otherService.getPhoneCodes().subscribe(res => {

                if (res['status'] == 'success') {
                    this.phoneCodeList = res['data'];
                } else {
                    this.toastr.error(res['message']);
                }

            }, (error) => {
                this.otherService.unAuthorizedUserAccess(error);
            });

        } catch (err) {
            this.toastr.error(err);
        }
    }

}
