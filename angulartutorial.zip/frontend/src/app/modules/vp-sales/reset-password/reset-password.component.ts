import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { VpSalesService } from '../../../services/vp-sales.service';
import { ValidatorList } from '../../../services/validator.service';
import { OtherService } from '../../../services/other.service';
import { AuthService } from '../../../services/auth.service';
import { from } from 'rxjs';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss']
})
export class ResetPasswordComponent implements OnInit 
{

  //phoneCodeList: any = [];
    changePasswordForm: FormGroup;
    public validationMessages = ValidatorList.accountValidationMessages;
  

    constructor(
        private fb: FormBuilder,
        private router: Router,
        private toastr: ToastrService,
        private otherService: OtherService,
        private authService: AuthService,
        private VpSalesService: VpSalesService,
    ) { }

    ngOnInit() 
    {

        this.createForm();
    }

    createForm() 
    {
        this.changePasswordForm = this.fb.group({
            oldPassword : ['', [Validators.required, ValidatorList.avoidEmptyStrigs]],
            password: ['', [Validators.required, ValidatorList.avoidEmptyStrigs]],
            password_confirmation : ['', [Validators.required, ValidatorList.avoidEmptyStrigs]],           
        });
    }

  onSubmit(values) 
  {
      if (this.changePasswordForm.invalid) 
      {
          this.validateFields(this.changePasswordForm);
          return ;
      }else {
         // console.log("here");
         let user_id = JSON.parse(localStorage.getItem('authData'));
         user_id=user_id['id'];
     
         const updateDataObject = {
           id:user_id,
           oldPassword: this.changePasswordForm.value.oldPassword,
           password: this.changePasswordForm.value.password,
           password_confirmation: this.changePasswordForm.value.password_confirmation,
            
         };
         // console.log(updateDataObject);
         this.authService.changePassword(updateDataObject).subscribe((result) => {
             //console.log(updateDataObject);
             if (result['status'] === 'success') {
                 //this.router.navigate(['VP/salesperson-list']).then(() => {
                     this.toastr.success('Password changed successfully');
                // });
             } else {
                 this.toastr.error(result['message']);
             }

         }, (error) => {
             this.otherService.unAuthorizedUserAccess(error);
         });
       }
  }


  validateFields(formGroup: FormGroup) {
      Object.keys(this.changePasswordForm.controls).forEach(field => {
          const control = this.changePasswordForm.get(field);
          control.markAsTouched({ onlySelf: true });
          control.markAsDirty({ onlySelf: true });
      });
  }


  


}

   