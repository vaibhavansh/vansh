import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { VpSalesService } from '../../services/vp-sales.service';
import { ValidatorList } from '../../services/validator.service';
import { OtherService } from '../../services/other.service';
import { AuthService } from '../../services/auth.service';
import { from } from 'rxjs';

@Component({
  selector: 'app-first-reset-password',
  templateUrl: './first-reset-password.component.html',
  styleUrls: ['./first-reset-password.component.scss']
})
export class FirstResetPasswordComponent implements OnInit {

    changePasswordForm: FormGroup;
    public validationMessages = ValidatorList.accountValidationMessages;
    
  
    constructor(
        private fb: FormBuilder,
        private router: Router,
        private toastr: ToastrService,
        private otherService: OtherService,
        private authService: AuthService,
        private VpSalesService: VpSalesService,
    ) { }
  
    ngOnInit() {
        
        this.createForm();
    }
  
    createForm() {
          this.changePasswordForm = this.fb.group({
            oldPassword : ['', [Validators.required]],
            password : ['', [Validators.required, Validators.minLength(6), Validators.maxLength(15), Validators.pattern('^[0-9]*$')]],
          
            password_confirmation: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(15), Validators.pattern('^[0-9]*$')
            ]],
                  
          });
    }
  
    onSubmit(values) {
        if (this.changePasswordForm.invalid) 
        {
            this.validateFields(this.changePasswordForm);
            return ;
        }else {
           // console.log("here");
            let added_by = JSON.parse(localStorage.getItem('authData'));
            added_by=added_by['id'];
        
            const updateDataObject = {
              id:added_by,
              oldPassword: this.changePasswordForm.value.oldPassword,
              password: this.changePasswordForm.value.password,
              password_confirmation:this.changePasswordForm.value.password_confirmation,
               
               
            };
           // console.log(updateDataObject);
            this.otherService.firstresetPassword(updateDataObject).subscribe((result) => {
                //console.log(updateDataObject);
                if (result['status'] === 'success') {
                    this.otherService.doLogout();
                    this.router.navigate(['login']).then(() => {
                        this.toastr.success('Password changed successfully');
                    });
                } else {
                    this.toastr.error(result['message']);
                }
  
            }, (error) => {
                this.otherService.unAuthorizedUserAccess(error);
            });
        }
    }
  
  
    validateFields(formGroup: FormGroup) {
        Object.keys(this.changePasswordForm.controls).forEach(field => {
            const control = this.changePasswordForm.get(field);
            control.markAsTouched({ onlySelf: true });
            control.markAsDirty({ onlySelf: true });
        });
    }
}
  
  
    
    
  
  
  
  
  


