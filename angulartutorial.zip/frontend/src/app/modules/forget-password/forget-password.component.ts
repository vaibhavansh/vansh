import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ValidatorList } from 'src/app/services/validator.service';
import { AuthService } from 'src/app/services/auth.service';
import { OtherService } from 'src/app/services/other.service';
import { VpSalesService } from 'src/app/services/vp-sales.service';


@Component({
  selector: 'app-forget-password',
  templateUrl: './forget-password.component.html',
  styleUrls: ['./forget-password.component.scss']
})
export class ForgetPasswordComponent implements OnInit {
  changePasswordForm: FormGroup;
  public validationMessages = ValidatorList.accountValidationMessages;
  token: any;


  constructor(
      private fb: FormBuilder,
      private router: Router,
      private toastr: ToastrService,
      private otherService: OtherService,
      private authService: AuthService,
      private VpSalesService: VpSalesService,
      private activatedRoute: ActivatedRoute,
  ) { }

  ngOnInit() 
  {
    this.token = this.activatedRoute.snapshot.params['token'];
      this.createForm();
  }

  createForm() 
  {
      this.changePasswordForm = this.fb.group({
          token : [''],
          password: ['', [Validators.required, ValidatorList.avoidEmptyStrigs]],
          password_confirmation : ['', [Validators.required, ValidatorList.avoidEmptyStrigs]],           
      });
  }

onSubmit(values) 
{
    if (this.changePasswordForm.invalid) 
    {
        this.validateFields(this.changePasswordForm);
        return ;
    }else {

       const updateDataObject = {
        
         token: this.token,
         password: this.changePasswordForm.value.password,
         password_confirmation: this.changePasswordForm.value.password_confirmation,
          
       };
       //function  when click on link send to email  to reset password

       this.authService.resetPassword(updateDataObject).subscribe((result) => {
           //console.log(updateDataObject);
           if (result['status'] === 'success') {
               //this.router.navigate(['VP/salesperson-list']).then(() => {
                   this.toastr.success('Password changed successfully');
              // });
           } else {
               this.toastr.error(result['message']);
           }

       }, (error) => {
           this.otherService.unAuthorizedUserAccess(error);
       });
     }
}


validateFields(formGroup: FormGroup) {
    Object.keys(this.changePasswordForm.controls).forEach(field => {
        const control = this.changePasswordForm.get(field);
        control.markAsTouched({ onlySelf: true });
        control.markAsDirty({ onlySelf: true });
    });
}





}

 