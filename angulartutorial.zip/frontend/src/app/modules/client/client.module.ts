import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ClientRoutingModule } from './client-routing.module';
import { RecordsComponent } from './records/records.component';
import { AddAuditComponent } from './add-audit/add-audit.component';
import { PaymentComponent } from './payment/payment.component';


@NgModule({
  declarations: [RecordsComponent, AddAuditComponent, PaymentComponent],
  imports: [
    CommonModule,
    ClientRoutingModule
  ]
})
export class ClientModule { }
