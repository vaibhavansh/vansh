import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-audit',
  templateUrl: './add-audit.component.html',
  styleUrls: ['./add-audit.component.scss']
})
export class AddAuditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
