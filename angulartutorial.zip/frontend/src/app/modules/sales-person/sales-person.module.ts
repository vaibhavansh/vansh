import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SalesPersonRoutingModule } from './sales-person-routing.module';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ProfileComponent } from './profile/profile.component';
import { AddClientComponent } from './add-client/add-client.component';
import { SeeTargetsComponent } from './see-targets/see-targets.component';
import { MonthlyReportsComponent } from './monthly-reports/monthly-reports.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ClientListComponent } from './client-list/client-list.component';
import { AddDetailsComponent } from './add-details/add-details.component';
import { TooltipModule, ModalModule } from 'ngx-bootstrap';
import { EditClientComponent } from './client-list/edit-client/edit-client.component';
import { AddLeadComponent } from './add-lead/add-lead.component';
import { ConfirmationService } from 'primeng/api';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { TotalEarningsComponent } from './total-earnings/total-earnings.component';
import {DataTableModule} from "angular-6-datatable";


@NgModule({
  declarations: [DashboardComponent, 
    ProfileComponent,
    AddClientComponent, 
     SeeTargetsComponent, 
     MonthlyReportsComponent,
     ClientListComponent,
     AddDetailsComponent,
     EditClientComponent,
     AddLeadComponent,
     ResetPasswordComponent,
     TotalEarningsComponent,
     ],
  imports: [
    CommonModule,
    SalesPersonRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    TooltipModule.forRoot(),
    ModalModule.forRoot(),
    ConfirmDialogModule,
    DataTableModule,
  ]
  
})
export class SalesPersonModule { }
