import { Component, OnInit } from '@angular/core';
import {SalesPersonService } from '../../../services/sales-person.service';
import { OtherService } from 'src/app/services/other.service';
import { AuthService } from 'src/app/services/auth.service';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-client-list',
  templateUrl: './client-list.component.html',
  styleUrls: ['./client-list.component.scss']
})
export class ClientListComponent implements OnInit 
{
    data: any;
    username: string;
    filterStatus: string;
    currentClientID: any;
  
    constructor(
        private SalesPersonService: SalesPersonService,
        private otherService: OtherService,
        private toastr: ToastrService,
    ) { }
   
    ngOnInit() 
    {
        this.clientList();
    }

    clientList() 
    {
        try 
        {
            let added_by = JSON.parse(localStorage.getItem('authData'));
            added_by=added_by['id'];
            this.SalesPersonService.clientList(added_by)
            .subscribe(res => 
                {
                    if (res['status'] == 'success') 
                    {
                        this.data = res['data'];
                        // console.log(this.clientList);
                    } 
                    else 
                    {
                        this.toastr.error(res['message']);
                    }
                }, (error) => {
                    this.otherService.unAuthorizedUserAccess(error);
            });
        } 
        catch (err) 
        {
            this.toastr.error(err);
        }
    }

    changeStatus(id: any)
    {
        var values = { id: id };
        this.SalesPersonService.changeStatus(values)
        .subscribe(res => 
            {
                if (res['status'] == 'success') 
                {
                    console.log(res);
                    this.toastr.success(res['message']);
                    this.ngOnInit();
                } 
                else 
                {
                    this.toastr.error(res['message']);
                }

            }, (error) => {
                this.otherService.unAuthorizedUserAccess(error);
        });
    }

    currentClient(id: any)
    {
        this.currentClientID = id;
    }

    seacrhClient()
    {
        if(this.username || this.filterStatus)
        {
            let added_by = JSON.parse(localStorage.getItem('authData'));
            added_by=added_by['id'];

            var values = { 
                client_name: this.username, 
                status: this.filterStatus, 
                id: added_by 
            };

            this.SalesPersonService.searchClient(values)
            .subscribe((result) => 
            {
                if (result['status'] === 'success') 
                {
                    console.log(result);
                    this.data=result['data'];
                    if(this.data.length > 0)
                    {
                        this.toastr.success(result['message']);
                    }
                    else
                    {
                        this.toastr.error("Sorry ! There is no Sales Person Like "+ this.username );
                    }  
                } 
                else 
                {                
                    console.log(result);
                    this.toastr.error(result['message']);
                }
        
            }, (error) => {
                this.otherService.unAuthorizedUserAccess(error);
            });
        }
        else
        {
            this.ngOnInit();
        }          
    }


    // DeleteSalesPerson(id: any)
    // {
    //     var values = { id: id };
    //     console.log(values);
    // }
}
