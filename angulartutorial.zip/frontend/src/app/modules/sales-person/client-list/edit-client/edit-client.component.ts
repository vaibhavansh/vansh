import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ValidatorList } from 'src/app/services/validator.service';
import { ActivatedRoute, Router } from '@angular/router';
import { OtherService } from 'src/app/services/other.service';
import { ToastrService } from 'ngx-toastr';
import { SalesPersonService } from 'src/app/services/sales-person.service';

@Component({
  selector: 'app-edit-client',
  templateUrl: './edit-client.component.html',
  styleUrls: ['./edit-client.component.scss']
})
export class EditClientComponent implements OnInit 
{
  editClientForm: FormGroup;
  public validationMessages = ValidatorList.accountValidationMessages;
  
  public clientData : any;
  public clientID : any;

  constructor(
    private fb: FormBuilder,
    private activatedRoute: ActivatedRoute,
    private salesPersonService: SalesPersonService,
    private otherService: OtherService,
    private toastr: ToastrService,
    private router: Router,
  ) { }

  ngOnInit() 
  {
    this.createClientForm();
    this.clientID = this.activatedRoute.snapshot.params.id;
    this.getclient(this.clientID);
  }

  createClientForm() 
  {
      this.editClientForm = this.fb.group({
        client_name : ['', [Validators.required,ValidatorList.numberNotRequiredValidator, ValidatorList.avoidEmptyStrigs]],
        address : ['', [Validators.required, ValidatorList.avoidEmptyStrigs]],
        phone_number: ['', [Validators.required, Validators.minLength(7), Validators.maxLength(15), Validators.pattern('^[0-9]*$')
          ]],
        email: [''],
        id : [''],
    });
  }

  getclient(id: any)
  {
    var values = { id: id };
    console.log(values);
    this.salesPersonService.getClient(values)
    .subscribe((result) => {
        if (result['status'] === 'success') 
        {
          this.clientData = result['data'];
          this.editClientForm.patchValue({
            client_name: this.clientData.client_name,
            phone_number: this.clientData.phone_number,
            address: this.clientData.address,
            id: this.clientData.id,
          });
        } 
        else 
        {
          console.log(result);
        }

       }, (error) => {
           this.otherService.unAuthorizedUserAccess(error);
       });
  }

  onSubmit() 
  {
    if(this.editClientForm.invalid) 
    {
        this.validateFields(this.editClientForm);
        return ;
    }
    else 
    {
      this.salesPersonService.updateClient(this.editClientForm.value)
      .subscribe((result) => {
        if (result['status'] === 'success') 
        {
          console.log(result);
          this.toastr.success(result['message']);
          this.router.navigate(['/SP/client-list']);
        } 
        else 
        {
          console.log(result);
          this.toastr.error(result['message']);
        }

       }, (error) => {
           this.otherService.unAuthorizedUserAccess(error);
       });
     }
  }


  validateFields(formGroup: FormGroup) 
  {
      Object.keys(this.editClientForm.controls).forEach(field => {
          const control = this.editClientForm.get(field);
          control.markAsTouched({ onlySelf: true });
          control.markAsDirty({ onlySelf: true });
      });
  }

}
