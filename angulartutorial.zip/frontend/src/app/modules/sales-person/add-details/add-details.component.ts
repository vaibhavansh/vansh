import { Component, OnInit, TemplateRef } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { ValidatorList } from 'src/app/services/validator.service';
import { ToastrService } from 'ngx-toastr';
import { Router, ParamMap, ActivatedRoute } from '@angular/router';
import { OtherService } from 'src/app/services/other.service';
import { AuthService } from 'src/app/services/auth.service';
import { VpSalesService } from 'src/app/services/vp-sales.service';
import { SalesPersonService } from 'src/app/services/sales-person.service';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { templateVisitAll } from '@angular/compiler';
import {ConfirmationService} from 'primeng/api';
import{saveAs} from 'file-saver';

//import { from } from 'rxjs';


@Component({
  selector: 'app-add-details',
  templateUrl: './add-details.component.html',
  styleUrls: ['./add-details.component.scss']
})
export class AddDetailsComponent implements OnInit {
  
  addDetailsForm: FormGroup;
  public validationMessages = ValidatorList.accountValidationMessages;
  //defaultValue=0;
  data: any;
  rowData: any;
    id: any;
    data1: any;
    officedetails: any;
    updateofficedetails: any;
    modalRef: BsModalRef;
    dropdown = [];
    key: string;
    parent_key: string;
    children: any;
    branch = [];
  

  constructor(
    //private DataTableModule:DataTableModule,
    private ConfirmationService : ConfirmationService,
    private fb: FormBuilder,
    private router: Router,
    private toastr: ToastrService,
    private otherService: OtherService,
    private authService: AuthService,
    private SalesPersonService: SalesPersonService,
    private route:ActivatedRoute,
    private modalService: BsModalService,
  ) { }

    ngOnInit() {
        this.route.paramMap.subscribe(
            (params: ParamMap) => {
            this.id = params.get('id');
            }
        )
        this.getOfficeDetails(this.id);
        this.createdetailsForm();
        this.getLeadDetails(this.id);
    }

    /*** Modal***/

    openModal(template: TemplateRef<any>,rowValue) {
       // console.log(rowValue);
        this.rowData=rowValue;
        let modalclass = 'modal-md';
        this.modalRef = this.modalService.show(template, { class: modalclass });
        this.updateOffice();
    }

    createdetailsForm() {
    this.addDetailsForm = this.fb.group({
        form_id:[''],
        office_name : ['', [Validators.required,ValidatorList.numberNotRequiredValidator, ValidatorList.avoidEmptyStrigs]],
        contact_name : ['', [Validators.required,ValidatorList.numberNotRequiredValidator, ValidatorList.avoidEmptyStrigs]],
        email: ['', [Validators.required, ValidatorList.emailValidator]],
        address : ['', [Validators.required]],  
        level:[''],
        state:['', [Validators.required,ValidatorList.numberNotRequiredValidator, ValidatorList.avoidEmptyStrigs]],
        country:['', [Validators.required,ValidatorList.numberNotRequiredValidator, ValidatorList.avoidEmptyStrigs]],
        city : ['', [Validators.required,ValidatorList.numberNotRequiredValidator, ValidatorList.avoidEmptyStrigs]],
        phone_number: ['', [Validators.required, Validators.minLength(7), Validators.maxLength(15), Validators.pattern('^[0-9]*$')
        ]],
        cell_phone: [''],
        employees:['',[Validators.required]],
        audit_type:[''],
    });
    }

    onSubmit() {
        if (this.addDetailsForm.invalid) {
            this.validateFields(this.addDetailsForm);
            return ;
        }else {
           // console.log('here')
            let added_by = JSON.parse(localStorage.getItem('authData'));
            let system_admin_id=added_by['system_admin_id'];
            let sp_id=added_by['id'];
            const updateDataObject = {
            
            form_id: this.addDetailsForm.value.form_id,
            office_name: this.addDetailsForm.value.office_name,
            contact_name: this.addDetailsForm.value.contact_name, 
            email: this.addDetailsForm.value.email,
            address: this.addDetailsForm.value.address,
            phone_number: this.addDetailsForm.value.phone_number,
            level:this.addDetailsForm.value.level,
            city: this.addDetailsForm.value.city,
            state: this.addDetailsForm.value.state,
            country: this.addDetailsForm.value.country,
            employees:this.addDetailsForm.value.employees,
            audit_type:this.addDetailsForm.value.audit_type,
            lead_id:this.id,
            cell_phone: this.addDetailsForm.value.cell_phone,
            system_admin_id:system_admin_id,
            sp_id:sp_id,
        
          //  added_by:added_by,
            };

            this.SalesPersonService.addOfficeDetails(updateDataObject).subscribe((result) => {
                //console.log(updateDataObject);
                if (result['status'] === 'success') { 
                        this.toastr.success(result['message']); 
                        window.location.reload();
                        this.getOfficeDetails(this.id);   
                } else {
                    //console.log(result);
                    this.toastr.error(result['message']);
                }

            }, (error) => {
                this.otherService.unAuthorizedUserAccess(error);
            });
        }
    }

    validateFields(formGroup: FormGroup) {
        Object.keys(this.addDetailsForm.controls).forEach(field => {
            const control = this.addDetailsForm.get(field);
            control.markAsTouched({ onlySelf: true });
            control.markAsDirty({ onlySelf: true });
        });
    }


    gettingDropdownValues(parent_id){
        this.SalesPersonService.getOfficeDetails(this.id).subscribe((res) => {
            this.dropdown = [];
                if(parent_id == 0) {
                    res['data'].forEach(element => {
                        if(element['parent_id'] == 0 && element['id']!=this.rowData.id) {
                            this.dropdown.push(element);
                            console.log(this.rowData.id);
                        }
                    });
                } else {
                    this.dropdown=res['data']; 
                    console.log(this.dropdown);         
                }
            }, (error) => {
                this.otherService.unAuthorizedUserAccess(error);
        });
    }

    getLeadDetails(values){
        try {
            this.SalesPersonService.getLeadDetails(this.id)
            .subscribe(res =>  {
                    //console.log("hi");
                    if (res['status'] == 'success') {
                        this.data = res['data']; 
                    } 
                    else {
                        this.toastr.error(res['message']);
                    }  
                }, (error) => {
                    this.otherService.unAuthorizedUserAccess(error);
            });
        }catch (err){
            this.toastr.error(err);
        }

    }


    getOfficeDetails(values){
       // console.log("hello");  
        try {
            this.SalesPersonService.getOfficeDetails(this.id)
            .subscribe(res =>  {
                    //console.log("hi");
                    if (res['status'] == 'success') {
                        this.officedetails = res['data']; 
                        console.log( this.officedetails);
                    } 
                    else {
                        this.toastr.error(res['message']);
                    }  
                }, (error) => {
                    this.otherService.unAuthorizedUserAccess(error);
            });

        }catch (err){
            this.toastr.error(err);
        }
    }
    
    
    updateOffice(){
        
        this.gettingDropdownValues(this.rowData.parent_id); 
        try {   
                       this.addDetailsForm.patchValue({
                        form_id: this.rowData.id,
                        email: this.rowData.email,
                        office_name: this.rowData.label,
                        contact_name: this.rowData.contact_name, 
                        address: this.rowData.address,
                        phone_number: this.rowData.organization_phone,
                        level:this.rowData.parent_id,
                        city: this.rowData.city,
                        state: this.rowData.state,
                        country: this.rowData.country,
                        employees:this.rowData.total_employees,
                        audit_type:this.rowData.audit_type,
                        lead_id:this.rowData.lead_id,
                        cell_phone: this.rowData.cell_phone,
                    });

        }catch (err){
            this.toastr.error(err);
        }
    }
   

    deleteOffice(id){
         //console.log(id);  
         this.ConfirmationService.confirm({
            message: 'Are you sure you want to Delete?',
            accept: () => {
                try {
                    this.SalesPersonService.deleteOffice(id)
                    .subscribe(res =>  {
                            if (res['status'] == 'success') {
                            } 
                            else {
                                this.toastr.error(res['message']);
                            }  
                        }, (error) => {
                            this.otherService.unAuthorizedUserAccess(error);
                    });
        
                }catch (err){
                    this.toastr.error(err);
                }
            }
        });
         
     }



     generateQuotation(){
        try {
           
           // window.open('http://127.0.0.1:8000/api/SP/generate-quotation/'+this.id);


            this.SalesPersonService.generateQuotation(this.id)
            .subscribe((res :any )=>  {
                     
                    if (res['status'] == 'error') {
                        this.toastr.error(res['message']);
                    } 
                    else {
                        var blob = new Blob([res], {type: 'application/pdf'});     
                        saveAs(blob, "quotation.pdf");
                    }  
                }, (error) => {
                    this.otherService.unAuthorizedUserAccess(error);
            });

        }catch (err){
            this.toastr.error(err);
        }

     }

        
       
}
     
  
