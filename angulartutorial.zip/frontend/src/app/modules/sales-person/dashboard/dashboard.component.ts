import { Component, OnInit } from '@angular/core';
import { VpSalesService } from 'src/app/services/vp-sales.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { OtherService } from 'src/app/services/other.service';
import { SalesPersonService } from 'src/app/services/sales-person.service';
import { $ } from 'protractor';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  data: any;
  IsmodelShow: false;
  show: boolean;

  constructor(
    private VpSalesService: VpSalesService,
    private SalesPersonService:SalesPersonService,
    private router: Router,
    private toastr: ToastrService,
    private otherService: OtherService,
  ) { }

  ngOnInit() {
    this.getLeads();
  }

  getLeads(){
    let values = JSON.parse(localStorage.getItem('authData'));
    //console.log(values['id']);
     this.SalesPersonService.getLeads(values['id']).subscribe((result) => {
        this.data=result['data'];
        //console.log(this.data);
        if (result['status'] === 'success') {
            this.data=result['data'];

        } else {
            this.toastr.error(result['message']);
        }

    }, (error) => {
        this.otherService.unAuthorizedUserAccess(error);
    });

  }
  
}
