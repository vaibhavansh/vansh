import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-monthly-reports',
  templateUrl: './monthly-reports.component.html',
  styleUrls: ['./monthly-reports.component.scss']
})
export class MonthlyReportsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
