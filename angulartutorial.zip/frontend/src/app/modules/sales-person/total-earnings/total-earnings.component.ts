import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-total-earnings',
  templateUrl: './total-earnings.component.html',
  styleUrls: ['./total-earnings.component.scss']
})
export class TotalEarningsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
