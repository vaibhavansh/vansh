import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {DashboardComponent} from './dashboard/dashboard.component'
import { AuthenticationGuard } from 'src/app/guard/authentication.guard';
import { ProfileComponent } from './profile/profile.component';
import { AddClientComponent } from './add-client/add-client.component';
import { ClientListComponent } from './client-list/client-list.component';
import { AddDetailsComponent } from './add-details/add-details.component';
import { EditClientComponent } from './client-list/edit-client/edit-client.component';
import { AddLeadComponent } from './add-lead/add-lead.component';
import { SeeTargetsComponent } from './see-targets/see-targets.component';
import { TotalEarningsComponent } from './total-earnings/total-earnings.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';




const routes: Routes = [
  {
    path:'',
    redirectTo: 'dashboard',
    pathMatch: 'full'
  },
  {
    path:'dashboard',
    component:DashboardComponent,
    canActivate: [AuthenticationGuard]
  },
  {
    path:'profile',
    component:ProfileComponent,
    canActivate: [AuthenticationGuard]
  },
  {
    path:'add-lead',
    component:AddLeadComponent,
    canActivate: [AuthenticationGuard]
  },
  {
    path:'client-list',
    component:ClientListComponent,
    canActivate: [AuthenticationGuard]
  },
  {
    path:'see-targets',
    component:SeeTargetsComponent,
    canActivate: [AuthenticationGuard]
  },
  {
    path:'total-earnings',
    component:TotalEarningsComponent,
    canActivate: [AuthenticationGuard]
  },
  {
    path:'reset-password',
    component:ResetPasswordComponent,
    canActivate: [AuthenticationGuard]
  },
  {
    path:'dashboard/:id/add-details',
    component:AddDetailsComponent,
    canActivate: [AuthenticationGuard]
  },
  {
    path:'client-list/:id',
    children:[
      {
        path:'edit-client',
        component: EditClientComponent
      }]
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SalesPersonRoutingModule { }
