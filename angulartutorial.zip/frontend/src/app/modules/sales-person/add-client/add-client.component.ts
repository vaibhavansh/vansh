import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { ValidatorList } from 'src/app/services/validator.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { OtherService } from 'src/app/services/other.service';
import { AuthService } from 'src/app/services/auth.service';
import { VpSalesService } from 'src/app/services/vp-sales.service';
import { SalesPersonService } from 'src/app/services/sales-person.service';


@Component({
  selector: 'app-add-client',
  templateUrl: './add-client.component.html',
  styleUrls: ['./add-client.component.scss']
})
export class AddClientComponent implements OnInit {
  phoneCodeList: any = [];
  addClientForm: FormGroup;
  public validationMessages = ValidatorList.accountValidationMessages;
  

constructor(
    private fb: FormBuilder,
    private router: Router,
    private toastr: ToastrService,
    private otherService: OtherService,
    private authService: AuthService,
    private SalesPersonService: SalesPersonService,
) { }

ngOnInit() {
    this.getPhoneCodes();
    this.createLoginForm();
}

createLoginForm() {
      this.addClientForm = this.fb.group({
        client_name : ['', [Validators.required,ValidatorList.numberNotRequiredValidator, ValidatorList.avoidEmptyStrigs]],
        company_name : ['', [Validators.required,ValidatorList.numberNotRequiredValidator, ValidatorList.avoidEmptyStrigs]],
        contact_name : ['', [Validators.required,ValidatorList.numberNotRequiredValidator, ValidatorList.avoidEmptyStrigs]],
        email: ['', [Validators.required, ValidatorList.emailValidator]],
        address : ['', [Validators.required, ValidatorList.avoidEmptyStrigs]],  
        website : ['',[Validators.required]],
        mobile_code: ['', [Validators.required]],
        mobile: ['', [Validators.required, Validators.minLength(7), Validators.maxLength(15), Validators.pattern('^[0-9]*$')
        ]],
      });
  }

  onSubmit() 
  {
    if (this.addClientForm.invalid) 
    {
        this.validateFields(this.addClientForm);
        return ;
    }
    else 
    {
        let added_by = JSON.parse(localStorage.getItem('authData'));
        added_by=added_by['id'];
    
        const updateDataObject = {
        client_name: this.addClientForm.value.client_name, 
        company_name: this.addClientForm.value.company_name,
        contact_name: this.addClientForm.value.contact_name, 
        email: this.addClientForm.value.email,
        address: this.addClientForm.value.address,
        mobile: this.addClientForm.value.mobile,
        mobile_code: this.addClientForm.value.mobile_code,
        added_by:added_by,
        };

        this.SalesPersonService.addClient(updateDataObject).subscribe((result) => {
            //console.log(updateDataObject);
            if (result['status'] === 'success') {
                console.log(result);
                this.router.navigate(['SP/client-list']).then(() => {
                    this.toastr.success(result['message']);
                });
            } else {
                console.log(result);
                this.toastr.error(result['message']);
            }

        }, (error) => {
            this.otherService.unAuthorizedUserAccess(error);
        });
    }
  }


  validateFields(formGroup: FormGroup) {
      Object.keys(this.addClientForm.controls).forEach(field => {
          const control = this.addClientForm.get(field);
          control.markAsTouched({ onlySelf: true });
          control.markAsDirty({ onlySelf: true });
      });
  }


  getPhoneCodes() {
      try {

          this.otherService.getPhoneCodes().subscribe(res => {

              if (res['status'] == 'success') {
                  this.phoneCodeList = res['data'];
              } else {
                  this.toastr.error(res['message']);
              }

          }, (error) => {
              this.otherService.unAuthorizedUserAccess(error);
          });

      } catch (err) {
          this.toastr.error(err);
      }
  }


}
