import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ClientService } from '../../../services/client.service'
import { ToastrService } from 'ngx-toastr';
import { ValidatorList } from 'src/app/services/validator.service';

@Component({
  selector: 'app-add-lead',
  templateUrl: './add-lead.component.html',
  styleUrls: ['./add-lead.component.scss']
})
export class AddLeadComponent implements OnInit {

 
  leadsForm: FormGroup;
  submitted = false;
  router: any;

  constructor(
    private formBuilder: FormBuilder,
    private clientService: ClientService,
    private toastr: ToastrService
  ) { }
  ngOnInit() {
      this.createLeadsForm();

    }
     createLeadsForm(){
      this.leadsForm = this.formBuilder.group({
          name: ['', [Validators.required, Validators.minLength(3),ValidatorList.numberNotRequiredValidator,ValidatorList.avoidEmptyStrigs]],
          company: ['', [Validators.required, Validators.minLength(3),ValidatorList.avoidEmptyStrigs]],
          email: ['', [Validators.required, ValidatorList.emailValidator]],
          phone: ['', [Validators.required,Validators.minLength(7), Validators.maxLength(15), Validators.pattern('^[0-9]*$')]],
          website:[''],
          location: ['', [Validators.required,ValidatorList.avoidEmptyStrigs]],
          offices_sites: ['', [Validators.required]],
          personnel: ['', [Validators.required]],
          proposed_audit: [''],
          number_of_pages: ['', [Validators.required]],
          standards: ['', [Validators.required, Validators.minLength(3)]],
          current_frequency: [''],
          management_system: ['', [Validators.required]],
          message: [''],
        });
     }
    get f() 
    { 
       return this.leadsForm.controls; 
    }
  
    onSubmit()
    {
      this .submitted = true;
      if(this.leadsForm.invalid)
      {
        return;
      }
      else
      {
        let added_by = JSON.parse(localStorage.getItem('authData'));
        added_by=added_by['id'];
        const updateDataObject = {
          name: this.leadsForm.value.name, 
          company: this.leadsForm.value.company,
          email: this.leadsForm.value.email,
          address: this.leadsForm.value.address,
          phone: this.leadsForm.value.phone,
          website: this.leadsForm.value.website,
          location:this.leadsForm.value.location,
          offices_sites:this.leadsForm.value.offices_sites,
          personnel:this.leadsForm.value.personnel,
          proposed_audit:this.leadsForm.value.proposed_audit,
          number_of_pages:this.leadsForm.value.number_of_pages,
          standards:this.leadsForm.value.standards,
          current_frequency:this.leadsForm.value.current_frequency,
          management_system:this.leadsForm.value.management_system,
          sp_id:added_by,
          };
        this.clientService.leadsRegistration(updateDataObject)
        .subscribe(response =>
          {
            if(response['status'] == "success")
            { 
              this.router.navigate(['SP/dashboard']).then(() => {
                this.toastr.success(response['message']);
            });
            }
            else if(response['status'] == "error")
            {
              console.log(response);
              this.toastr.error(response['message']);
            }
            else
            {
              console.log("Something went Wrong");
              this.toastr.warning("Something went Wrong");
            }
          });
      }
    }
  }

