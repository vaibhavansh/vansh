import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-see-targets',
  templateUrl: './see-targets.component.html',
  styleUrls: ['./see-targets.component.scss']
})
export class SeeTargetsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
