import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ClientService } from '../../../services/client.service'
import { ToastrService } from 'ngx-toastr';
import { ValidatorList } from 'src/app/services/validator.service';

@Component({
    selector: 'app-landing',
    templateUrl: './landing.component.html',
    styleUrls: ['./landing.component.scss']
})
export class LandingComponent implements OnInit {

    leadsForm: FormGroup;
    submitted = false;
  
    constructor(
      private formBuilder: FormBuilder,
      private clientService: ClientService,
      private toastr: ToastrService
    ) { }
    ngOnInit() {
        this.createLeadsForm();

      }
       createLeadsForm(){
        this.leadsForm = this.formBuilder.group({
            name: ['', [Validators.required, Validators.minLength(3),ValidatorList.numberNotRequiredValidator,ValidatorList.avoidEmptyStrigs]],
            company: ['', [Validators.required, Validators.minLength(3),ValidatorList.avoidEmptyStrigs]],
            email: ['', [Validators.required, ValidatorList.emailValidator]],
            phone: ['', [Validators.required,Validators.minLength(7), Validators.maxLength(15), Validators.pattern('^[0-9]*$')]],
            website:[''],
            location: ['', [Validators.required,ValidatorList.avoidEmptyStrigs]],
            offices_sites: ['', [Validators.required]],
            personnel: ['', [Validators.required]],
            proposed_audit: [''],
            number_of_pages: ['', [Validators.required]],
            standards: ['', [Validators.required, Validators.minLength(3)]],
            current_frequency: [''],
            management_system: ['', [Validators.required]],
            message: [''],
          });
       }
      get f() 
      { 
         return this.leadsForm.controls; 
      }
    
      onSubmit()
      {
        this .submitted = true;
        if(this.leadsForm.invalid)
        {
          return;
        }
        else
        {
          this.clientService.leadsRegistration(this.leadsForm.value)
          .subscribe(response =>
            {
              if(response['status'] == "success")
              { 
                window.location.reload();
                this.toastr.success(response['message']);
              }
              else if(response['status'] == "error")
              {
                console.log(response);
                this.toastr.error(response['message']);
              }
              else
              {
                console.log("Something went Wrong");
                this.toastr.warning("Something went Wrong");
              }
            });
        }
      }
    }
