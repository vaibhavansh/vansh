import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ClientService {
  baseUrl: string;

  constructor(
      private http: HttpClient
  ) {
    
      this.baseUrl = environment.baseUrl + 'Client/';
  }

  leadsRegistration(params){
   // console.log("here")
    return this.http.post(environment.baseUrl + 'leads-registration',params);

  }
}
