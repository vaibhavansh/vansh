import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class VpSalesService {
  baseUrl: string;
  url: string;

  constructor(
      private http: HttpClient
  ) {
      this.url = environment.baseUrl ;
      this.baseUrl = environment.baseUrl + 'VP/';
  }

 
  //   url: string = 'http://172.10.36.78:8001/Test/login1';

  // doLogin(params) {
  //   //console.log(params['email']);
  //      const headers = new HttpHeaders()
  //          .set('cache-control', 'no-cache')
  //          .set('content-type', 'application/json')
  //          .set('token', 'b408a67d-5f78-54fc-2fb7-00f6e9cefbd1');

  //      const body = {
  //          email: params['email'],
  //          password: params['password'],
  //          //token: 'my token'
  //      }

  //      return this.http.post(this.url, body, { headers: headers });
  // }       
  


  addSalesperson(params) {
    return this.http.post(this.baseUrl + 'add-salesperson', params);
  }


  setTargets(params) { 
    return this.http.post(this.baseUrl + 'set-targets', params);
  }

  salesPersonList(params) { 
    return this.http.post(this.baseUrl + 'salespersons-list',params);
  }

  changeStatus(id){
    return this.http.get(this.baseUrl + 'changestatus/'+id);
  }
  
  DeleteSalesPerson(params){
    return this.http.get(this.baseUrl + 'delete-salesperson/'+params);
  }

  newLeads(){
    return this.http.get(this.baseUrl + 'new-leads');
  }

  assignSalesperson(params){

    return this.http.post(this.baseUrl + 'assign-salesperson',params);
  }

  getDetails(id){
    return this.http.get(this.baseUrl + 'get-details/'+id);
  }

  updateProfile(values){
    return this.http.post(this.baseUrl + 'profile-update',values);

  }

  getsalesperson(values: any)
  {
    return this.http.post(this.baseUrl + 'get-sales-person', values);
  }

  updatesalesperson(values: any)
  {
    return this.http.post(this.baseUrl + 'update-sales-person', values);
  }

  searchbyusername(values: any)
  {
    return this.http.post(this.baseUrl + 'search-by-username', values);
  }
  revertAssignedLead(id){
    return this.http.get(this.baseUrl + 'revert-assigned-lead/'+id);
  }
}
