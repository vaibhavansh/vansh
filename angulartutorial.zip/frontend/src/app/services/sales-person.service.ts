import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class SalesPersonService {
  baseUrl: string;

  constructor(
    private http: HttpClient
  ) {
    this.baseUrl = environment.baseUrl + 'SP/';
  }


  addClient(params) {
    return this.http.post(this.baseUrl + 'add-client/', params);
  }

  clientList(id) {
    return this.http.get(this.baseUrl + 'client-list/' + id);
  }

  changeStatus(values: any) {
    return this.http.post(this.baseUrl + 'change-status', values);
  }

  getLeads(id) {
    return this.http.get(this.baseUrl + 'get-leads/' + id);
  }

  getLeadDetails(id) {
    return this.http.get(this.baseUrl + 'get-lead-details/' + id);
  }

  gettingDropdownValues(id) {
    // return this.http.get('http://34.211.31.84:9113/mobile/v1/recursiveOptionFieldsFrontEnd/51');
    return this.http.get(this.baseUrl + 'get-dropdown-values/'+id);
  }

  addOfficeDetails(values){
    return this.http.post(this.baseUrl + 'add-office-details', values);
  }

  getOfficeDetails(id){
      return this.http.get(this.baseUrl + 'get-office-details/' + id);
  }
  deleteOffice(id){
    return this.http.get(this.baseUrl + 'delete-office/' + id);
}

 

  getDetails(values: any)
  {
    return this.http.post(this.baseUrl + 'get-details', values);
  }

  updateProfile(values: any)
  {
    return this.http.post(this.baseUrl + 'update-profile', values);
  }

  getClient(values: any)
  {
    return this.http.post(this.baseUrl + 'get-client', values);
  }

  updateClient(values: any)
  {
    return this.http.post(this.baseUrl + 'update-client', values);
  }

  searchClient(values: any)
  {
    return this.http.post(this.baseUrl + 'search-client', values);
  }

  generateQuotation(id){
    let headers = new HttpHeaders();
    headers = headers.set('Accept', 'application/pdf');
    return this.http.get(this.baseUrl + 'generate-quotation/'+id ,{ headers: headers, responseType: 'blob' as 'json' });
  }


}
