import { disableDebugTools } from '@angular/platform-browser';

// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
    production: true,
    

     //baseUrl: 'http://127.0.0.1:8000/api/',
     
   baseUrl: 'http://34.211.31.84:9114/backend/public/api/',
    pagination_rows : 10,

   // imageUrl: 'http://127.0.0.1:8000/',


   imageUrl: 'http://34.211.31.84:9114/backend/public/',

};
// export const environment = {
//     production: false,
//     
//     baseUrl : function ()
//     {
//       if(window.location.hostname == 'localhost')
//       {
//         console.log(  'http://127.0.0.1:8000/api/');
//       }
//       else{
//           let url=window.location.href
//           let protocol=url.split('://')
//           let domain=protocol[1]
//           let domain_name=domain.split('/')
  
//           return protocol[0]+'://'+domain_name[0]+'/backend/api/';
//       }
//       }
//     };

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
