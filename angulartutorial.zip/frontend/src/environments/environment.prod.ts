export const environment = {
    production: true,
    pagination_rows : 10,
};
