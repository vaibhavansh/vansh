<?php

class Password_Controllers_UserPasswordsController extends Core_Controllers_SitesController
{
    function delete($id = 0) {
        $UserPassword = new Password_Models_UserPassword($id);
        if(!empty($UserPassword))
        {
            global $page;
            $passwordId = new Password_Models_Password($UserPassword->password_id);
            Notification_Models_Notification::AddNotifications($page->currentUser->id, $passwordId->title, 'Remove shared password with you', $UserPassword->user_id, '');
        }
        parent::delete($id);
        return array();
    }
}