<?php

/**
 *
 * @author saurabhgandhe
 */
class Password_Models_UserPassword extends Core_Models_DbTable {

    static $table = 'user_passwords';
    static $fields = NULL;
    static $requestStatus = array(
        1 => 'Pending',
        2 => 'Approved',
        3 => 'Rejected'
    );

    function getPasswordNotShared($userId) {
        $variables = Core_Controllers_SitesController::edit($userId);
        $optionBoxData = array();
        $passwords = Password_Models_Password::find_all(array('where' => "passwords.id NOT IN (SELECT password_id FROM user_passwords WHERE user_id = '{$userId}')",
                    'cols' => "passwords.*",
                    'orderBy' => "passwords.id asc"));
        if (!empty($passwords)) {
            foreach ($passwords as $password) {
                $optionBoxData[$password->id] = $password->title;
            }
        }
        $userSelector = new OptionBox(array('name' => 'passwords[]',
            'id' => 'passwords' . rand(10, 1000),
            'multiSelect' => true,
            'optionBoxData' => $optionBoxData,
            'className' => 'form-control select-primary',
            'noneOption' => 0,
            'noneOptionText' => 'Select Passwords'));
        $variables['userSelector'] = $userSelector->generate();
        $variables['userid'] = $userId;
        return $variables;
    }

}

?>
