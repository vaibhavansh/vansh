<?php
global $page;
if ($page->currentUser->userLoggedIn) {
    $webUserRole = $page->currentUser->webUserRole;
    $userId = $page->currentUser->id;
}
?>
<div id="modal-form" class="mfp-with-anim">
    <div class="panel">
        <?php
        if (!empty($editpassword)) {
            if (!empty($secured) && $secured == 'secured') {
                ?> 
                <div class="panel-heading">
                    <span class="panel-title">
                        <i class="fa fa-pencil hidden-xs"></i>View Password
                    </span>
                    <div class="clearfix"></div>
                </div>
                <div class="panel-body p10 admin-form">
                    <div class="section row col-md-6">
                        <div class="col-md-3">
                            <label class="field prepend-icon"><strong>Display Title:</strong></label>
                        </div>
                        <div class="col-md-6">
                            <label class="field prepend-icon"><?php echo $editpassword->title; ?></label>
                        </div>
                    </div>
                    <div class="section row col-md-6">
                        <div class="col-md-3">
                            <label class="field prepend-icon"><strong>URL:</strong></label>
                        </div>
                        <div class="col-md-6">
                            <label class="field prepend-icon"><?php echo $editpassword->url; ?></label>
                        </div>
                    </div>
                    <div class="section row col-md-6">
                        <div class="col-md-3">
                            <label class="field prepend-icon"><strong>Username:</strong></label>
                        </div>
                        <div class="col-md-6">
                            <label class="field prepend-icon"><?php echo $editpassword->username; ?></label>
                        </div>
                    </div>
                    <div class="section row col-md-6">
                        <div class="col-md-3">
                            <label class="field prepend-icon"><strong>Password:</strong></label>
                        </div>
                        <div class="col-md-6">
                            <label class="field prepend-icon"><?php echo htmlspecialchars(base64_decode($editpassword->password), ENT_QUOTES) ; ?></label>
                        </div>
                    </div>
                    <div class="section row col-md-6">
                        <div class="col-md-3">
                            <label class="field prepend-icon"><strong>Tags:</strong></label>
                        </div>
                        <div class="col-md-6">
                            <label class="field prepend-icon"><?php echo $editpassword->password_tags; ?></label>
                        </div>
                    </div>
                    <div class="section row col-md-6 mbn">
                        <div class="col-md-3">
                            <label class="field prepend-icon"><strong>Reason:</strong></label>
                        </div>
                        <div class="col-md-6">
                            <label class="field prepend-icon"><?php echo $editpassword->cause; ?></label>
                        </div>
                    </div>
                </div>
                <div class="panel-footer bg-wild-sand admin-form">
                    <div class="section row mbn">
                        <div class="pull-right">
                            <button class="button btn-danger col-xs-12 pull-right" onclick="cancel_onClick()">Close</button>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
            <?php } else { ?>
                <div id="passwordChanged<?php echo $editpassword->id; ?>ResultDiv" class="resultDiv"></div>
                <div class="panel-heading">
                    <span class="panel-title">
                        <i class="fa fa-pencil hidden-xs"></i><?php echo $header; ?>
                    </span>
                    <div class="clearfix"></div>
                </div>
                <form id="passwordChanged<?php echo $editpassword->id; ?>" name='passwordChanged<?php echo $editpassword->id; ?>' method="POST" close_popup="1" keepVisible="1" role="form" action="/savepassword/<?php echo $editpassword->id; ?>" rel='ajaxifiedForm' autocomplete="off" successMsg="Password Updated.">
                    <input type="hidden" id="privacyLevel" name="privacyLevel" value="<?php echo $editpassword->privacy_level; ?>"> 
                    <div class="panel-body p10 admin-form">
                        <div class="section row mbn mt10">
                            <div class="col-md-6 mb10">
                                <label for="displaytitle" class="field prepend-icon">
                                    <input id="title" type="text" name="title" class="gui-input required" value="<?php echo $editpassword->title; ?>">
                                    <label for="displaytitle" class="field-icon"><i class="fa fa-key"></i></label>
                                </label>
                            </div>
                            <div class="col-md-6 mb10">
                                <label for="displaytitleuserid" class="field prepend-icon">
                                    <input id="username" type="text" name="username" class="gui-input required" value="<?php echo $editpassword->username; ?>">
                                    <label for="displaytitleuserid" class="field-icon"><i class="fa fa-user"></i></label>
                                </label>
                            </div>
                        </div>
                        <div class="section row mbn">
                            <div class="col-md-6 mb10">
                                <label for="displaytitleurllink" class="field prepend-icon">
                                    <input id="urllink" type="url" name="urllink" class="gui-input" value="<?php echo $editpassword->url; ?>">
                                    <label for="displaytitleurllink" class="field-icon"><i class="fa fa-link"></i></label>
                                </label>
                            </div>

                            <div class="col-md-6 mb10">
                                <label for="password_tags" class="field prepend-icon">
                                    <input id="" type="text" name="password_tags" class="gui-input" value="<?php echo $editpassword->password_tags; ?>">
                                    <label for="displaytitleurllink" class="field-icon"><i class="glyphicon glyphicon-tags"></i></label>
                                </label>
                            </div>
                        </div>
                        <div class="section row mbn">
                            <div class="col-md-6 mb10">
                                <label for="displaytitlepassword" class="field prepend-icon">
                                    <input id="password" type="text" name="passwordDecode" class="gui-input required" value="<?php echo base64_decode($editpassword->password); ?>">
                                    <label for="displaytitlepassword" class="field-icon"><i class="fa fa-lock"></i></label>
                                </label>
                            </div>
                            <div class="col-md-6 mb10">
                                <label class="field prepend-icon" for="cause">
                                    <textarea autocomplete="off" class="event-name gui-textarea br-light light required" placeholder="Reason of Creation" name="cause" type="text" id="cause"><?php echo $editpassword->cause; ?></textarea>
                                    <label class="field-icon" for="cause"><i class="fa fa-info"></i></label>
                                </label>
                            </div>
                        </div>
                        <?php if ($webUserRole == '2') { ?>
                            <div class="section row mbn">
                                <div class="col-md-6 mb10">
                                    <div id="privacyLevelSpecificDivId">
                                        <?php
                                        $passwordTypeSelector = new OptionBox(array('name' => 'privacy_level',
                                            'id' => 'privacyLevel_' . rand(0, 9),
                                            'multiSelect' => false,
                                            'optionBoxData' => Password_Models_Password::getPasswordTypes(),
                                            'className' => 'event-name gui-input br-light light required privacy_change',
                                            'defaultValue' => isset($editpassword->privacy_level) ? array($editpassword->privacy_level) : array(),
                                            'noneOption' => 0));
                                        echo $passwordTypeSelector->generate();
                                        ?>
                                    </div>
                                </div>
                                <div class="col-md-6 mb10">
                                    <div id="userSpecificDivId">
                                        <div id="appendUserSpecific" style="display: none;">
                                            <?php
                                            $userTypeSelector = new OptionBox(array('name' => 'users[]',
                                                'id' => 'allUsers_' . rand(10, 100),
                                                'multiSelect' => true,
                                                'optionBoxData' => User_Models_User::getAllUsers(),
                                                'className' => 'event-name gui-input br-light light required privacy_change',
                                                'defaultValue' => isset($editpassword->user_specific_ids) ? array($editpassword->user_specific_ids) : array(),
                                                'noneOption' => 0));
                                            echo $userTypeSelector->generate();
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                    </div>
                    <div class="panel-footer bg-wild-sand admin-form">
                        <div class="section row mbn">
                            <div class="pull-right">
                                <button class="button btn-danger col-xs-12 pull-right" onclick="cancel_onClick()"> Cancel </button>
                            </div>
                            <div class="mr10 pull-right">
                                <button type="submit" id="<?php echo $editpassword->id; ?>" class="button btn-success pull-right">Save Changes</button>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </form>
                <?php
            }
        }
        ?>
    </div>
</div>
<script type="text/javascript">
    function cancel_onClick() {
        $('.close').click();
    }
    $('#privacyLevelSpecificDivId select').change(function () {
        var privacylevel_val = $(this).val();
        var webuserrole = '<?php echo $webUserRole; ?>';
        if (privacylevel_val === 'user_specific' && webuserrole === '2') {
            $('#appendUserSpecific').show();
        } else if (privacylevel_val === 'user_specific' && webuserrole !== '2') {
            $('#appendUserSpecific').hide();
            $('#userSpecificDivId').append($('<input type="hidden" name="user_specific_ids" value="<?php echo $userId; ?>">'));
        } else {
            $('#appendUserSpecific').hide();
            $('#userSpecificDivId').append($('<input type="hidden" name="user_specific_ids" value="">'));
        }
    });
    $(document).ready(function () {
        var webuserrole = '<?php echo $webUserRole; ?>';
        var get_privacylevel_val = $('#privacyLevelSpecificDivId select option:selected').val();
        if (get_privacylevel_val === 'user_specific' && webuserrole === '2') {
            $('#appendUserSpecific').show();
        } else {
            $('#appendUserSpecific').hide();
        }
    });
</script>
