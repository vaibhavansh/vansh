<?php
global $page;
if ($page->currentUser->userLoggedIn) {
    $webUserRole = $page->currentUser->webUserRole;
    $userId = $page->currentUser->id;
}
?>
<div class="panel">
    <div id="createPasswordResultDiv" class="resultDiv"></div>
    <div class="panel-heading">
        <span class="panel-title"> 
            <i class="fa fa-lock"></i><?php echo $header; ?>
        </span>
    </div>
    <form id="createPassword" name="createPassword" resultDiv="createPasswordResultDiv" method="POST" keepVisible="1" close_popup="1" role="form" action="/savepassword/<?php echo (isset($editpassword->id) ? $editpassword->id : ''); ?>" rel='ajaxifiedForm' autocomplete="off" backToPage="<?php echo $_SERVER['REQUEST_URI']; ?>" successMsg="Password Saved">
        <input type="hidden" name="webUserRole" value="<?php echo $webUserRole; ?>">
        <input type="hidden" name="userId" value="<?php echo $userId; ?>">
        <div class="panel-body p20 pb10">
            <div class="tab-content pn br-n admin-form">
                <div class="section row mbn">
                    <div class="col-md-12 pn">
                        <div class="section row mb15">
                            <div class="col-xs-12">
                                <label for="displaytitle" class="field prepend-icon">
                                    <input id="title" type="text" name="title" class="gui-input required" placeholder="Display Title" value="<?php echo (isset($editpassword->title) ? $editpassword->title : ''); ?>">
                                    <label for="displaytitle" class="field-icon"><i class="fa fa-key"></i></label>
                                </label>
                            </div>
                        </div>
                        <div class="section row mb15">
                            <div class="col-xs-12">
                                <label for="displaytitleuserid" class="field prepend-icon">
                                    <input id="username" type="text" name="username" class="gui-input required" placeholder="Username / Email" value="<?php echo (isset($editpassword->username) ? $editpassword->username : ''); ?>">
                                    <label for="displaytitleuserid" class="field-icon"><i class="fa fa-user"></i></label>
                                </label>
                            </div>
                        </div>
                        <div class="section row mb15">
                            <div class="col-xs-12">
                                <label for="displaytitleurllink" class="field prepend-icon">
                                    <input id="urllink" type="url" name="url" class="gui-input" placeholder="URL" value="<?php echo (isset($editpassword->url) ? $editpassword->url : ''); ?>">
                                    <label for="displaytitleurllink" class="field-icon"><i class="fa fa-link"></i></label>
                                </label>
                            </div>
                        </div>
                        <div class="section row mb15">
                            <div class="col-xs-12">
                                <label for="displaytitlepassword" class="field prepend-icon">
                                    <input id="password" type="text" name="passwordDecode" class="gui-input required" placeholder="Password" value="<?php echo (isset($editpassword->password) ? base64_decode($editpassword->password) : ''); ?>">
                                    <label for="displaytitlepassword" class="field-icon"><i class="fa fa-lock"></i></label>
                                </label>
                            </div>
                        </div>
                        <div class="section row mb15">
                            <div class="col-xs-12">
                                <label for="password_tags" class="field prepend-icon">
                                    <input id="" type="text" name="password_tags" class="gui-input" placeholder="Password Tags" value="<?php echo (isset($editpassword->password_tags) ? $editpassword->password_tags : ''); ?>">
                                    <label for="displaytitleurllink" class="field-icon"><i class="glyphicon glyphicon-tags"></i></label>
                                </label>
                            </div>
                        </div>
                        <div class="section row mb15">
                            <div class="col-xs-12">
                                <label class="field prepend-icon" for="cause">
                                    <textarea autocomplete="off" class="event-name gui-textarea br-light light required" placeholder="Reason of Creation" name="cause" type="text" id="cause"><?php echo (isset($editpassword->cause) ? $editpassword->cause : ''); ?></textarea>
                                    <label class="field-icon" for="cause"><i class="fa fa-info"></i></label>
                                </label>
                            </div>
                        </div>
                        <div class="section row mb15">
                            <div class="col-xs-12">
                                <div class="section row mb15">
                                    <div id="privacyLevelDivId" class="col-xs-12">
                                        <?php
                                        $passwordTypeSelector = new OptionBox(array('name' => 'privacy_level',
                                            'id' => 'privacyLevel_' . rand(0, 9),
                                            'multiSelect' => false,
                                            'optionBoxData' => Password_Models_Password::getPasswordTypes(),
                                            'className' => 'event-name gui-input br-light light required privacy_change',
                                            'defaultValue' => isset($editpassword->privacy_level) ? array($editpassword->privacy_level) : array(),
                                            'noneOption' => 0));
                                        echo $passwordTypeSelector->generate();
                                        ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="privacyUser" class="section row mb15">
                            <div id="privacyUserAppend" style="display: none;">
                                <?php if ($webUserRole == '2') { ?>
                                    <div class="col-xs-12">
                                        <div class="section row mb15">
                                            <div class="col-xs-12">
                                                <?php
                                                $userTypeSelector = new OptionBox(array('name' => 'users[]',
                                                    'id' => 'allUsers_' . rand(0, 9),
                                                    'multiSelect' => true,
                                                    'optionBoxData' => User_Models_User::getAllUsers(),
                                                    'className' => 'event-name gui-input br-light light required privacy_change',
                                                    'defaultValue' => isset($editpassword->user_specific_ids) ? array($editpassword->user_specific_ids) : array(),
                                                    'noneOption' => 0));
                                                echo $userTypeSelector->generate();
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php }
                                ?>
                            </div>
                        </div>
                    </div>
                    <div class="section row mb15">
                        <div class="col-xs-12">
                            <button class="button btn-success col-xs-12 pull-right" type="submit">Add Entry</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
    <script type="text/javascript">
        $('#privacyLevelDivId select').change(function () {
            var privacylevel_val = $(this).val();
            var webuserrole = '<?php echo $webUserRole; ?>';
            if (privacylevel_val === 'user_specific' && webuserrole === '2') {
                $('#privacyUserAppend').show();
            } else if (privacylevel_val === 'user_specific' && webuserrole !== '2') {
                $('#privacyUser').hide();
                $('#privacyUser').append($('<input type="hidden" name="user_specific_ids" value="<?php echo $userId; ?>">'));
            } else {
                $('#privacyUserAppend').hide();
                $('#privacyUser').append($('<input type="hidden" name="user_specific_ids" value="">'));
            }
        });
    </script>
</div>