<?php global $page; ?>
<div id="sharePasswordUserResultDiv" class="resultDiv"></div>
<div class="panel mb25">
    <div class="panel-heading"><span class="panel-title"> <i class="fa fa-unlock hidden-xs"></i> Share Password</span>
    </div>
    <?php
    if (!empty($userSelector)) {
        ?>
        <form id="sharePasswordUser<?php echo rand(0, 9); ?>" resultDiv="sharePasswordUserResultDiv" name="sharepassword" backToPage="<?php echo $_SERVER['REQUEST_URI']; ?>" method="POST" close_popup="1" keepvisible="1" role="form" action="/requestsharepassword/" rel="ajaxifiedForm" autocomplete="off" successMsg="Password Shared With User.">
            <?php if (!empty($password)) { ?>
                <input type="hidden" id="password" name="password" value="<?php echo $password; ?>">
            <?php } else if (!empty($userid)) { ?> 
                <input type="hidden" id="userid" name="userid" value="<?php echo $userid; ?>">
            <?php } ?>
            <input type="hidden" name="sharedbyadmin" value="Shared By Admin">
            <div class="panel-body p20 pb10">
                <div class="tab-content pn br-n admin-form">
                    <div id="tab1_1" class="tab-pane active">
                        <div class="section row mbn">
                            <div class="col-md-12 pn">
                                <div class="section row mb15">
                                    <div class="col-xs-12">
                                        <?php echo $userSelector; ?>
                                        <i class="arrow"></i>
                                    </div>
                                </div>
                                <div class="section row mb15">
                                    <div class="col-xs-12">
                                        <button class="button btn-success col-xs-12 pull-right" type="submit">Share</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    <?php } else if (!empty($password)) {
        ?>
        <div class="panel-body p20 pb10">
            <h5>This Password Shared With All Users.</h5>
        </div>
    <?php } else if (!empty($userid)) {
        ?>
        <div class="panel-body p20 pb10">
            <h5>All Passwords Shared With This User.</h5>
        </div>
    <?php }
    ?>
    <div class="clearfix"></div>
</div>