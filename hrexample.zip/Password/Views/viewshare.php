<section id="content_wrapper">
    <section id="content" class="animated fadeIn">
        <div id="animation-switcher" class="tray-center col-md-9 col-sm-8 main-div p5">
            <div class="panel mb25 mtn">
                <div class="panel-heading"><span class="panel-title"> <i class="fa fa-th-list hidden-xs"></i><?php echo Password_Models_Password::getPasswordByID($passwordId); ?> Shared List</span>
                </div>
                <div class="panel-menu admin-form theme-primary p5 pbn">
                    <div class="row">
                        <form resultDiv='mainContent' name="searchtagPassword"  id="searchtagPassword" method="post" class="form-inline col-xs-12 pln pb5" keepVisible="1" keepResult="1" action="<?php echo $_SERVER["REQUEST_URI"]; ?>" rel="ajaxifiedForm">        
                            <div class="col-xs-12 pn">
                                <label for="name" class="field prepend-icon">
                                    <input class="event-name gui-input br-light light mbn search-input" type="text" name="searchTitle" placeholder="Search" value="<?php echo $searchTitle = ( isset($_POST['searchTitle']) && $_POST['searchTitle'] != '' ) ? $_POST['searchTitle'] : ''; ?>" />
                                    <label for="name" class="field-icon"><i class="fa fa-search"></i></label>
                                    <div class="btn-fix-right">
                                        <button type="submit" class="submit-btn button btn-success pull-left mr5"><i class="fa fa-search hidden-lg"></i><span class="visible-lg">Search</span></button>
                                        <button type="reset" class="reset-btn button btn-danger"><i class="fa fa-refresh hidden-lg"></i><span class="visible-lg">Reset</span></button>    
                                    </div>
                                </label>
                            </div>
                        </form>
                    </div>
                </div>
                <?php if (!empty($viewShares->data)) { ?>
                    <div class="panel-body pn">
                        <div class="list-com" id="list-com">
                            <div class="col-sm-12 com-detail pt10">
                                <div class="col-sm-2 hidden-xs"><p><strong>Avatar</strong></p></div>
                                <div class="col-sm-6 col-xs-6"><p><strong>Name</strong></p></div>
                                <div class="col-sm-4 col-xs-6 text-right"><p><strong>Action</strong></p></div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                        <?php foreach ($viewShares->data as $viewShare) { ?>
                            <div class="col-sm-12 com-detail p15" id="row_<?php echo $viewShare->passwordId ?>">
                                <div class="col-sm-2 pln hidden-xs">
                                    <img title="user" src="<?php echo (!empty($viewShare->image)) ? '/images/' . $viewShare->image . '_thumb.jpg' : '/img/avatars1.jpg'; ?>" class="img-responsive mw30 ib mr10">
                                </div>
                                <div class="col-sm-6 pln col-xs-6"><p><?php echo $viewShare->fullName; ?></p></div>
                                <div class="col-sm-4 col-xs-6 prn text-right">
                                    <div class="btn-group text-right">                                               
                                        <a class="btn btn-danger br2 btn-xs fs12 dropdown-toggle" href="javascript:void(0);" onclick="deleteRow('<?php echo $viewShare->id; ?>', '<?php echo $viewShare->fullName; ?>', 'deletesharepassword', '/viewshare/<?php echo $passwordId; ?>', 'from this shared password list');">
                                            Remove <span class="glyphicon glyphicon-remove"></span>
                                        </a>
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        <?php } ?>
                    </div>
                    <div class="list-com-data pn">
                        <div class="panel-body pn">
                            <div class="com-detail ">
                                <div class="col-xs-12 pt5">
                                    <div class="pull-left">                             
                                        <h5><?php echo $viewShares->getCurrentPageInfo(); ?></h5>
                                    </div>
                                    <div class="pull-right" >   
                                        <?php echo $viewShares->printPageNumbers(array('url' => "/viewshare/{$passwordId}", 'div_id' => 'mainContent', 'ajaxRequest' => true)); ?>
                                    </div>
                                </div>
                            </div> 
                        </div>
                    </div>
                <?php } else { ?>
                    <div class="list-com-data pn">
                        <div class="panel-body pn">
                            <div class="com-detail ">
                                <div class="col-lg-12 p25">
                                    This password not shared with any user.
                                </div>
                            </div> 
                        </div>
                    </div>
                <?php } ?>
            </div>
            <div class="clearfix"></div>
            <span class="sliding-div">
                <div class="btn-group">
                    <button type="button" class="light div-slider-box visible-lg"><i class="fa fa-sign-out"></i></button>
                </div>
            </span>
        </div>
        <?php if (!empty($addform) || !empty($requestSharePassword)) { ?>
            <aside data-tray-height="match" class="tray tray-center side-div p5">
                <?php echo $addform; ?>
                <?php echo $requestSharePassword; ?>
            </aside>  
        <?php }
        ?>
        <div class="clearfix"></div>
    </section>
</section>
<script>
    $(".reset-btn").click(function () {
        $(this).parents("form").find(".search-input").val("");
        $(this).parents("form").find(".submit-btn").click();
    });
</script>