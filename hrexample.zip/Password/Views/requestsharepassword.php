<?php
global $page;
$webUserRole = !empty($webUserRole) ? $webUserRole : $page->currentUser->webUserRole;
if ($webUserRole == '2') {
    ?>
    <div class="panel mb25 mt5">
        <div id="taguserpwdResultDiv" class="resultDiv"></div>
        <div class="panel-heading"><span class="panel-title"> <i class="fa fa-lock hidden-xs"></i>Sharing Passwords</span>
        </div>
        <div class="panel-body p20 pb10">
            <div class="tab-content pn br-n admin-form">
                <div id="tab1_1" class="tab-pane active">
                    <div class="section row mbn">
                        <div class="col-md-12 pn">
                            <?php if (!empty($passwords)) { ?>
                                <form keepVisible="1" role="form" resultDiv="taguserpwdResultDiv" close_popup="1" action="/requestsharepassword" method="POST" id='tagUserPwd' rel='ajaxifiedForm' autocomplete="off" backToPage="<?php echo $_SERVER['REQUEST_URI']; ?>" successMsg="Password Shared With User">
                                    <input type="hidden" name="sharedbyadmin" value="Shared By Admin">
                                    <div class="section row mb15">
                                        <div class="col-xs-12">
                                            <label for="displaytitle" class="field select">
                                                <select class="event-name gui-input br-light light" id="passwordSharing" name="password" required>
                                                    <option selected disabled value="">Select Passwords</option>
                                                    <?php foreach ($passwords as $passwordList) { ?>
                                                        <option value="<?php echo $passwordList->id; ?>"><?php echo $passwordList->title; ?></option>
                                                    <?php } ?>
                                                </select>
                                                <i class="arrow"></i>
                                            </label>
                                            <div class="clearfix"></div>
                                            <div id="userIdDiv" class="mt15"></div>
                                        </div>
                                    </div>
                                    <div class="section row mb15">
                                        <div class="col-xs-12">
                                            <button class="button btn-success col-xs-12 pull-right sharepassword" type="submit">Share</button>
                                        </div>
                                    </div>
                                </form>
                                <?php
                            } else {
                                echo '<h5>Passwords Not Found For Share</h5>';
                            }
                            ?>
                            <script type="text/javascript">
                                $("#passwordSharing").change(function () {
                                    var password = $("#passwordSharing").val();
                                    if (password === 0) {
                                        $("#passwordlisterrormsg").removeAttr("style");
                                    } else {
                                        $("#passwordlisterrormsg").css("display", "none");
                                    }
                                    var val = $("#passwordSharing option:selected").val();
                                    $.post('/password_passwords/getUntaggedUser/' + password,
                                            {
                                                popup: 'popup',
                                                pageRequestType: 'ajax'
                                            },
                                            function (data) {
                                                if (data === '' || data === undefined) {
                                                    $("#userIdDiv").empty();
                                                    $("#userIdDiv").append('This Password Shared With All Users.');
                                                } else {
                                                    $("#userIdDiv").empty();
                                                    $("#userIdDiv").append(data);
                                                }
                                            });
                                });
                            </script>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
<?php } else { ?>
    <div class="panel mb25 mt5">
        <div id="requestPasswordUserResultDiv" class="resultDiv"></div>
        <div class="panel-heading"><span class="panel-title"> <i class="fa fa-lock hidden-xs"></i>Requesting Passwords</span>
        </div>
        <div class="panel-body p20 pb10">
            <div class="tab-content pn br-n admin-form">
                <div id="tab1_1" class="tab-pane active">
                    <div class="section row mbn">
                        <div class="col-md-12 pn">                                        
                            <?php if (!empty($passwords)) { ?>
                                <form id="requestPasswordUser" resultDiv="requestPasswordUserResultDiv" name="requestpassword" method="POST" close_popup="1" keepvisible="1" role="form" action="/requestsharepassword/" rel="ajaxifiedForm" autocomplete="off" backToPage="<?php echo $_SERVER['REQUEST_URI']; ?>" successMsg="Your Password Sharing Request Sent Successfully.">
                                    <input type="hidden" id="userId" name="user_id" value="<?php echo $page->currentUser->id; ?>">
                                    <input type="hidden" name="requestbyuser" value="requestbyuser">
                                    <div class="section row mb15">
                                        <div class="col-xs-12">
                                            <label for="displaytitle" class="field select">
                                                <select class="event-name gui-input br-light light" id="requestPasswordId" name="password_id" required>
                                                    <option value="" selected disabled>Select Passwords</option>
                                                    <?php
                                                    foreach ($passwords as $password) {
                                                        ?>
                                                        <option value="<?php echo $password->id; ?>"><?php echo $password->title; ?></option>
                                                        <?php
                                                    }
                                                    ?>
                                                </select>
                                                <i class="arrow"></i>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="section row mb15">
                                        <div class="col-xs-12">
                                            <label for="reasonPWD" class="field prepend-icon">
                                                <textarea id="reason" type="text" name="reason" placeholder="Requirement Reason" class="event-name gui-textarea br-light light required"></textarea>
                                                <label for="reasonPWD" class="field-icon"><i class="fa fa-info"></i></label>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="section row mb15">
                                        <div class="col-xs-12">
                                            <button class="button btn-success col-xs-12 pull-right requestbutton" type="submit">Request</button>
                                        </div>
                                    </div>
                                </form>
                            <?php } else {
                                ?>
                                <h5>All Passwords Shared With You.</h5>
                            <?php }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php } ?>