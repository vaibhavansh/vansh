<?php
global $page;
if ($page->currentUser->userLoggedIn) {
    $webUserRole = $page->currentUser->webUserRole;
}
?>
<section id="content_wrapper">
    <section id="content" class="animated fadeIn">
        <?php
        if (!empty($currentUser)) {
            User_Controllers_UsersController::userProfileMenus($currentUser);
        }
        ?>
        <div class="clearfix"></div>
        <div id="view_profile" name="view_profile">
            <div id="animation-switcher" class="tray-center col-md-9 col-sm-8 main-div p5">
                <?php if (!empty($requestPasswords->data)) { ?>       
                    <div class="panel mb15 mtn">
                        <div class="panel-heading"><span class="panel-title"> <i class="fa fa-th-list hidden-xs"></i><?php echo $requestHeader; ?></span>
                            <div class="clearfix"></div>
                        </div>
                        <div class="panel-body pn">
                            <div class="list-com" id="list-com">
                                <div class="no-tpad upperCase">
                                    <div class="panel-body pn">
                                        <div class="com-detail ">
                                            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-11 pn newbox-dropdown">
                                                <div class="col-md-4 hidden-sm hidden-xs">
                                                    <p><strong>Avatar</strong></p>
                                                </div>
                                                <div class="col-md-8 col-sm-12 col-xs-12 ">
                                                    <p><strong>Name</strong></p>
                                                </div>
                                            </div>
                                            <div class="col-lg-8 col-md-8 col-sm-8 hidden-xs pn ">
                                                <div class="col-md-4 col-sm-4">
                                                    <p> <strong>Password Title</strong></p>
                                                </div>
                                                <div class="col-md-4 col-sm-4">
                                                    <p><strong>Reason</strong></p>
                                                </div>
                                                <div class="col-md-4 col-sm-4 p5 text-right">
                                                    <p><strong>Action</strong></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php
                                $i = 1;
                                foreach ($requestPasswords->data as $viewRequestPassword) {
                                    ?>
                                    <div class="list-com-data pn">
                                        <div class="panel-body pn">
                                            <div class="com-detail ">
                                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-11 pn newbox-dropdown">
                                                    <div class="col-md-4 hidden-sm hidden-xs pt10 pb10">
                                                        <?php
                                                        if ($viewRequestPassword->image) {
                                                            echo '<img title="user" src="/images/' . $viewRequestPassword->image . '_thumb.jpg" class="img-responsive mw30 ib mr10">';
                                                        } else {
                                                            echo '<img title="user" src="/img/avatars1.jpg" class="img-responsive mw30 ib mr10">';
                                                        }
                                                        ?>
                                                    </div>
                                                    <div class="col-md-8 col-sm-12 col-xs-12 pt10">
                                                        <?php echo $viewRequestPassword->fullName; ?>
                                                    </div>
                                                </div>
                                                <div class="col-xs-1 visible-xs">
                                                    <span class="dropdown__caret fa fa-caret-down fa-caret-up"></span>
                                                </div>
                                                <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12 pn newbox-content">
                                                    <div class="col-md-4 col-sm-4 pt10">
                                                        <?php echo $viewRequestPassword->title; ?>
                                                    </div>
                                                    <div class="col-md-4 col-sm-4 pt10">
                                                        <?php echo $viewRequestPassword->reason; ?>
                                                    </div>
                                                    <div class="col-md-4 col-sm-4 p5 text-right">
                                                        <div class="btn-group">
                                                            <?php
                                                            if ($viewRequestPassword->status == 1) {
                                                                $class = 'btn-warning';
                                                            } else
                                                            if ($viewRequestPassword->status == 2) {
                                                                $class = 'btn-success';
                                                            } else
                                                            if ($viewRequestPassword->status == 3) {
                                                                $class = 'btn-danger';
                                                            }
                                                            ?>
                                                            <?php
                                                            if ($webUserRole == 2) {
                                                                $dropdown = '<span class="caret ml5"></span>';
                                                            } else {
                                                                $dropdown = '';
                                                            }
                                                            ?>
                                                            <button type="button" data-toggle="dropdown" aria-expanded="false" class="btn <?php echo $class; ?> br2 btn-xs fs12 dropdown-toggle">
                                                                <?php echo Password_Models_UserPassword::$requestStatus[$viewRequestPassword->status]; ?>
                                                                <?php echo $dropdown; ?>
                                                            </button>

                                                            <?php if ($webUserRole == 2 && $viewRequestPassword->status != 3 && $viewRequestPassword->status != 2) { ?>
                                                                <ul role="menu" class="dropdown-menu">
                                                                    <li><a href="Javascript:void(0);" onclick="return toggleStatus('Password_Models_UserPassword', '<?php echo $viewRequestPassword->id ?>', '2', '/viewpasswords/<?php echo $currentUser;?>')">Accept</a></li>
                                                                    <li><a href="Javascript:void(0);" onclick="deleteRow('<?php echo $viewRequestPassword->id ?>', '<?php echo $viewRequestPassword->title ?>', 'deletesharepassword', '/viewpasswords/<?php echo $currentUser;?>', 'Password Request');">Reject</a></li>
                                                                </ul>
                                                            <?php } else if ($webUserRole != 2 && $viewRequestPassword->status == 2) {
                                                                ?>
                                                                <ul role="menu" class="dropdown-menu">
                                                                    <li><a href="/viewpassword/<?php echo $viewRequestPassword->password_id; ?>/" rel="popUpBox">View</a></li>
                                                                </ul>
                                                            <?php } else if ($webUserRole != 2 && $viewRequestPassword->status == 3) {
                                                                ?>
                                                                <ul role="menu" class="dropdown-menu">
                                                                    <li><a href="Javascript:void(0);" onclick="return toggleStatus('Password_Models_UserPassword', '<?php echo $viewRequestPassword->id ?>', '1', '/viewpasswords/<?php echo $currentUser;?>')">Request Again</a></li>
                                                                </ul>
                                                            <?php } else if ($webUserRole == 2 && $viewRequestPassword->status == 2) {
                                                                ?>
                                                                <ul role="menu" class="dropdown-menu">
                                                                    <li><a href="Javascript:void(0);" onclick="return toggleStatus('Password_Models_UserPassword', '<?php echo $viewRequestPassword->id ?>', '3', '/viewpasswords/<?php echo $currentUser;?>')">Remove Tag</a></li>
                                                                </ul>
                                                            <?php } else if ($webUserRole == 2 && $viewRequestPassword->status == 3) {
                                                                ?>
                                                                <ul role="menu" class="dropdown-menu">
                                                                    <li><a href="Javascript:void(0);" onclick="deleteRow('<?php echo $viewRequestPassword->id ?>', '<?php echo $viewRequestPassword->title ?>', 'deletesharepassword', '/viewpasswords/<?php echo $currentUser;?>', 'Password Request');">Remove</a></li>
                                                                </ul>
                                                            <?php }
                                                            ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>   
                                    <?php
                                }
                                ?>
                            </div>
                        </div>
                    </div>    
                <?php }
                ?>
                <span id="msg"></span>
                <div class="panel mb15 mtn">
                    <div class="panel-heading"><span class="panel-title"> <i class="fa fa-th-list hidden-xs"></i><?php echo $header; ?></span>
                        <span class="pull-right fix-right">
                            <div class="btn-group">
                                <button type="button" class="btn btn-default light div-slider visible-lg"><i class="fa"></i></button>
                            </div>
                            <div class="btn-group">
                                <a   href="/requestsharepassword/"  rel="popUpBox" oncloseFunction = "reloadDiv('viewpasswords', 'mainContent', 'ajax');" class="btn btn-default btn-xs light hidden-lg"><i class="fa fa-share-alt"></i></a>
                            </div>
                            <div class="btn-group">
                                <a  href="/editpassword/" rel="popUpBox" oncloseFunction = "reloadDiv('viewpasswords', 'mainContent', 'ajax');" class="btn btn-success  btn-xs  hidden-lg"><i class="fa fa-plus"></i></a>
                            </div>
                        </span>
                        <div class="clearfix"></div>
                    </div>
                    <div class="panel-menu admin-form theme-primary pbn p5">
                        <div class="row">
                            <form resultDiv='mainContent' name="searchPassword" id="searchPassword" method="post" class="form-inline col-xs-12 pln pb5" keepVisible="1" keepResult="1" action="/password_passwords/viewpasswords/<?php echo $currentUser;?>" rel="ajaxifiedForm">      
                                <div class="col-xs-12 prn">
                                    <label for="name" class="field prepend-icon">
                                        <input class="event-name gui-input br-light light mbn search-input" type="text" name="searchTitle" id="searchDate" placeholder="Search By Title" value="<?php echo $searchTitle = ( isset($_POST['searchTitle']) && $_POST['searchTitle'] != '' ) ? $_POST['searchTitle'] : ''; ?>" />
                                        <label for="name" class="field-icon"><i class="fa fa-search"></i></label>
                                        <div class="btn-fix-right">
                                            <button type="submit" class="submit-btn button btn-success pull-left mr5"><i class="fa fa-search hidden-lg"></i><span class="visible-lg">Search</span></button>
                                            <button type="reset" class="reset-btn button btn-danger"><i class="fa fa-refresh hidden-lg"></i><span class="visible-lg">Reset</span></button>    
                                        </div>
                                    </label>
                                </div>
                            </form>
                        </div>
                    </div>
                    <?php if (!empty($passwords->data)) { ?>
                        <div class="panel-body pn">
                            <div class="list-com" id="list-com-all">
                                <div class="no-tpad upperCase">
                                    <div class="panel-body pn">
                                        <div class="com-detail ">
                                            <div class="col-md-3 col-sm-3 col-xs-11">
                                                <p><strong>Display Title</strong></p>
                                            </div>
                                            <div class="co-md-9 col-sm-9 hidden-xs">
                                                <div class="col-md-2 col-sm-2 col-xs-4">
                                                    <p><strong>URL</strong></p>
                                                </div>
                                                <div class="col-md-2 col-sm-2 col-xs-4 pn">
                                                    <p><strong>Username</strong></p>
                                                </div>
                                                <div class="col-md-2 col-sm-2 col-xs-4 pn">
                                                    <p> <strong>Password </strong></p>
                                                </div>
                                                <div class="col-md-6 col-sm-6 col-xs-12 pn">
                                                    <div class="col-md-8 col-sm-6 col-xs-7">
                                                        <p><strong>Tags</strong></p>
                                                    </div>
                                                    <div class="col-md-4 col-sm-6 col-xs-5 text-right pn">
                                                        <p><strong>Action</strong></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php
                                foreach ($passwords->data as $password) {
                                    ?>
                                    <div id="section_<?php echo $password->id; ?>" class="list-com-data pn">
                                        <div class="panel-body pn">
                                            <div class="com-detail ">
                                                <div class="col-md-3 col-sm-3 col-xs-11 pt5  newbox-dropdown">
                                                    <?php echo $password->title ?>
                                                </div>
                                                <div class="col-xs-1 visible-xs">
                                                    <span class="dropdown__caret fa fa-caret-down fa-caret-up"></span>
                                                </div>
                                                <div class="co-md-9 col-sm-9 col-xs-12 pn newbox-content">
                                                    <div class="col-md-2 col-sm-2 col-xs-4 pt10">
                                                        <a href="<?php echo $password->url ?>" target="_blank" class="btn btn-info br2 btn-xs" ><i class="fa fa-link"></i></a>
                                                    </div>
                                                    <div class="col-md-2 col-sm-2 col-xs-4 pt10">
                                                        <span id="copyTarget_<?php echo $password->id ?>" style="display:none;"><?php echo $password->username; ?></span> <button class="btn btn-success br2 btn-xs" id="copyButton_<?php echo $password->id ?>"><span class="fa fa-copy"></span></button>
                                                    </div>
                                                    <div class="col-md-2 col-sm-2 col-xs-4 pt10">
                                                        <span id="copyTarget2_<?php echo $password->id ?>" style="display:none;"><?php echo htmlspecialchars(base64_decode($password->password), ENT_QUOTES); ?></span> <button class="btn btn-danger br2 btn-xs" id="copyButton2_<?php echo $password->id ?>"><span class="fa fa-copy"></span></button>
                                                    </div>
                                                    <div class="col-md-6 col-sm-6 col-xs-12 pn">
                                                        <div class="col-md-8 col-sm-6 col-xs-12 pt10">
                                                            <?php
                                                            $tag = explode(",", $password->password_tags);
                                                            foreach ($tag as $tags) {
                                                                if ($tags) {
                                                                    echo '<span class="label label-info tags"> ' . $tags . ' </span>';
                                                                }
                                                            }
                                                            ?>
                                                        </div>
                                                        <div class="col-md-4 col-sm-6 col-xs-12 p5 text-right">
                                                            <div class="btn-group text-right">
                                                                <button type="button" data-toggle="dropdown" aria-expanded="false" class="btn btn-success br2 btn-xs fs12 dropdown-toggle">Action<span class="caret ml5"></span></button>
                                                                <?php if ($webUserRole == 2) { ?>
                                                                    <ul role="menu" class="dropdown-menu">
                                                                        <li><a href="/viewpassword/<?php echo $password->id; ?>/" rel="popUpBox">View</a></li>
                                                                        <li><a href="/editpassword/<?php echo $password->id; ?>/" rel="popUpBox" oncloseFunction = "reloadDiv('/viewpasswords/<?php echo $currentUser;?>', 'mainContent', 'ajax');">Edit</a></li>
                                                                        <li><a href="/viewshare/<?php echo $password->id; ?>/" rel="ajaxRequest">View Share</a></li>
                                                                        <li><a href="/share/<?php echo $password->id; ?>/"  rel="popUpBox" oncloseFunction = "reloadDiv('/viewpasswords/<?php echo $currentUser;?>', 'mainContent', 'ajax');">Share</a></li>
                                                                        <li><a href="Javascript:void(0);" onclick="deleteRow('<?php echo $password->id ?>', '<?php echo $password->title ?>', 'deletepassword', '/viewpasswords/<?php echo $currentUser;?>', 'Password Request');">Delete</a></li>
                                                                    </ul>
                                                                <?php } else { ?>
                                                                    <ul role="menu" class="dropdown-menu">
                                                                        <li><a href="/viewpassword/<?php echo $password->id; ?>/" rel="popUpBox">View</a></li>

                                                                        <?php if ($password->userId == $page->currentUser->id) { ?>
                                                                            <li><a href="/editpassword/<?php echo $password->id; ?>/" rel="popUpBox" oncloseFunction = "reloadDiv('/viewpasswords/<?php echo $currentUser;?>/', 'mainContent', 'ajax');">Edit</a></li>
                                                                        <?php } ?>
                                                                    </ul>
                                                                <?php } ?>
                                                            </div>
                                                        </div>
                                                        <script>
                                                            document.getElementById("copyButton_<?php echo $password->id ?>").addEventListener("click", function (e) {
                                                                e.preventDefault();
                                                                copyToClipboardMsg(document.getElementById("copyTarget_<?php echo $password->id ?>"), "msg", "<?php echo ucfirst($password->title); ?> Username Copied");
                                                            });

                                                            document.getElementById("copyButton2_<?php echo $password->id ?>").addEventListener("click", function (e) {
                                                                e.preventDefault();
                                                                copyToClipboardMsg(document.getElementById("copyTarget2_<?php echo $password->id ?>"), "msg", "<?php echo ucfirst($password->title); ?> Password Copied");
                                                            });
                                                        </script>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                }
                                ?>
                                <div class="list-com-data pn">
                                    <div class="panel-body pn">
                                        <div class="com-detail ">
                                            <div class="col-xs-12 pt5">
                                                <div class="pull-left">                             
                                                    <h5><?php echo $passwords->getCurrentPageInfo(); ?></h5>
                                                </div>
                                                <div class="pull-right" >   
                                                    <?php echo $passwords->printPageNumbers(array('url' => "/viewpasswords/" . $currentUser, 'div_id' => 'mainContent', 'ajaxRequest' => true)); ?>
                                                </div>
                                            </div>
                                        </div> 
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php } else {
                        ?>
                        <div class="list-com-data pn">
                            <div class="panel-body pn">
                                <div class="com-detail ">
                                    <div class="col-lg-12 p25">
                                        Passwords Not Found.
                                    </div>
                                </div> 
                            </div>
                        </div>
                    <?php } ?>
                </div>
                <div class="clearfix"></div>
                <span class="sliding-div">
                    <div class="btn-group">
                        <button type="button" class="light div-slider-box visible-lg"><i class="fa fa-sign-out"></i></button>
                    </div>
                </span>
            </div>
            <?php if (!empty($addform) || !empty($requestSharePassword)) { ?>
                <aside data-tray-height="match" class="tray tray-center side-div p5">
                    <?php echo $addform; ?>
                    <?php echo $requestSharePassword; ?>
                </aside>  
            <?php }
            ?>
            <div class="clearfix"></div>
        </div>
    </section>
</section>
<script type="text/javascript">
    function copyToClipboard(elem) {
        var targetId = "_hiddenCopyText_";
        var isInput = elem.tagName === "INPUT" || elem.tagName === "TEXTAREA";
        var origSelectionStart, origSelectionEnd;
        if (isInput) {
            target = elem;
            origSelectionStart = elem.selectionStart;
            origSelectionEnd = elem.selectionEnd;
        } else {
            target = document.getElementById(targetId);
            if (!target) {
                var target = document.createElement("textarea");
                target.style.position = "absolute";
                target.style.left = "-9999px";
                target.style.top = "0";
                target.id = targetId;
                document.body.appendChild(target);
            }
            target.textContent = elem.textContent;
        }
        // select the content
        var currentFocus = document.activeElement;
        target.focus();
        target.setSelectionRange(0, target.value.length);
        var succeed;
        try {
            succeed = document.execCommand("copy");
        } catch (e) {
            succeed = false;
        }
        if (currentFocus && typeof currentFocus.focus === "function") {
            currentFocus.focus();
        }

        if (isInput) {
            elem.setSelectionRange(origSelectionStart, origSelectionEnd);
        } else {
            target.textContent = "";
        }
        return succeed;
    }
    function copyToClipboardMsg(elem, msgElem, alertmsg) {
        var succeed = copyToClipboard(elem);
        var msg;
        if (!succeed) {
            msg = '<div class="errorBox">Sorry, This Type of Copy not supported Your Browser. Please Copy from View (Action > View)</div>';
        } else {
            msg = '<div class="validBox">' + alertmsg + ' Password successfully.</div>';
        }
        if (typeof msgElem === "string") {
            msgElem = document.getElementById(msgElem);
        }
        msgElem.innerHTML = msg;
        setTimeout(function () {
            msgElem.innerHTML = "";
        }, 6000);
    }
    $(".reset-btn").click(function () {
        $(this).parents("form").find(".search-input").val("");
        $(this).parents("form").find(".submit-btn").click();
    });
</script>