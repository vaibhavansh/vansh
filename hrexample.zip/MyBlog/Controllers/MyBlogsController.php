<?php

class MyBlog_Controllers_MyBlogsController extends Core_Controllers_SitesController {

    function home() {
        $this->layoutId = 21;
        echo 'You are in myblogs controller';
        return array();
    }

}
