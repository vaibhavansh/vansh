<?php

class Asset_Models_AssetComment extends Core_Models_DbTable {

    static $table = 'asset_comments';
    static $fields = null;

    public function getUserComments($asset_id = '', $pageNumber = '1') {
        global $page;
        $Paginateddata = Asset_Models_AssetComment::getPaginatedData(array('where' => "asset_comments.asset_id = '{$asset_id}'",
                    'join' => "users on users.id = asset_comments.user_id",
                    'cols' => "asset_comments.*, concat(name,' ' ,lastName) as fullName, users.image",
                    'orderBy' => "asset_comments.comment_at desc",
                    'pageNumber' => $pageNumber));
        $variables['comments'] = $Paginateddata->data;
        return $variables;
    }

    function printImageFancyComment() {
        ?>
        <div id="displayImageThumb<?php echo $this->comment_images ?>">
            <a class="fancybox" data-thumbnail="/images/<?php echo $this->comment_images ?>_thumb.jpg" href="#displayImage<?php echo $this->comment_images ?>" rel="group_comment">
                <img src='/images/<?php echo $this->comment_images ?>_thumb.jpg' class='mw140' />
            </a>
        </div>
        <div id="displayImage<?php echo $this->comment_images ?>" style="display:none;">
            <img src='/images/<?php echo $this->comment_images ?>_main.jpg' />
        </div>
        <?php
    }

    function likeSystem($userId = '', $asset = '', $type = '') {
        if (!empty($asset)) {
            $like = new Asset_Models_AssetLike();
            $linkstatus = $like->likesComment($userId, $asset, $type);
            $query = $like->likesViewStatus($asset, $type);

            $i = 1;
            $showuserstooltip = "";
            foreach ($query as $querydata) {
                if ($i < 13) {
                    $showuserstooltip .= $querydata->name . ' ' . $querydata->lastname . " <br>\n";
                } else {
                    break;
                }
                $i = $i + 1;
            }

            $totalCounts = $query;
            if (!empty($linkstatus)) {
                echo '<a class="like link" id="like' . $asset . '" title="Unlike" rel="Unlike"><span class="glyphicon glyphicon-thumbs-down"></span> Unlike</a>';
            } else {
                echo '<a  class="like link" id="like' . $asset . '" title="Like" rel="Like"><span class="glyphicon glyphicon-thumbs-up"></span> Like</a>';
                if (!empty($totalCounts)) {
                    echo '<div id="counts"><a tooltipData="'.$showuserstooltip.'"  href="/likeuserslist/' . $asset . '/' . $type . '" rel="popUpBox" class="link hovertooltip">' . count($query) . ' people like this</a></div>';
                }
            }
            $counts = array_shift($linkstatus);
            $like_count = !empty($counts->like_count) ? $counts->like_count : '';
            if ($like_count > 0) {
                ?>
                <div class='likeUsers' id="likes<?php echo $asset ?>">
                    <?php
                    $new_like_count = $like_count - 1;
                    foreach ($query as $querydata) {
                        $like_uid = $querydata->id;
                        $likeusername = $querydata->name . '' . $querydata->lastname;
                        if ($like_uid == $userId) {
                            echo '<span id="you' . $asset . '"><b>You </b></span>';
                        }
                    }
                    if (!empty($new_like_count)) {
                        echo ' and <a tooltipData="'.$showuserstooltip.'" href="/likeuserslist/' . $asset . '/' . $type . '" rel="popUpBox" class="link hovertooltip">' . $new_like_count . ' people like this</a>';
                    }
                    ?> 
                </div>
                <?php
            } else {
                echo '<div class="likeUsers" id="elikes' . $asset . '"></div>';
            }
        }
        ?>
        <div id="youlike<?php echo $asset ?>"></div>
        <?php
    }

}
?>
