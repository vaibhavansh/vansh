<?php

class Asset_Models_AssetAsset extends Core_Models_DbTable {

    static $table = 'asset_assets';
    static $fields = null;
}

?>
