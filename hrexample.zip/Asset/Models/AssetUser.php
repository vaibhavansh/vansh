<?php

class Asset_Models_AssetUser extends Core_Models_DbTable {

    static $table = 'asset_users';
    static $fields = null;
}

?>
