<?php

class Asset_Models_AssetLike extends Core_Models_DbTable {

    static $table = 'asset_likes';
    static $fields = null;

    function likesComment($userid = '', $commentId = '', $type = '') {
        if ($type == "comment") {
            $join = "asset_comments on asset_comments.id = asset_likes.comment_id";
            $where = "asset_likes.comment_id = {$commentId}";
        } elseif ($type == "assetComment") {
            $join = "assets on assets.id = asset_likes.asset_id";
            $where = "asset_likes.asset_id = {$commentId}";
        }
        $data = Asset_Models_AssetLike::find_all(array(
                    'where' => "asset_likes.user_id = {$userid} and {$where}",
                    'join' => $join
        ));
        return $data;
    }

    function likesViewStatus($commentId = '', $type = '') {
        if ($type == "comment") {
            $where = "asset_likes.comment_id = {$commentId}";
        } elseif ($type == "assetComment") {
            $where = "asset_likes.asset_id = {$commentId}";
        }
        $data = Asset_Models_AssetLike::find_all(array(
                    'where' => $where,
                    'join' => "users on users.id = asset_likes.user_id ",
                    'cols' => 'users.name,users.lastname,users.id'
        ));
        return $data;
    }

    function loadmore($assetId = '', $type = "", $pageNumber = '1') {
        if ($type == 'comment') {
            $where = "asset_likes.comment_id = {$assetId}";
        } elseif ($type == 'assetComment') {
            $where = "asset_likes.asset_id = {$assetId}";
        }
        $Paginateddata = Asset_Models_AssetLike::getPaginatedData(array(
                    'where' => "{$where}",
                    'join' => "users on users.id = asset_likes.user_id ",
                    'recordsPerPage' => 5,
                    'pageNumber' => $pageNumber
        ));

        return $Paginateddata->data;
    }

}
