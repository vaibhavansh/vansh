<?php

class Asset_Models_AssetTime extends Core_Models_DbTable {

    static $table = 'asset_times';
    static $fields = null;
}

?>
