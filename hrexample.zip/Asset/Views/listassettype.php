<section class="">
    <div class="bs-components">
        <div id="add<?php echo $assetType->slug; ?>ResultDiv" class="resultDiv"></div>
        <div class="panel panel-widget draft-widget">
            <div class="panel-heading"><span class="panel-icon"><i class="fa fa-star"></i></span><span class="panel-title"> <?php echo $header; ?></span> 
                <span class="pull-right fix-right">
                    <div class="btn-group text-right">
                        <a rel="ajaxRequest" href="/<?php echo $assetType->slug; ?>" class="btn btn-info btn-sm ph15">View All </a>
                    </div>
                </span>
            </div>
            <div class="panel-body pn">
                <?php if (!empty($list->data)) { ?> 
                    <div class="table-responsive of-a">
                        <table class="table table-striped admin-form theme-warning tc-checkbox-1 fs13">
                            <tbody id="bookmarktbody">
                                <?php foreach ($list->data as $assetList) { ?>
                                    <tr>
                                        <td class="text-left">
                                            <a href="<?php echo $assetList->url; ?>" target="_blank"><?php echo!empty($assetList->title) ? $assetList->title : $assetList->url; ?></a>
                                        </td>
                                    </tr>	
                                <?php } ?> 
                            </tbody>
                        </table>
                    </div>
                    <?php
                }
                ?>
            </div>
            <div class="panel-heading">
                <span class="panel-icon">
                    <i class="fa fa-star"></i>
                </span>
                <span class="panel-title">Add <?php echo $header; ?></span>
            </div>
            <form method="POST" resultDiv="add<?php echo $assetType->slug; ?>ResultDiv" id="add<?php echo $assetType->slug; ?>" close_popup="1" keepvisible="1" role="form" action="asset_assets/save/" rel="ajaxifiedForm" autocomplete="off" backToPage = '/asset_assets/listassettype/<?php echo $assetType->slug.'/5';?>' backToPageDiv = 'asset_widget_<?php echo $assetType->slug;?>' successMsg="<?php echo $assetType->title; ?> Save Successfully!">
                <div class="panel-body p10 mt-5">
                    <input id="FormType" class="FormType" name="FormType" type="hidden" value="dashboard" >
                    <input class="asset_type_id" name="asset_type_id" type="hidden" value="<?php echo $assetType->id; ?>" >
                    <div class="admin-form theme-primary">
                        <?php if ($assetType->slug == 'bookmarks') { ?>
                            <div class="section mb15">
                                <input id="draft-title" name="title" type="text" placeholder="<?php echo $header; ?> Title" class="gui-input bg-light bookmarktitle required">     
                            </div>
                        <?php } ?>
                        <div class="section mb5">
                            <input id="draft-title1" name="url"  type="url" placeholder="<?php echo $header; ?> Url" class="gui-input bg-light bookmarkurl required">
                        </div>
                    </div>
                </div>
                <div class="clearfix"> <div id="bookmarkResultDiv" class="resultDiv∂"></div></div>
                <div class="panel-footer bg-wild-sand text-right">
                    <button type="submit" class="btn btn-success btn-sm ph15" id="savenote">Save <?php echo $header; ?></button>
                </div>
            </form>
        </div>
    </div>
</section>