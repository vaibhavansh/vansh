<?php global $page; ?>
<section class="">
    <div id="animation-switcher" class="col-md-12 col-sm-12 no-pad">
        <div class="panel mb25 mt5">
            <div class="panel-heading"><span class="panel-title"> <i class="glyphicon glyphicon-thumbs-up"></i> Like <?php echo count($likeUsers); ?></span><div class="clearfix"></div>
            </div>
           
                <div class="panel-body pn">
                    <div class="">
                        <div class="list-com" id="list-com">
                            <div class="col-sm-12 com-detail hidden-xs">
                                <div class="col-sm-1">Image</div>
                                <div class="col-sm-2 col-xs-4">Name</div>

                            </div>
                         
                                <div id="CommentCollection<?php echo $asset_id; ?>"><?php
                                if (!empty($likeUsersLayout)) {
                                    echo $likeUsersLayout;
                                }
                                ?>
                            </div>
                      
                        </div>
                    </div>
                </div>
           
        </div>
    </div>
</section>
