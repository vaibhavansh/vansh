<?php $heading  = !empty($asset->id) ? 'Edit Certificate' : 'Add Certificate';?>
<div class="panel mb25 mt5">
    <div id="certifiacatesResultDiv" class="resultDiv"></div>
        <div class="panel-heading"><span class="panel-title"><?php echo $heading; ?></span>
    </div>
    <div class="panel-body p20 pb10">
        <div class="tab-content pn br-n admin-form">
            <div id="tab1_1" class="tab-pane active">
                <div class="section row mbn">
                    <div class="col-md-12 pn">
                        <form id="certifiacates" name="certifiacates" method="POST" close_popup="1" keepvisible="1" role="form" action="/savecertificates/<?php echo !empty($asset->id) ? $asset->id : '';?>" rel="ajaxifiedForm" autocomplete="off" backToPage="" successMsg="Certificate Save Successfully!">
                            <input  type="hidden" name="asset_type_id" value="7">
                            <div class="section row mb15">
                                <div class="col-xs-12">
                                    <label for="certifiacatestitle" class="field prepend-icon">
                                        <input id="certifiacatestitle" type="text" name="title" placeholder="Certificate Title" class="event-name gui-input br-light light required" value="<?php echo  !empty($asset->title) ? $asset->title : '';?>">
                                        <label for="certifiacatestitle" class="field-icon"><i class="fa fa-file-text"></i></label>
                              
                                    </label>
                                </div>
                            </div>
                            <div class="section row mb15">
                                <div class="col-xs-12">
                                    <label for="description" class="field prepend-icon">
                                        <textarea id="description" type="text" name="description" placeholder="Add Desription Here..." class="event-name summernote gui-textarea br-light light required"><?php echo !empty($asset->description) ? $asset->description : '';?></textarea>
                                    </label>
                                </div>
                            </div>
                            <div class="section row mb15">
                                <div class="col-xs-12">
                                    <input type="submit" class="button btn-success col-xs-12 pull-right savenotesave notes_save" id="save"  value="<?php echo $heading; ?> ">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</div>   <!-- menu quick links-->
<!-- Start: Right Sidebar-->
<script type="text/javascript">
    jQuery(document).ready(function () {
        "use strict";
        $('.summernote').summernote({
            height: 290, //set editable area's height
            focus: false, //set focus editable area after Initialize summernote
            oninit: function () {
            },
            onChange: function (contents, $editable) {
            },
        });

        
    });
        </script>