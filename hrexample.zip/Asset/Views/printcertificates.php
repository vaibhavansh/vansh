<?php
global $page;
if ($page->currentUser->userLoggedIn) {
    $webUserRole = $page->currentUser->webUserRole;
    if ($webUserRole == 2) {
        ?>
        <section id="content_wrapper">
            <!-- Begin: Content-->
            <section id="content" class="">
                <div>
                    <div id="animation-switcher" class="tray-center col-sm-12">                        <!-- recent orders table-->
                        <input type="hidden" class="userid" id="userId" value="<?php echo $userid; ?>"  >
                        <input type="hidden" class="certificateId" id="certificateId" value="<?php echo $certificateid; ?>"  >
                        <input type="hidden" class="username" id="username" value="<?php echo $employeedetails->username; ?>"  >
                         <input type="hidden" class="email" id="email" value="<?php echo $employeedetails->email; ?>">
                        <input type="hidden" class="filename" id="filename" value="<?php echo $employeedetails->username . "_" . str_replace(' ', '_', $viewcertificate->title) . "_" . date("M-Y-d-h:i:s") . "_" . rand(10, 1000) . '.pdf'; ?>"  > 
                        <div>
                            <div class="panel panel-success panel-border top mb25 mt5">
                                <div id="saveEmployeeResultDiv" class="resultDiv"></div>
                                <div class="panel-heading"><span class="panel-title"> <i class="fa fa-certificate"></i> <?php echo $viewcertificate->title; ?></span>
                                </div>
                                <div class="panel-body pn">
                                    <div class="message-reply">
                                        <div class="summernote">
                                            <?php echo str_replace(array('{{FIRSTNAME}}', '{{LASTNAME}}', '{{STARTDATE}}', '{{JOINDATE}}', '{{CURRENTDATE}}'), array($employeedetails->name, $employeedetails->lastname, $employeedetails->created, $employeedetails->created, date('Y-M-d')), $viewcertificate->description); ?>
                                        </div>
                                    </div>
                                    <div class="panel-footer text-right bg-wild-sand">
                                        <button type="button" class="btn btn-success btn-sm ph15"  onclick="certificates();">Save to Cloud & Print</button>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </section>
        <?php
    }
}
?>


<script>
    function certificates(assetid = '') {
        description = $('.note-editable').html();
        title = $('.certificatetitle').html();
        username = $('.username').val();
        filename = $('.filename').val();
        userid = $('#userId').val();
        fileid = $('#certificateId').val();
         email = $('#email').val();
        $.ajax({
            type: "POST",
            url: '<?php echo BASE_PATH_ROOT; ?>/dropboxapi/letterhead.php',
            data: ({title: title, description: description, username: username, filename: filename,pageRequestType: 'ajax'}),
            success: function (data) {
                $('.resultDiv').html('<div class="validBox">Uploaded Successfully On Dropbox</div> ');
                setTimeout(function () {
                    $('.resultDiv').html('');
                    var w = window.open('data:application/pdf;base64, ' + btoa(data));
                    $(w.document.body).html(data);
                }, 2000);

                $.ajax({
                    type: "POST",
                    url: '/user_users/certificatedocuments/',
                    data: ({username: username, description: description, email: email,filename: filename, userid: userid, fileId: fileid,pageRequestType: 'ajax'}),
                    success: function (data) {
                    }
                });
            }
        });
    }


    jQuery(document).ready(function () {
        "use strict";
        $('.summernote').summernote({
            height: 290, //set editable area's height
            focus: false, //set focus editable area after Initialize summernote
            oninit: function () {
            },
            onChange: function (contents, $editable) {
            },
        });
    });
</script>
