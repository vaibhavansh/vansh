<?php
global $page;
if ($page->currentUser->userLoggedIn) {
    $webUserRole = $page->currentUser->webUserRole;
    if ($webUserRole == 2) {
        $cols = 'col-md-9 main-div';
    } else {
        $cols = 'col-md-12';
    }
}
?>
<section class="">
    <!-- begin: .tray-center-->
    <div id="animation-switcher" class="tray-center p5 <?php echo $cols; ?> ">
        <div class="col-sm-12 col-xs-12 changeclass " id="">
            <div class="DelResultDiv"></div>
            <div class="panel mb25 mt5">
                <div class="panel-heading"><span class="panel-title"> <i class="fa fa-th-list"></i> Holiday List</span>
                    <?php if ($page->currentUser->webUserRole == 2) { ?>
                        <span class="pull-right fix-right">
                            <div class="btn-group">
                                <button type="button" class="btn btn-default light div-slider"><i class="fa"></i></button>
                            </div>
                            <div class="btn-group">
                                <a   href="holidays/edit"  rel="popUpBox" oncloseFunction = "reloadDiv('mainContent', 'ajax');" class="btn btn-default light hidden-lg"><i class="fa fa-plus"></i></a>
                            </div>
                        </span>
                    <?php } ?><div class="clearfix"></div>
                </div>
                <div class="panel-menu admin-form theme-primary p5 pbn">
                    <div class="row">                    
                        <form resultDiv='mainContent' name="searchAssets" id="searchAssets" method="post" class="form-inline col-xs-12 pln pb5" keepVisible="1" keepResult="1" action="/holidays/" rel="ajaxifiedForm">        
                            <div class="col-lg-12 prn">
                                <label for="name" class="field prepend-icon">
                                    <input class="event-name gui-input br-light light mbn search-input" type="text" name="searchTitle" placeholder="Search" value="<?php echo $searchTitle = ( isset($_POST['searchTitle']) && $_POST['searchTitle'] != '' ) ? $_POST['searchTitle'] : ''; ?>" />
                                    <label for="name" class="field-icon"><i class="fa fa-search"></i></label>
                                    <div class="btn-fix-right">
                                        <button type="submit" class="submit-btn button btn-success pull-left mr5"><i class="fa fa-search hidden-lg"></i><span class="visible-lg">Search</span></button>
                                        <button type="reset" class="reset-btn button btn-danger"><i class="fa fa-refresh hidden-lg"></i><span class="visible-lg">Reset</span></button>    
                                    </div>
                                </label>
                            </div>
                        </form>            
                    </div>
                </div>
                <div class="panel-body pn task-widget">
                    <div class="">
                        <div class="list-com" id="list-com">
                            <div class="col-sm-12 com-detail">
                                <div class="col-sm-4"><p class="mt5"><strong>Holiday Title</strong></p></div>
                                <div class="col-sm-4"><p class="mt5"><strong>Holiday Date</strong></p></div>
                                <?php if ($webUserRole == 2) { ?>
                                <div class="col-sm-4 text-right"><p class="mt5"><strong>Action</strong></p></div>
                                <?php } ?>
                                    <div class="clearfix"></div>
                            </div>
                                <?php if (empty($list->data)) { ?>
                            <div class="col-sm-12 com-detail p15">
                                <div class="col-sm-12">Holidays Not Found</div>
                            </div>
                            <?php
                            } else {
                                $i = 1;
                                foreach ($list->data as $holidaylist) {
                                    ?>
                                    <div id="section_<?php echo $holidaylist->id ?>" class="col-sm-12 com-detail">
                                        <div class="col-sm-4 text-left titleholiday"><p><?php echo $holidaylist->title; ?></p></div>
                                        <div class="col-sm-4"><p><?php echo $holidaylist->release_date; ?></p></div>   
                                        <?php if ($webUserRole == 2) { ?>
                                        <div class="col-sm-4 text-right"><p>
                                                <div class="btn-group text-right">
                                                    <a href="/holidays/edit/<?php echo $holidaylist->id; ?>/"  class="btn btn-danger br2 btn-xs closediv" rel="popUpBox">
                                                        <i class="fa fa-pencil"></i>
                                                    </a>
                                                </div>
                                                <div class="btn-group text-right">
                                                    <a href="#" id="" class="btn btn-danger br2 btn-xs " onclick="deleteRow('<?php echo $holidaylist->id ?>', '<?php echo $holidaylist->title; ?>', 'deleteholiday', '/holidays', 'Holiday');"><span class="fa fa-close"></span></a>
                                                </div>
                                                </p>
                                            </div>   
                                        <?php } ?>
                                        <div class="clearfix"></div>
                                    </div>
                                    <?php
                                    $i = $i + 1;
                                }
                            }
                            ?>
                            <div class="col-sm-12">
                                <div class="pull-left">
                                    <h5><?php echo $list->getCurrentPageInfo(); ?></h5>
                                </div>
                                <div class="pull-right" >
                                    <?php echo $list->printPageNumbers(array('url' => "/holidays", 'div_id' => 'mainContent', 'ajaxRequest' => true)); ?>
                                </div>
                            </div>
                        </div>
                    </div>            
                </div>
            </div>
        </div> 
        <!-- recent orders table-->
        <div class="clearfix"></div>
         <?php
        if ($webUserRole == 2) { ?>
        <span class="sliding-div">
            <div class="btn-group">
              <button type="button" class="light div-slider-box visible-lg"><i class="fa fa-sign-out"></i></button>
            </div>
        </span>
         <?php } ?>
    </div>
    <!-- begin: .tray-right-->
    <div class=" side-div tray-right p5" id="add_new_book_popup">
        <?php
        if ($webUserRole == 2) {
            if (!empty($addform))
                echo $addform;
        }
        ?>
    </div>
</section>
<script>
$(".reset-btn").click(function(){
  $(this).parents("form").find(".search-input").val("");
  $(this).parents("form").find(".submit-btn").click();
});
</script>