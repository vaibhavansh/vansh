<section class="">
    <div class="bs-components">
        <div id="add<?php echo $assetType->slug; ?>ResultDiv" class="resultDiv"></div>
        <div class="panel panel-widget draft-widget">
            <div class="panel-heading"><span class="panel-icon"><i class="fa <?php if($assetType->id=='11'){?> fa-ticket <?php }else{?> fa-line-chart <?php }?> "></i></span><span class="panel-title"> <?php echo $header; ?></span> 
                <span class="pull-right fix-right">
                    <div class="btn-group text-right">
                        <?php if($assetType->id!='11'){?>
                            <a rel="ajaxRequest" href="/<?php echo $assetType->slug; ?>" class="btn btn-info btn-sm ph15">View All </a>
                        <?php }?>
                    </div>
                </span>
            </div>
            <div class="panel-body pn">
                <?php if (!empty($list->data)) { ?> 
                    <div class="table-responsive of-a">
                        <table class="table table-striped admin-form theme-warning tc-checkbox-1 fs13">
                            <tbody id="bookmarktbody">
                                <?php foreach ($list->data as $assetList) { 
                                    if($assetList->asset_type_id=='9'){?>
                                        <tr>
                                            <td class="text-left">
                                                <a card-id="<?php echo $assetList->id; ?>" class="card card<?php echo $assetList->id; ?>"  href="/lists/<?php echo $assetList->id; ?>" rel="ajaxRequestHR"><?php echo $assetList->title; ?></a>
                                            </td>
                                        </tr>
                                    <?php }elseif($assetList->asset_type_id=='11'){?>
                                        <tr>
                                            <td class="text-left">
                                                <a card-id="<?php echo $assetList->id; ?>" class="card card<?php echo $assetList->id; ?>" href="/viewticket/<?php echo $assetList->id; ?>" rel="popUpBoxHR"><?php echo $assetList->title; ?></a>
                                            </td>
                                        </tr>
                                    <?php }
                                }?> 
                            </tbody>
                        </table>
                    </div><?php
                }?>
            </div>
        </div>
    </div>
</section>