<?php
global $page;
$userId = $page->currentUser->id;
?>
<section class="">
    <?php
    if (!empty($asset)) {
        ?>
        <div class="col-md-12 col-sm-8 pn">
            <div class="panel mb25 mt5">
                <div class="panel-body pt5 ">
                    <div class="message-view">
                        <div class="message-meta"><span class="pull-right text-muted"><?php echo $asset->created; ?></span>
                            <h3 class="subject"><?php echo $asset->title; ?></h3>
                            <hr class="mt20 mb15">
                        </div>
                        <div class="message-header"><img src="<?php echo (!empty($asset->image)) ? '/images/' . $asset->image . '_thumb.jpg' : '/img/avatars1.jpg'; ?>" class="img-responsive mw40 pull-left mr20">
                            <h4 class="mt15 mb5">By: <?php echo $asset->fullName; ?></h4><small class="text-muted clearfix"><?php echo $asset->userEmail; ?></small>
                        </div>
                        <div id="likesyetem" class="panel-body p10 mimh-100"  title-tooltip="assetComment">  
                            <div title="">
                                <?php
                                $likecomments = new Asset_Models_AssetComment();
                                $likecomments->likeSystem($userId, $asset->id, $type = "assetComment");
                                ?>

                            </div>     
                        </div>
                        <hr class="mb15 mt15">
                        <div class="message-body">
                            <p><?php echo $asset->description; ?></p>
                        </div>
                        <hr class="mb15 mt15">
                        <?php
                        if (!empty($asset->imageId)) {
                            $attachments = explode(',', $asset->imageId);
                            if (!empty($attachments)) {
                                ?>
                                <div class="message-footer">
                                    <h4 class="mb25">
                                        <span class="glyphicon glyphicon-paperclip mr10"></span>
                                        <?php echo count($attachments); ?> Attachments</h4>
                                    <div class="attachments mb10">
                                        <?php foreach ($attachments as $attachment) { ?>
                                            <img src="/images/<?php echo $attachment; ?>_thumb.jpg" class="mw140 mr15">
                                        <?php } ?>
                                    </div>
                                </div>
                                <?php
                            }
                        }
                        ?>                        
                        <div class="panel-body pn">
                                <div id="assetImage<?php echo $asset->id ?>ResultDiv">
                                    <?php echo $assetImages; ?>
                                </div>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
                <hr class="mb5 mt5">
                <div class="clearfix"></div>
                <div class="panel panel-widget chat-widget mbn">
                    <div class="panel-heading"><span class="panel-icon"><i class="fa fa-comment hidden-xs"></i></span><span class="panel-title">Comments</span></div>
                    <form id="blogComment" name='blogComment<?php echo $asset->id; ?>' method="POST" keepVisible="1" role="form" action="/saveblogcomment/" rel="ajaxifiedFormShowResultHR" autocomplete="off"  backToPage="" successMsg="Comment Saved Successfully!" resultdiv="CommentCollection<?php echo $asset->id?>">
                        <input type="hidden" name="user_id" value="<?php echo $page->currentUser->id; ?>">
                        <input type="hidden" name="asset_id" value="<?php echo $asset->id; ?>">
                        <input type="hidden" name="asset_type_id" value="<?php echo $asset->asset_type_id; ?>">
                        <div class="panel-footer bg-wild-sand">
                            <div id="blogCommentResultDiv" class="resultDiv"></div>
                            <div class="tab-content pn br-n admin-form">
                                <div id="tab1_1" class="tab-pane active">
                                    <div class="section row mbn">
                                        <div class="col-md-12 pl5">
                                            <div class="section row mb15">
                                                <div class="col-xs-12">
                                                </div>
                                            </div>
                                            <div class="section row mb15">
                                                <div class="col-xs-12">
                                                    <label for="blogComment" class="field prepend-icon">
                                                        <textarea id="blogComments" type="text" name="comments" placeholder="Add Your Comment Here..." class="event-name gui-textarea br-light light required reset" required=""></textarea>
                                                        <label for="blogComment" class="field-icon"><i class="fa fa-file-o"></i></label>
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="section row mb15">
                                                <div class="col-xs-12">
                                                    <label for="file1" class="field file"><span class="button btn-primary"> Choose File</span>
                                                        <input id="commentImages" multiple="multiple" type="file" name="commentImages[]" onchange="document.getElementById('uploader2').value = this.value;" class="gui-file reset">
                                                        <input id="uploader2" type="text" placeholder="no file selected" readonly="" class="gui-input reset">
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="section row mb15">
                                                <div class="col-xs-12">
                                                    <input type="submit" href='javascript:void(0)' id="saveComment" name="saveComment" value="Comment" class="button btn-success col-xs-12 pull-right" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </form>
                    <div class="clearfix"></div>
                    <div id="CommentCollection<?php echo $asset->id?>"><?php
                        if (!empty($assetUserComments)) {
                            echo $assetUserComments;
                        }?>
                    </div>
                </div>
            </div>
        </div>
    <?php } ?>
    
    <div class="clearfix"></div>
</section>