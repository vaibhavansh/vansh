<?php $rand = rand(); ?>
<div id="ticketEstimated<?php echo $rand; ?>ResultDiv" class="resultDiv">
    <div class="panel mb10 mt5">
        <div class="panel-heading">
            <a data-toggle="collapse" data-parent="#accordion2" href="#accord2_6" class="accordion-toggle accordion-icon link-unstyled collapsed">
                <span class="panel-title"> <i class="fa fa-clock-o hidden-xs"></i>Estimate Time</span>
            </a>
        </div>
        <div id="accord2_6" style="height: 0px;" class="panel-collapse collapse">
            <div class="panel-body p20 pb10 pt5">
                <div class="tab-content pn br-n admin-form">
                    <div id="tab1_1" class="tab-pane active">
                        <div class="section row mbn">
                            <div class="col-md-12 pn">
                                <div class="">
                                    <?php
                                    if (!empty($AssignUsers)) {
                                        if ($page->currentUser->webUserRole == 2) {
                                            echo '<h4 class="mt5 mb5">Estimated Time By You</h4>';
                                        } else {
                                            echo '<h4 class="mt5 mb5">Estimated Time For You</h4>';
                                        }
                                        ?>
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <th>To</th>
                                                    <th>Time</th>
                                                    <th>By</th>
                                                    <th>Date</th>
                                                </tr>
                                            </thead>
                                            <tbody><?php foreach ($AssignUsers as $AssignUser) { ?>
                                                    <tr>
                                                        <td><?php echo $AllUsers[$AssignUser->estimated_for]->name[0] . '' . $AllUsers[$AssignUser->estimated_for]->lastname[0]; ?></td>
                                                        <td><?php echo sprintf('%02d', $AssignUser->hours) . ':' . sprintf('%02d', $AssignUser->minutes); ?></td>
                                                        <td><?php echo $AllUsers[$AssignUser->estimated_by]->name[0] . '' . $AllUsers[$AssignUser->estimated_by]->lastname[0]; ?></td>
                                                        <td><?php
                                        $phpdate = strtotime($AssignUser->added_date);
                                        echo date("M j", $phpdate);
                                            ?></td>
                                                    </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table>
                                        <?php
                                    }
                                    if (!empty($EstimatedByUsers)) {
                                        if ($page->currentUser->webUserRole == 2) {
                                            echo '<h4 class="mt5 mb5">Estimated Time By Assigned User</h4>';
                                        } else {
                                            echo '<h4 class="mt5 mb5">Estimated Time By You</h4>';
                                        }
                                        ?>
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <th>To</th>
                                                    <th>Time</th>                                                  
                                                    <th>Date</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($EstimatedByUsers as $EstimatedByUser) {
                                                    ?>

                                                    <tr>
                                                        <td><?php echo $AllUsers[$EstimatedByUser->estimated_for]->name[0] . '' . $AllUsers[$EstimatedByUser->estimated_for]->lastname[0]; ?></td>
                                                        <td><?php echo sprintf('%02d', $EstimatedByUser->hours) . ':' . sprintf('%02d', $EstimatedByUser->minutes); ?></td>                                               
                                                        <td><?php
                                            $phpdate1 = strtotime($EstimatedByUser->added_date);
                                            echo date("M j", $phpdate1);
                                                    ?></td>
                                                    </tr>
                                                    <!--<div class="btn-group text-right mb10 mt10 ml10">
                                                        <span class="button btn btn-light btn-custom  p5 pr10 pl15"><?php echo $AllUsers[$EstimatedByUser->estimated_by]->name[0] . '' . $AllUsers[$EstimatedByUser->estimated_by]->lastname[0]; ?>- <?php
                                                    echo sprintf('%02d', $EstimatedByUser->hours) . ':' . sprintf('%02d', $EstimatedByUser->minutes);
                                                    ?></span>
                                                    <?php /* ?><a class="btn btn-danger btn-rounded  fs12 btn-xs" rel="ajaxRequestShowResultHR" data-href="/assignmember/<?php echo $asset_id; ?>" parameterid="<?php echo $AssignUser->assetuserid;?>" parameter="removeuser" resultDiv="assingMember<?php echo $rand;?>ResultDiv" confirmMsg="Are you sure to remove <?php echo $AssignUser->name.' '.$AssignUser->lastname;?> form assign members.">
                                                      <span class="fa fa-close"></span>
                                                      </a><?php */ ?>
                                                    </div>-->
                                                <?php } ?></tbody>
                                        </table>
                                    <?php } else { ?>
                                        <div class="emptyData"></div>
                                    <?php } ?>
                                </div>
                                <?php if (($page->currentUser->webUserRole == 2 && !empty($userSelector)) || $page->currentUser->webUserRole != 2) { ?>
                                    <form id="ticketEstimated<?php echo $rand; ?>" method="POST" keepvisible="1" role="form" action="/saveticketestimated/<?php echo $assetId; ?>/" rel="ajaxifiedFormShowResultHR" autocomplete="off" successMsg="Estimated Time Set Successfully!">
                                        <div class="section row mb15">
                                            <div class="col-md-12">
                                                <?php
                                                if (isset($userSelector)) {
                                                    echo '<h4 class="mt5 mb5">Set Time for</h4>';
                                                    echo $userSelector;
                                                } else {
                                                    global $project_Id;
                                                    echo '<h4 class="mt5 mb5">Set Your Time</h4>';
                                                    echo '<input type="hidden" name="reloadUrl" value="/lists/'.$project_Id.'">';
                                                    echo '<input type="hidden" name="project_Id" value="'.$project_Id.'">';
                                                }
                                                ?>
                                            </div>
                                            <div class="col-xs-12 mt-15">
                                                <div class="col-xs-6">
                                                    <label for="hoursestimated" class="field prepend-icon">
                                                        <select name="hours" id="hoursestimated" required="" class="required form-control reset">
                                                            <option value="">Select hour</option>
                                                            <?php
                                                            $i = 0;
                                                            while ($i < 200) {
                                                                echo '<option value="' . sprintf('%02d', $i) . '">' . sprintf('%02d', $i) . '</option>';
                                                                $i++;
                                                            }
                                                            ?>
                                                        </select>
                                                    </label>
                                                </div>
                                                <div class="col-xs-6">
                                                    <label for="minutesestimated" class="field prepend-icon">
                                                        <select name="minutes" id="minutesestimated" required="" class="required form-control reset">
                                                            <option value="">Select minutes</option>
                                                            <?php
                                                            $i = 0;
                                                            while ($i < 60) {
                                                                echo '<option value="' . sprintf('%02d', $i) . '">' . sprintf('%02d', $i) . '</option>';
                                                                $i++;
                                                            }
                                                            ?>
                                                        </select>
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="clearfix"></div>
                                        </div>
                                        <div class="section row mb15">
                                            <div class="col-xs-12">
                                                <button class="button btn-success col-xs-12 pull-right">Set Estimated Time</button>
                                            </div>
                                        </div>
                                    </form>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>