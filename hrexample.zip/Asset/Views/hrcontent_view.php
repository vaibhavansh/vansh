<?php global $page;
if(isset($restrict) && $restrict==true)
{?>
<section class="">
    <div class="panel mb25 mt5">
        <div id="animation-switcher" class="tray-center col-lg-12 ">
            <div class=" col-sm-12">
                <!-- Task Widget-->
                <div class="panel panel-widget">
                    <h3 class="p20">Access Denied !</h3>
                </div>
            </div>
        </div>
    </div>
</section>
<?php }else{?>
<section>
    <div class="panel mb25 mt5"><?php
        if (!empty($asset)) {?>
            <div id="animation-switcher" class="tray-center col-lg-12 col-md-8 col-sm-8 p5">
                <div class=" col-sm-12 pn">
                    <!-- Task Widget-->
                    <div class="panel panel-widget">
                        <form id="ticket<?php echo $asset->id; ?>" name='ticket<?php echo $asset->id; ?>' method="POST" keepVisible="1" role="form" action="/saveticket/<?php echo $asset->id; ?>" rel="ajaxifiedFormHR" autocomplete="off" backToPage="" successMsg="Ticket Saved Successfully!" updateClass="card<?php echo $asset->id; ?>" updateData="card<?php echo $asset->id; ?>">
                            <div id="ticket<?php echo $asset->id?>ResultDiv" class="resultDiv"></div>
                            <div class="panel-heading bg-danger" >
                                <span class="panel-icon pull-left"><i class="fa fa-ticket hidden-xs"></i></span>
                                <span class="editablebox pull-left col-md-11">
                                    <span class="editableedit btn-info btn" ><i class="fa fa-pencil"></i></span>
                                    <div class="clearfix"></div>   <div class="clearfix"></div>
                                    <input class="contenteditable" id="card<?php echo $asset->id;?>" value="<?php echo $asset->title;?>" onkeypress="set('card<?php echo $asset->id; ?>')" name="title" readonly="true" type="text"/>
                                    <button type="submit" class="editablesave btn-success btn" onclick="clearCookie('card<?php echo $asset->id; ?>')">save</button>
                                </span>
                                <span></span>
                            </div>
                            <hr class="m1"/>
                        </form>
                        <form resultDiv="ticket<?php echo $asset->id?>ResultDiv" id="ticket<?php echo $asset->id; ?>des" name='ticket<?php echo $asset->id; ?>' method="POST" keepVisible="1" role="form" action="/saveticket/<?php echo $asset->id; ?>" rel="ajaxifiedFormHR" autocomplete="off" backToPage="" successMsg="Ticket Saved Successfully!">
                            <div class="panel-body">
                                <div class="editablebox hrsitesummernote">
                                    <span class="editableedit btn-info btn"><i class="fa fa-pencil"></i></span>
                                    <textarea id="card<?php echo $asset->id; ?>description" class="summernote" readonly="true" name="description" onkeypress="set('card<?php echo $asset->id; ?>description')"><?php echo $asset->description;?></textarea>
                                    <button type="submit" class="btn-success btn" onclick="clearCookie('card<?php echo $asset->id; ?>description')">save</button>
                                </div>
                            </div>
                        <div class="clearfix"></div>
                        </form>
                    </div>
                    <div class="clearfix"></div>
                    <div class="panel panel-widget">
                        <?php /*<form id="assetImage<?php echo $asset->id; ?>" name='assetImage<?php echo $asset->id; ?>' method="POST" keepVisible="1" role="form" action="/saveticket/<?php echo $asset->id; ?>" rel="ajaxifiedFormShowResultHR" autocomplete="off" backToPage="" successMsg="Attachments Saved Successfully!" >*/?>
                            <div class="panel-heading pn" >
                                <input type="hidden" name="asset_type_id" value="<?php echo $asset->asset_type_id;?>">
                                <div class="col-sm-12"><span class="panel-icon"><i class="fa fa-paperclip hidden-xs"></i></span><span class="panel-title" > Attachments</span></div>
                                <div class="panel-footer col-md-12">
                                    <div class="tab-content pn br-n admin-form">
                                        <div id="tab1_1" class="tab-pane active">
                                            <div class="section row mbn">
                                                <div class="col-md-12 pn">                                             
                                                    <div class="section col-sm-8 mb15 pn">
                                                        <div class="col-xs-12">
                                                            <input type="hidden" name="title" class="tickettitle<?php echo $asset->id;?>" value="<?php echo $asset->title;?>"/>
                                                            <?php /*<input id="commentImages" multiple="multiple" type="file" name="attachments[]" class="gui-file reset" required="">*/?>
                                                            <script type="text/javascript">
                                                                $('#commentImages').fineUploader({
                                                                    template: 'qq-template-manual-trigger',
                                                                    request: {
                                                                        endpoint: '/saveticket/<?php echo $asset->id; ?>',
                                                                        inputName: 'attachments[]',
                                                                        params: {
                                                                            title:'<?php echo $asset->title; ?>',
                                                                            asset_type_id:'<?php echo $asset->asset_type_id; ?>'
                                                                        },
                                                                    },
                                                                    validation: {
                                                                        allowedExtensions: ['jpeg', 'jpg', 'png','gif'],
                                                                        sizeLimit: 10240000 // 50 kB = 50 * 1024 bytes
                                                                    },
                                                                    autoUpload: true,
                                                                    callbacks: {
                                                                        onAllComplete: function(status,data)
                                                                        {
                                                                        }
                                                                    }
                                                                });
                                                                $('#trigger-upload').click(function() {
                                                                    $('#commentImages').fineUploader('uploadStoredFiles');
                                                                });
                                                            </script>
                                                            <script type="text/template" id="qq-template-manual-trigger">
                                                                <div class="qq-uploader-selector qq-uploader tray-bin pl10 mb10 mt10 mrn mln" qq-drop-area-text="Drop files here">
                                                                    <div class="row">
                                                                        <div class="col-sm-6 col-xs-12 pull-left text-center"><h3 class="mb10 mt10 mrn mln"><i class="fa fa-cloud-upload"></i>  Drop files to upload</h3></div>
                                                                        <div class="buttons text-right col-sm-2 pull-right hidden-xs">
                                                                            <div class="qq-upload-button-selector btn btn-primary">
                                                                                <div>Select files</div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="buttons text-center col-xs-12 pull-right visible-xs">
                                                                            <div class="qq-upload-button-selector btn btn-primary">
                                                                                <div>Select files</div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="qq-total-progress-bar-container-selector qq-total-progress-bar-container">
                                                                        <div role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" class="qq-total-progress-bar-selector qq-progress-bar qq-total-progress-bar"></div>
                                                                    </div>
                                                                    <div class="qq-upload-drop-area-selector qq-upload-drop-area" qq-hide-dropzone>
                                                                        <span class="qq-upload-drop-area-text-selector">Drop files here</span>
                                                                    </div>
                                                                    <span class="qq-drop-processing-selector qq-drop-processing">
                                                                        <span>Processing dropped files...</span>
                                                                        <span class="qq-drop-processing-spinner-selector qq-drop-processing-spinner"></span>
                                                                    </span>
                                                                    <ul class="qq-upload-list-selector qq-upload-list mb10 mt10 " aria-live="polite" aria-relevant="additions removals">
                                                                        <li>
                                                                            <div class="qq-progress-bar-container-selector">
                                                                                <div role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" class="qq-progress-bar-selector qq-progress-bar"></div>
                                                                            </div>
                                                                            <span class="qq-upload-spinner-selector qq-upload-spinner"></span>
                                                                            <img class="qq-thumbnail-selector" qq-max-size="100" qq-server-scale>
                                                                            <span class="qq-upload-file-selector qq-upload-file"></span>
                                                                            <span class="qq-edit-filename-icon-selector qq-edit-filename-icon" aria-label="Edit filename"></span>
                                                                            <input class="qq-edit-filename-selector qq-edit-filename" tabindex="0" type="text">
                                                                            <span class="qq-upload-size-selector qq-upload-size"></span>
                                                                            <button type="button" class="qq-btn qq-upload-retry-selector qq-upload-retry">Retry</button>
                                                                            <span role="status" class="qq-upload-status-text-selector qq-upload-status-text"></span>
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                            </script>
                                                        </div>
                                                        <div class="clearfix"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                </div>
                            </div>
                        <div class="clearfix"></div>
                        <div id="commentImages" class="col-sm-12"></div>
                        <div class="clearfix"></div>
                        <?php /*</form>*/?>
                        <div class="panel-body pn">
                            <div id="assetImage<?php echo $asset->id?>ResultDiv">
                                <?php echo $assetImages;?>
                            </div>
                        </div>
                    </div>
                    <div class="clearfix"></div>
              
                </div>
            </div>
        <?php } ?>

        <div class="clearfix"></div>
    </div>
</section>
<script>
 jQuery(document).ready(function () {
        $('.summernote').summernote({
            height: 290, //set editable area's height
            focus: false, //set focus editable area after Initialize summernote
            oninit: function () {
            },
            onChange: function (contents, $editable) {
            },
        });
    });
</script>
<style>
    
    .actionButton.single-pet-shown {
    display: block !important;
}
  
    #trigger-upload {
        color: white;
        background-color: #00ABC7;
        font-size: 14px;
        padding: 7px 20px;
        background-image: none;
    }

    #commentImages .qq-upload-button {
        margin-right: 15px;
    }

    #commentImages .buttons {
        width: 36%;
    }

    #commentImages .qq-uploader .qq-total-progress-bar-container {
        width: 60%;
    }
    @media screen and (max-width : 767px){
        #commentImages .buttons {width: 100%;}
    }
</style>
<?php /*
debug: false,
    button: null,
    multiple: true,
    maxConnections: 3,
    disableCancelForFormUploads: false,
    autoUpload: true,
    request: {
        customHeaders: {},
        endpoint: "/server/upload",
        filenameParam: "qqfilename",
        forceMultipart: true,
        inputName: "qqfile",
        method: "POST",
        params: {},
        paramsInBody: true,
        totalFileSizeName: "qqtotalfilesize",
        uuidName: "qquuid"
    },
    validation: {
        allowedExtensions: [],
        sizeLimit: 0,
        minSizeLimit: 0,
        itemLimit: 0,
        stopOnFirstInvalidFile: true,
        acceptFiles: null,
        image: {
            maxHeight: 0,
            maxWidth: 0,
            minHeight: 0,
            minWidth: 0
        }

*/?>
<?php }?>