<!DOCTYPE HTML>

        <style type="text/css">
            img{
                margin-left: 10px;
    margin-top: -19px;
    position: absolute;
            }
            .maindiv{
                width: 940px;
                margin-left: 81px;
                margin-bottom: 1px;
            }
            .bodyBody {
                margin: 10px;
                font-size: 1.50em;
            }
            .divHeader {
                text-align: right;
                border: 1px solid;
            }
            .divReturnAddress {
                text-align: left;
                    margin-top: 51px;
                float: right;
            }
            .divSubject {
                clear: both;
                font-weight: bold;
                padding-top: 80px;
            }
            .divAdios {
                float: right;
                padding-top: 50px;
            }
        </style>
        <div id="table">
        <div>   <img src="http://local.hrbezoar.com/images/imgpsh_fullsize.jpg" style="margin-left: 10px" alt="" class="img-responsive __web-inspector-hide-shortcut__"></div>
  
        <div class="divReturnAddress"> 
            <b>Bezoar Software Consultancy Pvt Ltd</b><br/>
            www.bezoarsoftware.coma<br/>
            info@bezoarsoftware.com<br/>    
            
            <br/>
            01 Dezember, 2012
        </div>

        <div class="divSubject">
            Betreff:  Vertretung waehrend Reise
        </div>

        <div class="divContents">
            <p>
                Sehr geehrte Frau Graf,
            </p>

            <p>
                Ich fliege nach Brasilien am 29. Dezember 2012 f&uuml;r 6 Wochen.
                Meine Nichte kann mich vertreten.  Sie arbeitet sehr gesissenhaft.
                Sie heisst Yasmin.  Ihre Nummer ist xxx.
            </p>
        </div>

        <div class="divAdios">
            Freundliche Gr&uuml;sse <br/>
            <!-- Space for signature. -->
            <br/>
            <br/>
            <br/>
            Evanildo Lopes do Almeida <br/>
            Hauswart Binningerstrasse 19/23 <br/>
        </div>
        </div>
        
        <button onclick="printDiv();">Print it</button>
<script>
    function printDiv() {
        var divToPrint = document.getElementById('table');
        var htmlToPrint = '' +
                '<style type="text/css">' +
                'table  {' +
                'width: 100%;table-layout: auto;border:1px solid #000;' +              
                '}' +
              
                 'tr:nth-child(even)  {' +
                ' background-color: #f2f2f2' +              
                '}' +
                '</style>';
        htmlToPrint += divToPrint.outerHTML;
        newWin = window.open("");
        newWin.document.write(htmlToPrint);
        newWin.print();
        newWin.close();
    }</script>
 