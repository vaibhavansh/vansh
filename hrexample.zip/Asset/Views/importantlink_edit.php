<!-- create new order panel-->
<div class="panel mb25 mt5">
    <div id="importantlinksResultDiv" class="resultDiv"></div>
    <div class="panel-heading"><span class="panel-title"> <i class="fa fa-file-text"></i> Add Important Links</span>
    </div>
    <div class="panel-body p20 pb10">
        <div class="tab-content pn br-n admin-form">
            <div id="tab1_1" class="tab-pane active">
                <div class="section row mbn">
                    <div class="col-md-12 pn">
                        <form id="importantlinks" name="importantlinks" method="POST" resultDiv="importantlinksResultDiv"  close_popup="1" keepvisible="1" role="form" action="/saveimportantlinks/" rel="ajaxifiedForm" autocomplete="off" backToPage="/importantlinks/" successMsg="Importants Links Added Successfully!">
                            <input  type="hidden" name="asset_type_id" value="16">
                            <div class="section row mb15">
                                <div class="col-xs-12">
                                    <label for="importantlinkstitle" class="field prepend-icon">
                                        <input id="importantlinkstitle" type="text" name="title" placeholder="Important Links Title" class="event-name gui-input br-light light copycutpast required">
                                        <label for="importantlinkstitle" class="field-icon"><i class="fa fa-file-text"></i></label>
                                        <p class="notetitleclass"></p>
                                    </label>
                                </div>
                            </div>
                             <div class="section row mb15">
                                <div class="col-xs-12">
                                    <label for="importantlinksslug" class="field prepend-icon">
                                        <input id="importantlinksslug" type="text" name="slug" placeholder="Important Links Slug" class="event-name gui-input br-light light copycutpast required">
                                        <label for="importantlinksslug" class="field-icon"><i class="fa fa-file-text"></i></label>
                                        <p class="notetitleclass"></p>
                                    </label>
                                </div>
                            </div>
                            <div class="section row mb15">
                                <div class="col-xs-12">
                                    <label for="importantlinksdescription" class="field prepend-icon">
                                        <textarea id="importantlinksdescription" type="text" name="description" placeholder="Add Desription Here..." class="event-name gui-textarea br-light light required"></textarea>
                                        <label for="importantlinksdescription" class="field-icon"><i class="fa fa-file-o"></i></label>
                                        <p class="notedescriptionclass"></p>
                                    </label>
                                </div>
                            </div>
                            <div class="section row mb15">
                                <div class="col-xs-12">
                                    <input type="submit" class="button btn-success col-xs-12 pull-right savenotesave notes_save" id="save"  value="Add Important Links">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</div>   <!-- menu quick links-->
