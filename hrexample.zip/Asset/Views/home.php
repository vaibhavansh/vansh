<div class="panel panel-default">
        <div class="panel-body">
            <h1 class="margin-0">Features</h1>
            <h3 class="large-h3">European Pigment Production is on the Rise</h3>
            <div class="spacer"></div>
                        <h4 class="margin-0"><small>
                    By Sean Milmo, European Editor | May 13, 2016<br>                </small>
            </h4>

            <p class="large-italic">Ink manufacturers are moving away from traditional organic pigments in favor of customized colorants.</p>
            <span class="st_sharethis_large" displaytext="ShareThis" st_processed="yes"><span style="text-decoration:none;color:#000000;display:inline-block;cursor:pointer;" class="stButton"><span class="stLarge" style="background-image: url(&quot;http://w.sharethis.com/images/sharethis_32.png&quot;);"></span></span></span>
            <span class="st_facebook_large" displaytext="Facebook" st_processed="yes"><span style="text-decoration:none;color:#000000;display:inline-block;cursor:pointer;" class="stButton"><span class="stLarge" style="background-image: url(&quot;http://w.sharethis.com/images/facebook_32.png&quot;);"></span></span></span>
            <span class="st_twitter_large" displaytext="Tweet" st_processed="yes"><span style="text-decoration:none;color:#000000;display:inline-block;cursor:pointer;" class="stButton"><span class="stLarge" style="background-image: url(&quot;http://w.sharethis.com/images/twitter_32.png&quot;);"></span></span></span>
            <span class="st_linkedin_large" displaytext="LinkedIn" st_processed="yes"><span style="text-decoration:none;color:#000000;display:inline-block;cursor:pointer;" class="stButton"><span class="stLarge" style="background-image: url(&quot;http://w.sharethis.com/images/linkedin_32.png&quot;);"></span></span></span>
            <span class="st_pinterest_large" displaytext="Pinterest" st_processed="yes"><span style="text-decoration:none;color:#000000;display:inline-block;cursor:pointer;" class="stButton"><span class="stLarge" style="background-image: url(&quot;http://w.sharethis.com/images/pinterest_32.png&quot;);"></span></span></span>
            <span class="st_email_large" displaytext="Email" st_processed="yes"><span style="text-decoration:none;color:#000000;display:inline-block;cursor:pointer;" class="stButton"><span class="stLarge" style="background-image: url(&quot;http://w.sharethis.com/images/email_32.png&quot;);"></span></span></span>

            <div class="spacer"></div>

                            <div class="carousel slide" id="carousel-924232">
                    <div class="carousel-inner">
                                                    <div class="item active">
                                <img id="image_thumb_69025" src="http://dev.rodpub.com/images/122/559_main.jpg" alt="European Pigment Production is on the Rise" class="col-sm-12 wrap">
                                <div class="clearfix"></div>
                                <div class="carousel-caption">
                                    <h4>European Pigment Production is on the Rise</h4>
                                </div>
                            </div>
                                                </div>
                    <!-- <ol class="carousel-indicators">
                                                 <li class="" data-slide-to= data-target="#carousel-924232">
                             </li>
                                         </ol> -->
                                    </div>
                <div class="spacer20"></div>            <div id="contentBody">
                                    <div id="showInTextAds">The European market for printing ink pigments is becoming increasingly fragmented amid declining demand for traditional organic colorants. A lot of small, virtually niche segments have emerged with requirements for specialist, customized pigments, often based on new technologies.<br>
<br>
One result of this trend has been that a rising share of printing ink pigments are being produced in Europe so that the region has become less reliant on Asian imports,.<br>
<br>
A new dynamic among Europe’s pigment manufacturers has occurred at a time when China’s sector for the production of pigments and their intermediates is being restructured. China, followed by India, is by far the biggest of exporters of pigments into Europe, making it a dominant force in the region’s market for classical organic pigments.<br>
<br>
The expansion of European manufacturing in some key pigments segments is being accelerated by the threat of price volatility and supply disruptions stemming from the changes in China, which have been triggered by the Chinese government’s desire to tackle high levels of industrial pollution in the country. Plants making pigments and their intermediates are being closed as a result of the stricter enforcement of environmental regulations.<br>
<br>
Chinese prices and supply of red pigments have already been affected by the recent closure of a relatively big producer of the intermediate naphthol for breaching environmental regulations.<br>
<br>
Then in late April, one of the country’s leading producer of arylamide, another intermediate, was shut down for similar reasons, which could lead to sharp rises in the prices for yellow pigments like PY 12 and 13.<br>
<br>
“The supply situation outlook (for pigments) is very uncertain,” said <a href="http://www.flintgrp.com">Flint Group</a> in its raw material update issued in October last year. “The supply of pigment intermediates is very erratic with wide price fluctuation. Some small intermediate producers may ill afford to invest in environment protection and may decide to wind up (which) will impose more challenges to the pigment producers.”<br>
<br>
Due to the shutdown of a major producer of arylamide, prices of the intermediate may go up by as much as 40% because of likely shortages of the chemical in China and scarcities in India. Both countries have virtually become the only major sources of intermediates for key pigments.<br>
<br>
“For pigment producers, the difficulty is that the manufacturers of these intermediates at times of scarcities do not consider pigment makers to be priority customers because there are other, much larger users of their products,” said Phillip Myles, director and GM of <a href="http://www.unioncolours.com">Union Colours</a>, Stockport, England, a distribution subsidiary of Longyu Pigments, China, one of the country’s largest pigments manufacturers.<br>
<br>
“Recently, printing ink pigment prices in Europe have been fairly stable,” he added. “There could now be some fluctuations in prices because of the problems with availability of certain intermediates in China. Producers of intermediates have been given a warning period about breaching environmental regulations. Now they are being ordered to close plants because of non-compliance.”<br>
<br>
Another danger for ink manufacturers is the effects of consolidation among pigments and intermediates manufacturers. Flint Group warned that consolidation restricts ink producers’ choice of raw materials suppliers.<br>
<br>
“Any marginal increase in demand could have significant upward price impact due to a smaller supply base,” the company said in its raw material update. “Many pigment producers are considering consolidation of production units to cut the cost for survival.”<br>
In the titanium dioxide sector, analysts are predicting a trend to more consolidation after DuPont, the world’s biggest producer, and Huntsman Corporation divested or are planning to sell off their TiO2 operation following a period of a decline in prices to levels which hardly covered production costs.<br>
<br>
Only two years after it took over Rockwell Holdings’ TiO2 business, Huntsman announced last year it was spinning off all of its TiO2 operations. It had already sold its 30,000 tons a year German-based Sachtleben unit for printing ink TiO2 grades to Henan Billions, giving China’s leading TiO2 player its first foothold in the European market.<br>
<br>
The Sachtleben facility specializes in the development and supply of nano-scale TiO2 particles, which is an area of expertise being nurtured by pigments producers in Europe.<br>
<br>
Some of the key parts of pigments manufacturing in Europe have been in the finishing of imported semi-finished pigments from Asia. Recently there has signs of a decrease in the imports of these semi-finished products as Chinese and Indian manufacturers expand into added-value products.<br>
<br>
<span class="paragraphHeader">Interest in Customization</span><br>
<br>
In response, European producers have been concentrating on specialist and customized pigments, especially in those requiring sizing, shaping and surfacing of the pigments to specified requirements.<br>
<br>
European expertise in the preparation of pigments for new printing technologies and applications has been helping European-based ink producers strengthen their share of the domestic printing ink market. It has also enabled them to expand their exports to emerging economies and developing countries where there is a lack of expertise in more advanced inks.<br>
<br>
“Ink producers have been able to benefit from the growth in packaging across the world to increase their export sales,” said Myles. “Developing countries have their own ink producers but often without sufficient know-how about some packaging inks. The European producers have a competitive advantage in their skills in the grinding and preparation of the pigments in the inks.”<br>
<br>
A major driving force behind the reinvigoration of the European pigments sector has been the injection of more creativity in the use of the colorants in order to respond quickly to market needs, especially in areas like textile printing.<br>
<br>
The designing and production of printed colors is having to be done as close as possible to local markets. Some of the larger European pigment manufacturers doing all or key stages of the manufacturing in Europe have been reporting surges in both domestic and foreign sales.<br>
<br>
Synthesia reported record sales due to a strengthening of its position as a local supplier in Europe, as well as improved export sales. “(We) achieved annual revenue growth of 8.3% last year and we plan to further increase our sales by about 5% this year,” said Richard Dacer, director of Synthesia’s pigments and dyes business.<br>
<br>
In the European market for printing ink pigments, there have been variations in growth rates, with the faster expanding segments being the ones targeted by pigment producers and importers.<br>
<br>
Sales of ink pigments for publishing – such as newspapers, magazines and to a lesser extent books – have continued to decline as the sector contracts in the face of the relentless rise of the electronic media.<br>
<br>
Demand for traditional pigments in commercial printing inks has been weak mainly because use of conventional printing processes like offset and gravure have been under pressure.<br>
<br>
Among the historically well established printing sectors, packaging is about the only one that is thriving. This is particularly the case with fast moving consumer goods whose packaging is used as a promotional tool. Brand owners want their products wrapped in eye-catching, bright colors on the supermarket shelves.<br>
<br>
Packaging is also reflecting the trends in the overall market for pigments in that it is sector which is also becoming fragmented with a range of segments with different needs and sales outlets.<br>
<br>
In parts of the segments for carton and board and flexible and rigid plastic packaging, the demand is centered on conventional classical pigments, mostly imported from China or India with finishing and preparation work done on them in Europe.<br>
<br>
But there is a relatively fast growing upper end of the packaging market that includes luxury goods and more expensive cosmetics. It seeks sophisticated, high performance and special effect pigments, which can be sold with healthy margins.<br>
Packaging is also making more use of enhanced printing such as embossing with metallic effects and 3D layered printing.<br>
<br>
A big impetus behind these advances has been the rise of digital printing, which has resulted in the creation of a new, high growth pigments sectors, such as those for ceramics, glass and a range of metals, requiring the development of innovative technologies and pigment preparation techniques.<br>
<br>
In ceramics, and to a lesser extent, glass, these new technologies have transformed the use of colorants among manufacturers who have tended to be relatively conservative in their approach to design.<br>
<br>
Much greater scope for original design in ceramic tiles and other products has been provided by the introduction of inkjet printing, which now accounts for aproximately 40% of Europe’s ceramics market after making rapid inroads into a sector long dominated by screenprinting.<br>
<br>
Inkjet printing has required the development of alternative pigments to replace standardized colorants first used as long as 70 to 80 years ago.<br>
<br>
It has changed the role of pigments in formulations, which are equivalent to “engineered inks,” with pigments and dyes being mere components in a mix of solvents, carrier fluids and a variety of additives.<br>
<br>
To avoid clogging in thousands of tiny printhead nozzles, pigment sizes have to be reduced below the micron level.<br>
<br>
However, this necessity has been complicated by research that shows that pigment particles below certain sizes can lose their color strength because of changes in crystal structures and optical features. Another problem, as in other segments, is that small sizes narrow the color gamut.<br>
<br>
The sizing, shaping and surface preparation of pigment particles for printing inks now has to be carefully controlled. As a result, in certain key sectors the proportion of pigments in printing inks made or finished in Europe is likely to continue to rise.&nbsp;<br>
<br>
        </div>
    </div>