<?php
global $page;
$userId = $page->currentUser->id;
?>
<div class="panel panel-widget chat-widget">
    <div class="panel-heading"><span class="panel-title"><span class="panel-icon"><i class="fa fa-star"></i></span> Share, Engage, Collaborate.</span>
        <span class="pull-right fix-right">
            <div class="btn-group text-right">
                <?php echo $list->printPageNumbers(array('url' => "/news_feed", 'div_id' => 'asset_widget_news_feed', 'ajaxRequest' => true)); ?>
            </div>
        </span>

    </div>
    <form method="POST" resultDiv="add<?php echo $assetType->slug; ?>ResultDiv" id="add<?php echo $assetType->slug; ?>" close_popup="1" keepvisible="1" role="form" action="asset_assets/save/" rel="ajaxifiedForm" autocomplete="off" backToPage = '/asset_assets/listAssetType/<?php echo $assetType->slug . '/limit_5/list'; ?>' backToPageDiv = 'asset_widget_<?php echo $assetType->slug; ?>' successMsg="<?php echo $assetType->title; ?> Save Successfully!">
        <div class="panel-body p10 mtn mbn pb5">    
            <div class="tab-content pn br-n admin-form">
                <input id="FormType" class="FormType" name="FormType" type="hidden" value="dashboard" >
                <input class="asset_type_id" name="asset_type_id" type="hidden" value="<?php echo $assetType->id; ?>" >
                <div class="admin-form theme-primary">                        
                    <div class="section mb5">
                        <input id="draft-title1" name="title"  type="text" placeholder="What's on your mind" class="gui-input bg-light bookmarkurl required">
                    </div>
                </div>    
                <div class="section row mbn">
                    <div class="col-xs-6">
                        <label for="file1" class="field file"><span class="button btn-info btn btn-xs" style="left:0px; right: auto;"><i class="fa fa-picture-o fa-5x" > </i></span>
                            <input id="attachments" multiple="multiple" type="file" name="attachments[]" onchange="document.getElementById('uploader1').value = this.value;" class="gui-file">
                            <input id="uploader1" type="text" placeholder="no file selected" readonly="" class="gui-input" style="visibility: hidden;">
                        </label>
                    </div>
                    <div class="col-xs-6"><button type="submit" class="btn btn-success btn-sm ph15 pull-right" id="savenote">Send</button></div>
                </div>
                <div class="clearfix"></div>
            </div>
            <div class="clearfix"> <div id="bookmarkResultDiv" class="resultDiv∂"></div></div>
        </div>
    </form><div class="clearfix"></div><hr class="mtn mb5" />
    <div class="panel-body pn no-image-chat col-sm-12 ">
        <div id="add<?php echo $assetType->slug; ?>ResultDiv" class="resultDiv"></div>
        <?php if (!empty($list->data)) { ?> 
            <?php foreach ($list->data as $assetList) { ?>
                <div class="media">                    
                    <div class="media-body">
                        <?php if (!empty($assetList->uploaderImage)) { ?>
                            <div class="media-left newsFeedImage">
                                <img src="/images/<?php echo $assetList->uploaderImage; ?>_thumb.jpg" class="media-object">
                            </div>
                        <?php } ?>
                        <span class="media-side"><h5 class="media-heading mt10"><?php echo $assetList->uploaderName; ?><small class="text-muted"> <div class="clearfix mt10"></div> <?php echo Core_Models_Utility::printFormatedDates(array('startDate' => $assetList->modified)); ?></small></h5></span>
                        <div class="clearfix"></div>
                        <?php echo $status_text = preg_replace('#(\A|[^=\]\'"a-zA-Z0-9])(http[s]?://(.+?)/[^()<>\s]+)#i', '\\1<a target="_blank" href="\\2">\\3</a>', $assetList->title); ?>
                        <div class="clearfix"></div>
                        <?php if ($assetList->assetimageId): ?>
                            <?php
                            $assetImageobj = new Asset_Models_AssetImage($assetList->assetimageId);
                            $assetImageobj->printImageFancy();
                            ?>
                <!--                            <a class="fancybox" data-fancybox-title="<?php echo htmlspecialchars($assetList->title, ENT_QUOTES); ?>" href="/images/<?php echo $assetList->image; ?>_main.jpg"  rel="new-feed"><img src="/images/<?php echo $assetList->image; ?>_main.jpg" class="col-sm-12"></a>-->
                         <?php endif; ?>

                        <!-------------like system start----------->
                        <div id="likesyetem" class="panel-body p10 mimh-100" title-tooltip="assetComment">  
                            <div title="">
                            <?php
                               if (!empty($assetList->id)) {
                                $likecomments = new Asset_Models_AssetComment();
                                $likecomments->likeSystem($userId, $assetList->id, $type = "assetComment");
                               }
                            ?>
                             </div>
                        </div>     
                        <!-----------end lik system----------------->
                    </div>
                </div>
            <?php }
            ?>     <!--<script>$('.newsFeedImage:even').removeClass('media-left').addClass('media-right');</script>-->
            <?php
        }
        ?>
    </div>
    <div class="clearfix"></div>
</div>