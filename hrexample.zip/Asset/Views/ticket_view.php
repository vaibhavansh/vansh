<?php
global $page;
if (isset($restrict) && $restrict == true) {
    ?>
    <section class="">
        <div class="panel mb25 mt5">
            <div id="animation-switcher" class="tray-center col-lg-12 ">
                <div class=" col-sm-12">
                    <!-- Task Widget-->
                    <div class="panel panel-widget">
                        <h3 class="p20">Access Denied !</h3>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php } else { ?>
    <section>
        <div class="panel mb25 mt5"><?php if (!empty($asset)) { ?>
                <div id="animation-switcher" class="tray-center col-lg-9 col-md-8 col-sm-8 p5">
                    <div class=" col-sm-12 pn">
                        <!-- Task Widget-->
                        <div class="panel panel-widget">
                            <form id="ticket<?php echo $asset->id; ?>" name='ticket<?php echo $asset->id; ?>' method="POST" keepVisible="1" role="form" action="/saveticket/<?php echo $asset->id; ?>" rel="ajaxifiedFormHR" autocomplete="off" backToPage="" successMsg="Ticket Saved Successfully!" updateClass="card<?php echo $asset->id; ?>" updateData="card<?php echo $asset->id; ?>">
                                <div id="ticket<?php echo $asset->id ?>ResultDiv" class="resultDiv"></div>
                                <div class="panel-heading bg-danger" >
                                    <span class="panel-icon pull-left"><i class="fa fa-ticket hidden-xs"></i></span>
                                    <span class="editablebox pull-left col-md-11">
                                        <span class="editableedit btn-info btn" ><i class="fa fa-pencil"></i></span>
                                        <input class="contenteditable" id="card<?php echo $asset->id; ?>" value="<?php echo $asset->title; ?>" onkeypress="set('card<?php echo $asset->id; ?>')" name="title" readonly="true" type="text"/>
                                        <button type="submit" class="editablesave btn-success btn" onclick="clearCookie('card<?php echo $asset->id; ?>')">save</button>
                                    </span>
                                    <span></span>
                                </div>
                                <hr class="m1"/>
                            </form>
                            <form resultDiv="ticket<?php echo $asset->id ?>ResultDiv" id="ticket<?php echo $asset->id; ?>des" name='ticket<?php echo $asset->id; ?>' method="POST" keepVisible="1" role="form" action="/saveticket/<?php echo $asset->id; ?>" rel="ajaxifiedFormHR" autocomplete="off" backToPage="" successMsg="Ticket Saved Successfully!">
                                <div class="panel-body">
                                    <div class="editablebox">
                                        <span class="editableedit btn-info btn"><i class="fa fa-pencil"></i></span>
                                        <textarea id="card<?php echo $asset->id; ?>description" class="contenteditable" readonly="true" name="description" onkeypress="set('card<?php echo $asset->id; ?>description')"><?php echo $asset->description; ?></textarea>
                                        <button type="submit" class="editablesave btn-success btn" onclick="clearCookie('card<?php echo $asset->id; ?>description')">save</button>
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                            </form>
                        </div>
                        <div class="clearfix"></div>
                        <div class="panel panel-widget">
                            <?php /* <form id="assetImage<?php echo $asset->id; ?>" name='assetImage<?php echo $asset->id; ?>' method="POST" keepVisible="1" role="form" action="/saveticket/<?php echo $asset->id; ?>" rel="ajaxifiedFormShowResultHR" autocomplete="off" backToPage="" successMsg="Attachments Saved Successfully!" > */ ?>
                            <div class="panel-heading pn" >
                                <input type="hidden" name="asset_type_id" value="<?php echo $asset->asset_type_id; ?>">
                                <div class="col-sm-12"><span class="panel-icon"><i class="fa fa-paperclip hidden-xs"></i></span><span class="panel-title" > Attachments</span></div>
                                <div class="panel-footer col-md-12">
                                    <div class="tab-content pn br-n admin-form">
                                        <div id="tab1_1" class="tab-pane active">
                                            <div class="section row mbn">
                                                <div class="col-md-12 pn">                                             
                                                    <div class="section col-sm-8 mb15 pn">
                                                        <div class="col-xs-12">
                                                            <input type="hidden" name="title" class="tickettitle<?php echo $asset->id; ?>" value="<?php echo $asset->title; ?>"/>
                                                            <?php /* <input id="commentImages" multiple="multiple" type="file" name="attachments[]" class="gui-file reset" required=""> */ ?>
                                                            <script type="text/javascript">
                                                                $('#commentImages').fineUploader({
                                                                    template:'qq-template-manual-trigger',
                                                                    request:{
                                                                        endpoint:'/saveticket/<?php echo $asset->id; ?>',
                                                                        inputName:'attachments[]',
                                                                        params:{
                                                                            title:'<?php echo $asset->title; ?>',
                                                                            asset_type_id:'<?php echo $asset->asset_type_id; ?>'
                                                                        },
                                                                    },
                                                                    validation:{
                                                                        allowedExtensions:['jpeg','jpg','png','gif'],
                                                                        sizeLimit:10240000 // 50 kB = 50 * 1024 bytes
                                                                    },
                                                                    autoUpload:true,
                                                                    callbacks:{
                                                                        onAllComplete:function(status,data)
                                                                        {
                                                                        }
                                                                    }
                                                                });
                                                                $('#trigger-upload').click(function()
                                                                {
                                                                    $('#commentImages').fineUploader('uploadStoredFiles');
                                                                });
                                                            </script>
                                                            <script type="text/template" id="qq-template-manual-trigger">
                                                                <div class="qq-uploader-selector qq-uploader tray-bin pl10 mb10 mt10 mrn mln" qq-drop-area-text="Drop files here">
                                                                <div class="row">
                                                                <div class="col-sm-6 col-xs-12 pull-left text-center"><h3 class="mb10 mt10 mrn mln"><i class="fa fa-cloud-upload"></i>  Drop files to upload</h3></div>
                                                                <div class="buttons text-right col-sm-2 pull-right hidden-xs">
                                                                <div class="qq-upload-button-selector btn btn-primary">
                                                                <div>Select files</div>
                                                                </div>
                                                                </div>
                                                                <div class="buttons text-center col-xs-12 pull-right visible-xs">
                                                                <div class="qq-upload-button-selector btn btn-primary">
                                                                <div>Select files</div>
                                                                </div>
                                                                </div>
                                                                </div>
                                                                <div class="qq-total-progress-bar-container-selector qq-total-progress-bar-container">
                                                                <div role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" class="qq-total-progress-bar-selector qq-progress-bar qq-total-progress-bar"></div>
                                                                </div>
                                                                <div class="qq-upload-drop-area-selector qq-upload-drop-area" qq-hide-dropzone>
                                                                <span class="qq-upload-drop-area-text-selector">Drop files here</span>
                                                                </div>
                                                                <span class="qq-drop-processing-selector qq-drop-processing">
                                                                <span>Processing dropped files...</span>
                                                                <span class="qq-drop-processing-spinner-selector qq-drop-processing-spinner"></span>
                                                                </span>
                                                                <ul class="qq-upload-list-selector qq-upload-list mb10 mt10 " aria-live="polite" aria-relevant="additions removals">
                                                                <li>
                                                                <div class="qq-progress-bar-container-selector">
                                                                <div role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" class="qq-progress-bar-selector qq-progress-bar"></div>
                                                                </div>
                                                                <span class="qq-upload-spinner-selector qq-upload-spinner"></span>
                                                                <img class="qq-thumbnail-selector" qq-max-size="100" qq-server-scale>
                                                                <span class="qq-upload-file-selector qq-upload-file"></span>
                                                                <span class="qq-edit-filename-icon-selector qq-edit-filename-icon" aria-label="Edit filename"></span>
                                                                <input class="qq-edit-filename-selector qq-edit-filename" tabindex="0" type="text">
                                                                <span class="qq-upload-size-selector qq-upload-size"></span>
                                                                <button type="button" class="qq-btn qq-upload-retry-selector qq-upload-retry">Retry</button>
                                                                <span role="status" class="qq-upload-status-text-selector qq-upload-status-text"></span>
                                                                </li>
                                                                </ul>
                                                                </div>
                                                            </script>
                                                        </div>
                                                        <div class="clearfix"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                            <div id="commentImages" class="col-sm-12"></div>
                            <div class="clearfix"></div>
                            <?php /* </form> */ ?>
                            <div class="panel-body pn">
                                <div id="assetImage<?php echo $asset->id ?>ResultDiv">
                                    <?php echo $assetImages; ?>
                                </div>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                        <div class="panel panel-widget chat-widget mbn">
                            <div class="panel-heading"><span class="panel-icon"><i class="fa fa-comment hidden-xs"></i></span><span class="panel-title">Comments</span></div>
                            <form id="ticketComment" name='ticketComment<?php echo $asset->id; ?>' method="POST" keepVisible="1" role="form" action="/saveticketcomment/" rel="ajaxifiedFormShowResultHR" autocomplete="off"  backToPage="" successMsg="Comment Saved Successfully!" resultdiv="CommentCollection<?php echo $asset->id ?>">
                                <input type="hidden" name="user_id" value="<?php echo $page->currentUser->id; ?>">
                                <input type="hidden" name="asset_id" value="<?php echo $asset->id; ?>">
                                <input type="hidden" name="asset_type_id" value="<?php echo $asset->asset_type_id; ?>">
                                <div class="panel-footer bg-wild-sand">
                                    <div id="ticketCommentResultDiv" class="resultDiv"></div>
                                    <div class="tab-content pn br-n admin-form">
                                        <div id="tab1_1" class="tab-pane active">
                                            <div class="section row mbn">
                                                <div class="col-md-12 pl5">
                                                    <div class="section row mb15">
                                                        <div class="col-xs-12">
                                                        </div>
                                                    </div>
                                                    <div class="section row mb15">
                                                        <div class="col-xs-12">
                                                            <label for="ticketComment" class="field prepend-icon">
                                                                <textarea id="ticketComments" type="text" name="comments" placeholder="Add Your Comment Here..." class="event-name gui-textarea br-light light required reset" required=""></textarea>
                                                                <label for="ticketComment" class="field-icon"><i class="fa fa-file-o"></i></label>
                                                            </label>
                                                        </div>
                                                    </div>
                                                    <div class="section row mb15">
                                                        <div class="col-xs-12">
                                                            <label for="file1" class="field file"><span class="button btn-primary"> Choose File</span>
                                                                <input id="commentImages" multiple="multiple" type="file" name="commentImages[]" onchange="document.getElementById('uploader2').value=this.value;" class="gui-file reset">
                                                                <input id="uploader2" type="text" placeholder="no file selected" readonly="" class="gui-input reset">
                                                            </label>
                                                        </div>
                                                    </div>
                                                    <div class="section row mb15">
                                                        <div class="col-xs-12">
                                                            <input type="submit" href='javascript:void(0)' id="saveComment" name="saveComment" value="Comment" class="button btn-success col-xs-12 pull-right" />
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                </div>
                            </form>
                            <div class="clearfix"></div>
                            <div id="CommentCollection<?php echo $asset->id ?>"><?php
                                if (!empty($assetUserComments)) {
                                    echo $assetUserComments;
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php } ?>
            <aside data-tray-height="match" class="tray tray-center side-div col-lg-3 col-md-4 col-sm-4 p5" >
                <div id="accordion2" class="panel-group accordion accordion-lg">
                    <!-- create new order panel-->
                    <?php echo $AssignedUsers; ?>
                    <div class="panel mb10 mt5">
                        <div id="ticketmoveResultDiv" class="resultDiv"></div>
                        <div class="panel-heading">
                            <a data-toggle="collapse" data-parent="#accordion2" href="#accord2_4" class="accordion-toggle accordion-icon link-unstyled collapsed">
                                <span class="panel-title"> <i class="fa fa-calendar hidden-xs"></i>Move Card To List</span>
                            </a>
                        </div>
                        <div id="accord2_4" style="height: 0px;" class="panel-collapse collapse">
                            <div class="panel-body p20 pb10">
                                <div class="tab-content pn br-n admin-form">
                                    <div id="tab1_1" class="tab-pane active">
                                        <div class="section row mbn">
                                            <div class="col-md-12 pn">
                                                <form id="ticketmove" name="ticketmove" method="POST" keepvisible="1" role="form" action="/saveticket/<?php echo $asset->id; ?>/" rel="ajaxifiedFormShowResultHR" autocomplete="off" successMsg="Card Move Successfully!">
                                                    <div class="section row mb15">
                                                        <div class="col-xs-12">
                                                            <label for="setduedate" class="field prepend-icon">  
                                                                <input type="hidden" name="reloadUrl" value="/lists/<?php echo $project_id; ?>">
                                                                <input type="hidden" name="cardId" value="<?php echo $asset->id; ?>">                                                        
                                                                <select name="listcard" id="status" class="required form-control">                                                     
                                                                    <?php foreach ($listNames as $listName) { ?>
                                                                        <option value="<?php echo $listName->id; ?>"><?php echo $listName->title; ?></option>                                             
                                                                    <?php } ?>                                                                                                             
                                                                </select>  
                                                            </label>
                                                        </div>
                                                    </div>
                                                    <div class="section row mb15">
                                                        <div class="col-xs-12">
                                                            <button class="button btn-success col-xs-12 pull-right">Set Due Date</button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="panel mb10 mt5">
                        <div id="ticketdateResultDiv" class="resultDiv"></div>
                        <div class="panel-heading">
                            <a data-toggle="collapse" data-parent="#accordion2" href="#accord2_3" class="accordion-toggle accordion-icon link-unstyled collapsed">
                                <span class="panel-title"> <i class="fa fa-calendar hidden-xs"></i>Set Due Date</span>
                            </a>
                        </div>
                        <div id="accord2_3" style="height: 0px;" class="panel-collapse collapse">
                            <div class="panel-body p20 pb10">
                                <div class="tab-content pn br-n admin-form">
                                    <div id="tab1_1" class="tab-pane active">
                                        <div class="section row mbn">
                                            <div class="col-md-12 pn">
                                                <form id="ticketdate" name="tickets" method="POST" keepvisible="1" role="form" action="/saveticket/<?php echo $asset->id; ?>/" rel="ajaxifiedFormShowResultHR" autocomplete="off" successMsg="Due Date Set Successfully!">
                                                    <div class="section row mb15">
                                                        <div class="col-xs-12">
                                                            <label for="setduedate" class="field prepend-icon">
                                                                <input id="setduedate<?php echo rand(); ?>" type="text" name="release_date" placeholder="Set Due Date" class="required datepicker event-name gui-input br-light light" value="<?php echo $asset->release_date ?>">
                                                                <label for="setduedate" class="field-icon"><i class="fa fa-calendar"></i></label>
                                                            </label>
                                                        </div>
                                                    </div>
                                                    <div class="section row mb15">
                                                        <div class="col-xs-12">
                                                            <button class="button btn-success col-xs-12 pull-right">Set Due Date</button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="panel mb10 mt5">
                        <div id="cardstatusResultDiv" class="resultDiv"></div>
                        <div class="panel-heading">
                            <a data-toggle="collapse" data-parent="#accordion2" href="#accord2_2" class="accordion-toggle accordion-icon link-unstyled collapsed">
                                <span class="panel-title"> <i class="fa fa-calendar hidden-xs"></i>Set Card Status</span>
                            </a>
                        </div>
                        <div id="accord2_2" style="height: 0px;" class="panel-collapse collapse">
                            <div class="panel-body p20 pb10">
                                <div class="tab-content pn br-n admin-form">
                                    <div id="tab1_1" class="tab-pane active">
                                        <div class="section row mbn">
                                            <div class="col-md-12 pn">
                                                <form id="cardstatus" name="cardstatus" method="POST" keepvisible="1" role="form" action="/saveticket/<?php echo $asset->id; ?>/" rel="ajaxifiedFormShowResultHR" autocomplete="off" successMsg="Status Set Successfully!">
                                                    <div class="section row mb15">
                                                        <div class="col-xs-12">
                                                            <label for="cardstatus" class="field prepend-icon">
                                                                <select name="status" id="status" class="required form-control">
                                                                    <option value="1">Open</option>
                                                                    <option value="3">Close</option>                                                      
                                                                </select>                                                
                                                            </label>
                                                        </div>
                                                    </div>
                                                    <div class="section row mb15">
                                                        <div class="col-xs-12">
                                                            <button class="button btn-success col-xs-12 pull-right">Set Card Status</button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php echo $ticketEstimatedTime; ?>
                    <div class="panel mb10 mt5 ticketEstimatedClass" <?php if ($vallowaddtime != 'yes') { echo ' style="display:none;" ';} ?> >
                        <div id="tickettimeResultDiv" class="resultDiv"></div>
                        <div class="panel-heading">
                            <a data-toggle="collapse" data-parent="#accordion2" href="#accord2_1" class="accordion-toggle accordion-icon link-unstyled collapsed">
                                <span class="panel-title"> <i class="fa fa-clock-o hidden-xs"></i>Your Working hours</span>
                            </a>
                        </div>
                        <div id="accord2_1" style="height: 0px;" class="panel-collapse collapse">
                            <div class="panel-body p20 pb10">
                                <div class="tab-content pn br-n admin-form">
                                    <div id="tab1_1" class="tab-pane active">
                                        <div class="section row mbn">
                                            <div id="tickettimeCollection<?php echo $asset->id ?>" class="col-sm-12">
                                                <?php
                                                if (!empty($ticketTimes)) {
                                                    $olddate = '';
                                                    foreach ($ticketTimes as $ticketTime) {
                                                        $date = date('M j, Y', strtotime($ticketTime->added_date));
                                                        if ($olddate != $date) {
                                                            if ($olddate != '')
                                                                echo '<div class="clearfix"></div><hr class="mt10 mb10" />';
                                                            echo '<div class="col-sm-12 mb10">' . $date . '</div><div class="clearfix"></div>';
                                                            $olddate = $date;
                                                        }
                                                        echo '<div class="time-tag">' . sprintf('%02d', $ticketTime->hours) . ':' . sprintf('%02d', $ticketTime->minutes) . ' </div>';
                                                    }
                                                }
                                                ?>
                                            </div>
                                            <div class="col-md-12 pn mt10">
                                                <form id="tickettime" name="tickets" method="POST" keepvisible="1" role="form" action="/savetickettime/<?php echo $asset->id; ?>/" rel="ajaxifiedFormShowResultHR" autocomplete="off" successMsg="Added working hours Successfully!" resultdiv="tickettimeCollection<?php echo $asset->id ?>">
                                                    <input type="hidden" name="record_type" value="1">
                                                    <div class="section row mb15">
                                                        <div class="col-xs-6">
                                                            <label for="hours" class="field prepend-icon">
                                                                <select name="hours" id="hours" required="" class="required form-control reset">
                                                                    <option value="">Select hour</option>
                                                                    <?php
                                                                    $i = 0;
                                                                    while ($i < 24) {
                                                                        echo '<option value="' . sprintf('%02d', $i) . '">' . sprintf('%02d', $i) . '</option>';
                                                                        $i++;
                                                                    }
                                                                    ?>
                                                                </select>
                                                            </label>
                                                        </div>
                                                        <div class="col-xs-6">
                                                            <label for="minutes" class="field prepend-icon">
                                                                <select name="minutes" id="minutes" required="" class="required form-control reset">
                                                                    <option value="">Select minutes</option>
                                                                    <?php
                                                                    $i = 0;
                                                                    while ($i < 60) {
                                                                        echo '<option value="' . sprintf('%02d', $i) . '">' . sprintf('%02d', $i) . '</option>';
                                                                        $i++;
                                                                    }
                                                                    ?>
                                                                </select>
                                                            </label>
                                                        </div>
                                                    </div>
                                                    <div class="section row mb15">
                                                        <div class="col-xs-12">
                                                            <button class="button btn-success col-xs-12 pull-right">Add working hours</button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- menu quick links-->
                    <div class="clearfix"></div>
                    <!-- menu quick links-->
                </div>
            </aside>
            <div class="clearfix"></div>
        </div>
    </section>
    <style>
        #trigger-upload {
            color: white;
            background-color: #00ABC7;
            font-size: 14px;
            padding: 7px 20px;
            background-image: none;
        }

        #commentImages .qq-upload-button {
            margin-right: 15px;
        }

        #commentImages .buttons {
            width: 36%;
        }

        #commentImages .qq-uploader .qq-total-progress-bar-container {
            width: 60%;
        }
        @media screen and (max-width : 767px){
            #commentImages .buttons {width: 100%;}
        }
    </style>
    <?php /*
      <script>
      $(function()
      {
      var popUpDiv_id=$('.popUpDiv').attr("id");
      var emptyData=$("#"+popUpDiv_id).find(".emptyData").html();
      if(emptyData=='')
      {
      $(".ticketEstimatedClass").hide();
      }else
      {
      $(".ticketEstimatedClass").show();
      }
      });
      </script>
      debug: false,
      button: null,
      multiple: true,
      maxConnections: 3,
      disableCancelForFormUploads: false,
      autoUpload: true,
      request: {
      customHeaders: {},
      endpoint: "/server/upload",
      filenameParam: "qqfilename",
      forceMultipart: true,
      inputName: "qqfile",
      method: "POST",
      params: {},
      paramsInBody: true,
      totalFileSizeName: "qqtotalfilesize",
      uuidName: "qquuid"
      },
      validation: {
      allowedExtensions: [],
      sizeLimit: 0,
      minSizeLimit: 0,
      itemLimit: 0,
      stopOnFirstInvalidFile: true,
      acceptFiles: null,
      image: {
      maxHeight: 0,
      maxWidth: 0,
      minHeight: 0,
      minWidth: 0
      }

     */ ?>
    <?php
}?>