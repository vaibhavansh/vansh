<?php $bulkid = rand(0, 100); ?>
<div class="panel mb25 mt5">
    <div id="addbookmark<?php echo $bulkid; ?>ResultDiv"></div>
    <div class="panel-heading"><span class="panel-title"> <i class="fa fa-star hidden-xs"></i> Add Bookmark</span>
    </div>
    <div class="panel-body p20 pb10">
        <div class="tab-content pn br-n admin-form">
            <div id="tab1_1" class="tab-pane active">
                <div class="section row mbn">
                    <div class="col-md-12 pn">
                        <form method="POST" resultDiv="addbookmark<?php echo $bulkid; ?>ResultDiv" id="addbookmark<?php echo $bulkid; ?>form" close_popup="1" keepvisible="1" role="form" action="/savebookmarks/" rel="ajaxifiedForm" autocomplete="off" backToPage="/bookmarks" successMsg="Bookmark Added Successfully!">
                            <div class="section row mb15">
                                <div class="col-xs-12">
                                    <label for="bookmarktitle" class="field prepend-icon">
                                        <input id="bookmarktitle" type="text" name="title" placeholder="Bookmark Title" class="event-name gui-input br-light light required" required="required" >
                                        <label for="bookmarktitle" class="field-icon"><i class="fa fa-file-text"></i></label>

                                    </label>
                                </div>
                            </div>
                            <div class="section row mb15">
                                <div class="col-xs-12">
                                    <label for="bookmarkurl" class="field prepend-icon">
                                        <input id="bookmarkurl" type="url" name="url" placeholder="Enter Bookmark URL" class="event-name gui-input br-light light required url" autocomplete="off" required>
                                        <label for="bookmarkurl" class="field-icon"><i class="fa fa-link"></i></label>
                                    </label>
                                </div>
                            </div>               
                            <input type="hidden" name="asset_type_id" value="2" />
                            <div class="section row mb15">
                                <div class="col-xs-12">
                                    <button type="submit" class="button btn-success col-xs-12 pull-right bookmarksave" id="submitBtn">Add Bookmark</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</div>