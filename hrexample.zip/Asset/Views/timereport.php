<?php
global $page;
$rand = rand(10, 1000);
?>
<section class="">
    <div id="animation-switcher" class="tray-center ">
        <div id="projects_listing" class="paginationnew">
            <div class="panel mb25 mt5">
                <div class="panel-heading"><span class="panel-title"> <i class="fa fa-th-list hidden-xs"></i> Project Time Report</span></div>
                <div class="panel-menu theme-primary p5 pbn">
                    <div class="row"> 
                        <div class="col-xs-12 prn">
                            <div class="col-md-4 col-sm-3 pln">
                                <div class="col-sm-12 mb10">
                                    <label class="pt10 pl10"><strong>Filter By Project</strong></label>
                                </div>
                                <div class="col-sm-12  admin-form">
                                    <div class="col-sm-12 mb10">
                                        <label class="field select">
                                            <select id="filterproject" class="event-name gui-input br-light light " onchange="clean_user();filter_contents();">
                                                <option value="0">All Projects</option>
                                                <?php
                                                if (!empty($filterdata['projects'])) {
                                                    foreach ($filterdata['projects'] as $project) {
                                                        $selected = ($project_id == $project->id) ? ' selected="selected" ' : ' ';
                                                        echo '<option value="' . $project->id . '" ' . $selected . '>' . $project->title . '</option>';
                                                    }
                                                }
                                                ?>
                                            </select>
                                            <i class="arrow"></i>
                                        </label>
                                    </div>
                                    <div class="col-sm-12 mb10">
                                        <label class="field select">
                                            <select id="filterlist" class="event-name gui-input br-light light " onchange="filter_contents()">
                                                <option value="0">All Lists</option>
                                                <?php
                                                if (!empty($filterdata['lists'])) {
                                                    foreach ($filterdata['lists'] as $list) {
                                                        $selected = ($list_id == $list->id) ? ' selected="selected" ' : ' ';
                                                        echo '<option value="' . $list->id . '" ' . $selected . '>' . $list->title . '</option>';
                                                    }
                                                }
                                                ?>
                                            </select>
                                            <i class="arrow"></i>
                                        </label>
                                    </div>
                                    <div class="col-sm-12 mb10">
                                        <label class="field select">
                                            <select id="filtercard" class="event-name gui-input br-light light " onchange="filter_contents()">
                                                <option value="0">All Cards</option>
                                                <?php
                                                if (!empty($filterdata['cards'])) {
                                                    foreach ($filterdata['cards'] as $card) {
                                                        $selected = ($card_id == $card->id) ? ' selected="selected" ' : ' ';
                                                        echo '<option value="' . $card->id . '" ' . $selected . '>' . $card->title . '</option>';
                                                    }
                                                }
                                                ?>
                                            </select>
                                            <i class="arrow"></i>
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-3 pr15 ptn">
                                <div class="col-sm-12 mb10">
                                    <label class="pt10"><strong>Filter By User</strong></label>
                                </div>
                                <div class="col-sm-12 mb10  admin-form">
                                    <label class="field select">
                                        <select id="filteruser" class="event-name gui-input br-light light" onchange="filter_contents()">
                                            <option value="0">All Users</option>
                                            <?php
                                            if (!empty($filterdata)) {
                                                foreach ($filterdata['users'] as $id => $name) {
                                                    $selected = ($userid == $id) ? ' selected="selected" ' : ' ';
                                                    echo '<option value="' . $id . '" ' . $selected . '>' . $name . '</option>';
                                                }
                                            }
                                            ?>
                                        </select>
                                        <i class="arrow"></i>
                                    </label>
                                </div>
                                <div class="col-sm-12 mb10">
                                    <label class="pt10"><strong>Filter By Project Type</strong></label>
                                </div>
                                <div class="col-sm-12 mb10  admin-form">
                                    <label class="field select">
                                        <select id="filterProjectType" class="event-name gui-input br-light light" onchange="filter_contents()">
                                            <option value="0">All Type</option>
                                            <option value="1" <?php if($ProjectType=='1') echo ' selected="selected" ';?>>Productive only</option>
                                            <option value="2" <?php if($ProjectType=='2') echo ' selected="selected" ';?>>Non Productive only</option>
                                        </select>
                                        <i class="arrow"></i>
                                    </label>
                                </div>
                            </div>
                            <div class="clearfix visible-xs"></div>
                            <div class="col-md-4 col-sm-6 mb10">
                                <div class="col-sm-12 mb10">
                                    <label class="pt10"><strong>Filter By Date</strong></label>
                                </div>
                                <form resultdiv="mainContent" name="searchDates" id="search" method="post" class="form-inline col-xs-12 pln pb5  admin-form" keepvisible="1" keepresult="1" action="/projecttimereport/<?php echo $project_id . '/' . $list_id . '/' . $card_id . '/' . $userid . '/' . $FromDate . '/' . $ToDate.'/'.$ProjectType ?>/" rel="ajaxifiedForm" novalidate="novalidate">
                                    <div class="col-sm-12 pn">
                                        <div class="col-sm-6 mb10">
                                            <input type="text" name="formdate" class="datepicker gui-input from_data" value="<?php echo !empty($FromDate) ? $FromDate : ''; ?>"/>
                                        </div>
                                        <div class="col-sm-6 mb10">
                                            <input type="text" name="todate" class="datepicker gui-input to_date" value="<?php echo !empty($ToDate) ? $ToDate : ''; ?>"/>
                                        </div>
                                        <div class="clearfix"></div>
                                        <div class="col-xs-12 pb5">
                                            <a class="link fs14" onclick="searchReport('today')" >Today</a> |
                                            <a class="link fs14" onclick="searchReport('weekly')" >This Week</a> |
                                            <a class="link fs14" onclick="searchReport('month')" >This Month</a> |
                                            <a class="link fs14" onclick="searchReport('lastmonth')" >Last Month</a>
                                        </div>
                                        <div class="col-sm-12 mb10 text-right">
                                            <input type="button" onclick="filter_contents();" value="Search" class="btn btn-info col-sm-12">
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>  
                <div class="panel-body pn">
                    <div id="status_apporaveResultDiv" class="resultDiv"></div>
                    <form id="status_apporave" name="importantlinks" method="POST" resultDiv="status_apporaveResultDiv"  keepvisible="1" role="form" action="/approveticket/" rel="ajaxifiedForm" autocomplete="off" backToPage="<?php echo "/projecttimereport/" . $project_id . '/' . $list_id . '/' . $card_id . '/' . $userid . '/' . $FromDate . '/' . $ToDate.'/'.$ProjectType; ?>" successMsg="Successfully!">
                        <div class="">
                            <div class="list-com" id="list-com">
                                <div class="col-sm-12 com-detail pt10">
                                    <div class="col-sm-12">
                                        <div class="col-sm-1 col-xs-12"><p><strong><input type="checkbox" class="checkall"> Approved</strong></p></div>
                                        <div class="col-sm-3 col-xs-12"><p><strong>Card</strong></p></div>
                                        <div class="col-sm-2 hidden-xs"><p><strong>User</strong></p></div>
                                        <div class="col-sm-2 hidden-xs"><p><strong>Date</strong></p></div>
                                        <div class="col-sm-2 hidden-xs text-right"><p><strong>Record Type</strong></p></div>
                                        <div class="col-sm-2 hidden-xs text-right"><p><strong>Time</strong></p></div>
                                        <div class="clearfix"></div>
                                    </div>
                                </div>
                                <?php
                                if (!empty($ticketTimes->data)) {

                                    foreach ($ticketTimes->data as $ticketTime) {
                                        ?>
                                        <div class="col-sm-12 com-detail p15" id="section_2">

                                            <input name="status[<?php echo $ticketTime->id; ?>]" value="0" type="hidden"/>
                                            <?php if ($ticketTime->status == 1) { ?>   
                                                <div class="col-sm-1 col-xs-12"><div class="app-switch"><input type="checkbox" name="status[<?php echo $ticketTime->id; ?>]"  class="apporaveStatus" checked=""/><label><i></i></label></div></div>
                                            <?php } else { ?>
                                                <div class="col-sm-1 col-xs-12"><div class="app-switch"><input type="checkbox" name="status[<?php echo $ticketTime->id; ?>]" class="apporaveStatus" /><label><i></i></label></div></div>
                                            <?php } ?>

                                            <div class="col-sm-3 col-xs-12"><p><a class="link" onclick="filter_contents(<?php echo $ticketTime->asset_id; ?>)" ><span class="fa fa-filter fa-2x"></span></a> <a rel="popUpBoxHR"  href="/viewticket/<?php echo $ticketTime->asset_id; ?>"><?php echo $ticketTime->card; ?></a></p></div><div class="clearfix visible-xs"></div>
                                            <div class="col-sm-2 col-xs-12 "><p><a class="link" onclick="listbyuser(<?php echo $ticketTime->user_id; ?>)" ><?php echo $ticketTime->user; ?></a></p></div><div class="clearfix visible-xs"></div>
                                            <div class="col-sm-2 col-xs-6"><p><?php echo date('M j, Y', strtotime($ticketTime->added_date)); ?></p></div>
                                            <div class="col-sm-2 col-xs-6 text-right"><p><?php
                                                if ($ticketTime->record_type == 1) {
                                                    echo "Manually";
                                                } else {
                                                    echo "Auto";
                                                }
                                                ?></p>
                                            </div>
                                            <div class="col-sm-2 col-xs-6 text-right"><p><?php echo sprintf('%02d', $ticketTime->hours) . ':' . sprintf('%02d', $ticketTime->minutes); ?></p></div>
                                            <div class="clearfix"></div>
                                        </div>
                                        <?php
                                        $hours[] = $ticketTime->hours;
                                        $minutes[] = $ticketTime->minutes;
                                    }?>                   
                                    <div class="col-sm-12 com-detail p15" id="section_2">                                
                                        <div class="col-xs-12 text-right"><p><b>Total Page Time</b>: <b><?php echo Core_Models_Utility::countTime($hours, $minutes); ?> Hours</b></p></div>
                                        <div class="col-xs-12 text-right"><p><b>Grand Total Time</b>: <b><?php echo $alltotaltime; ?> Hours</b></p></div>
                                        <?php if ($page->currentUser->webUserRole == 2) { ?>
                                            <div class="col-xs-12"> <input type="submit" value="Aprroved selected" class="text-left btn btn-success"></div>
                                        <?php } ?>
                                        <div class="clearfix"></div>
                                    </div>                                                           
                                    <?php
                                } else {
                                    echo '<div class="col-xs-12 text-center"><h3>No one worked on this project yet!</h3></div>';
                                }
                                ?>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="clearfix"></div>
            <div id="pagingControls" class="pull-left">
                <h5><?php echo $ticketTimes->getCurrentPageInfo(); ?></h5>
            </div>
            <div class="pull-right" >              
                <ul class="pagination bootpag">  
                    <?php
                    echo $ticketTimes->printPageNumbers(array('url' => "/projecttimereport/" . $project_id . '/' . $list_id . '/' . $card_id . '/' . $userid . '/' . $FromDate . '/' . $ToDate.'/'.$ProjectType, 'div_id' => 'mainContent',
                        'ajaxRequest' => true));
                    ?>
                </ul>
            </div>  
            <div class="clearfix" ></div>

            <div class="clearfix visible-sm visible-lg visible-md visible-xs"></div>                 
        </div>
    </div>
</section>



<script type="text/javascript" >
    $('.checkall').click(function()
    {
        if($(this).is(':checked'))
            $(".apporaveStatus").prop("checked",true);
        else
            $(".apporaveStatus").prop("checked",false);
    });

    function searchReport(reporttype)
    {
        $(".from_data").val(reporttype);
        $('.to_date').val('');
        filter_contents();
    }
    function listbyuser(userid)
    {
        $("#filteruser").val(userid);
        filter_contents();
    }
    function filter_contents(cardid)
    {
        var filterproject=$("#filterproject").val();
        var filterlist=$("#filterlist").val();
        var filteruser=$("#filteruser").val();
        var filtercard=$("#filtercard").val();
        var fromdate=$(".from_data").val();
        var todate=$(".to_date").val();
        var filterProjectType=$("#filterProjectType").val();

        if(fromdate==null||fromdate=='')
        {
            var fromdate='0';
        }
        if(todate==null||todate=='')
        {
            var todate='0';
        }
        if(cardid)
        {
            var filtercard=cardid;
        }
        window.location.assign("#.projecttimereport."+filterproject+'.'+filterlist+'.'+filtercard+'.'+filteruser+'.'+fromdate+'.'+todate+'.'+filterProjectType);
    }
    function clean_user()
    {
        $("#filterlist").val('0');
        $("#filtercard").val('0');
    }
    $(document).ready(function()
    {
        if($('#filterproject').val()=='0')
        {
            $('#filterlist, #filtercard').parent('label').hide();
        }
//        if($('#filterlist').val() == '0' && $('#filtercard').val() == '0'){ 
//            $('#filtercard').parent('label').hide();
//        }
    });
</script>