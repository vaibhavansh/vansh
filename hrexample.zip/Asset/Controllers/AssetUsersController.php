<?php

class Asset_Controllers_AssetUsersController extends Core_Controllers_SitesController {

}
