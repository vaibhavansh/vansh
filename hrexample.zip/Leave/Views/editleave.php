<?php
global $page;
$webUserRole = $page->currentUser->webUserRole;
$disabled = isset($restrict) && $restrict == 'view' ? 'disabled = "disabled"' : '';
$header = isset($restrict) && $restrict == 'view' ? 'View Leave' : 'Edit Leave';
$button = isset($restrict) && $restrict == 'view' ? 'display:none' : '';
$joinDate = new DateTime(date($page->currentUser->created));
$currentDate = new DateTime(date("Y-m-d"));
$interval = date_diff($joinDate, $currentDate);
$years = $interval->format('%y');
?>
<div id="modal-form" class=" mfp-with-anim">
    <?php if (!empty($editLeave)) { ?>
        <div class="panel">
            <div id="requestLeaveResultDiv" class="resultDiv"></div>
            <div class="panel-heading">
                <span class="panel-title">
                    <i class="fa fa-pencil hidden-xs"></i>
                    <?php echo $header; ?>
                </span><div class="clearfix"></div>
            </div>
            <form keepVisible="1" class="admin-form" role="form" resultDiv="requestLeaveResultDiv" close_popup="1" method="POST" rel='ajaxifiedForm' autocomplete="off" backToPage="/leaveview" successMsg="Your Leave Request Sent Successfully" id="requestLeave" action="/leave_leaves/saveLeave/<?php echo $editLeave->id; ?>">
                <input type="hidden" id="userId" name="userId" value="<?php echo $editLeave->userId; ?>">
                <div class="panel-body p25 ">
                    <div class="section row mb15">
                        <div class="col-xs-12">
                            <label for="leavetype" class="field select">
                                <?php
                                $leaveTypes = Leave_Models_Leave::getLeaveType();
                                if (!empty($leaveTypes)) {
                                    ?>
                                    <select class="event-name gui-input br-light light" name="leavetype" id="leavetype" <?php echo $disabled; ?>>
                                        <option value="" disabled="" selected="">Select Leave Type</option>
                                        <?php
                                        foreach ($leaveTypes as $key => $leaveType) {
                                            $selected = ($editLeave->leavetype == $key) ? 'selected="selected"' : '';
                                            ?>
                                            <option value="<?php echo $key ?>" <?php echo $selected; ?>><?php echo $leaveType; ?></option>
                                            <?php
                                        }
                                        ?>
                                    </select>
                                    <i class="arrow"></i>
                                <?php } ?>
                            </label>
                        </div>
                    </div>

                    <div class="hideleaveform" style="display:none;">
                        <div class="section row mb15">
                            <div class="col-xs-12">
                                <label for="startdate" class="field prepend-icon">
                                    <input id="startdate" type="text" name="startdate" placeholder="Start Date" class="event-name gui-input br-light light required" value="<?php echo $editLeave->startdate; ?>" <?php echo $disabled; ?>>
                                    <label for="startdate" class="field-icon"><i class="fa fa-calendar"></i></label>
                                </label>
                            </div>
                        </div>
                        <div class="section row mb15">
                            <div class="col-xs-12">
                                <label for="enddate" class="field prepend-icon">
                                    <input id="enddate" type="text" name="enddate" placeholder="End Date" class="event-name gui-input br-light light required" value="<?php echo $editLeave->enddate; ?>" <?php echo $disabled; ?>>
                                    <label for="enddate" class="field-icon"><i class="fa fa-calendar"></i></label>
                                </label>
                            </div>
                        </div>
                        <?php $duration = isset($editLeave->duration) ? $editLeave->duration : ''; ?>
                        <div id="section_duration" class="section row mb15">
                            <div class="col-xs-12">
                                <label for="duration" class="field prepend-icon">
                                    <input id="duration" type="text" name="duration" placeholder="Duration" class="event-name gui-input br-light light" value="<?php echo $duration . ' Day'; ?>" <?php echo $disabled; ?> readonly="">
                                    <label for="duration" class="field-icon"><i class="fa fa-clock-o"></i></label>
                                </label>
                            </div>
                        </div>
                        <div id="section_sick" class="section row mb15" style="display: none;">
                            <div class="col-xs-12">
                                <label for="sickDoc" class="field file"><span class="button btn-primary"> Choose File</span>
                                    <input id="sick" type="file" name="fileToUpload" onchange="document.getElementById('uploadmedicaldoc').value = this.value;" class="gui-file">
                                    <input id="uploadmedicaldoc" type="text" placeholder="Upload a Medical Certificate within 7 days" class="gui-input">
                                </label>
                            </div>
                        </div>
                        <div class="section row mb15">
                            <div class="col-xs-12">
                                <label for="cause" class="field prepend-icon">
                                    <textarea id="cause" type="text" name="cause" placeholder="Reason" class="event-name gui-textarea br-light light required" <?php echo $disabled; ?>><?php echo $editLeave->cause; ?></textarea>
                                    <label for="cause" class="field-icon"><i class="fa fa-info"></i></label>
                                </label>
                            </div>
                        </div>
                        <?php if ($restrict != 'view') { ?>
                            <div id="requestbutton" class="section row mb15">
                                <div class="col-xs-12">
                                    <button onclick="durationFunction();" type="button" name="submit" value="Request Leave" class="button btn-success col-xs-12 pull-right">Request Leave</button>
                                </div>
                            </div>
                        <?php } ?>
                    </div>            
                </div>
            </form>
        </div>
    <?php } else { ?>
        <div class="panel">
            <div id="requestLeaveResultDiv" class="resultDiv"></div>
            <div class="panel-heading">
                <span class="panel-title">
                    <i class="fa fa-pencil hidden-xs"></i>
                    Request Leave
                </span><div class="clearfix"></div>
            </div>
            <form  class="admin-form" keepVisible="1" role="form" resultDiv="requestLeaveResultDiv" close_popup="1" method="POST" rel='ajaxifiedForm' autocomplete="off" backToPage="/leaveview" successMsg="Your Leave Request Sent Successfully" id="requestLeave" action="/leave_leaves/saveLeave">
                <input type="hidden" id="userId" name="userId" value="<?php echo $page->currentUser->id; ?>">
                <input type="hidden" id="duration" name="duration" value="">
                <div class="panel-body p25">
                    <div class="section row mb15">
                        <div class="col-xs-12">
                            <label for="leavetype" class="field select">
                                <?php
                                $leaveTypes = Leave_Models_Leave::getLeaveType();
                                if (!empty($leaveTypes)) {
                                    ?>
                                    <select class="event-name gui-input br-light light required" name="leavetype" id="leavetype">
                                        <option value="" disabled="" selected="">Select Leave Type</option>
                                        <?php
                                        foreach ($leaveTypes as $key => $leaveType) {
                                            ?>
                                            <option value="<?php echo $key ?>"><?php echo $leaveType; ?></option>
                                            <?php
                                        }
                                        ?>
                                    </select>
                                    <i class="arrow"></i>
                                <?php } ?>
                            </label>
                        </div>
                    </div>

                    <div class="hideleaveform" style="display:none;">
                        <div class="section row mb15">
                            <div class="col-xs-12">
                                <label for="startdate" class="field prepend-icon">
                                    <input id="startdate" type="text" name="startdate" placeholder="Start Date" class="event-name gui-input br-light light startdate1 required">
                                    <label for="startdate" class="field-icon"><i class="fa fa-calendar"></i></label>
                                </label>
                            </div>
                        </div>
                        <div class="section row mb15">
                            <div class="col-xs-12">
                                <label for="enddate" class="field prepend-icon">
                                    <input id="enddate" type="text" name="enddate" placeholder="End Date" class="event-name gui-input br-light light enddate1 required">
                                    <label for="enddate" class="field-icon"><i class="fa fa-calendar"></i></label>
                                </label>
                            </div>
                        </div>
                        <div class="section row mb15">
                            <div class="col-xs-12">
                                <label for="allottedCL" class="field prepend-icon">
                                    <input disabled="true" id="allottedCL" type="text" name="allottedCL"  placeholder="Allowed Leave" class="event-name gui-input br-light light" value="">
                                    <label for="allottedCL" class="field-icon"><i class="fa fa-clock-o"></i></label>
                                </label>
                            </div>
                        </div>
                        <div id="section_sick" class="section row mb15" style="display: none;">
                            <div class="col-xs-12">
                                <label for="sickDoc" class="field file"><span class="button btn-primary"> Choose File</span>
                                    <input id="sick" type="file" name="fileToUpload" onchange="document.getElementById('uploadmedicaldoc').value = this.value;" class="gui-file">
                                    <input id="uploadmedicaldoc" type="text" placeholder="Upload a Medical Certificate within 7 days" readonly="" class="gui-input">
                                </label>
                            </div>
                        </div>
                        <div class="section row mb15">
                            <div class="col-xs-12">
                                <label for="cause" class="field prepend-icon">
                                    <textarea id="cause" type="text" name="cause" placeholder="Reason" class="event-name gui-textarea br-light light required"></textarea>
                                    <label for="cause" class="field-icon"><i class="fa fa-info"></i></label>
                                </label>
                            </div>
                        </div>
                        <div id="noleavenote" class="section row mb15">
                            <div class="col-xs-12 appendNote">
                            </div>
                        </div>
                    </div>            
                </div>
            </form>
        </div>
    <?php }
    ?>
    <script type="text/javascript">
        $(document).ready(function () {
            var leavetype_val = $("#leavetype option:selected").val();
            if (leavetype_val !== '') {
                $('.hideleaveform').show();
                $('#startdate, #enddate').datepicker({
                    showWeek: true,
                    showAnim: "slide",
                    dateFormat: "yy-mm-dd",
                    changeMonth: true,
                    changeYear: true,
                    numberOfMonths: 2,
                onSelect: function() {
                  durationFunction(countdays=1);
                    }
                });
            } else {
                $('.hideleaveform').hide();
            }
        });

        $("#leavetype").change(function () {
            var leavetype_val = $("#leavetype option:selected").val();
            var leavetype_name = $("#leavetype option:selected").text();
            $('.hideleaveform input').val('');
            $('.hideleaveform').show();
            $('#startdate, #enddate').datepicker({
                showWeek: true,
                showAnim: "slide",
                dateFormat: "yy-mm-dd",
                changeMonth: true,
                numberOfMonths: 2
            });
            $.post('/leave_leaves/editleave/',
                    {
                        leaveTypeVal: leavetype_val,
                        leaveTypeName: leavetype_name,
                        joiningYear: '<?php echo $years; ?>'
                    },
                    function (data) {
                        $('#allottedCL').val('Your remaining leaves is ' + data);
                        if (data <= '0') {
                            $('#noleavenote .appendNote').empty();
                            $('#noleavenote').find('button').remove();
                            $('#noleavenote .appendNote').append('<h4 class="red-note text-center">You Have No Available ' + leavetype_name + ' Leaves Or Your Leaves Is Pending. Please Contact Administration For Extra Leaves.</h4>');

                        } else {
                            $('#noleavenote .appendNote').empty();
                            $('#noleavenote .appendNote').find('h4').remove();
                            $('#noleavenote .appendNote').append('<button type="button" onclick="durationFunction();" name="submit" value="Request Leave" class="button btn-success col-xs-12 pull-right">Request Leave</button>');
                        }
                    });
            if (leavetype_val === '1') {
                $('#section_sick').hide();
//                $('#startdate, #enddate').datepicker('option', 'minDate', '1m');
//                $('#startdate').datepicker('setDate', '1m');
            } else if (leavetype_val === '2') {
                $('#section_sick').hide();
//                $('#startdate, #enddate').datepicker('option', 'minDate', '1d');
//                $('#startdate').datepicker('setDate', '1d');
            } else if (leavetype_val === '3') {
                $('#section_sick').hide();
//                $('#startdate, #enddate').datepicker('option', 'minDate', '0d');
//                $('#startdate').datepicker('setDate', '0d');
            } else if (leavetype_val === '4') {
                $('#section_sick').hide();
//                $('#startdate, #enddate').datepicker('option', 'minDate', '1m');
//                $('#startdate').datepicker('setDate', '1m');
            } else if (leavetype_val === '5') {
                $('#section_sick').show();
//                $('#startdate, #enddate').datepicker('option', 'minDate', '0d');
//                $('#startdate').datepicker('setDate', '0d');
            } else if (leavetype_val === '6') {
                $('#section_sick').hide();
//                $('#startdate, #enddate').datepicker('option', 'minDate', '1d');
//                $('#startdate').datepicker('setDate', '1d');
            }
        });
        function durationFunction(countdays='') {
            var startdate = new Date(document.getElementById("startdate").value);
            var enddate = new Date(document.getElementById("enddate").value);
            var leavetype = document.getElementById("leavetype").value;
            if (startdate.getTime() <= enddate.getTime()) {
                var timeDiff = Math.abs(startdate.getTime() - enddate.getTime());
                var duration = Math.ceil(timeDiff / (1000 * 3600 * 24))+1;            
            } else {
                alert('Please Enter Start Date And End Date Properly....');
                return false;
            }
            if (leavetype === '1' && duration > 5) {
                alert("You Can't Take Leave More Than 5 days");
            } else if (leavetype === '2' && duration >= 2) {
                alert("You Can't Take Leave More Than 1 day");
                $('.hideleaveform input').val('');
                $('#startdate').datepicker('setDate', '1d');
            } else if (leavetype === '3' && duration >= 4) {
                alert("You Can't Take Leave More Than 3 days");
            } else if (leavetype === '4' && duration >= 31) {
                alert("You Can't Take Leave More Than 30 days");
            } else if (leavetype === '5' && duration >= 16) {
                alert("You Can't Take Leave More Than 15 days");
            } else if (leavetype === '6' && duration >= 2 ) {
                alert("You Can't Take Leave More Than 1 day");
                $('.hideleaveform input').val('');
                $('#startdate').datepicker('setDate', '1d');
            }else if (leavetype === '7' && duration >= 2) {
                alert("You Can't Take Leave More Than 1 days");
            }else if (duration !== undefined || duration !== null) {
                $('#duration').val(duration);
                if((countdays == '')){ 
                    $('#requestLeave').submit();
                }
            }
            return false;
        }
    </script>
</div>