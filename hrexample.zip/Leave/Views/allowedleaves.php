<?php global $page; ?>
<section class="">
    <div id="animation-switcher" class="col-md-12 col-sm-12 no-pad">
        <div class="panel mb25 mt5">
            <div class="panel-heading"><span class="panel-title"> <i class="fa fa-rocket hidden-xs"></i> <?php echo $user->fullName() ?>'s Leave Balance</span><div class="clearfix"></div>
            </div>
            <?php if (!empty($allotedLeaves)) { ?>
                <div class="panel-body pn">
                    <div class="">
                        <div class="list-com" id="list-com">
                            <div class="col-sm-12 com-detail hidden-xs">
                                <div class="col-sm-6">Leave Type</div>
                                <div class="col-sm-2 col-xs-4">Allotted Leave</div>
                                <div class="col-sm-2 col-xs-4">Used</div>
                                <div class="col-sm-2 col-xs-4">Remaining</div>
                            </div>
                            <?php
                            foreach ($allotedLeaves as $key => $allotedLeave) {
                                $vacationTitle = Core_Models_Utility::toUpper(Leave_Models_Leave::getLeaveType($key));
                                if (isset($usedLeaves[$key])) {
                                    $valueUsed[$key] = array_sum($usedLeaves[$key]);
                                    $leftLeave = intval($allotedLeave) - intval($valueUsed[$key]);
                                } else {
                                    $valueUsed[$key] = 0;
                                    $leftLeave = $allotedLeave;
                                }
                                ?>
                                <div class="col-sm-12 com-detail pt5 pb5">
                                    <div class="col-sm-6 text-left"><strong><?php echo $vacationTitle; ?></strong></div>
                                    <div class="clearfix visible-xs pb5"></div>
                                    <div class="visible-xs col-xs-5">Allotted Leave</div>
                                    <div class="visible-xs col-xs-3">Used</div>
                                    <div class="visible-xs col-xs-4">Remaining</div>
                                    <div class="clearfix visible-xs"></div>
                                    <div class="col-sm-2 col-xs-5"><?php echo $allotedLeave; ?></div>
                                    <div class="col-sm-2 col-xs-3"><?php echo $valueUsed[$key]; ?></div>
                                    <div class="col-sm-2 col-xs-4"><?php echo!empty($leftLeave) ? $leftLeave : 'No Leave'; ?></div>
                                    <div class="clearfix"></div>
                                </div>
                                <?php
                            }
                            ?>
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>
</section>