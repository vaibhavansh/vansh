<?php foreach ($leaves as $leavess) { ?>
    <div id="editObject<?php echo $leavess->id ?>ResultDiv"></div>
    <div id="editObject1<?php echo $leavess->id ?>ResultDiv"></div>

    <div class="container">
        <h2>User Leaves Details</h2>
        <div class="panel panel-default" style="width: 807px;">
            <div class="panel-heading"> <?php echo $leavess->username; ?></div>
            <div class="panel-body">

                <div class="col-lg-6">                      
                    <div class="form-group">
                        <label for="leavetype">Leave Type:</label> :  <?php echo $leavess->leaveType; ?>            
                    </div>
                    <div class="form-group">
                        <label for="startdate">Start Date:</label> :  <?php echo $leavess->startdate; ?>  
                    </div>
                    <div class="form-group">
                        <label for="enddate">End Date:</label>     :  <?php echo $leavess->enddate; ?>  
                    </div>
                    <div class="form-group">
                        <label for="enddate">Duration:</label>      :  <?php echo $leavess->duration; ?> 
                    </div>
                    <div class="form-group">
                        <label for="enddate">Cause:</label>         :  <?php echo $leavess->cause; ?> 
                    </div>   
                    <div class="form-group"><label for="enddate">Status:</label> 
                        <?php
                        if ($leavess->status == 0) {
                            echo '<span class="label label-warning">Pending</span>';
                        } else {
                            if ($leavess->status == 1) {
                                echo '<span class="label label-success">Accepted</span>';
                            } else {
                                echo '<span class="label label-important" style="background-color: #ff0000;">Rejected</span>';
                            }
                        }
                        ?>
                    </div>
                </div>
                <div class="col-lg-2">

                    <form class="form-horizontal" id="editObject<?php echo $leavess->id ?>" action="/leaveApporvePopUp" method="POST" keepVisible="1" keepResult="1"  rel="ajaxifiedForm">    
                        <input type="hidden" name="leaveId" value="<?php echo $leavess->id ?>"/>
                        <input type="hidden" name="status" value="1"/>
                        <input type="submit" name="submit" value="Approve" class="btn btn-success">
                    </form>
                </div>
                <div class="col-lg-2">
                    <form class="form-horizontal" id="editObject1<?php echo $leavess->id ?>" action="/leaveApporvePopUp" method="POST" keepVisible="1" keepResult="1"  rel="ajaxifiedForm">    
                        <input type="hidden" name="leaveId" value="<?php echo $leavess->id ?>"/>
                        <input type="hidden" name="status" value="2"/>
                        <input type="submit" name="submit" value="Disapprove" class="btn btn-danger">
                    </form>
                </div>

            </div>

        </div>
    </div>
<?php } ?>