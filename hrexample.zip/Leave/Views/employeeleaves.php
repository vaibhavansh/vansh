<div class="monthly" id="leavesCalender"></div>
<script type="text/javascript">
    var sampleEvents = {
        "monthly": [
<?php
$count = 1;
foreach ($leaves as $leave) {
    $colorchange = '303081';
    $newcolor = $colorchange + ($count * 432);
    ?>
                {
                    id: <?php echo $leave->id; ?>,
                    name: "<?php echo User_Models_User::getFullNameById($leave->userId); ?> : <?php echo Leave_Models_Leave::$leaveTypes[$leave->leavetype]; ?>",
                    startdate: "<?php echo $leave->startdate; ?>",
                    enddate: "<?php echo $leave->enddate; ?>",
                    color: "<?php echo '#' . $newcolor; ?>",
                    url: "/editleave/<?php echo $leave->id;?>/view"
                },
    <?php
    $count++;
}
?>
                        ]
                    };
                    $(document).ready(function () {
                        $('#leavesCalender').monthly({
                            mode: 'event',
                            dataType: 'json',
                            events: sampleEvents
                        });
                    });
</script>