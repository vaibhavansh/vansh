<div id="modal-form" class="admin-form mfp-with-anim">
    <div class="panel">
        <div id="editObject<?php echo $object->id ?>ResultDiv"></div>
        <form name ="editObject<?php echo $object->id ?>" id="editObject<?php echo $object->id ?>" method="post"
              keepVisible="1" keepResult="1" action="/<?php echo $object->coreURL ?>/save" rel="ajaxifiedForm">
            <input type="hidden" name="id" value="<?php echo $object->id ?>"/>
            <div class="panel-heading">
                <span class="panel-title">
                    <i class="fa fa-pencil"></i><?php echo $header ?></span><div class="clearfix"></div>
            </div>
            <div class="panel-body p25 ">
                <div class="section row">
                    <div class="col-md-12">
                        <label class="col-md-3 control-label">Title</label>
                        <div class="col-md-8">         
                            <input type="textbox" name="title" id="layoutItemTitle" class="gui-input form-control" value="<?php echo $object->title ?>"/>
                        </div>               
                    </div>                
                </div>
                <div class="section row">
                    <div class="col-md-12">
                        <label class="col-md-3 control-label">Slug (must be unique)</label>
                        <div class="col-md-8">         
                            <input type="textbox" name="slug" id="slug" class="gui-input form-control" value="<?php echo $object->slug ?>"/>
                        </div>               
                    </div>                
                </div>
                <div class="section row">
                    <div class="col-md-12">
                        <label class="col-md-3 control-label">Description</label>
                        <div class="col-md-8">         
                            <textarea name="description" id="description" class="gui-input form-control"><?php echo $object->description ?></textarea>
                        </div>               
                    </div>                
                </div>
                <div class="section row">
                    <div class="col-md-12">
                        <label class="col-md-3 control-label">Parent</label>
                        <div class="col-md-8">         
                            <?php echo $tagSelector->generate(); ?>
                        </div>               
                    </div>                
                </div>
                <div class="section row">
                    <div class="col-md-12">
                        <label class="col-md-3 control-label">Priority</label>
                        <div class="col-md-8">         
                            <?php echo $priority->generate(); ?>
                        </div>               
                    </div>                
                </div>
                <div class="section row">
                    <div class="col-md-12">
                        <label class="col-md-3 control-label">List View</label>
                        <div class="col-md-8">         
                            <input type="textbox" name="list_view" id="list_view" class="gui-input form-control" value="<?php echo $object->list_view; ?>"/>
                        </div>               
                    </div>                
                </div>
                <div class="section row">
                    <div class="col-md-12">
                        <label class="col-md-3 control-label">Edit View</label>
                        <div class="col-md-8">         
                            <input type="textbox" name="edit_view" id="edit_view" class="gui-input form-control" value="<?php echo $object->edit_view; ?>"/>
                        </div>               
                    </div>                
                </div>
                <div class="section row">
                    <div class="col-md-12">
                        <label class="col-md-3 control-label">Create View</label>
                        <div class="col-md-8">         
                            <input type="textbox" name="create_view" id="create_view" class="gui-input form-control" value="<?php echo $object->create_view; ?>"/>
                        </div>               
                    </div>                
                </div>
            </div>
                <div class="section panel-footer mbn">
                    <div class="pull-right">
                        <button type="submit" id="submitButton" rel="submitButton" class="button btn-success col-xs-12 pull-right">Submit</button>
                    </div>
                    <div class="clearfix"></div>
                </div>
        </form>
    </div>
</div>

