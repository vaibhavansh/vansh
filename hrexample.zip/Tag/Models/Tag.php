<?php

class Tag_Models_Tag extends Core_Models_DbTable {

    static $table = 'tags';
    protected $className;
    static $fields = null;

}

