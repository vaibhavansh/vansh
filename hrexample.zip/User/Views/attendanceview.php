<section id="content_wrapper">
    <!-- Begin: Content-->
    <section id="content" class="">

        <!-- begin: .tray-center-->
        <div id="animation-switcher" class="tray-center col-md-12 col-sm-12 no-pad">
            <div class="col-sm-12 col-xs-12 changeclass">
                <?php if (!empty($attendanceUserId)) { ?>
                    <?php User_Controllers_UsersController::userProfileMenus($attendanceUserId); ?>
                <?php } ?>
                <div class="clearfix"></div>
                <div id="view_profile" name="view_profile">
                    <div class="panel mb25 mtn">
                        <div class="panel-heading"><span class="panel-title"> <i class="fa fa-th-list"></i><?php echo $fullname; ?> Attendance List </span><div class="clearfix"></div>
                        </div>
                        <div class="panel-menu admin-form theme-primary p5 pbn">
                            <div class="row">
                                <form resultDiv='mainContent' name="searchDates" id="searchDates" method="post" class="form-inline col-xs-12 pln pb5" keepVisible="1" keepResult="1" action="/attendanceview/<?php echo $attendanceUserId; ?>" rel="ajaxifiedForm">      
                                    <div class="col-xs-12 prn">
                                        <label for="name" class="field prepend-icon">
                                            <input class="event-name gui-input br-light light mbn search-input" type="text" name="searchTitle" id="searchDate" placeholder="Search By Date" value="<?php echo $searchTitle = ( isset($_POST['searchTitle']) && $_POST['searchTitle'] != '' ) ? $_POST['searchTitle'] : ''; ?>" />
                                            <label for="name" class="field-icon"><i class="fa fa-search"></i></label>
                                            <div class="btn-fix-right">
                                                <button type="submit" class="submit-btn button btn-success pull-left mr5"><i class="fa fa-search hidden-lg"></i><span class="visible-lg">Search</span></button>
                                                <button type="reset" class="reset-btn button btn-danger"><i class="fa fa-refresh hidden-lg"></i><span class="visible-lg">Reset</span></button>    
                                            </div>
                                        </label>
                                    </div>
                                </form>          
                            </div>
                        </div>
                        <div class="panel-body pn task-widget">
                            <div class="">
                                <div class="list-com" id="list-com">
                                    <div class="col-sm-12 com-detail">
                                        <div class="col-sm-2 col-xs-6"><p><strong>Date</strong></p></div>
                                        <div class="col-sm-2 col-xs-6"><p><strong>Check In</strong></p></div>
                                        <div class="col-sm-2 col-xs-6"><p><strong>Check Out</strong></p></div>
                                        <div class="col-sm-2 col-xs-6"><p><strong>IPaddress</strong></p></div>
                                        <div class="col-sm-2 col-xs-6"><p><strong>Status</strong></p></div>
                                        <div class="col-sm-2 col-xs-6"><p><strong>Hours</strong></p></div>
                                        <div class="clearfix"></div>
                                    </div>
                                    <?php
                                    if ($attendance->data) {
                                        foreach ($attendance->data as $key => $userattendances) {
                                            ?>
                                            <div id="section_<?php echo $userattendances->id; ?>" class="col-sm-12 pt10 pb5">
                                                <div class="col-sm-2 col-xs-6 text-left"><p><span class="footable-toggle"></span><?php echo $userattendances->attendance_date_daily; ?></p></div>
                                                <div class="col-sm-2 col-xs-6"><p><?php
                                                        $phpdate = strtotime($userattendances->check_in_time);
                                                        echo date("M j, g:i a", $phpdate);
                                                        ?></p></div>
                                                <div class="clearfix visible-xs"></div>
                                                <div class="col-sm-2 col-xs-6"><p><?php
                                                        if ($userattendances->check_out_time == "0000-00-00 00:00:00") {
                                                            echo "<span style='color:red;'>User is not checked out</span>";
                                                        } else {
                                                            $phpdate = strtotime($userattendances->check_out_time);
                                                            echo date("M j, g:i a", $phpdate);
                                                        }
                                                        ?></p></div>   
                                                <div class="col-sm-2 col-xs-6"><p><?php echo $userattendances->ip_address; ?></p></div>  
                                                <div class="clearfix visible-xs"></div>
                                                <div class="col-sm-2 col-xs-6"><p><?php echo $userattendances->attendence_status; ?></p></div>  
                                                <div class="col-sm-2 col-xs-6"><p>                                              
                                                        <?php
                                                        $checkin = $userattendances->check_in_time;
                                                        $checkout = $userattendances->check_out_time;
                                                        $datetime1 = new DateTime($checkin);
                                                        $datetime2 = new DateTime($checkout);


                                                        $interval = $datetime1->diff($datetime2);
                                                        if ($userattendances->check_out_time == "0000-00-00 00:00:00") {
                                                            echo "<span style='color:red;'>User is not checked out</span>";
                                                        } else {
                                                            echo $interval->format('%h') . " Hrs " . $interval->format('%i') . " Min";
                                                        }
                                                        ?></p>
                                                </div> 
                                                <div class="clearfix"></div>
                                            </div>
                                            <?php
                                        }
                                    } else {
                                        ?>
                                        <div class="col-sm-12">
                                            <div class="col-sm-12">Record not found</div>
                                        </div>

                                    <?php } ?>
                                    <div class="col-sm-12">
                                        <div class="pull-left">
                                            <h5><?php echo $attendance->getCurrentPageInfo(); ?></h5>
                                        </div>
                                        <div class="pull-right" >
                                            <?php echo $attendance->printPageNumbers(array('url' => "/attendanceview/" . $attendanceUserId, 'div_id' => 'mainContent', 'ajaxRequest' => true)); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>            
                        </div>
                    </div>
                </div>
            </div>  
        </div>
    </section>
</section>

<script type="text/javascript">
    $('#searchDate').datepicker({dateFormat: "yy-mm-dd"});
</script>
<script>
    $(".reset-btn").click(function () {
        $(this).parents("form").find(".search-input").val("");
        $(this).parents("form").find(".submit-btn").click();
    });
</script>

