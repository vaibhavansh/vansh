<?php
global $page;
if ($page->currentUser->userLoggedIn) {
    $userId = $page->currentUser->id;
    $username = $page->currentUser->username;
}
?>
    <!-- Begin: Content-->
<section class="">
    <!-- Begin .page-heading-->
    <div id="animation-switcher">
        <div class="page-heading">
            <div class="media clearfix">
                <div class="media-left pr30"><a href="/viewprofile/<?php echo $userId; ?>/userprofileupload" rel="popUpBox"><img height="150" width="150" src="<?php  if($usersdetails->image){ echo $usersdetails->image; }else{ echo  '/img/avatars1.jpg' ;}?>" alt="/img/avatars1.jpg" class="media-object mw150 emp-img"></a></div>
                <div class="media-body va-m">
                    <h2 class="media-heading"><?php echo $page->currentUser->name . ' ' . $page->currentUser->lastname; ?><small> - Profile  <a href="/viewprofile/<?php echo $userId; ?>/userprofileupload" rel="popUpBox"><i class="fa fa-pencil"></i></a></small></h2>

                     <p class="lead"><?php if($usersdetails->tagline){ echo $usersdetails->tagline; } else {  echo "Please Enter Your Tagline...";} ?><a href="/viewprofile/<?php echo $userId; ?>/tagline" rel="popUpBox"><i class="fa fa-pencil"></i></a></p>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="panel">
                    <div class="panel-heading"><span class="panel-icon"><i class="fa fa-pencil"></i></span><span class="panel-title">About Me</span></div>
                    <div class="panel-body pb5">
                        <?php
                        foreach ($userProfileOptions as $userProfileOption) {
                            $userProfileOptionId[] = $userProfileOption->user_option_id;
                            ?>
                            <h3><?php echo $userProfileOption->title; ?><span> 
                                    <a href="/user_users/editusersection/<?php echo $userProfileOption->user_option_id; ?>" rel="popUpBox" class="pull-right btn btn-danger popup" data-effect="mfp-flipInY" oncloseFunction="reloadDiv('viewprofile', 'mainContent', 'ajax');"><i class="fa fa-pencil"></i>
                                    </a>
                                </span>
                            </h3>
                            <?php
                            $userProilekesys = array_shift(json_decode($userProfileOption->value, 1));
                            $custom_fields = array_shift(json_decode($userProfileOption->custom_fields, 1));
                            $title_collection = array();
                            foreach ($custom_fields['fields'] as $singlefield) {
                                $title_collection[$singlefield['key']] = $singlefield['title'];
                                $field_collection[$singlefield['key']] = $singlefield['fieldType'];
                                $key_collection[$singlefield['key']] = $singlefield['key'];
                            }
                            foreach ($userProilekesys['fields'] as $key => $userProfile) {
                                if (!empty($userProfile)) {
                                    if (isset($field_collection[$key]) && $field_collection[$key] == 'file') {?>
                                        <a href="<?php echo $userProfile; ?>" target="_blank"><?php echo $title_collection[$key]; ?></a><br/><?php
                                    } else {

                                        foreach($userProfile as $userprofilekeys => $userprofilevalues){
                                            $count = 0;
                                            foreach ($custom_fields['fields'] as $singlefield) 
                                            {
                                                $count =  $count+1;
                                                if($singlefield['key'] == $userprofilekeys)
                                                {
                                                    if($count == 1){
                                                        echo "<h4>". $userProfile[$userprofilekeys]."</h4>";
                                                    }else{
                                                        echo $singlefield['title'] .':'.  $userProfile[$userprofilekeys]."<br>";
                                                    }  
                                                }              
                                            } 
                                        }    
                                    }
                                }
                            }
                            echo '<div class="clearfix"></div>';
                            echo '<hr class="short br-lighter">';
                        }
                        echo '<div class="clearfix"></div>';
                        foreach ($userOptionsEmpties as $userOptionsEmpty) {
                            if (!in_array($userOptionsEmpty->user_option_id, $userProfileOptionId)) {
                                ?>
                                <h3><?php echo $userOptionsEmpty->title; ?><span> 
                                        <a href="/user_users/editusersection/<?php echo $userOptionsEmpty->user_option_id; ?>" rel="popUpBox" class="pull-right btn btn-danger popup" data-effect="mfp-flipInY" oncloseFunction="reloadDiv('viewprofile', 'mainContent', 'ajax');"><i class="fa fa-pencil"></i>
                                        </a>
                                    </span>
                                </h3>
                                <?php
                                echo '<div class="clearfix"></div>';
                                echo '<hr class="short br-lighter">';
                            }
                        }
                        echo '<div class="clearfix"></div>';
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>
</section>
