<?php
global $page;
if ($page->currentUser->userLoggedIn) {
    $userId = $page->currentUser->id;
    $username = $page->currentUser->username;
}
?> 
<script type="text/javascript">
    function add_more_section(input) {
        $('#addmoresection_' + input).append('<h4>Section: New Section</h4>');
        $('#add_more_' + input).clone(true).appendTo($('#addmoresection_' + input)).find('input.event-name').val('');
        $('#addmoresection_' + input + ' #add_more_' + input + ' #remove_button').show();

        $('#addmoresection_' + input + ' #add_more_' + input).find('input.from_date').removeClass('hasMonthpicker').removeAttr('id').monthpicker({
            changeYear: true,
            dateFormat: 'yy-mm'
        });
        $('#addmoresection_' + input + ' #add_more_' + input).find('input.to_date').removeClass('hasMonthpicker').removeAttr('id').monthpickerr({
            changeYear: true,
            dateFormat: 'yy-mm'
        });
    }
    $(document).ready(function () {
        $('body').on('focus', '.from_date', function () {
            $(this).monthpicker({
                changeYear: true,
                dateFormat: 'yy-mm'
            });
        });
        $('body').on('focus', '.to_date', function () {
            $(this).monthpicker({
                changeYear: true,
                dateFormat: 'yy-mm'
            });
        });
    });
</script>
<section id="content_wrapper">
    <!-- Begin: Content-->
    <section id="content" class="">
        <!-- Content Header-->
        <div class="content-header">
            <h2><b class="text-default">Welcome To Bezoar Team</b></h2>
            <p class="lead">Complete The Form Below To Gain Instant Access...</p>
        </div>
        <div class="mw1000 center-block">
            <!-- Form Wizard-->
            <div class="admin-form" id="formsholder">
                <div class="wizard steps-bg clearfix steps-tabs steps-justified">
                    <?php
                    if (!empty($userGroups)) {
                        foreach ($userGroups as $userGroup) {
                            ?>
                            <!-- Wizard step 1-->
                            <div id="form-wizard_<?php echo $userGroup->id ?>ResultDiv" class="resultDiv"></div>
                            <h4 id="wizardTitle<?php echo $userGroup->child_group_id; ?>" class="wizard-section-title"><i class="fa fa-user pr5"></i><?php echo $userGroup->group_title; ?></h4>
                            <section class="wizard-section">
                                <form id="form-wizard_<?php echo $userGroup->id ?>" successMsg="Data Saved Successfully." class="form-wizard" method="post" action="/user_users/saveUserData/<?php echo $userId; ?>/<?php echo $userGroup->id; ?>"  rel='ajaxifiedForm' keepVisible="1" keep_visible="1" >
                                    <input type="hidden" name="username" value="<?php echo $username; ?>">
                                    <input type="hidden" id="childGroupId" value="<?php echo $userGroup->child_group_id; ?>">
                                    <div id="add_more_<?php echo $userGroup->id; ?>" class="section row mb5 add_more_<?php echo $userGroup->id; ?>">
                                        <?php
                                        if (!empty($userFields)) {
                                            $count = 1;
                                            $multivalgroup = 0;
                                            foreach ($userFields as $userField) {
                                                if ($userField->group_id == $userGroup->id) {
                                                    if ($userField->fieldType == 'OptionBox') {
                                                        if (!empty($userField->option_data)) {
                                                            list( $optionsBoxData, $optionBoxKeys) = explode(':', $userField->option_data);
                                                            $fieldOptions['optionBoxData'] = array_combine(explode(',', $optionBoxKeys), explode(',', $optionsBoxData));
                                                        }
                                                        $fieldOptions['defaultValue'] = isset($userField->default_val) ? array($userField->default_val) : array();
                                                        $fieldOptions['className'] = isset($userField->className) ? $userField->className : 'form-control'; #using isset, as it could be blank.
                                                        $fieldOptions['multiSelect'] = $userField->multi_select;
                                                        $fieldOptions['name'] = "data_array[{$userField->id}][data][]";
                                                        $fieldOptions['forceDropDown'] = 1;
                                                        $fieldOptions['id'] = '';
                                                        $fieldOptions['noneOption'] = 1;
                                                        $fieldOptions['noneOptionText'] = isset($userField->default_val) ? $userField->default_val : '';
                                                        $valueField = new $userField->fieldType($fieldOptions);
                                                        ?>
                                                        <div class="col-sm-6 col-xs-12 mb15">
                                                            <label for="<?php echo $userField->field_key; ?>" class="field select">
                                                                <?php echo $valueField->generate(); ?>
                                                                <i class="arrow"></i>
                                                            </label>
                                                        </div>
                                                        <?php
                                                    } else if ($userField->fieldType == 'Textarea') {
                                                        ?>
                                                        <div class="col-sm-6 col-xs-12 mb15">
                                                            <label for="<?php echo $userField->field_key; ?>" class="field prepend-icon">
                                                                <textarea class="<?php echo $userField->className; ?>" placeholder="<?php echo $userField->field_title; ?>" name="data_array[<?php echo $userField->id; ?>][data][]" type="<?php echo $userField->fieldType; ?>" id="<?php echo $userField->field_key; ?>"></textarea>
                                                                <label for="<?php echo $userField->field_key; ?>" class="field-icon">
                                                                    <i class="<?php echo $userField->divclassName ?>"></i>
                                                                </label>
                                                            </label>
                                                        </div>
                                                        <?php
                                                    } else if ($userField->fieldType == 'file') {
                                                        ?>
                                                        <input type="hidden" name="field[<?php echo $userField->id; ?>][field_key][]" value="<?php echo $userField->field_key; ?>">
                                                        <div class="col-sm-6 col-xs-12 mb20">
                                                            <label class="p10"><?php echo $userField->title; ?></label>
                                                            <label for="<?php echo $userField->field_key; ?>" class="field file"><span class="button btn-primary"> Choose File</span>
                                                                <input id="<?php echo $userField->field_key; ?>" type="<?php echo $userField->fieldType; ?>" 
                                                                       name="data_array[<?php echo $userField->id; ?>][data][]" 
                                                                       onchange="document.getElementById('uploader<?php echo $userField->field_key; ?>').value = this.value;" class="<?php echo $userField->className; ?>">
                                                                <input id="uploader<?php echo $userField->field_key; ?>" type="text" placeholder="<?php echo $userField->field_title; ?>" readonly class="gui-input">
                                                            </label>
                                                        </div>
                                                        <?php
                                                    } else {
                                                        ?>
                                                        <div class="col-sm-6 col-xs-12 mb15">
                                                            <label for="<?php echo $userField->field_key; ?>" class="field prepend-icon">
                                                                <input id="<?php echo $userField->field_key; ?>" type="<?php echo $userField->fieldType; ?>" name="data_array[<?php echo $userField->id; ?>][data][]" placeholder="<?php echo $userField->field_title; ?>" class="<?php echo $userField->className; ?>">
                                                                <label for="<?php echo $userField->field_key; ?>" class="field-icon">
                                                                    <i class="<?php echo $userField->divClassName ?>"></i>
                                                                </label>
                                                            </label>
                                                        </div>
                                                        <?php
                                                    }
                                                    ?>
                                                    <input type="hidden" name="data_array[<?php echo $userField->id; ?>][id][]" value="<?php echo isset($userField->userDataId) ? $userField->userDataId : ''; ?>">
                                                    <input type="hidden" name="data_array[<?php echo $userField->id; ?>][group_id][]" value="<?php echo $userField->group_id; ?>">
                                                    <input type="hidden" name="data_array[<?php echo $userField->id; ?>][field_id][]" value="<?php echo $userField->id; ?>">
                                                    <input type="hidden" name="data_array[<?php echo $userField->id; ?>][form_id][]" value="<?php echo $userGroup->form_id ?>">
                                                    <input type="hidden" name="data_array[<?php echo $userField->id; ?>][user_id][]" value="<?php echo $page->currentUser->id; ?>">
                                                    <input type="hidden" name="data_array[<?php echo $userField->id; ?>][modified_date][]" value="<?php echo date('Y-m-d'); ?>">
                                                    <input type="hidden" name="data_array[<?php echo $userField->id; ?>][registration][]" value="1">
                                                    <?php
                                                    if ($count % 2 == 0) {
                                                        echo '<div class="clearfix"></div>';
                                                    }
                                                    $count++;
                                                }
                                            }
                                        }
                                        ?>
                                        <a style="display:none;" id="remove_button" href="javascript:void(0)" onclick="$(this).parents('.add_more_<?php echo $userGroup->id; ?>').prev('h4').remove();
                                                        $(this).parents('.add_more_<?php echo $userGroup->id; ?>').remove();" class="btn btn-sm btn-danger pull-right">Remove</a>
                                    </div>
                                    <div id="childGroupDiv"></div>
                                    <div id="appendAddMore">
                                        <?php if ($userGroup->add_more_group == 1) {
                                            ?>
                                            <div id="addmoresection_<?php echo $userGroup->id; ?>"></div>
                                            <div class="col-xs-12 mb15">
                                                <input type="button" class="button btn-danger pull-right" onclick="add_more_section('<?php echo $userGroup->id; ?>')" value="Add More <?php echo $userGroup->group_title; ?>" />
                                            </div>
                                        <?php }
                                        ?>
                                    </div>
                                </form>
                            </section>
                            <script type = "text/javascript">
                                $(document).ready(function () {
                                    var form<?php echo $userGroup->id; ?> = $("#form-wizard_<?php echo $userGroup->id ?>");
                                    form<?php echo $userGroup->id ?>.validate({
                                        errorPlacement: function errorPlacement(error, element) {
                                            element.before(error);
                                        },
                                        rules: {
                                            confirm: {
                                                equalTo: "#password"
                                            }
                                        }
                                    });
                                });
                            </script>
                            <?php
                        }
                    }
                    ?>
                </div>
                <script type="text/javascript">
                    $(document).ready(function () {
                        $('body').removeClass('external-page');
                        $('body').addClass('sb-l-c no-side-bar');
                        $('#formsholder').children(".wizard").steps({
                            headerTag: ".wizard-section-title",
                            bodyTag: ".wizard-section",
                            onInit: function (event, current) {
                                $('.actions > ul > li:first-child').attr('style', 'display:none');
                            },
                            onStepChanging: function (event, currentIndex, newIndex) {
                                $('.actions > ul > li:first-child').attr('style', 'display:none');
                                var form = $('.wizard-section.current form');
                                form.validate().settings.ignore = ":disabled,:hidden";
                                if (form.valid()) {
                                    return form.submit();
                                } else {
                                    return false;
                                }
                            },
                            onFinishing: function (event, currentIndex) {
                                $('.actions > ul > li:first-child').attr('style', 'display:none');
                                var form = $('.wizard-section.current form');
                                form.validate().settings.ignore = ":disabled,:hidden";
                                form.valid();
                                return form.submit();
                            },
                            onFinished: function (event, currentIndex) {
                                $('.actions > ul > li:first-child').attr('style', 'display:none');
                                $.post('/user_users/toggleStatus/User_Models_User/<?php echo $userId; ?>/1',
                                        function (data) {
                                            if (data.match("Successfully")) {
                                                setTimeout(function () {
                                                    window.location = ('/dashboard/');
                                                }, 500);
                                            }
                                        }
                                );
                            }
                        });
                        var Finishform = $('#formsholder form').last();
                        $('<input type="hidden" value="yes" name="lastform" >').appendTo(Finishform);
                        // Demo Wizard Functionality
                        var formWizard = $('.wizard');
                        var formSteps = formWizard.find('.steps');
                        $('.wizard-options .holder-style').on('click', function (e) {
                            e.preventDefault();
                            var stepStyle = $(this).data('steps-style');
                            var stepRight = $('.holder-style[data-steps-style="steps-right"]');
                            var stepLeft = $('.holder-style[data-steps-style="steps-left"]');
                            var stepJustified = $('.holder-style[data-steps-style="steps-justified"]');
                            if (stepStyle === "steps-left") {
                                stepRight.removeClass('holder-active');
                                stepJustified.removeClass('holder-active');
                                formWizard.removeClass('steps-right steps-justified');
                            }
                            if (stepStyle === "steps-right") {
                                stepLeft.removeClass('holder-active');
                                stepJustified.removeClass('holder-active');
                                formWizard.removeClass('steps-left steps-justified');
                            }
                            if (stepStyle === "steps-justified") {
                                stepLeft.removeClass('holder-active');
                                stepRight.removeClass('holder-active');
                                formWizard.removeClass('steps-left steps-right');
                            }
                            // Assign new style
                            if ($(this).hasClass('holder-active')) {
                                formWizard.removeClass(stepStyle);
                            } else {
                                formWizard.addClass(stepStyle);
                            }
                            // Assign new active holder
                            $(this).toggleClass('holder-active');
                        });
                        // select dropdowns - placeholder like creation
                        var selectList = $('.admin-form select');
                        selectList.each(function (i, e) {
                            $(e).on('change', function () {
                                if ($(e).val() == "0")
                                    $(e).addClass("empty");
                                else
                                    $(e).removeClass("empty")
                            });
                        });
                        selectList.each(function (i, e) {
                            $(e).change();
                        });
                        $('form[rel=ajaxifiedForm]').makeFormAjaxified();
                    });
                </script>
            </div>
        </div>
    </section>
</section>
