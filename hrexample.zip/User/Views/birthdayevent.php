<?php
// birthday show before three days
if (!empty($birthdaylists)) {
    ?>
    <div class="panel panel-alt">
        <div class="panel-heading"><span class="panel-title"><i class="fa fa-birthday-cake"></i> Upcoming Birthday</span>
            <div class="panel-btns pull-right ml10"></div>
        </div>
        <?php
        foreach ($birthdaylists as $birthdaylist) {
            $list = explode("_", $birthdaylist);
            ?>

            <div class="panel-body">
                <h2 class="mt-0"><?php echo ucfirst($list[1]); ?></h2>
                <span>
        <?php Core_Models_Utility::printFormatedDates(array('startDate' => $list[0], 'endDate' => $list[0])); ?> 
                </span>
            </div>
    <?php } ?>
    </div>
<?php } ?>