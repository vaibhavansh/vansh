<?php
global $page;
if ($page->currentUser->userLoggedIn) {
    $webUserRole = $page->currentUser->webUserRole;
}
?>
<div id="tagline<?php echo $user->id; ?>ResultDiv" class="resultDiv"></div>
<div class="clearfix"></div>
<?php if ($webUserRole == 2 && !empty($user->id)) { ?>
    <span class="mrn">
        <a href="/listusers" rel="ajaxRequest" class="pull-btn btn btn-info light ml10"> Back to Employees</span></a>
    </span>
<?php } ?>
<div class="col-sm-12 mt20">
    <div class="media clearfix">
        <span class="media-left pr30 col-lg-2 col-sm-3">
            <img src="<?php echo!empty($user->image) ? '/images/' . $user->image . '_thumb.jpg' : '/img/avatars1.jpg'; ?>" alt="<?php echo $user->fullName; ?>" class="media-object mw150">
            <?php if ($page->currentUser->id === $user->id) { ?>
                <div class="btn-group mt15">
                    <a href="/user_users/userprofileupload/" rel="popUpBox" class="pull-btn btn btn-info"><i class="fa fa-pencil"></i> Edit Image</a>
                </div>
            <?php } ?>
        </span>
        <span class="media-right va-m col-lg-10 col-sm-9 col-xs-12">
            <h2 class="media-right pn"><?php echo $user->name . ' ' . $user->lastname; ?></h2>
            <div class="clearfix"></div>
            <?php if ($page->currentUser->id === $user->id) { ?>
                <form id="tagline<?php echo $user->id; ?>" method="POST" keepvisible="1" role="form" action="/user_users/saveProfile/<?php echo $user->id; ?>" rel="ajaxifiedFormHR" autocomplete="off" successMsg="Project Save Successfully!">
                    <div class="editablebox col-sm-12 pn">  <span class="editableedit btn-info btn"><i class="fa fa-pencil"></i></span>
                    <?php } ?>                           
                    <?php if ($user->tagline) { ?>
                        <input name="tagline" type="text" class="contenteditable lead" value="<?php echo $user->tagline; ?>" readonly="true"/> 
                    <?php } else { ?>
                        <input name="tagline" type="text" class="contenteditable lead" value="<?php echo "No Tagline"; ?>" readonly="true"/> 
                    <?php } ?>
                    <button type="submit" class="editablesave btn-success btn">save</button>
                </div>    
            </form> 
        </span>                 
        <div class="clearfix mb15"></div>
    </div>
</div>
<div id="pageRequestTab" class="col-sm-12">
    <span class="mrn">
        <a href="/user_users/viewprofile/<?php echo $userId; ?>/" rel="partialPageRequest" div_name="view_profile" class="pull-btn btn btn-info"><span class="fa fa-user visible-xs"></span><span class="hidden-xs"> View Profile</span></a>
    </span>
    <span class="mrn">
        <a href="/form_forms/viewsubmittedform/<?php echo $userId; ?>/" rel="partialPageRequest" div_name="view_profile" class="pull-btn btn btn-warning"><span class="fa fa-file visible-xs"></span><span class="hidden-xs"> Submitted Form</span></a>
    </span>
    <span class="mrn">
        <a href="/leave_leaves/leaveview/<?php echo $userId; ?>/" rel="partialPageRequest" div_name="view_profile" class="pull-btn btn btn-success"><span class="fa fa-rocket visible-xs"></span><span class="hidden-xs"> Leaves</span></a>
    </span>
    <?php if ($page->currentUser->id == $userId) { ?>
        <span class="mrn">
            <a href="/password_passwords/viewpasswords/<?php echo $userId; ?>/" rel="partialPageRequest" div_name="view_profile" class="pull-btn btn btn-default"><span class="fa fa-lock visible-xs"></span><span class="hidden-xs"> Passwords</span></a>
        </span>
    <?php } else {
        ?>
        <span class="mrn">
            <a href="/password_passwords/employeesharedpasswords/<?php echo $userId; ?>/" rel="partialPageRequest" div_name="view_profile" class="pull-btn btn btn-default"><span class="fa fa-lock visible-xs"></span><span class="hidden-xs"> Passwords</span></a>
        </span>
    <?php } ?>
    <span class="mrn">
        <a href="attendanceview/<?php echo $userId; ?>/" rel="partialPageRequest" div_name="view_profile" class="pull-btn btn btn-dark"><span class="fa fa-bell visible-xs"></span><span class="hidden-xs"> Attendance</span></a>
    </span>
</div>