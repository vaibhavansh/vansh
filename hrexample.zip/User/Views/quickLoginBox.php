<?php global $page; ?>
<?php if (empty($page->currentUser->userLoggedIn)) { ?>
    <div class="spacer10"></div>
    <form name ="loginForm" id="loginForm" method="post" keepVisible="1" action="/user_users/authenticate" rel="ajaxifiedForm" class="form-inline">
        <input class="required " type="text" name="userName" placeholder="UserName/Email" />
        <input class="required" type="password" name="password" placeholder="Password"/>
        <button type="submit" class="btn">Sign in</button>
        <input  type="hidden" name="redirectTo" value="<?php echo $redirectTo; ?>" />

        <a href="/user_users/edit/0" rel="popUpBox" >Register Here</a> |
        <a href="/user_users/forgotPasswordForm/" rel="popUpBox" >Forgot password</a>
    </form><?php } else { ?>
    <h4>Welcome <?php echo $page->currentUser->name; ?> || <a href="/user_users/logout/">Logout</a></h4>


<?php }
?>
