<?php
global $page;
if ($page->currentUser->userLoggedIn) {
    $webUserRole = $page->currentUser->webUserRole;
}
?> 
<style>
    .select2-selection__clear{
        display:none;
    }
</style>
<script>

</script>
<section class="">
    <div id="saveEmployeeResultDiv" class="resultDiv"></div>
    <!-- begin: .tray-center-->
    <div id="animation-switcher" class="tray-center main-div p5">
        <!-- recent orders table-->

        <div class="panel mb25 mt5">
            <div class="panel-heading"><span class="panel-title"> <i class="fa fa-th-list"></i> Employees List</span>
                <span class="pull-right fix-right">
                    <div class="btn-group">
                        <button type="button" class="btn btn-default light div-slider visible-lg"><i class="fa"></i></button>
                    </div>
                    <div class="btn-group">
                        <a href="/user_users/editprofile/edit"  rel="popUpBox"  class="btn btn-default light hidden-lg"><i class="fa fa-plus"></i></a>
                    </div>
                </span><div class="clearfix"></div>
            </div>
            <div class="panel-menu admin-form theme-primary p5 pbn">
                <div class="row">
                    <form resultDiv='mainContent' name="searchUsers" id="searchUsers" method="post" class="form-inline col-xs-12 pln pb5" keepVisible="1" keepResult="1" action="/listusers/" rel="ajaxifiedForm">      
                        <div class="col-xs-12 prn">
                            <label for="name" class="field prepend-icon">
                                <input class="event-name gui-input br-light light mbn search-input" type="text" name="searchTitle" placeholder="Search" value="<?php echo $searchTitle = ( isset($_POST['searchTitle']) && $_POST['searchTitle'] != '' ) ? $_POST['searchTitle'] : ''; ?>" />
                                <label for="name" class="field-icon"><i class="fa fa-search"></i></label>
                                <div class="btn-fix-right">
                                    <button type="submit" class="submit-btn button btn-success pull-left mr5"><i class="fa fa-search hidden-lg"></i><span class="visible-lg">Search</span></button>
                                    <button type="reset" class="reset-btn button btn-danger"><i class="fa fa-refresh hidden-lg"></i><span class="visible-lg">Reset</span></button>    
                                </div>
                            </label>
                        </div>
                    </form>
                </div>
            </div>
            <div class="panel-body pn">
                <div class="list-com" id="list-com">
                    <div class="no-tpad upperCase">
                        <div class="panel-body pn">
                            <div class="com-detail ">
                                <div class="col-lg-2 col-md-1 hidden-sm hidden-xs">
                                    <p><strong>Avatar</strong></p>
                                </div>
                                <div class="col-lg-4 col-md-5 col-sm-4 col-xs-12 ">
                                    <p><strong>Details</strong></p>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-8 hidden-xs no-pad ">
                                    <div class="col-md-4 col-sm-4 pn">
                                        <p class="text-right"> <strong>Certificate</strong></p>
                                    </div>
                                    <div class="col-md-8 col-sm-8 pln text-right">
                                        <div class="col-sm-6">
                                            <p><strong>Action</strong></p>
                                        </div>
                                        <div class="col-sm-6">
                                            <p><strong>Status</strong></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                    if (!empty($listUsers->data)) {
                        ?>
                        <?php foreach ($listUsers->data as $listUser) { ?>
                            <div class="list-com-data pn">
                                <div class="panel-body pn">
                                    <div class="com-detail ">
                                        <div class="col-lg-2 col-md-1 hidden-sm hidden-xs p5">
                                            <img src="<?php echo!empty($listUser->image) ? '/images/' . $listUser->image . '_thumb.jpg' : '/img/avatars1.jpg'; ?>" alt="<?php echo $listUser->name; ?>" class="img-responsive ib mr10">
                                        </div>
                                        <div class="col-lg-4 col-md-5 col-sm-4 col-xs-12 pt10">
                                            <p><a href="/viewprofile/<?php echo $listUser->id; ?>" rel="ajaxRequest"><?php echo $listUser->fullName; ?></a></p>
                                            <p><?php echo $listUser->email; ?></p>
                                            <p><?php echo $listUser->username; ?></p>
                                            <p><?php echo!empty($listUser->phoneno) ? $listUser->phoneno : ''; ?></p>
                                        </div>
                                        <?php if ($listUser->id != $page->currentUser->id) { ?>
                                            <div class="col-lg-6 col-md-6 col-sm-8 col-sm-12 pt10 ">
                                                
                                                    <div class="col-md-4 col-sm-4 col-xs-4 no-pad text-right">
                                                        <button type="button" data-toggle="dropdown" aria-expanded="false" class="btn btn-info br2 btn-xs fs12 dropdown-toggle">
                                                            Certificate
                                                            <?php if (!empty($certificates)) { ?>
                                                                <span class="caret ml5"></span>
                                                            <?php } ?>
                                                        </button>
                                                        <?php if (!empty($certificates)) { ?>                                                       
                                                        <ul role="menu" class="dropdown-menu">
                                                            <?php foreach ($certificates as $certificate) { ?>
                                                                <li>
                                                                    <a href="/printcertificates/<?php echo $certificate->id; ?>/<?php echo $listUser->id; ?>" rel="ajaxRequest">
                                                                        <?php echo $certificate->title; ?>
                                                                    </a>
                                                                </li>
                                                            <?php } ?>
                                                        </ul>
                                                         <?php } ?>
                                                    </div>
                                               
                                                <div class="col-md-8 col-sm-8 col-xs-8 pln">
                                                    <div class="col-sm-6 col-xs-6 pln text-right">
                                                        <button type="button" data-toggle="dropdown" aria-expanded="false" class="btn btn-info br2 btn-xs fs12 dropdown-toggle">
                                                            Action<span class="caret ml5"></span>
                                                        </button>
                                                        <ul role="menu" class="dropdown-menu">
                                                            <li><a href="/projecttimereport/0/0/0/<?php echo $listUser->id; ?>" rel="ajaxRequest">Time Report</a></li>
                                                            <li><a href="/attendanceview/<?php echo $listUser->id; ?>" rel="ajaxRequest">Attendance</a></li>
                                                            <li><a href="/leaveview/<?php echo $listUser->id; ?>" rel="ajaxRequest">Leaves</a></li>
                                                            <li><a href="/employeesharedpasswords/<?php echo $listUser->id; ?>" rel="ajaxRequest">Passwords</a></li>
                                                            <li><a href="/viewprofile/<?php echo $listUser->id; ?>" rel="ajaxRequest">View  Profile</a></li>
                                                            <li> <a href="/user_users/editprofile/<?php echo $listUser->id; ?>/"  rel="popUpBox">Edit</a></li>
                                                        </ul>
                                                    </div>
                                                    <div class="col-sm-6 col-xs-6 prn text-right">
                                                        <div class="btn-group text-right">
                                                            <?php
                                                            if ($listUser->status == 1) {
                                                                $class = 'btn-success';
                                                                $active = 'active disabled';
                                                                $activeIn = '';
                                                                $activeSu = '';
                                                            } else
                                                            if ($listUser->status == 2) {
                                                                $class = 'btn-danger';
                                                                $activeIn = 'active disabled';
                                                                $active = '';
                                                                $activeSu = '';
                                                            } else
                                                            if ($listUser->status == 3) {
                                                                $class = 'btn-system';
                                                                $activeSu = 'active disabled';
                                                                $active = '';
                                                                $activeIn = '';
                                                            }
                                                            ?>
                                                            <button type="button" data-toggle="dropdown" aria-expanded="false" class="btn <?php echo $class; ?> br2 btn-xs fs12 dropdown-toggle">
                                                                <?php echo User_Models_User::$employeeActive[$listUser->status]; ?>
                                                                <span class="caret ml5"></span>
                                                            </button>
                                                            <ul role="menu" class="dropdown-menu">
                                                                <li class="<?php echo $activeSu; ?>"><a href="javascript:void(0);" onclick="return toggleStatus('User_Models_User', '<?php echo $listUser->id ?>', '3', 'listusers')">Suspend</a></li>
                                                                <li class="<?php echo $activeIn; ?>"><a href="javascript:void(0);" onclick="return toggleStatus('User_Models_User', '<?php echo $listUser->id ?>', '2', 'listusers')">In Active</a></li>
                                                                <li class="<?php echo $active; ?>"><a href="javascript:void(0);" onclick="return toggleStatus('User_Models_User', '<?php echo $listUser->id ?>', '1', 'listusers')">Active</a></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php } ?>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        <div class="list-com-data pn">
                            <div class="panel-body pn">
                                <div class="com-detail ">
                                    <div class="col-xs-12 pt5">
                                        <div class="pull-left">                             
                                            <h5><?php echo $listUsers->getCurrentPageInfo(); ?></h5>
                                        </div>
                                        <div class="pull-right" >   
                                            <?php echo $listUsers->printPageNumbers(array('url' => "/listusers", 'div_id' => 'mainContent', 'ajaxRequest' => true)); ?>
                                        </div>
                                    </div>
                                </div> 
                            </div>
                        </div>
                    <?php } else {
                        ?>
                        <div class="panel-heading">
                            <span class="panel-title">Records Not Found</span>
                            <div class="clearfix"></div>
                        </div>
                    <?php }
                    ?>
                </div>
            </div>
        </div>
        <div class="clearfix"></div>
        <span class="sliding-div">
            <div class="btn-group">
              <button type="button" class="light div-slider-box visible-lg"><i class="fa fa-sign-out"></i></button>
            </div>
        </span>
    </div>
    <?php if (($webUserRole == 2) && !empty($addform)) { ?>
        <!--Right Side Column-->
        <aside data-tray-height="match" class="tray tray-center side-div p5">
            <?php echo $addform; ?>
            <?php echo $viewSubmittedFormWidget; ?>
        </aside>  
        <!--Right Side Column Ends-->
    <?php }
    ?>  
    <div class="clearfix"></div>
</section>
<script>
$(".reset-btn").click(function(){
  $(this).parents("form").find(".search-input").val("");
  $(this).parents("form").find(".submit-btn").click();
});
</script>
