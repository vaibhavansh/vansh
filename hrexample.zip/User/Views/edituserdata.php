<?php
global $page;
if ($page->currentUser->userLoggedIn) {
    $userId = $page->currentUser->id;
    $username = $page->currentUser->username;
}
?>
<script type="text/javascript">
    function edit_more_section(input) {
        $('#editmoresection_' + input).append('<h4>Section: New Section</h4>');
        $('#edit_more_group').clone(true).appendTo($('#editmoresection_' + input)).show().find('input.event-name').val('');
        $('#editmoresection_' + input + ' #edit_more_group #remove_button').show();
        $('#editmoresection_' + input + ' #edit_more_group').find('input.from_date').removeClass('hasMonthpicker').removeAttr('id').monthpicker({
            changeYear: true,
            dateFormat: 'yy-mm',
            onSelect: function (selected) {
                var dt = new Date(selected);
                dt.setMonth(dt.getMonth());
                $('#editmoresection_' + input + ' #edit_more_group input.to_date').monthpicker("option", "minDate", dt);
            }
        });
        $('#editmoresection_' + input + ' #edit_more_group').find('input.to_date').removeClass('hasMonthpicker').removeAttr('id').monthpicker({
            changeYear: true,
            dateFormat: 'yy-mm',
            onSelect: function (selected) {
                var dt = new Date(selected);
                dt.setMonth(dt.getMonth());
                $('#editmoresection_' + input + ' #edit_more_group input.from_date').monthpicker("option", "minDate", dt);
            }
        });
    }

    function child_edit_more_section(input, input_group) {
        $('#editmoresection_' + input_group).append('<h4>Section: New Section</h4>');
        $('#childeditmoresection_' + input).clone(true).appendTo($('#editmoresection_' + input_group)).show().find('input.event-name').val('');
        $('#editmoresection_' + input_group + ' #childeditmoresection_' + input).find('input.from_date').removeClass('hasMonthpicker').removeAttr('id').monthpicker({
            changeYear: true,
            dateFormat: 'yy-mm',
            onSelect: function (selected) {
                var dt = new Date(selected);
                dt.setMonth(dt.getMonth());
                $('#editmoresection_' + input_group + ' #childeditmoresection_' + input + ' input.to_date').monthpicker("option", "minDate", dt);
            }
        });
        $('#editmoresection_' + input_group + ' #childeditmoresection_' + input).find('input.to_date').removeClass('hasMonthpicker').removeAttr('id').monthpicker({
            changeYear: true,
            dateFormat: 'yy-mm',
            onSelect: function (selected) {
                var dt = new Date(selected);
                dt.setMonth(dt.getMonth());
                $('#editmoresection_' + input_group + ' #childeditmoresection_' + input + ' input.from_date').monthpicker("option", "minDate", dt);
            }
        });
    }

    function add_file_section(inputfile) {
        $('#add_file_section' + inputfile).clone(true).appendTo($('#reuploaddoc')).show();
    }

    $(document).ready(function () {
        var hasGroupId = $('form input#getGroupId').val();
        var hasFieldId = $('input.showId').val();
        var hasChildGroupId = $('form input#getChildGroupId').val();
        if (hasFieldId === '' || hasFieldId === undefined) {
            $('#edit_more_group').clone(true).appendTo($('#editmoresection_' + hasGroupId)).show().find('input.event-name').val('');
            $('#childeditmoresection_' + hasChildGroupId).clone(true).appendTo($('#editmoresection_' + hasGroupId)).show().find('input.event-name').val('');
        }
        $('input.showId').remove();
        $('#sectionId input.from_date').monthpicker({
            changeYear: true,
            dateFormat: 'yy-mm',
            onSelect: function (selected) {
                var dt = new Date(selected);
                dt.setMonth(dt.getMonth());
                $('#sectionId input.to_date').monthpicker("option", "minDate", dt);
            }
        });
        $('#sectionId input.to_date').monthpicker({
            changeYear: true,
            dateFormat: 'yy-mm',
            onSelect: function (selected) {
                var dt = new Date(selected);
                dt.setMonth(dt.getMonth());
                $('#sectionId input.from_date').monthpicker("option", "minDate", dt);
            }
        });
    });
</script>
<div id="modal-form" class="mfp-with-anim">
    <?php if (!empty($dashboardGroup)) { ?>
        <div class="panel panel-success">
            <div id="edit_user_data_<?php echo $dashboardGroup->id ?>ResultDiv" class="resultDiv"></div>
            <form close_popup="1" keep_visible="1" keepVisible="1" role="form" successMsg="Data Saved Successfully." name="edit_user_data_<?php echo $dashboardGroup->id ?>" resultDiv="edit_user_data_<?php echo $dashboardGroup->id ?>ResultDiv" id="edit_user_data_<?php echo $dashboardGroup->id ?>" method="post" action="/user_users/saveuserdata/<?php echo $userId; ?>/<?php echo $dashboardGroup->id; ?>"  rel='ajaxifiedFormHR' autocomplete="off">
                <input type="hidden" name="metakeytitle" value="<?php echo $dashboardGroup->group_title; ?>">
                <input type="hidden" name="username" value="<?php echo $username; ?>">
                <input type="hidden" id="getGroupId" value="<?php echo $dashboardGroup->id; ?>">
                <input type="hidden" id="getChildGroupId" value="<?php echo $dashboardGroup->child_group_id; ?>">
                <div class="panel-heading">
                    <span class="panel-title">
                        <i class="fa fa-pencil"></i>
                        <?php echo $dashboardGroup->group_title; ?>
                        <!--<input onclick="$('.popUpDiv').overlay().close();" type="button" value="Close" class="button btn-danger hidden-xs pull-right">-->
                    </span>
                    <div class="clearfix"></div>
                </div>
                <div class="panel-body p25 admin-form ">
                    <div id="sectionId" class="section row mb5">
                        <?php
                        if (!empty($userDatas)) {
                            $count = 1;
                            $multivalgroup = '';
                            foreach ($userDatas as $userData) {
                                $userDataId[$userData->field_id] = $userData->id;
                                ?>
                                <input type="hidden" class="showId" value="<?php echo $userData->id; ?>">
                                <div id="multi_<?php echo $userData->multi_val_group; ?>" class="multi_<?php echo $userData->multi_val_group; ?>">
                                    <?php
                                    if ($multivalgroup != $userData->multi_val_group) {
                                        $multivalgroup = $userData->multi_val_group;
                                        ?>
                                        <a href="javascript:void(0)" onclick="removedMultiVal('<?php echo $userData->group_id; ?>', '<?php echo $userData->multi_val_group; ?>')" class="btn btn-sm btn-danger pull-right">Remove</a>
                                        <div class="clearfix mb15"></div>
                                    <?php }
                                    ?>
                                    <div class="col-sm-6 col-xs-12 mb15">
                                        <?php
                                        if ($userData->fieldType == 'OptionBox') {
                                            if (!empty($userData->option_data)) {
                                                list( $optionsBoxData, $optionBoxKeys) = explode(':', $userData->option_data);
                                                $fieldOptions['optionBoxData'] = array_combine(explode(',', $optionBoxKeys), explode(',', $optionsBoxData));
                                            }
                                            $fieldOptions['defaultValue'] = isset($userData->data) ? array($userData->data) : array();
                                            $fieldOptions['className'] = isset($userData->className) ? $userData->className : 'form-control'; #using isset, as it could be blank.
                                            $fieldOptions['multiSelect'] = $userData->multi_select;
                                            $fieldOptions['name'] = "data_array[{$userData->field_id}][data][]";
                                            $fieldOptions['forceDropDown'] = 1;
                                            $fieldOptions['noneOption'] = 1;
                                            $fieldOptions['noneOptionText'] = isset($userData->default_val) ? $userData->default_val : '';
                                            $valueField = new $userData->fieldType($fieldOptions);
                                            ?>
                                            <label for="<?php echo $userData->field_key; ?>" class="field select">
                                                <?php echo $valueField->generate(); ?>
                                                <i class="arrow"></i>
                                            </label>
                                            <?php
                                        } else if ($userData->fieldType == 'Textarea') {
                                            ?>
                                            <label for="<?php echo $userData->field_key; ?>" class="field prepend-icon">
                                                <textarea class="<?php echo $userData->className; ?>" placeholder="<?php echo $userData->field_title; ?>" name="data_array[<?php echo $userData->field_id; ?>][data][]" type="<?php echo $userData->fieldType; ?>" id="<?php echo $userData->field_key; ?>"><?php echo $userData->data; ?></textarea>
                                                <label for="<?php echo $userData->field_key; ?>" class="field-icon">
                                                    <i class="<?php echo $userData->divclassName ?>"></i>
                                                </label>
                                            </label>
                                            <?php
                                        } else if ($userData->fieldType == 'file') {
                                            ?>
                                            <input type="hidden" name="field[<?php echo $userData->field_id; ?>][field_key][]" value="<?php echo $userData->field_key; ?>">
                                            <?php if (!empty($userData->data)) { ?>
                                                <label class="p10"><strong><?php echo $userData->field_title; ?></strong></label>
                                                <div class="clearfix"></div>
                                                <input type="hidden" name="data_array[<?php echo $userData->field_id; ?>][data][]" value="<?php echo $userData->data; ?>">
                                                <div class="clearfix"></div>
                                                <label class="p10">You have already uploaded <?php echo $userData->field_title; ?>. <a href='#' onclick="add_file_section('<?php echo $userData->field_id; ?>')"> Upload <?php echo $userData->field_title; ?> again</a>?</label>
                                                <div id="reuploaddoc"></div>
                                            <?php } else { ?>
                                                <label for="<?php echo $userData->field_key; ?>" class="field file"><span class="button btn-primary"> Choose File</span>
                                                    <input id="<?php echo $userData->field_key; ?>" type="<?php echo $userData->fieldType; ?>" 
                                                           name="data_array[<?php echo $userData->field_id; ?>][data][]" 
                                                           onchange="document.getElementById('uploader<?php echo $userData->field_key; ?>').value = this.value;" class="<?php echo $userData->className; ?>">
                                                    <input id="uploader<?php echo $userData->field_key; ?>" type="text" placeholder="<?php echo $userData->field_title; ?>" readonly class="<?php echo $userData->divClassName; ?>">
                                                </label><br />
                                                <?php
                                            }
                                        } else {
                                            ?>
                                            <label for="<?php echo $userData->field_key; ?>" class="field prepend-icon">
                                                <input id="<?php echo $userData->field_key; ?>" type="<?php echo $userData->fieldType; ?>" name="data_array[<?php echo $userData->field_id; ?>][data][]" placeholder="<?php echo $userData->field_title; ?>" class="<?php echo $userData->className; ?>" value="<?php echo $userData->data; ?>">
                                                <label for="<?php echo $userData->field_key; ?>" class="field-icon">
                                                    <i class="<?php echo $userData->divClassName ?>"></i>
                                                </label>
                                            </label>
                                        <?php }
                                        ?>
                                        <input type="hidden" name="data_array[<?php echo $userData->field_id; ?>][id][]" value="<?php echo $userData->id; ?>">
                                        <input type="hidden" name="data_array[<?php echo $userData->field_id; ?>][group_id][]" value="<?php echo $userData->group_id; ?>">
                                        <input type="hidden" name="data_array[<?php echo $userData->field_id; ?>][field_id][]" value="<?php echo $userData->field_id; ?>">
                                        <input type="hidden" name="data_array[<?php echo $userData->field_id; ?>][form_id][]" value="<?php echo $userData->form_id ?>">
                                        <input type="hidden" name="data_array[<?php echo $userData->field_id; ?>][user_id][]" value="<?php echo $page->currentUser->id; ?>">
                                        <input type="hidden" name="data_array[<?php echo $userData->field_id; ?>][modified_date][]" value="<?php echo date('Y-m-d'); ?>">
                                        <input type="hidden" name="data_array[<?php echo $userData->field_id; ?>][multi_val_group][]" value="<?php echo $userData->multi_val_group; ?>">
                                        <div class="clearfix"></div>
                                    </div>
                                </div>
                                <?php
                                if ($count % 2 == 0) {
                                    echo '<div class="clearfix"></div>';
                                }
                                $count++;
                                ?>
                                <?php
                            }
                        }
                        ?>
                        <div id="editmoresection_<?php echo $dashboardGroup->id; ?>"></div>
                    </div>
                </div>
                <div class="panel-footer bg-wild-sand admin-form">
                    <div class="col-sm-6 mb15">
                        <?php if ($dashboardGroup->add_more_group == 1) {
                            ?>
                            <input type="button" class="button btn-warning" onclick="edit_more_section('<?php echo $dashboardGroup->id; ?>')" value="Add More <?php echo $dashboardGroup->group_title; ?>" />
                        <?php } else if ($dashboardGroup->getChildIdData() == 1) {
                            ?>
                            <input type="button" class="button btn-warning" onclick="child_edit_more_section('<?php echo $dashboardGroup->child_group_id; ?>', '<?php echo $dashboardGroup->id; ?>')" value="Add More <?php echo $dashboardGroup->group_title; ?>" />
                        <?php }
                        ?>
                    </div>
                    <div class="section col-sm-6 mb15">
                        <div class="pull-right">                            
                            <input type="submit" id="submit" value="Save <?php echo $dashboardGroup->group_title; ?>" class="button btn-success">
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </form>
            <?php
            if (!empty($userFields)) {
                $count = 1;
                ?>
                <div id ="edit_more_group" class="edit_more_group" style="display:none;"> 
                    <?php
                    foreach ($userFields as $userField) {
                        if ($userField->fieldType == 'OptionBox') {
                            if (!empty($userField->option_data)) {
                                list( $optionsBoxData, $optionBoxKeys) = explode(':', $userField->option_data);
                                $fieldOptions['optionBoxData'] = array_combine(explode(',', $optionBoxKeys), explode(',', $optionsBoxData));
                            }
                            $fieldOptions['defaultValue'] = array();
                            $fieldOptions['className'] = isset($userField->className) ? $userField->className : 'form-control'; #using isset, as it could be blank.
                            $fieldOptions['multiSelect'] = $userField->multi_select;
                            $fieldOptions['name'] = "data_array[{$userField->id}][data][]";
                            $fieldOptions['forceDropDown'] = 1;
                            $fieldOptions['noneOption'] = 1;
                            $fieldOptions['noneOptionText'] = isset($userField->default_val) ? $userField->default_val : '';
                            $valueField = new $userField->fieldType($fieldOptions);
                            ?>
                            <div class="col-sm-6 col-xs-12 mb15">
                                <label for="<?php echo $userField->field_key; ?>" class="field select">
                                    <?php echo $valueField->generate(); ?>
                                    <i class="arrow"></i>
                                </label>
                            </div>
                            <?php
                        } else if ($userField->fieldType == 'Textarea') {
                            ?>
                            <div class="col-sm-6 col-xs-12 mb15">
                                <label for="<?php echo $userField->field_key; ?>" class="field prepend-icon">
                                    <textarea class="<?php echo $userField->className; ?>" placeholder="<?php echo $userField->field_title; ?>" name="data_array[<?php echo $userField->id; ?>][data][]" type="<?php echo $userField->fieldType; ?>" id="<?php echo $userField->field_key; ?>"></textarea>
                                    <label for="<?php echo $userField->field_key; ?>" class="field-icon">
                                        <i class="<?php echo $userField->divclassName ?>"></i>
                                    </label>
                                </label>
                            </div>
                            <?php
                        } else if ($userField->fieldType == 'file') {
                            ?>
                            <input type="hidden" name="field[<?php echo $userField->id; ?>][field_key][]" value="<?php echo $userField->field_key; ?>">
                            <input type="hidden" name="data_array[<?php echo $userField->id; ?>][data][]" value="<?php echo $userField->data; ?>">
                            <div class="col-sm-6 col-xs-12 mb20">
                                <div id="add_file_section<?php echo $userField->id; ?>">
                                    <label class="p10"><?php echo $userField->title; ?></label>
                                    <label for="<?php echo $userField->field_key; ?>" class="field file"><span class="button btn-primary"> Choose File</span>
                                        <input id="<?php echo $userField->field_key; ?>" type="<?php echo $userField->fieldType; ?>" 
                                               name="data_array[<?php echo $userField->id; ?>][data][]" 
                                               onchange="document.getElementById('uploader<?php echo $userField->field_key; ?>').value = this.value;" class="<?php echo $userField->className; ?>">
                                        <input id="uploader<?php echo $userField->field_key; ?>" type="text" placeholder="<?php echo $userField->field_title; ?>" readonly class="<?php echo $userField->divClassName; ?>">
                                    </label>
                                </div>
                            </div>
                            <?php
                        } else {
                            ?>
                            <div class="col-sm-6 col-xs-12 mb15">
                                <label for="<?php echo $userField->field_key; ?>" class="field prepend-icon">
                                    <input id="<?php echo $userField->field_key; ?>" type="<?php echo $userField->fieldType; ?>" name="data_array[<?php echo $userField->id; ?>][data][]" placeholder="<?php echo $userField->field_title; ?>" class="<?php echo $userField->className; ?>">
                                    <label for="<?php echo $userField->field_key; ?>" class="field-icon">
                                        <i class="<?php echo $userField->divClassName ?>"></i>
                                    </label>
                                </label>
                            </div>
                        <?php }
                        ?>
                        <input type="hidden" name="data_array[<?php echo $userField->id; ?>][group_id][]" value="<?php echo $userField->group_id; ?>">
                        <input type="hidden" name="data_array[<?php echo $userField->id; ?>][field_id][]" value="<?php echo $userField->id; ?>">
                        <input type="hidden" name="data_array[<?php echo $userField->id; ?>][form_id][]" value="<?php echo $dashboardGroup->form_id ?>">
                        <input type="hidden" name="data_array[<?php echo $userField->id; ?>][user_id][]" value="<?php echo $page->currentUser->id; ?>">
                        <input type="hidden" name="data_array[<?php echo $userField->id; ?>][modified_date][]" value="<?php echo date('Y-m-d'); ?>">
                        <?php
                        if ($count % 2 == 0) {
                            echo '<div class="clearfix"></div>';
                        }
                        $count++;
                    }
                    ?>
                    <a style="display:none;" id="remove_button" href="javascript:void(0)" onclick="$(this).parents('.edit_more_group').prev('h4').remove();
                                    $(this).parents('.edit_more_group').remove();" class="btn btn-sm btn-danger pull-right">Remove</a>
                    <div class="clearfix mb15"></div>
                </div>
            <?php } else { ?>
                <div class="col-md-12">
                    <h4>No Data Found For This Group.</h4>
                </div>  
            <?php } ?>
            <div id="childeditmoresection_<?php echo $dashboardGroup->child_group_id; ?>" class="childeditmoresection" style="display:none;">
                <?php echo $dashboardGroup->getChildIdAddMoreData(); ?>
            </div>
            <?php
        }
        ?>
    </div>
    <script type="text/javascript">
        function removedMultiVal(group_id, value) {
            var msg = 'Are you sure to delete.\nThis will delete this content';
            if (confirm(msg)) {
                if (value !== undefined) {
                    $.post('/deleteDashboardForms/0/0/0/' + value + '/', {
                        group_id: group_id,
                        pageRequestType: 'ajax'
                    }, function (data) {
                        if (data.indexOf('Delete Success') !== -1) {
                            $(".multi_" + value).remove();
                        }
                    });
                }
            }
        }
    </script>
</div>