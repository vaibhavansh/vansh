<?php
global $page;
if ($page->currentUser->userLoggedIn) {
    $userid = $page->currentUser->id;
}
?> 
<div id="modal-form" class=" mfp-with-anim">
    <div class="panel">
        <div id="dropboxcredentialsResultDiv" class="ResultDiv"></div>
        <div class="panel-heading"><span class="panel-title"><i class="fa fa-pencil hidden-xs"></i>Dropbox Credentials</span></div>
        <form class="admin-form" method="POST" resultDiv="dropboxcredentialsResultDiv" id="dropboxcredentials" close_popup="1" keepvisible="1" role="form" action="/dropboxcredentialsave/" rel="ajaxifiedForm" autocomplete="off" backToPage="" successMsg="Credentials Save/Edit Successfully!">
            <input type="hidden" name="user_form_type" value="dropbox_credentials">
            <input type="hidden" name="id" value="<?php echo $dropboxcredentials->id; ?>">   
            <div class="panel-body p25">
                <div class="col-md-12">
                    <label for="dropboxcredentials" class="field ">
                        <input type="text" class="event-name gui-input br-light light"  name="dropboxcredentials" value="<?php
                        if ($dropboxcredentials->dropbox_token) {
                            echo $dropboxcredentials->dropbox_token;
                        }
                        ?>" placeholder="<?php echo "Enter Dropbox App Key"; ?>">
                    </label>
                    
                </div> 
            </div>
            <div class="panel-footer">
                <button type="submit" class="button btn-success pull-right">Save</button>
                <div class="clearfix"></div>
            </div>
        </form>
    </div>
</div>
