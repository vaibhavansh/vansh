<script>
    function claimyourlink() {
        var link = '<?php echo $link; ?>';
        var userId = '<?php echo $user->id ?>';
        $('#resultDiv').html(loadingDivHTML());
        $.ajax({
            type: 'POST',
            url: '/user_users/claimyourlink/',
            data: {link: link, userId: userId}
        }).done(function(data) {
            $('#resultDiv').append("<div class='alert alert-success notice-pos alert-dismissible'><strong>Success!</strong> Notification Settings Saved Successful.<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>");
            setTimeout(function() {
                $('.notice-pos').remove();
                // reloadData();
            }, 5000);
        });
    }
</script>

<?php
global $page;
if ($page->currentUser->userLoggedIn) {
    $userId = $page->currentUser->id;
    $username = $page->currentUser->username;
}
?> 

<div class="clearfix spacer20"></div>
<div class="row">
    <div class="">
        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6"><strong>Welcome <?php echo $user->username; ?></strong></div>
        <div class="col-lg-4 col-md-4 hidden-sm hidden-xs"></div>
        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 text-right"><?php
            date_default_timezone_set('America/Chicago');
            $date = getdate();
            echo $date['weekday'] . ", " . $date['month'] . " " . $date['mday'] . ", " . $date['year'];
            ?></div>
    </div>
</div>
<div class="row">
    <div class="">
 


        <div class="col-lg-9 col-md-9 col-sm-12" id="content_pan">
            <div class="col-lg-12 col-md-12 col-sm-12 no-pad">
                <div class="page-header">
                    <h1 class="mag-color">My Profile</h1>
                </div>
                <div class="text-right"><a class="btn btn-success" rel='ajaxRequest' href="/user_users/userdashboardcustomfields/<?php echo $user->id; ?>/1/edit" >Add Your Details</a></div>
                <div class="clearfix"></div>
            </div>
            <div class="clearfix"></div>
          <div class="clearfix"></div>
          <div class="form-group"> 
                    <?php
                    foreach ($MagazineUserOptions as $MagazineUserOption) {
                        ?>
                        <div class="panel panel-danger border-1" style="position:relative;">
                            <?php
                            // echo $MagazineUserOption->title;
                            $magazineCustomFields = json_decode($MagazineUserOption->custom_fields);
                            $user_options = json_decode($MagazineUserOption->value);
                            foreach ($magazineCustomFields as $key => $magazineCustomField) {
                                if (isset($user_options->{'custom_' . $key . '_view'})) {
                                    if (1 == $user_options->{'custom_' . $key . '_view'}->value) {
                                        ?>  
                                        <div class="panel-heading">
                                            <h3 class="panel-title"><strong> <?php echo $MagazineUserOption->title; ?></strong></h3>
                                        </div>
                                        <div class="text-right"><a  class="btn btn-info"  rel='ajaxRequest' href="/user_users/userdashboardcustomfields/<?php echo $user->id; ?>/<?php echo $MagazineUserOption->mag_user_option_id; ?>/edit" >Edit</a></div>

                    <!--                                    <div class="panel-heading"><h5><?php echo $magazineCustomField->title; ?> </h5></div>-->
                                        <div class="panel-body">
                                            <?php
                                            if (!empty($magazineCustomField->add_more_group)) {
                                                foreach ($magazineCustomField->fields as $magazineFields) {
                                                    ?>
                                                    <div class="col-sm-12">
                                                        <?php
                                                        $AddmoreuserOptions = array();
                                                        foreach ($user_options as $useroption) {
                                                            if (isset($useroption->group)) {
                                                                if ($useroption->group == $magazineCustomField->key) {
                                                                    $AddmoreuserOptions[$magazineCustomField->key][$useroption->level][$useroption->field] = $useroption->value;
                                                                }
                                                            }
                                                        }
                                                        ?> </div><?php
                                                }
                                                ?>
                                                <div class="col-sm-12">
                                                    <?php
                                                    if (!empty($AddmoreuserOptions)) {
                                                        $all_levels = count($AddmoreuserOptions[$magazineCustomField->key]);
                                                        ?>
                                                        <div class="table-responsive">
                                                            <table class="table table-bordered">
                                                                <?php
                                                                $count = 0;
                                                                foreach ($AddmoreuserOptions[$magazineCustomField->key] as $levelkey => $addmoreuseroption) {
                                                                    if ($count == 0) {
                                                                        ?><tr><?php
                                                                            foreach (array_keys($addmoreuseroption) as $head) {
                                                                                ?><th><?php echo Core_Models_Utility::toUpper($head); ?></th><?php
                                                                            }
                                                                            ?></tr><?php
                                                                        }
                                                                        ?>
                                                                    <tr id="<?php echo 'entry_' . $levelkey; ?>">
                                                                        <?php
                                                                        foreach ($addmoreuseroption as $leveloptions) {
                                                                            ?> <td><?php echo $leveloptions; ?></td>                                           
                                                                            <?php
                                                                        }
                                                                        ?></tr>
                                                                    <?php
                                                                    $count++;
                                                                }
                                                                ?></table>
                                                        </div>
                                                        <?php
                                                    } else {
                                                        echo 'Please Update Your Details From Dashboard';
                                                    }
                                                    ?></div>
                                                <?php
                                            } else {
                                                foreach ($magazineCustomField->fields as $k => $magazineFields) {
                                                    ?>
                                                    <div>
                                                        <?php
                                                        // Utility::debug($user_options);
                                                        if (isset($user_options->{$magazineFields->key}->value)) {
                                                            if ($magazineFields->fieldType == 'checkbox') {
                                                                echo $magazineFields->title;
                                                            } else {
                                                                echo $magazineFields->title . ' - ' . $user_options->{$magazineFields->key}->value;
                                                            }
                                                        }
                                                        ?></div>
                                                    <?php
                                                }
                                            }
                                            ?></div><div class="clearfix spacer10"></div><?php
                                        }
                                    }
                                }
                                ?></div><?php
                        }
                        ?>
                    
                    
                    <?php if(!empty($getData['contents'])){?>
                     <div class="panel panel-default border-1" style="position:relative;">     
                         <div class="panel-heading">
                                            <h3 class="panel-title"><strong> Upload Documents Here</strong></h3>
                          </div>
                           <div class="pos-r" style="top:10px; right:10px;"><a  rel='ajaxRequest' href="/user_users/userdashboardcustomfields/<?php echo $user->id; ?>/edit" >Edit</a></div>
                          <div class="panel-body">
              <?php  
   foreach ($getData['contents'] as $key => $value) {         
                if (is_array($value)) {            
                 $pieces = explode("/", $value['path']);
                 foreach($pieces as $ss){
                     if(!empty($ss)){ if($ss==$userId.''.$username){ }else{  echo "<li>".$ss."</br>"; }}}
                }              
            } ?>        
            
                     </div>
                     </div>
                    <?php } ?>
            </div>
        </div>
    </div>
</div>

<?php if($MagazineUserOptions){?>
 <div class="checkbox">
     <label><input type="checkbox" id="clickme"> <strong>Please Check If you fill all data.. </strong></label>
    </div>
    <form method="POST" action="http://hr.bezoarsoftware.com/dropboxapi/index.php">
    
    <input type="hidden" name="id" value="<?php echo $userId; ?>">
    <input type="hidden" name="name" value="<?php echo $username; ?>">   
    <input style="display: none;" type="submit" class="btn btn-default show_button" id="user_options_<?php echo $MagazineUserOptions->id ?>" value="Click Here"/>
    
</form>
<?php } ?>

<script>
$( "#clickme" ).click(function() {
  $( ".show_button" ).toggle();
  });

</script>
<div class="clearfix spacer20"></div><div class="clearfix spacer20"></div><div class="clearfix spacer20"></div><div class="clearfix spacer20"></div><div class="clearfix spacer20"></div><div class="clearfix spacer20"></div><div class="clearfix spacer20"></div><div class="clearfix spacer20"></div><div class="clearfix spacer20"></div><div class="clearfix spacer20"></div><div class="clearfix spacer20"></div>
