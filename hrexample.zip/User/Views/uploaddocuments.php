<!-- <div id='edit_section_<?php echo $section->id ?>_form_result' class="resultDiv"></div>
<form keep_visible="1" name='edit_section_<?php echo $section->id ?>' rel='ajaxifiedForm' id = 'edit_section_<?php echo $section->id ?>' enctype='multipart/form-data' method='post' action='/user_users/uploadDocuments/' class="form-horizontal" role="form" onCompleteFunction="Javascript:history.go(-2)">
    <h2> Documents </h2>    
<div class="spacer"></div>
<div id="tkv" name ="tkv" style="display:none" class="form-inline">
    
    <input class=" grid_3 btn" type="button"  onclick="$(this).parent('div [name=tkv]').remove()" value="Remove" />
    <input type="hidden" name="fileid[]" id="fileToUpload" class="grid_8">
    <input type="file" name="fileToUpload[]" multiple="multiple" id="fileToUpload" class="grid_8">
    <div class="spacer10"></div>        
</div>
<div id="assetCustomFields" ><?php 
   foreach ($getData['contents'] as $key => $value) {                
                if (is_array($value)) {
                //echo    $value['path']."<br/>";  
                 $pieces = explode("/87vishal/", $value['path']);
                 foreach($pieces as $ss){
                     if(!empty($ss)){
                     echo "<li>".$ss."</br>";
                 }}
                }              
            } ?>
    <div class="spacer10"></div>
    <input type='button' onclick="$('#tkv').clone(true).insertBefore($(this)).show().removeAttr('id');" value='Add Custom Fields' />
    <div class="spacer10"></div>
    <h4>        
        <button type="submit" class="btn btn-primary">Save</button>
        <button type="button" onclick="Javascript:history.go(-1)" class="btn btn-danger">Cancel</button>
    </h4>
</div>
</form>

 -->

