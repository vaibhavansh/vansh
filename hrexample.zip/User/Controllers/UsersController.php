<?php

class User_Controllers_UsersController extends Core_Controllers_SitesController {

    public function loginForm() {
       global $page;
       $page->currentUser->webUserRole;
        if ($page->currentUser->webUserRole != 4) {
            echo "<script>window.location.href = '" . BASE_PATH_ROOT . "/dashboard';</script>";
            die;
        }
        $this->layoutId = 37;
        $variables = array();
   
        $variables['view'] = 'loginform';
        $page->logToGoogle = true;
        $page->metaKeywords = "employee management, leave management";
        $page->pageTitle = "HR Bezoar: A Powerful Employee Management Tool";
        return $variables;
    }
    
    function hrsite(){
        $this->layoutId = 50;
       return array();
    }
    
    /**
     * DO NOT USE. CHECKIN CHECKOUT CONNECTED TO LOGIN/LOGOUT
     * @global type $page
     * @param type $attendanceId
     * @return type
     */
    public function checkInOut($attendanceId = '') { // This Method Should Move in HR Bezoar Site And Removed attendance()
        global $page;
        $variables = array();
        $variables['attendance'] = $page->currentUser->isCheckedIn();
        if (!empty($_POST['check_in'])) {
            if ($page->currentUser->checkIn()) {
                echo Core_Models_Utility::flashMessage("Check In Successfully");
            }
            return array();
        } else if (!empty($_POST['check_out'])) {
            if ($page->currentUser->checkOut($attendanceId)) {
                echo Core_Models_Utility::flashMessage("Check Out Successfully");
            }
            return array();
        }
        return $variables;
    }

    public function birthdayevent() {
        $variables = array();
        $birthdayevents = User_Models_UserData::find_all(array(
                    'where' => "user_data.group_id = 1 AND field_id in(1,2,5) and user_data.user_id",
                    'join' => "`form_group_fields` on user_data.field_id = form_group_fields.id",
                    'cols' => "form_group_fields.id, form_group_fields.field_title,user_data.user_id, group_concat(user_data.data SEPARATOR ',') as user_data, group_concat(user_data.user_id SEPARATOR ',') as user_id ",
                    'groupBy' => ' user_data.field_id',
                    'orderBy' => ' form_group_fields.id DESC, `user_data`.`data` ASC'));
        if (!empty($birthdayevents)) {
            foreach ($birthdayevents as $birthdayevent) {
                $datebirth[] = $birthdayevent->user_data;
                $userid[] = $birthdayevent->user_id;
            }

            $birthdaye = explode(",", $datebirth[0]);
            $iduser = explode(",", $userid[0]);
            foreach ($birthdaye as $key => $birthdayevent) {
                $user = User_Models_User::getFullNameById($iduser[$key]);
                $bdaylist = $birthdayevent;
                $bday = explode('-', $bdaylist);
                $Month = $bday[1];
                $Day = $bday[2];
                $userdate = trim(date("Y") . "-" . $Month . "-" . $Day);
                $NewDate = trim(date('Y-m-d', strtotime("+3 days")));
                if ($userdate <= $NewDate && $userdate >= date('Y-m-d')) {
                    $birthdaylist[] = $userdate . '_' . $user;
                }
            }
            $variables['birthdaylists'] = !empty($birthdaylist) ? $birthdaylist : '';
        }
        return $variables;
    }

    public function attendanceview($attendanceUserId = '') {
        global $page;
        $tags = func_get_args();
        $variables['pageNumber'] = array_pop($tags);
        if (!(substr($variables['pageNumber'], 0, 5) == 'page_')) {
            $tags[] = $variables['pageNumber'];
            $variables['pageNumber'] = 'page_1';
        }
        $where = '';
        if (isset($_POST['searchTitle'])) {
            $variables['searchTitle'] = (trim(str_replace(array('/', '.'), '', ($_POST['searchTitle']))));
            $where = !empty($_POST['searchTitle']) ? " AND attendances.attendance_date_daily = '" . $variables['searchTitle'] . "'" : "";
        }
        $userId = array_pop($tags);
        if (!empty($userId) && is_numeric($userId)) {
            $variables['userId'] = $userId;
            $variables['fullname'] = User_Models_User::getFullNameById($userId);
        } else {
            $variables['userId'] = $page->currentUser->id;
            $variables['fullname'] = $page->currentUser->name . ' ' . $page->currentUser->lastname;
        }

        $variables['attendance'] = User_Models_Attendance::getPaginatedData(array('where' => "attendances.employee_ID = " . $variables['userId'] . $where,
                    'pageNumber' => $variables['pageNumber'],
                    'orderBy' => "id desc"
        ));
        $variables['attendanceUserId'] = $userId;
        return $variables;
    }

    public function addendanceviewsingle($attendanceId = '') {
        global $page;
        $variables = array();
        if (!empty($attendanceId)) {
            $variables['singleattendance'] = array_shift(User_Models_Attendance::find_all(array(
                        'where' => "attendances.id = {$attendanceId}",
                        'join' => "users on users.id = attendances.employee_ID ",
                        'cols' => "attendances.*, concat(name,' ' ,lastName) as fullName"
            )));
        }
        return $variables;
    }

    function deleteRow($tableClass, $id, $resourceId = '') {

        if (!empty($tableClass) && !empty($id)) {
            $content = new $tableClass($id);

            if (empty($resourceId)) {
                if ($content->delete()) {
                    $variables['result'] = 'Delete Success';
                } else {
                    $variables['result'] = 'Delete Fail';
                }
            } else {
                if ($content->delete($id)) {
                    $variables['result'] = 'Delete Success';
                } else {
                    $variables['result'] = 'Delete Fail';
                }
            }
            echo $variables['result'];
        }
        return $variables;
    }

    function listUsers() {
        global $page;
        $variables = array();
        $tags = func_get_args();
        $variables['pageNumber'] = array_pop($tags);
        if (!(substr($variables['pageNumber'], 0, 5) == 'page_')) {
            $tags[] = $variables['pageNumber'];
            $variables['pageNumber'] = 'page_1';
        }
        $where = '';
        if (isset($_POST['searchTitle'])) {
            $variables['searchTitle'] = (trim(str_replace(array('/', '.'), '', ($_POST['searchTitle']))));
            $where .= "(users.name like ('%" . $variables['searchTitle'] . "%') OR (users.lastname like ('%" . $variables['searchTitle'] . "%')))";
        }
        $variables['listUsers'] = User_Models_User::getPaginatedData(array(
                    'pageNumber' => $variables['pageNumber'],
                    'where' => $where,
                    'cols' => "users.*, concat(name,' ' ,lastName) as fullName", 'orderBy' => 'id desc'));
        $variables['certificates'] = Asset_Models_Asset::find_all(array('where' => "assets.asset_type_id = 7"));
        $variables['addform'] = Layout_Models_Layout::getWidget('User_Controllers_UsersController', 'editprofile', 'editprofile');
        $variables['viewSubmittedFormWidget'] = Layout_Models_Layout::getWidget('Form_Models_Form', 'listAllUsersSubmittedForm', 'listalluserssubmittedform');
        return $variables;
    }

    function viewProfile($id = '') {
        global $page;
        $variables = array();
        $where = '';
        $userId = !empty($id) ? $id : $page->currentUser->id;
        $where .= "form_groups.form_id = '1'";
        $variables['header'] = 'Personal Info';
        $variables['userGroups'] = Form_Models_FormGroup::find_all(array('where' => $where,
                    'join' => "forms on forms.id = form_groups.form_id",
                    'cols' => 'form_groups.*',
                    'orderBy' => "form_groups.form_id asc,form_groups.group_priority asc"));
        $variables['userFields'] = User_Models_UserData::find_all(array('where' => "user_data.user_id = '{$userId}'",
                    'join' => "form_group_fields on form_group_fields.id = user_data.field_id",
                    'cols' => "user_data.*,form_group_fields.fieldType,form_group_fields.field_key,form_group_fields.field_title",
                    'orderBy' => "user_data.multi_val_group asc",
        ));
        $variables['user'] = new User_Models_User($userId);
        return $variables;
    }

    function dropboxcredentials() {
        $dropboxcredentials = array_shift(User_Models_User::find_all());
        $variables['dropboxcredentials'] = $dropboxcredentials;
        $variables['view'] = 'dropboxcredentials';
        return $variables;
    }

    function editProfile($id, $column = '') {
        global $page;
        $variables = array();

        $userId = !empty($id) ? $id : '';
        if ($userId == "edit") {
            $userId = "";
        }
        $variables['header'] = !empty($column) ? "Edit " . $column : !empty($userId) ? "Edit" : "Add";
        $variables['userdetailcol'] = new User_Models_User($userId);
        $variables['column'] = $column;
        return $variables;
    }

    function userProfileUpload() {
        return array();
    }

    function saveProfile($id) {
        global $page;
        $userId = !empty($id) ? $id : $page->currentUser->id;
        if (!empty($userId)) {
            $userdetails = new User_Models_User($userId);
            if (!empty($_FILES['profileImage']['tmp_name'])) {
                $imageData['image'] = Image_Models_Image::scaleImage($_FILES['profileImage']['tmp_name']);
                $imageData['image_thumb'] = Image_Models_Image::generateThumb($_FILES['profileImage']['tmp_name']);
                $imageData['type'] = 'jpeg';
                $imageData['title'] = $_POST['title'];
                $image = new Image_Models_Image();
                $_POST['image'] = $image->save($imageData);
                $_SESSION['userAuth']['image'] = $_POST['image'];
            }
            $userdetails->save($_POST);
            echo Core_Models_Utility::flashMessage("Your profile updated.", 'valid');
            if ($_FILES) {
                echo '<script type="text/javascript">  setTimeout(function () { history.go(0) }, 100); </script>';
            }
        }
        return array();
    }

    function employee() {
        global $page;
        $this->layoutId = 42;
        $variables = array();
        $group_id = array();
        $tags = func_get_args();
        $slug = array_pop($tags);
        $userguestformshow = array_shift(Form_Models_Form::find_all(array('where' => "link_form = '{$slug}'")));
        $variables['userGroups'] = Form_Models_FormGroup::find_all(array('where' => "form_groups.form_id = '{$userguestformshow->id}'",
                    'orderBy' => "group_priority asc"));
        if (!empty($variables['userGroups'])) {
            foreach ($variables['userGroups'] as $value) {
                $group_id[] = $value->id;
            }
        }
        $groupId = implode(',', $group_id);
        $variables['userFields'] = Form_Models_FormGroupField::find_all(array('where' => "form_group_fields.group_id in ({$groupId})",
                    'orderBy' => "priority ASC,group_id ASC"));
        $variables['view'] = 'registration';
        return $variables;
    }

    function editUserData($group_id, $userId = '') {
        global $page;
        $variables = array();
        if (!empty($userId)) {
            $variables['dashboardGroup'] = array_shift(Form_Models_FormGroup::find_all(array('where' => "id = '{$group_id}'")));
            if (!empty($variables['dashboardGroup'])) {
                $variables['userFields'] = Form_Models_FormGroupField::find_all(array('where' => "form_group_fields.group_id = '{$variables['dashboardGroup']->id}'",
                            'orderBy' => "form_group_fields.priority ASC"));
                $variables['userDatas'] = User_Models_UserData::find_all(array('where' => "user_data.user_id = '{$userId}' and (user_data.group_id = '{$variables['dashboardGroup']->id}' OR form_group_fields.group_id = '{$variables['dashboardGroup']->child_group_id}')",
                            'join' => "form_group_fields on form_group_fields.id = user_data.field_id",
                            'cols' => "user_data.*,form_group_fields.field_title,form_group_fields.field_key,form_group_fields.className,form_group_fields.divClassName,form_group_fields.fieldType,form_group_fields.option_data,form_group_fields.default_val",
                            'orderBy' => 'user_data.multi_val_group asc'));
            }
        }
        return $variables;
    }

    function saveUserData($userId = '', $metaKey = '') {
        global $page;
        if (!empty($_FILES['data_array']['tmp_name'])) {
            if (is_array($_FILES['data_array']['tmp_name'])) {
                $username = $_POST['username'];
                $images = $_FILES['data_array'];
                foreach ($images['tmp_name'] as $key => $file) {
                    foreach ($file['data'] as $keyVal => $value) {
                        $fieldKey = $_POST['field'][$key]['field_key'][$keyVal];
                        $single_images = array();
                        $file_name = time() . $images['name'][$key]['data'][$keyVal];
                        $target_dir = "dropboxapi/user_documents/{$username}/user_upload/";
                        $target_file = $target_dir . $fieldKey . $file_name;
                        if (file_exists($target_file)) {
                            echo Core_Models_Utility::flashMessage("file already exists. Try Again.", 'error');
                            die;
                        }
                        $client = Core_Models_Utility::dropboxApiKeyandToken();
                        $f = fopen($value, "rb");
                        $result = $client->uploadFile("/{$username}/user_upload/{$fieldKey}" . $file_name, Dropbox\WriteMode::add(), $f);

                        if (!is_dir($target_dir) && !mkdir($target_dir)) {
                            die("Error creating folder $target_dir");
                        }
                        if (move_uploaded_file($value, $target_file)) {
                            $_POST['data_array'][$key]['data'][$keyVal] = BASE_PATH_ROOT . '/' . $target_file;
                        }
                        fclose($f);
                    }
                    if (!empty($result)) {
                        
                    } else {
                        Core_Models_Utility::flashMessage('error', 'Some Problems to save data. Try Again');
                        die();
                    }
                }
            }
        }
        if (isset($_POST['data_array']) && !empty($_POST['data_array'])) {
            foreach ($_POST['data_array'] as $PostData) {
                foreach ($PostData['field_id'] as $key => $id) {
                    foreach ($PostData as $datatype => $dataid) {
                        if (is_array($dataid)) {
                            $Post_Datas[$key][$datatype] = $PostData[$datatype][$key];
                            $Post_Datas[$key]['multi_val_group'] = isset($PostData['multi_val_group'][$key]) ? $PostData['multi_val_group'][$key] : $key;
                        }
                    }
                }
                foreach ($Post_Datas as $key => $Post_Data) {
                    if (isset($Post_Data['registration']) && $Post_Data['registration'] == 1) {
                        $RowId = array_shift(User_Models_UserData::find_all(array('where' => "user_data.field_id = '{$Post_Data['field_id']}' and user_data.user_id = '{$Post_Data['user_id']}' and user_data.group_id = '{$Post_Data['group_id']}'")));
                        if (!empty($RowId)) {
                            $RowId = new User_Models_UserData($RowId->id);
                            $Post_Data['id'] = $RowId->id;
                            $postDataId = $RowId->save($Post_Data);
                        } else {
                            $userData = new User_Models_UserData();
                            $userData->save($Post_Data);
                        }
                    } else {
                        if (!empty($Post_Data['id'])) {
                            $RowId = new User_Models_UserData($Post_Data['id']);
                            $postDataId = $RowId->save($Post_Data);
                        } else {
                            $userData = new User_Models_UserData();
                            $userData->save($Post_Data);
                        }
                    }
                }
            }
            if (isset($_POST['nextstep']) && !empty($_POST['nextstep'])) {
                $getNextGroupId = Form_Models_FormGroup::getGroupsByFormId($_POST['sameForm'], $_POST['changeGroup']);
                if (!empty($getNextGroupId->id)) {
                    Form_Controllers_FormsController::informationCollectedForm($_POST['sameForm'], $getNextGroupId->id, $formnext = 1);
                    echo '<script type="text/javascript">reloadDiv("/form_forms/informationcollectedform/' . $_POST['sameForm'] . '/' . $getNextGroupId->id . '/' . $formnext . '", "modal-form", "ajax"); </script>';
                }
            }
            echo json_encode(array('status' => 'success', 'msg' => "Data Saved Successfully"));
        }
        return array();
    }

    function certificateDocuments() {
        global $page;
        $filename = $_POST['filename'];
        $username = $_POST['username'];
        $client = Core_Models_Utility::dropboxApiKeyandToken();
        $f = fopen("dropboxapi/user_documents/{$username}/company_upload/{$filename}.pdf", "rb");
        $result = $client->uploadFile("/{$username}/company_upload/{$filename}", Dropbox\WriteMode::add(), $f);
        fclose($f);
        if (!empty($result)) {
            $targetCertificate = BASE_PATH_ROOT . "/dropboxapi/user_documents/{$username}/company_upload/{$filename}.pdf";
            $certificateField = array_shift(Form_Models_FormGroupField::find_all(array('where' => "form_group_fields.option_data = '{$_POST['fileId']}'",
                        'join' => 'form_groups on form_groups.id = form_group_fields.group_id',
                        'cols' => "form_group_fields.*,form_groups.form_id")));
            $userData = new User_Models_UserData();
            $userData->save(array('user_id' => $_POST['userid'], 'field_id' => $certificateField->id, 'group_id' => $certificateField->group_id, 'form_id' => $certificateField->form_id, 'data' => $targetCertificate, 'multi_val_group' => '0', 'modified_date' => date('Y-m-d')));
        }
        return array();
    }

    function userProfileMenus($userId = '') {
        global $page;
        $userId = (!empty($userId)) ? $userId : $page->currentUser->id;
        $user = new User_Models_User($userId);
        $detect = new Core_Models_MobileDetect;
        if ($detect->isMobile() && !($detect->isTablet())) {
            (file_exists(SITES_MODULE_DIRECTORY . DS . 'User' . DS . 'mobileViews' . DS . 'userprofilemenus.php')) ?
                            include SITES_MODULE_DIRECTORY . DS . 'User' . DS . 'mobileViews' . DS . 'userprofilemenus.php' : include BASE_PATH_ROOT . DS . SITES_MODULE_DIRECTORY . DS . 'User' . DS . 'mobileViews' . DS . 'userprofilemenus.php';
        } else {
            (file_exists(ROOT . DS . 'Modules' . DS . 'User' . DS . 'Views' . DS . 'userprofilemenus.php')) ?
                            include ROOT . DS . 'Modules' . DS . 'User' . DS . 'Views' . DS . 'userprofilemenus.php' : include BASE_PATH_ROOT . DS . 'Modules' . DS . 'User' . DS . 'Views' . DS . 'userprofilemenus.php';
        }
        return TRUE;
    }

    /**
     * Logout the user
     * @global type $page
     */
    function logout() {
        global $page;
        if (($page->currentUser->userLoggedIn)) { //only do this if user is logged in. Just in case
            $remoteAdd = md5($_SERVER['REMOTE_ADDR']);
            $cookieValue = $_COOKIE[$remoteAdd];
            setcookie($remoteAdd, '', time() - 3600, '/');
            setcookie($cookieValue, '', time() - 3600, '/');
            $userAuthNamespace = new Core_Models_SessionNamespace('userAuth');
            unset($userAuthNamespace);
            $page->currentUser->checkOut();
        }
        echo "<script>window.location='/login';</script>";
        return array();
    }

    /**
     * Autheticate the user.
     * @global type $page
     * @return type
     */
    function authenticate() {
        global $page;
        $encryptedPassword = User_Models_User::encryptPassword($_POST['password']);

        $user = array_shift(User_Models_User::find_all(array(
                    'where' => "username = '{$_POST['userName']}' and (password='{$encryptedPassword}' OR temp_pass_form='{$_POST['password']}')")));

        if (!empty($user->id)) {
            if ($user->status == 3) {
                echo Core_Models_Utility::flashMessage("Your Account Has Been Suspended. Please Contact Administration For reactivating your account.<br />Thank You.", 'error');
            } else {
                $user->userLoggedIn = true;
                $remoteAdd = md5($_SERVER['REMOTE_ADDR']);
                $someRandomSecret = md5(Config::getConfig('SOME_SECRET_SALT') . $remoteAdd);
                $usernamemd5 = md5($user->username);
                $sessionSecretValue = md5($remoteAdd . $encryptedPassword . time());
                setcookie($someRandomSecret, $usernamemd5, time() + 36000000, '/');
                setcookie($remoteAdd, $sessionSecretValue, time() + 36000000, '/');
                $defaultSession = new Core_Models_SessionNamespace('userAuth');
                foreach ($user as $key => $value) {
                    $defaultSession->$key = $value;
                }
                $defaultSession->session_secret = $sessionSecretValue;
                $user->save(array('session_secret' => $sessionSecretValue, 'last_logged' => $page->todayDate));
                $page->currentUser = $user;
                echo Core_Models_Utility::flashMessage("Login Successful");
                if ($user->status == 1) {
                    Core_Models_Utility::redirect_to(array('url' => 'dashboard'));
                } else if ($user->status == 2 && $user->webUserRole != '5') {
                    Core_Models_Utility::redirect_to(array('url' => 'employee/registration'));
                } else if ($user->webUserRole == '5') {
                    Core_Models_Utility::redirect_to(array('url' => $_POST['redirectTo']));
                }
                $page->currentUser->checkIn();
            }
        } else {
            $user->userLoggedIn = false;
            echo Core_Models_Utility::flashMessage("Your Username/Password Can Not be Validated.<br />Please try again..", 'error');
            return array();
        }
        return array();
    }

    function save() {
        global $page;
        $mailSent = '';
        switch ($_POST['user_form_type']) {

            case 'dropbox_credentials':  //save dropbox credentioals
                $certificate = !empty($_POST['id']) ? new User_Models_User($_POST['id']) : '';
                $certificate->save(array('dropbox_token' => trim($_POST['dropboxcredentials'])));
                if ($_POST['id']) {
                    echo json_encode(array('status' => 'success', 'msg' => "DropBoxCredentials Update Successfully."));
                } else {
                    echo json_encode(array('status' => 'success', 'msg' => "DropBoxCredentials Save Successfully."));
                }
                break;

            case 'user_details_save':  //  first Registration  
                $client = Core_Models_Utility::dropboxApiKeyandToken();
                $id = !empty($_POST['id']) ? $_POST['id'] : '';
                $fname = !empty($_POST['name']) ? $_POST['name'] : '';
                $lname = !empty($_POST['lastname']) ? $_POST['lastname'] : '';
                $email = !empty($_POST['email']) ? $_POST['email'] : '';
                $phoneno = !empty($_POST['phoneno']) ? $_POST['phoneno'] : '';
                $created = date("Y-m-d");
                $password = !empty($_POST['password']) ? md5($_POST['password']) : '';
                $webUserRole = !empty($_POST['webUserRole']) ? $_POST['webUserRole'] : '';
                $status = !empty($status) ? $status : '2';
                if (empty($webUserRole)) {
                    $webUserRole = 1;
                }
                $firstLetterOfLastname = $lname[0];
                $company = !empty($_POST['company']) ? $_POST['company'] : 'bezoar';
                $newUsername = strtolower($firstLetterOfLastname . '' . $fname . '_' . $company);
                $sendEmailName = strtolower($fname . '.' . $lname);
                $user = !empty($id) ? new User_Models_User($id) : '';
                if (!empty($fname) && !empty($lname) && !empty($email)) {
                    if ($webUserRole != 5 && $_POST['sendMail'] == 0) {
                        $to = $email . ','; // note the comma
                        $to .= HR_EMAIL;
                        $subject = "Hr Bezoar Password";
                        $message = "
                            *------------------------------------------------------------------------*
                            --First Three Password Active with in 24 hours After Your Resgistration--
                            *------------------------------------------------------------------------*

                            * Webmail username password *

                                URL: http://email.1and1.com/
                                username : " . $email . "
                                password : " . $_POST['password'] . "

                            * Skype username Password *
                                username : " . $email . "
                                password : " . $_POST['password'] . "

                            * Trello username Password *
                                URL: https://trello.com
                                username : " . $newUsername . "
                                password : " . $_POST['password'] . "

                            *------------------------------------*
                            --Active this usernane and password-- 
                            *------------------------------------*

                            * Hr Bezoar Login username Password *
                                URL: " . BASE_PATH_ROOT . ";
                                username : " . $newUsername . "
                                password : " . $_POST['password'] . "";

                        $from = DEVELOPER_EMAIL;
                        $headers = "From:" . $from;
                        if (mail($to, $subject, $message, $headers)) {
                            $mailSent = 'Mail Sent';
                        } else {
                            echo Core_Models_Utility::flashMessage("Please Enter Proper Email Address", 'error');
                            return array();
                        }
                    }
                    if (empty($user)) {
                        $checkAvailability = User_Models_User::find_all(array('where' => 'users.username="' . $newUsername . '"'));
                        if (!empty($checkAvailability)) {
                            $newUsername = $newUsername . '' . rand(0, 100);
                            $sendEmailName = strtolower($fname . '.' . $lname . '' . rand(0, 100));
                        }
                        if (!empty($mailSent) || $webUserRole == 5) {
                            $user = new User_Models_User();
                            $user->save(array('name' => $fname, 'lastname' => $lname, 'email' => $email, 'phoneno' => $phoneno, 'username' => $newUsername, 'password' => $password, 'webUserRole' => $webUserRole, 'created' => $created, 'status' => 1, 'send_mail' => 1, 'temp_pass_form' => ''));
                            $create_new_folder = $client->createFolder('/' . $newUsername . '/user_upload', 'dropbox');
                            $create_new_folder = $client->createFolder('/' . $newUsername . '/company_upload', 'dropbox');
                            $user_upload = "dropboxapi/user_documents/" . $newUsername;
                            if (is_dir($newUsername) === false) {
                                mkdir("dropboxapi/user_documents/" . $newUsername);
                                mkdir('dropboxapi/user_documents/' . $newUsername . '/company_upload/');
                                mkdir('dropboxapi/user_documents/' . $newUsername . '/user_upload/');
                            }
                            echo json_encode(array('status' => 'success', 'msg' => "Registration successfully."));
                            die; /* please donot remove die, this is for remove error when new use add by admin "Layout_Models_Layout not found" */
                        }
                    } else {
                        $user->save(array('name' => $fname, 'lastname' => $lname, 'email' => $email, 'phoneno' => $phoneno, 'webUserRole' => $webUserRole, 'status' => $status, 'send_mail' => 1, 'temp_pass_form' => '', 'password' => $password));
                        echo json_encode(array('status' => 'success', 'msg' => "User information updated."));
                        return array();
                    }
                } else {
                    echo json_encode(array('status' => 'unsuccess', 'msg' => "Please Fill Up All Information of Employee."));
                    return array();
                }
                break;
            default:
        }
        return array();
    }

    public function toggleStatus($tableClass, $rowId, $status) {
        global $page;

        if ($page->currentUser->userLoggedIn) {
            $userId = $page->currentUser->id;
        } else {
            echo "<script>window.location.href = '" . BASE_PATH_ROOT . "';</script>";
            die;
        }
        if ('Password_Models_UserPassword' == $tableClass) {
            $password_tags = array_shift(Password_Models_UserPassword::find_all(array('where' => 'id=' . $rowId)));
            $user_id = $password_tags->user_id;
            $password_id = $password_tags->password_id;
            $password_detail = array_shift(Password_Models_Password::getPasswords('id=' . $password_id));
            $password_title = $password_detail->title;
            $html = '';
            if ($status == 2) {
                $html = serialize(array('Password_Models_Password' => $password_id));
            }
            Notification_Models_Notification::AddNotifications($userId, Password_Models_UserPassword::$requestStatus[$status], 'Requested Password ' . $password_title, $user_id, $html);
        } elseif ('Leave_Models_Leave' == $tableClass) {
            $leave = array_shift(Leave_Models_Leave::find_all(array('where' => 'id=' . $rowId)));
            $user_id = $leave->userId;
            Notification_Models_Notification::AddNotifications($userId, (Leave_Models_Leave::$requestLeave[$status]), 'Requested Leave', $user_id, '');
        }
        $tableClass = new $tableClass($rowId);
        if (!empty($status)) {
            $tableClass->save(array('status' => $status));
            echo Core_Models_Utility::flashMessage("Status Changed Successfully");
        }
        return array();
    }

}
