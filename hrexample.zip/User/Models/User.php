<?php

class User_Models_User extends Core_Models_DbTable {

    static $table = 'users';
    static $fields = NULL;
    static $employeeActive = array(
        3 => 'Suspended',
        2 => 'In Active',
        1 => 'Active'
    );

    static function encryptPassword($password) {
        return md5($password);
    }

    /**
     * Check if User is logged in or not.
     * Returns true or false. It also puts the info in the user it's operated, if logged in.
     * @return <type>
     */
    function isLoggedIn() {
        $remoteAdd = md5($_SERVER['REMOTE_ADDR']);
        $someRandomSecret = md5(Config::getConfig('SOME_SECRET_SALT') . $remoteAdd);
        if (isset($_COOKIE[$someRandomSecret])) { //so username is set
            if (isset($_COOKIE[$remoteAdd])) {
                $username = $_COOKIE[$someRandomSecret];
                $sessionSecret = $_COOKIE[$remoteAdd];
                $defaultSession = new Core_Models_SessionNamespace('userAuth');
                if (!empty($defaultSession->username) && !empty($defaultSession->session_secret)) {
                    if (md5($defaultSession->username) == $username && $defaultSession->session_secret == $sessionSecret) {
                        foreach ($defaultSession as $key => $value) {
                            $this->$key = $value;
                        }
                        $this->userLoggedIn = true;
                        return $this->id;
                    } else {
                        return false;
                    }
                } else {
                    return false;
                }
            }
        } else {
            return false;
        }
    }

    function userRole() {
        return new User_Models_UserRole($this->webUserRole);
    }

    function allowed($page) {

        $sitePermissions = User_Models_Permission::find_all(array('where' => "controller='{$page->controller}' and action='{$page->action}' ", 'join' => 'user_roles on permissions.userRoleId = user_roles.id', 'cols' => 'permissions.*,user_roles.level'));
        if (!empty($sitePermissions)) {
            foreach ($sitePermissions as $sitePermission) {
                if ($page->currentUser->userRole->level >= $sitePermission->level) {

                    return true;
                }
            }
            return false;
        } else {
            return true;
        }
        return true;
    }

    public function getnameById($userId) {
        if ($userId != 0) {
            $user = User_Models_User::find_all(array('where' => "id = {$userId}",
                        'cols' => "users.name"));
            $username = array_shift($user);
            return $username->name;
        }
    }

    public function getFullNameById($userId) {
        if ($userId != 0) {
            $user = User_Models_User::find_all(array('where' => "id = {$userId}",
                        'cols' => "users.name,users.lastname"));
//            print_r($user);
            $username = array_shift($user);
            return $username->name . ' ' . $username->lastname;
        }
    }

    public function fullName() {
        return $this->name . ' ' . $this->lastname;
    }

    public function checkOut($id = '') {
        global $page;
        if (!empty($id)) {
            $where = " id = '{$id}' ";
        } else {
            $where = " employee_ID = '{$page->currentUser->id}'";
            $where .= " and check_out_time = '0000-00-00 00:00:00' ";
        }
        return User_Models_Attendance::updateRow($where, array('check_out_time' => date("Y-m-d H:i:s"), 'status' => 2));
    }

    public function checkIn() {
        $ipAddress = $_SERVER['REMOTE_ADDR'];
        $attendance_status = User_Models_Attendance::employeeLocation();
        $addAttendance = new User_Models_Attendance();
        return $addAttendance->save(array('attendance_date_daily' => date('Y-m-d'), 'employee_ID' => $this->id, 'check_in_time' => date("Y-m-d H:i:s"), 'attendence_status' => $attendance_status, 'status' => 1, 'ip_address' => $ipAddress));
    }

    public function isCheckedIn() {
        global $page;
        $where = " employee_ID = '{$page->currentUser->id}'";
        $where .= " and check_out_time = '0000-00-00 00:00:00' ";
        $this->isCheckedIn = array_shift(User_Models_Attendance::find_all(array('where' => $where, 'limit' => 1)));
        return $this->isCheckedIn;
    }

    public function getAllUsers() {
        $getAllUsers = User_Models_User::find_all(array('where' => 'users.webUserRole != 0 and users.webUserRole != 2 and users.status != 2 and users.status != 3',
                    'cols' => "id,concat(name,' ' ,lastName) as fullName"));
        if (!empty($getAllUsers)) {
            foreach ($getAllUsers as $getAllUser) {
                $allUsers[$getAllUser->id] = $getAllUser->fullName;
            }
        }
        return $allUsers;
    }

    function randomPassword() {
        $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
        $pass = array(); //remember to declare $pass as an array
        $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
        for ($i = 0; $i < 8; $i++) {
            $n = rand(0, $alphaLength);
            $pass[] = $alphabet[$n];
        }
        return implode($pass); //turn the array into a string
    }

}
