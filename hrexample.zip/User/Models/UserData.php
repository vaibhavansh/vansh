<?php

class User_Models_UserData extends Core_Models_DbTable {

    var $className = 'UserData';
    static $table = 'user_data';
    static $fields = NULL;

    function getDataByFormId($formId,$userId = '') {
        global $page;
        $userid = !empty($userId) ? $userId : $page->currentUser->id;
        $getDataId = User_Models_UserData::find_all(array('where' => "form_id = '{$formId}' and user_id = '{$userid}'"));
        return $getDataId;
    }

}

?>