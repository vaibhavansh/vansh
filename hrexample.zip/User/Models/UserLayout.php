<?php

class User_Models_UserLayout extends Core_Models_DbTable
{

    static $table = 'user_layouts';

    static $fields = null;


}

