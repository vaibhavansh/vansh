<?php

class User_Models_UserRole extends Core_Models_DbTable {

    static $table = 'user_roles';
    static $fields = NULL;
    static $userRoles = array(
        1 => 'Employee',
        2 => 'Super Admin',
        3 => 'Admin'
    );

}
