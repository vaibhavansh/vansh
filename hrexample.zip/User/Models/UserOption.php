<?php

class User_Models_UserOption extends Core_Models_DbTable {

    static $table = 'user_options';
    static $fields = NULL;
}
?>