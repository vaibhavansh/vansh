<html>
 <head>
   <title>Simple Login with CodeIgniter - Private Area</title>
 </head>
 <body>
   <h1>Home</h1>
   <h2>Welcome <?php echo $username; ?>!</h2>

<?php echo $error;?>

<form id="upload_form" method="POST" enctype="multipart/form-data">

<input type="file" name="userfile[]" size="20" id="userfile" />

<br /><br />

<input type="submit" value="upload" id="upload" />

</form>
   <a href="home/logout">Logout</a>

   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
var $ = jQuery;
$(document).ready(function(){
  $("#upload_form").on('submit',function(e){
    e.preventDefault();
     if($('#userfile').val() == ''){
     	alert('please select a file');
     }else{
     	$.ajax({
     		url:"<?php echo base_url();?>/home/do_upload",
     		method:"POST",
     		data: new FormData(this),
     		contentType:false,
     		cache:false,
     		processData:false,
     		success:function(data){
     			alert(data);
     		}

     	});
     }
  });
});
</script>
 </body>
</html>