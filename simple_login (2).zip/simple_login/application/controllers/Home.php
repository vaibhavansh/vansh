<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home extends CI_Controller {
 function __construct()
 {
   parent::__construct();
    $this->load->helper(array('form', 'url'));
 }
 function index()
 {
   if($this->session->userdata('logged_in'))
   {
     $session_data = $this->session->userdata('logged_in');
     $data['username'] = $session_data['username'];
     $data['error'] = '';
    
     $this->load->view('home_view', $data);
   }
   else
   {
     redirect('login', 'refresh');
   }
 }
 function logout()
 {
   $this->session->unset_userdata('logged_in');
   session_destroy();
   redirect('home', 'refresh');
 }


    public function do_upload() {
        if($this->session->userdata('logged_in')) {
           $session_data = $this->session->userdata('logged_in');
           $data['username'] = $session_data['username'];
           $data['error'] = '';      
        }      

        echo  "<Pre>";
        print_r($_FILES);
        echo  "</pre>";   


        $config['upload_path']          = './uploads/';
        $config['allowed_types']        = 'gif|jpg|png';
        $config['max_size']             = 100000;
        $config['max_width']            = 100000;
        $config['max_height']           = 1000000;

        $this->load->library('upload', $config);

        if ( ! $this->upload->do_upload('userfile'))
        {
            $this->load->view('home_view', $data);
        }
        else
        {
            $data['upload_data'] = $this->upload->data();
            $this->load->view('upload_success', $data);
        }
    }
}
?>
