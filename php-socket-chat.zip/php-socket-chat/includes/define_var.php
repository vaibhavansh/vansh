<?php
define("HOST","localhost");
define("PORT","9000");
define("DB_HOST","localhost");
define("DB_USER","root");
define("DB_PASS","smartsdn");
define("DB_NAME","chat_aa");

$null = NULL;
?>