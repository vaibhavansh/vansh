# php-socket-chat

Fully functioned One-2-One PHP socket based chat system.


#requirements
php 5.5 or greater
Mysql 5.0 or greater
VPS server or multiport server.

# Installation
download the source and extract in your working directory.

import the "chat_aa.sql" file in your database.

Change your mysql access and port configuration in "includes/define_var.php".

run the "server.php" file using shell by command:-

php -f /YOUR-WORKING-DIRECTORY/server.php

open your chat url on your browser by "http://YOUR-DOMAIN.com/YOUR-WORKIN-DIRECTORY/index.php"

use following credentials for login on multiple browser window:-

1) User name -: admin AND Password -: admin             
    
2) User name -: user AND Password -: user

3) User name -: test AND Password -: test 
    
Enjoy the chat.

#dependencies
Need to open extra port on the server for chat, which need to assign in configuration.


