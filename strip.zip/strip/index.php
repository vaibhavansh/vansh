<?php require_once('config.php'); ?>

<form action="charge.php" method="post">
  <script src="https://checkout.stripe.com/checkout.js" class="stripe-button"
          data-key="<?php echo $stripe['publishable_key']; ?>"
          data-description="Access for a year"
          data-amount="5000"
          data-locale="auto"></script>
</form> 
<?php



// $ch = \Stripe\Charge::retrieve("ch_1FMqjfIyJazFTn3apc3n24KG", ['api_key' => "sk_test_UfEVIV0FuwotmppATyC3iwP900Iy0I9y2O"]
// );
// // Uses the same API Key.
// echo  "<pre>";



// $customerList = \Stripe\Customer::all(["limit" => 3]);
//  echo  "<pre>";
// print_r($customerList);


  // $token  = $_POST['stripeToken'];
  // $email  = $_POST['stripeEmail'];

  // $customer = \Stripe\Customer::create([
  //     'email' => $email,
  //     'source'  => $token,
  // ]);

  // $charge = \Stripe\Charge::create([
  //     'customer' => $customer->id,
  //     'amount'   => 5000,
  //     'currency' => 'usd',
  // ]);

function payment(){	

	$charge = \Stripe\Transfer::create([
	  "amount" => 1,
	  "currency" => "usd",
	  "destination" => "acct_1FOk4qKBR385HT5w",
	  "transfer_group" => "ORDER_95"
	]);

	return $charge;
}
// $result = payment();

// echo  "<pre>";
// print_r($result);
// echo "</pre>";

?>

