<?php
require_once('vendor/autoload.php');

$stripe = [
    "secret_key" => "sk_test_UfEVIV0FuwotmppATyC3iwP900Iy0I9y2O",
    "publishable_key" => "pk_test_2eznvkyUpCSvZwDHTEdOorBj00izoppiw5",
];

\Stripe\Stripe::setApiKey($stripe['secret_key']);
?>
