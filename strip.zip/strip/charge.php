<?php
  require_once('config.php');

  $token  = $_POST['stripeToken'];
  $email  = $_POST['stripeEmail'];

  $customer = \Stripe\Customer::create([
      'email' => $email,
      'source'  => $token,
  ]);

  $charge = \Stripe\Charge::create([
      'customer' => $customer->id,
      'amount'   => 60000,
      'currency' => 'usd',
  ]);

  echo "<pre>";
  print_r($customer);




// // Create a PaymentIntent:
// $paymentIntent = \Stripe\PaymentIntent::create([
//   "amount" => 2,
//   "currency" => "usd",
//   "payment_method_types" => ["card"],
//   "transfer_group" => "{ORDER10}",
// ]);

// // Create a Transfer to a connected account (later):
// $transfer = \Stripe\Transfer::create([
//   "amount" => 1,
//   "currency" => "usd",
//   "destination" => "{{CONNECTED_STRIPE_ACCOUNT_ID}}",

// ]);

// $transfer = \Stripe\Transfer::create([
//   "amount" => 0.01,
//   "currency" => "usd",
//   "destination" => "acct_1FMx83G6M5VNxvVL",

// ]);

// echo  "<pre>";
// print_r($transfer);
// echo  "</pre>";
// die;
echo '<h1>Successfully charged $50.00!</h1>';
?>
