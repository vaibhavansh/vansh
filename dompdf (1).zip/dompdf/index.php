<?php
require 'vendor/autoload.php';
use Dompdf\Dompdf;
Class PDF{
	function index(){
		$dompdf = new Dompdf();
		$dompdf->loadHtml('hello dsfdsdsfdsfsdfdsfworld');
		$dompdf->setPaper('A4', 'landscape');
		$dompdf->render();
		$dompdf->stream();
	}
}

$test = new PDF;
$test->index();



